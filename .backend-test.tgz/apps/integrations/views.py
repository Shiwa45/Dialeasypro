"""
TeleCRM Backend — apps/integrations/views.py

Inbound webhook handlers for all Indian lead sources.

IndiaMART Webhook      POST /api/v1/integrations/indiamart/
Meta Lead Ads Webhook  POST /api/v1/integrations/meta/
Meta Click-to-WhatsApp GET/POST /api/v1/integrations/meta/whatsapp/
Google Ads Webhook     POST /api/v1/integrations/google/
Generic Webhook        POST /api/v1/integrations/webhook/{token}/
Portal Webhook         POST /api/v1/integrations/portal/{slug}/
IntegrationConfigView  GET/POST/PATCH /api/v1/integrations/configs/
"""
import hashlib
import hmac
import json
import logging

from django.db import connection
from django.http import HttpResponse, JsonResponse
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.authentication.permissions import (
    IsAuthenticatedAgent,
    IsTenantAdmin,
    require_feature,
)
from apps.core.constants import LeadPriority, LeadSource
from apps.core.exceptions import PlanLimitExceededException
from apps.core.quotas import enforce_lead_quota, note_leads_created
from apps.core.utils import normalize_indian_phone
from apps.integrations.models import LeadSourceConfig, WebhookLog
from apps.integrations.serializers import LeadSourceConfigSerializer

logger = logging.getLogger(__name__)


# ============================================================
# Base Webhook View
# ============================================================

UNAUTHENTICATED_MESSAGE = (
    "Unauthenticated delivery refused. Copy the webhook URL again from "
    "Integrations — it now carries this integration's token — or set the "
    "provider's signing secret."
)


class BaseWebhookView(View):
    """
    Base class for all lead source webhook handlers.
    Subclasses implement parse_payload() and signature_valid() / provider_key_valid().
    """

    source = None   # Override in subclass: LeadSource.INDIAMART etc.

    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    def post(self, request, *args, **kwargs):
        config = self._get_config()
        if config and not config.is_active:
            # Recorded, not merely refused: "we turned IndiaMART off and leads
            # kept arriving" and "we turned it off and cannot see that anything
            # was sent" are both answered by a row in the webhook log.
            WebhookLog.objects.create(
                source=self.source or "webhook",
                config=config,
                method="POST",
                headers=dict(request.headers),
                payload={"raw": request.body.decode("utf-8", errors="replace")[:5000]},
                error="Integration is switched off — delivery rejected.",
            )
            logger.info(
                "[Integration] Delivery rejected, %s is switched off | schema=%s",
                self.source, connection.schema_name,
            )
            return HttpResponse("Integration disabled", status=403)

        # Log raw payload immediately (before any processing)
        raw_body = request.body
        try:
            payload = json.loads(raw_body)
        except json.JSONDecodeError:
            payload = {"raw": raw_body.decode("utf-8", errors="replace")[:5000]}

        log = WebhookLog.objects.create(
            source=self.source or "webhook",
            config=config,
            method="POST",
            headers=dict(request.headers),
            payload=payload,
        )

        # Every delivery must prove where it came from. This used to check a
        # signature only when a secret happened to be configured, so with no
        # secret — or no integration set up at all — anyone who knew the
        # (predictable) URL could create leads and burn the lead quota.
        if not self.is_authentic(request, raw_body, config, payload):
            log.error = UNAUTHENTICATED_MESSAGE
            log.save(update_fields=["error"])
            if config:
                config.error_message = UNAUTHENTICATED_MESSAGE
                config.save(update_fields=["error_message"])
            logger.warning(f"[Integration] Unauthenticated delivery refused — source={self.source}")
            return HttpResponse("Unauthenticated webhook", status=401)

        # Parse and create leads
        try:
            leads_created, leads_updated = self.process_payload(payload, config, request)
            log.processed = True
            log.leads_created = leads_created
            log.leads_updated = leads_updated
            log.save(update_fields=["processed", "leads_created", "leads_updated"])

            if config:
                config.total_leads_received += leads_created
                config.last_received_at = timezone.now()
                config.error_message = ""
                config.save(update_fields=["total_leads_received", "last_received_at", "error_message"])

        except PlanLimitExceededException as exc:
            # The tenant is over their plan's lead cap. Surface it distinctly so
            # the Integrations UI shows an upgrade prompt rather than a generic
            # failure — and still answer 200 so the provider doesn't retry
            # forever against a limit that only an upgrade can lift.
            msg = str(exc.detail)
            logger.warning(f"[Integration] Lead quota reached — source={self.source}: {msg}")
            log.error = msg[:500]
            log.save(update_fields=["error"])
            if config:
                config.error_message = msg[:500]
                config.status = "error"
                config.save(update_fields=["error_message", "status"])
            return JsonResponse({"status": "quota_exceeded", "message": msg}, status=200)

        except Exception as exc:
            logger.error(f"[Integration] Processing failed — source={self.source}: {exc}", exc_info=True)
            log.error = str(exc)[:500]
            log.save(update_fields=["error"])
            if config:
                config.error_message = str(exc)[:500]
                config.status = "error"
                config.save(update_fields=["error_message", "status"])

        return JsonResponse({"status": "ok"})

    def is_authentic(self, request, raw_body: bytes, config, payload) -> bool:
        """
        True when the delivery proves it is for this tenant's integration:
        a valid provider signature, the config's webhook token (in the URL as
        ?token= or an X-Webhook-Token header), or a provider key in the body.
        No config means nothing to prove it against — refused.
        """
        if config is None:
            return False
        return (
            self.signature_valid(request, raw_body, config)
            or self.token_valid(request, config)
            or self.provider_key_valid(payload, config)
        )

    @staticmethod
    def token_valid(request, config) -> bool:
        sent = request.GET.get("token") or request.headers.get("X-Webhook-Token") or ""
        return bool(sent and config.webhook_token) and hmac.compare_digest(sent, config.webhook_token)

    def signature_valid(self, request, raw_body: bytes, config) -> bool:
        """Provider signature, verified against a configured secret. Override."""
        return False

    def provider_key_valid(self, payload, config) -> bool:
        """A shared key the provider puts in the body. Override."""
        return False

    def process_payload(self, payload: dict, config, request) -> tuple:
        """Override to implement provider-specific lead creation."""
        raise NotImplementedError

    def _get_config(self):
        """
        This source's config, switched on or off.

        Deliberately NOT filtered to is_active: filtering here made a disabled
        integration look like an unconfigured one, so `if config and not
        config.is_active` could never fire and switching an integration off in
        the CRM did nothing at all — deliveries kept creating leads, minus the
        field mapping and assignment rules the config carries.

        .first() (not .get()) — a duplicate config for the same source would
        raise MultipleObjectsReturned and 500 every webhook delivery. Active
        first, so an active config still wins if a duplicate ever exists.
        """
        return (
            LeadSourceConfig.objects.filter(source=self.source)
            .order_by("-is_active", "id")
            .first()
        )

    def _create_or_update_lead(self, lead_data: dict, config, duplicate_action: str = "skip"):
        """
        Core lead creation logic — shared by all webhook handlers.
        Returns (created: bool, lead).
        """
        from apps.leads.models import Lead, LeadActivity
        from apps.authentication.models import Agent

        phone = normalize_indian_phone(lead_data.get("phone", ""))
        if not phone:
            raise ValueError(f"Invalid phone: {lead_data.get('phone')}")

        existing = Lead.objects.filter(phone=phone, is_deleted=False).first()

        # Determine assigned agent
        assigned_to = None
        if config and config.options.get("auto_assign_to"):
            assigned_to = Agent.objects.filter(
                pk=config.options["auto_assign_to"], is_active=True
            ).first()

        if existing:
            if duplicate_action == "skip":
                return False, existing
            elif duplicate_action == "update":
                # Only fill in real, currently-empty Lead model fields.
                UPDATABLE = {
                    "name", "email", "city", "state", "pincode",
                    "alternate_phone", "requirement", "campaign_name", "ad_name",
                }
                changed = {}
                for field, value in lead_data.items():
                    if field not in UPDATABLE:
                        continue
                    if value and not getattr(existing, field, ""):
                        setattr(existing, field, value)
                        changed[field] = value
                if changed:
                    existing.save(update_fields=list(changed.keys()))
                # Fill custom values even on dedupe-update.
                self._save_custom_values(existing, lead_data.get("custom_values"))
                return False, existing

        # Plan capacity. A new lead (not a dedupe-update) counts against the
        # tenant's max_leads / max_leads_per_day caps.
        enforce_lead_quota(1)

        # Today's batch for this source, opened on first arrival and reused
        # for the rest of the day. Webhook leads trickle in one at a time, so
        # a batch per lead would be meaningless — a day is the unit people
        # already think in when they look at a source's output.
        from apps.leads.models import LeadBatch

        batch = LeadBatch.open_for_source(self.source or LeadSource.WEBHOOK)

        lead = Lead.objects.create(
            batch=batch,
            phone=phone,
            name=lead_data.get("name", "Unknown"),
            email=lead_data.get("email", ""),
            city=lead_data.get("city", ""),
            state=lead_data.get("state", ""),
            pincode=lead_data.get("pincode", ""),
            alternate_phone=normalize_indian_phone(lead_data.get("alternate_phone", "")) or "",
            requirement=lead_data.get("requirement", ""),
            source=self.source or LeadSource.WEBHOOK,
            source_meta=lead_data.get("meta", {}),
            source_lead_id=str(lead_data.get("source_lead_id", "")),
            campaign_name=lead_data.get("campaign_name", "")[:300],
            ad_name=lead_data.get("ad_name", "")[:300],
            priority=lead_data.get("priority", LeadPriority.WARM),
            assigned_to=assigned_to,
        )
        note_leads_created(1)
        if batch is not None:
            batch.note_leads_added(1)

        # Persist any mapped custom-field values.
        self._save_custom_values(lead, lead_data.get("custom_values"))

        LeadActivity.objects.create(
            lead=lead, activity_type="imported",
            description=f"Lead received via {dict(LeadSource.CHOICES).get(self.source, self.source) or 'webhook'}",
            meta={"source": self.source},
        )
        logger.info(f"[Integration] Lead created: {lead.name} ({lead.phone}) via {self.source}")
        return True, lead

    @staticmethod
    def _save_custom_values(lead, custom_values: dict | None):
        """Write mapped custom-field values, ignoring keys with no matching field."""
        if not custom_values:
            return
        from apps.leads.models import CustomField, CustomFieldValue
        for field_key, value in custom_values.items():
            field = CustomField.objects.filter(field_key=field_key, is_active=True).first()
            if field:
                CustomFieldValue.objects.update_or_create(
                    lead=lead, field=field, defaults={"value": str(value)},
                )


# ============================================================
# IndiaMART Webhook
# ============================================================

class IndiaMArtWebhookView(BaseWebhookView):
    """
    POST /api/v1/integrations/indiamart/
    Receives buyer enquiries from IndiaMART via their Lead Manager API.
    Docs: https://seller.indiamart.com/leadmanager/leadsapi

    IndiaMART sends leads as JSON array or single object.
    HMAC-SHA256 signature in X-IM-SIGNATURE header.
    """

    source = LeadSource.INDIAMART

    def signature_valid(self, request, raw_body: bytes, config) -> bool:
        secret = config.credentials.get("webhook_secret", "")
        if not secret:
            return False
        signature = request.headers.get("X-Im-Signature", "")
        expected = hmac.new(secret.encode(), raw_body, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature)

    def process_payload(self, payload: dict, config, request) -> tuple:
        # IndiaMART wraps leads in different structures depending on API version
        leads_data = []
        if isinstance(payload, list):
            leads_data = payload
        elif "RESPONSE" in payload:
            leads_data = payload["RESPONSE"] if isinstance(payload["RESPONSE"], list) else [payload["RESPONSE"]]
        elif "leads" in payload:
            leads_data = payload["leads"]
        else:
            leads_data = [payload]

        from apps.integrations.field_mapping import apply_field_mapping

        duplicate_action = (config.options.get("duplicate_action", "skip") if config else "skip")
        mapping = (config.options or {}).get("field_mapping", {}) if config else {}
        created, updated = 0, 0

        for raw_lead in leads_data:
            try:
                lead_data, custom_values = apply_field_mapping(raw_lead, mapping)
                lead_data["custom_values"] = custom_values
                lead_data["source_lead_id"] = (
                    raw_lead.get("UNIQUE_QUERY_ID") or raw_lead.get("id", "")
                )
                is_created, _ = self._create_or_update_lead(lead_data, config, duplicate_action)
                if is_created:
                    created += 1
                else:
                    updated += 1
            except Exception as exc:
                logger.warning(f"[IndiaMART] Failed to process lead: {exc}")

        return created, updated


# ============================================================
# Meta (Facebook/Instagram) Lead Ads Webhook
# ============================================================

class MetaLeadAdsWebhookView(BaseWebhookView):
    """
    GET  /api/v1/integrations/meta/  → Webhook verification (Meta requires GET)
    POST /api/v1/integrations/meta/  → Lead form submission event

    Meta sends a GET request first to verify the webhook endpoint.
    Then sends POST with lead form data in real time.
    Lead form values must be fetched via Meta Graph API (not included in webhook payload).
    """

    source = LeadSource.META_FACEBOOK

    def get(self, request, *args, **kwargs):
        """Handle Meta's webhook verification challenge."""
        mode = request.GET.get("hub.mode")
        token = request.GET.get("hub.verify_token") or ""
        challenge = request.GET.get("hub.challenge")

        config = self._get_config()
        verify_token = config.credentials.get("verify_token", "") if config else ""

        # A token must be configured: with none set, an empty hub.verify_token
        # used to equal the empty expected value and pass. Constant-time, like
        # the WhatsApp handshake below.
        if mode == "subscribe" and verify_token and hmac.compare_digest(token, verify_token):
            logger.info("[Meta] Webhook verified")
            return HttpResponse(challenge, content_type="text/plain")

        return HttpResponse("Forbidden", status=403)

    def signature_valid(self, request, raw_body: bytes, config) -> bool:
        """Validate X-Hub-Signature-256 from Meta."""
        app_secret = config.credentials.get("app_secret", "")
        if not app_secret:
            return False
        signature = request.headers.get("X-Hub-Signature-256", "")
        if not signature.startswith("sha256="):
            return False
        expected = f"sha256={hmac.new(app_secret.encode(), raw_body, hashlib.sha256).hexdigest()}"
        return hmac.compare_digest(expected, signature)

    def process_payload(self, payload: dict, config, request) -> tuple:
        """
        Meta sends leadgen events. We extract lead ID and fetch details via Graph API.
        For now, log and return — full Graph API fetch is implemented below.
        """
        created, updated = 0, 0

        entries = payload.get("entry", [])
        for entry in entries:
            for change in entry.get("changes", []):
                if change.get("field") != "leadgen":
                    continue
                value = change.get("value", {})
                lead_id = value.get("leadgen_id")
                form_id = value.get("form_id")
                page_id = value.get("page_id")

                if lead_id and config:
                    # Fetch lead details from Meta Graph API
                    lead_data = self._fetch_meta_lead(lead_id, config)
                    if lead_data:
                        is_created, _ = self._create_or_update_lead(
                            lead_data, config,
                            duplicate_action=config.options.get("duplicate_action", "skip"),
                        )
                        if is_created:
                            created += 1

        return created, updated

    def _fetch_meta_lead(self, lead_id: str, config) -> dict | None:
        """
        Fetch lead form details from Meta Graph API and map them to CRM fields
        using the tenant's configured field mapping.
        """
        try:
            import requests as req
            from apps.integrations.field_mapping import (
                flatten_meta_field_data, apply_field_mapping,
            )

            access_token = config.credentials.get("access_token", "")
            if not access_token:
                return None

            # Request campaign/ad attribution alongside the form field data.
            resp = req.get(
                f"https://graph.facebook.com/v25.0/{lead_id}",
                params={
                    "access_token": access_token,
                    "fields": (
                        "field_data,created_time,ad_id,ad_name,adset_id,"
                        "adset_name,campaign_id,campaign_name,form_id,platform"
                    ),
                },
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()

            raw_fields = flatten_meta_field_data(data.get("field_data", []))
            mapping = (config.options or {}).get("field_mapping", {})
            lead_data, custom_values = apply_field_mapping(raw_fields, mapping)

            lead_data["source_lead_id"] = lead_id
            lead_data["custom_values"] = custom_values
            # Campaign attribution (explicit mapping can still override).
            lead_data.setdefault("campaign_name", data.get("campaign_name", ""))
            lead_data.setdefault("ad_name", data.get("ad_name") or data.get("adset_name", ""))
            # Keep full attribution in raw meta for reporting/debugging.
            lead_data["meta"].update({
                "campaign_id": data.get("campaign_id", ""),
                "campaign_name": data.get("campaign_name", ""),
                "adset_name": data.get("adset_name", ""),
                "ad_id": data.get("ad_id", ""),
                "ad_name": data.get("ad_name", ""),
                "form_id": data.get("form_id", ""),
                "platform": data.get("platform", ""),
            })
            return lead_data
        except Exception as exc:
            logger.error(f"[Meta] Failed to fetch lead {lead_id}: {exc}")
            return None


# ============================================================
# Google Ads Lead Forms Webhook
# ============================================================

class GoogleAdsWebhookView(BaseWebhookView):
    """
    POST /api/v1/integrations/google/
    Receives lead form submissions from Google Ads Lead Form extensions.
    Uses Zapier or direct webhook integration.
    """

    source = LeadSource.GOOGLE_ADS

    def provider_key_valid(self, payload, config) -> bool:
        """Google Ads lead forms send the webhook key you set as `google_key`."""
        expected = config.credentials.get("google_key", "")
        sent = payload.get("google_key", "") if isinstance(payload, dict) else ""
        return bool(expected and sent) and hmac.compare_digest(str(sent), expected)

    def process_payload(self, payload: dict, config, request) -> tuple:
        from apps.integrations.field_mapping import apply_field_mapping

        mapping = (config.options or {}).get("field_mapping", {}) if config else {}
        lead_data, custom_values = apply_field_mapping(payload, mapping)
        lead_data["custom_values"] = custom_values
        lead_data["source_lead_id"] = payload.get("lead_id", "")
        # Google Lead Form extensions include campaign attribution.
        lead_data.setdefault("campaign_name", payload.get("campaign_name", "") or payload.get("campaign", ""))
        lead_data.setdefault("ad_name", payload.get("adgroup_name", "") or payload.get("ad_name", ""))
        is_created, _ = self._create_or_update_lead(
            lead_data, config,
            duplicate_action=config.options.get("duplicate_action", "skip") if config else "skip",
        )
        return (1, 0) if is_created else (0, 1)


# ============================================================
# Generic Webhook (token-based)
# ============================================================

class GenericWebhookView(BaseWebhookView):
    """
    POST /api/v1/integrations/webhook/{token}/
    A universal webhook URL that any external system can POST to.
    Token is unique per tenant and per integration source.

    Payload format (flexible — tries to extract common fields):
    {
      "name": "Rahul Sharma",
      "phone": "9876543210",
      "email": "rahul@example.com",
      "city": "Mumbai",
      "message": "Looking for 2BHK in Andheri"
    }
    """

    source = LeadSource.WEBHOOK

    def post(self, request, token, *args, **kwargs):
        # Find config by token (overrides base class which uses source)
        config = LeadSourceConfig.objects.filter(webhook_token=token).first() if token else None
        if config is None or not hmac.compare_digest(token, config.webhook_token):
            return HttpResponse("Invalid webhook token", status=401)
        self.source = config.source
        self._config = config

        return super().post(request, token=token, *args, **kwargs)

    def _get_config(self):
        # The config found by its token. This returned None, so the base
        # class processed every generic delivery with no config at all — its
        # field mapping, duplicate rule and assignment were all ignored, and a
        # switched-off integration kept accepting leads.
        return self._config

    def is_authentic(self, request, raw_body, config, payload) -> bool:
        return True  # the token in the path already proved it

    def process_payload(self, payload: dict, config, request) -> tuple:
        from apps.integrations.field_mapping import apply_field_mapping

        mapping = (config.options or {}).get("field_mapping", {}) if config else {}
        lead_data, custom_values = apply_field_mapping(payload, mapping)
        lead_data["custom_values"] = custom_values
        lead_data["source_lead_id"] = payload.get("id") or payload.get("lead_id", "")
        lead_data.setdefault("campaign_name", payload.get("campaign_name", "") or payload.get("utm_campaign", ""))
        duplicate_action = config.options.get("duplicate_action", "skip") if config else "skip"
        is_created, _ = self._create_or_update_lead(lead_data, config, duplicate_action)
        return (1, 0) if is_created else (0, 1)


# ============================================================
# Integration Config API
# ============================================================

def check_may_activate(request, source, *, exclude_pk=None, enforce_cap=True):
    """
    May this tenant have `source` switched on right now?

    The FEATURE gate applies wherever an integration starts running, creation
    or switch-on alike. A downgrade leaves the config row behind, and without
    this, switching it back on quietly resumes a source the tenant no longer
    pays for.

    The COUNT cap (`enforce_cap`) applies on creation only. Applying it to a
    switch-on strands anyone whose active integrations already outnumber their
    plan's cap — which is not hypothetical: a plan's limit can be lowered after
    the fact, and a tenant in that state who switched one off to look at
    something could not put it back. Nothing new is added to the account by
    restoring a config the tenant already has, and the cap still governs
    adding one.

    Raises what the create path raises: 402 for a source the plan does not
    include, 402 for one integration too many.
    """
    if feature_key := LeadSource.FEATURE_MAP.get(source):
        require_feature(request, feature_key)

    if not enforce_cap:
        return

    plan = getattr(request, "tenant_plan", None)
    if plan and plan.lead_sources_limit:
        active = LeadSourceConfig.objects.filter(is_active=True)
        if exclude_pk is not None:
            active = active.exclude(pk=exclude_pk)
        count = active.count()
        if count >= plan.lead_sources_limit:
            raise PlanLimitExceededException(
                limit_type="lead source integrations",
                current=count,
                max_allowed=plan.lead_sources_limit,
            )


class IntegrationConfigListView(generics.ListCreateAPIView):
    """
    GET  /api/v1/integrations/configs/  → List all configured integrations
    POST /api/v1/integrations/configs/  → Enable/configure a new integration

    Each lead source maps to its own plan feature (LeadSource.FEATURE_MAP), and
    the plan also caps how many integrations may be active at once
    (Plan.lead_sources_limit).
    """

    permission_classes = [IsTenantAdmin]
    serializer_class = LeadSourceConfigSerializer
    pagination_class = None  # Small finite list; return plain array

    def get_queryset(self):
        return LeadSourceConfig.objects.order_by("source")

    def perform_create(self, serializer):
        source = serializer.validated_data.get("source")
        check_may_activate(self.request, source)
        serializer.save()


class IntegrationConfigDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET/PATCH/DELETE /api/v1/integrations/configs/{id}/

    Switch an integration on or off, change its options, or remove it.
    Switching off is the reversible one: the credentials, field mapping and
    webhook token are kept, and inbound deliveries are refused until it is
    switched back on.
    """

    permission_classes = [IsTenantAdmin]
    serializer_class = LeadSourceConfigSerializer

    def get_queryset(self):
        return LeadSourceConfig.objects.all()

    def perform_update(self, serializer):
        config = self.get_object()
        turning_on = serializer.validated_data.get("is_active") and not config.is_active
        if turning_on:
            # Feature gate only: restoring a config the tenant already owns is
            # not the same as adding one. See check_may_activate.
            check_may_activate(
                self.request, config.source, exclude_pk=config.pk, enforce_cap=False,
            )
        serializer.save()


class MetaFormFieldsView(APIView):
    """
    GET /api/v1/integrations/meta/forms/
    Introspect the tenant's Meta Lead Ad forms + their question field names,
    so the UI can offer the REAL field names to map (no guessing).

    Requires the Meta config to have access_token and a page_id saved.
    """

    permission_classes = [IsTenantAdmin]

    def get(self, request):
        configs = LeadSourceConfig.objects.filter(
            source__in=[LeadSource.META_FACEBOOK, LeadSource.META_INSTAGRAM]
        )
        # The integrations page can contain more than one Meta configuration.
        # Use the card the administrator is currently editing instead of an
        # arbitrary `.first()` record, which may hold an old User token.
        config_id = request.query_params.get("config_id")
        config = configs.filter(pk=config_id).first() if config_id else configs.order_by("id").first()
        if not config:
            return Response(
                {
                    "error": "no_config",
                    "message": "The selected Meta integration was not found. Reopen its configuration and try again.",
                },
                status=404,
            )

        access_token = (config.credentials or {}).get("access_token", "")
        page_id = (config.credentials or {}).get("page_id") or (config.options or {}).get("page_id")
        if not access_token or not page_id:
            return Response(
                {
                    "error": "missing_credentials",
                    "message": "Save your Page Access Token and Page ID first to auto-fetch form fields.",
                },
                status=400,
            )

        try:
            import requests as req

            # Try primary page_id first
            resp = req.get(
                f"https://graph.facebook.com/v25.0/{page_id}/leadgen_forms",
                params={"access_token": access_token, "fields": "id,name,status,questions"},
                timeout=15,
            )

            # If primary call succeeded:
            if resp.status_code == 200:
                forms = []
                for form in resp.json().get("data", []):
                    questions = [
                        {"key": q.get("key") or q.get("id"), "label": q.get("label", "")}
                        for q in form.get("questions", [])
                    ]
                    forms.append({
                        "id": form.get("id"),
                        "name": form.get("name"),
                        "status": form.get("status"),
                        "fields": questions,
                    })
                return Response({"forms": forms})

            # A 190 here means the saved token is a User token.  Convert it to
            # the Page token for *this configured Page* before trying the edge
            # again.  Do not scan/save a different managed Page.
            logger.info("[Meta] Primary request failed; resolving a Page token through /me/accounts.")
            accounts_resp = req.get(
                "https://graph.facebook.com/v25.0/me/accounts",
                params={"access_token": access_token, "fields": "id,name,access_token"},
                timeout=15,
            )

            def meta_error(response):
                """Return Meta's safe error message without ever logging a token."""
                try:
                    return (response.json().get("error", {}).get("message") or response.text)[:300]
                except (ValueError, TypeError):
                    return response.text[:300]

            if accounts_resp.status_code != 200:
                detail = meta_error(accounts_resp)
                logger.warning("[Meta] /me/accounts failed (%s): %s", accounts_resp.status_code, detail)
                return Response(
                    {
                        "error": "page_token_resolution_failed",
                        "message": (
                            f"Meta could not list Pages for this User Token ({accounts_resp.status_code}): {detail}. "
                            "Generate a User Token for this app with pages_show_list, pages_read_engagement, "
                            "and leads_retrieval, then save it again."
                        ),
                    },
                    status=400,
                )

            pages = accounts_resp.json().get("data", [])
            page = next((item for item in pages if str(item.get("id")) == str(page_id)), None)
            page_token = page.get("access_token") if page else None

            # A System User token (created in Meta Business Settings) is not a
            # human User token, so /me/accounts legitimately returns no Pages.
            # It can nevertheless obtain the token for an asset assigned to the
            # System User through the Page's access_token field.
            if not page_token:
                page_token_resp = req.get(
                    f"https://graph.facebook.com/v25.0/{page_id}",
                    params={"access_token": access_token, "fields": "id,name,access_token"},
                    timeout=15,
                )
                if page_token_resp.status_code == 200:
                    page_token = page_token_resp.json().get("access_token")

            if not page_token:
                detail = meta_error(page_token_resp) if 'page_token_resp' in locals() else ""
                logger.warning(
                    "[Meta] Could not resolve a Page token for Page %s; /me/accounts returned %d Page(s). %s",
                    page_id,
                    len(pages),
                    detail,
                )
                return Response(
                    {
                        "error": "page_token_not_returned",
                        "message": (
                            "Meta could not obtain a Page Access Token for this Page. "
                            "Assign the Easyian Page and Dialeasypro app to the Meta Business System User, "
                            "then generate a System User token with leads_retrieval and save it here."
                            + (f" Meta says: {detail}" if detail else "")
                        ),
                    },
                    status=400,
                )

            page_forms_resp = req.get(
                f"https://graph.facebook.com/v25.0/{page_id}/leadgen_forms",
                params={"access_token": page_token, "fields": "id,name,status,questions"},
                timeout=15,
            )
            if page_forms_resp.status_code != 200:
                detail = meta_error(page_forms_resp)
                logger.warning("[Meta] Page token request for Page %s failed (%s): %s", page_id, page_forms_resp.status_code, detail)
                return Response(
                    {
                        "error": "page_token_rejected",
                        "message": f"Meta rejected the Page token ({page_forms_resp.status_code}): {detail}",
                    },
                    status=400,
                )

            # Persist the Page token even when there are no lead forms.  The
            # previous implementation only saved it when at least one form was
            # returned, leaving the User Token in place and repeating error 190.
            credentials = dict(config.credentials or {})
            credentials["page_id"] = str(page_id)
            credentials["access_token"] = page_token
            config.credentials = credentials
            config.save(update_fields=["credentials"])

            forms = []
            for form in page_forms_resp.json().get("data", []):
                questions = [
                    {"key": q.get("key") or q.get("id"), "label": q.get("label", "")}
                    for q in form.get("questions", [])
                ]
                forms.append({
                    "id": form.get("id"),
                    "name": form.get("name"),
                    "status": form.get("status"),
                    "fields": questions,
                })
            return Response({"forms": forms})
        except Exception as exc:
            logger.warning(f"[Meta] Form introspection failed: {exc}", exc_info=True)
            return Response(
                {"error": "fetch_failed", "message": f"Could not fetch forms from Meta: {exc}"},
                status=400,
            )


class MetaSyncLeadsView(APIView):
    """
    POST /api/v1/integrations/meta/sync/
    Manually pull the newest Meta Lead Ads leads into the CRM — a fallback for
    when the realtime webhook hasn't delivered (or missed) leads.
    """

    permission_classes = [IsTenantAdmin]

    def post(self, request):
        config = LeadSourceConfig.objects.filter(
            source__in=[LeadSource.META_FACEBOOK, LeadSource.META_INSTAGRAM]
        ).first()
        if not config:
            return Response(
                {"error": "no_config", "message": "Add the Meta integration first."},
                status=404,
            )

        from apps.integrations.meta_sync import sync_meta_leads

        result = sync_meta_leads(config)
        if result.get("error") == "missing_credentials":
            return Response(
                {"error": "missing_credentials",
                 "message": "Save your Page Access Token and Page ID first."},
                status=400,
            )
        if result.get("error"):
            return Response(
                {"error": "fetch_failed",
                 "message": "Could not fetch leads from Meta. Check the token/Page ID."},
                status=502,
            )

        msg = f"{result['created']} new lead(s) imported"
        if result["skipped"]:
            msg += f", {result['skipped']} already in CRM"
        if result.get("quota_reached"):
            msg += ". Stopped early — your plan's lead limit was reached. Upgrade to import the rest."
        return Response({**result, "message": msg})


class WebhookLogListView(generics.ListAPIView):
    """GET /api/v1/integrations/logs/ — Integration webhook log for debugging."""

    permission_classes = [IsTenantAdmin]
    pagination_class = None  # Already capped at 200 rows; return plain array
    from apps.integrations.serializers import WebhookLogSerializer as _LogSer

    def get_serializer_class(self):
        from apps.integrations.serializers import WebhookLogSerializer
        return WebhookLogSerializer

    def get_queryset(self):
        qs = WebhookLog.objects.order_by("-created_at")
        if source := self.request.query_params.get("source"):
            qs = qs.filter(source=source)
        return qs[:200]


# ============================================================
# Meta Click-to-WhatsApp Webhook (WhatsApp Business Platform)
# ============================================================

class MetaWhatsAppWebhookView(View):
    """
    GET  /api/v1/integrations/meta/whatsapp/  → Meta webhook verification
    POST /api/v1/integrations/meta/whatsapp/  → inbound messages + statuses

    Click-to-WhatsApp ads, NOT Lead Ads. The customer taps WhatsApp on an ad
    and sends a message; there is no Lead Form anywhere in the flow, and the ad
    attribution rides along on the message itself as `referral`.
    MetaLeadAdsWebhookView above handles the entirely separate `leadgen` event.

    This deliberately does not extend BaseWebhookView: that base is built
    around LeadSourceConfig and a lead-per-payload shape, while a WhatsApp
    delivery is a batch of messages and receipts configured on the tenant's
    WhatsAppConfig. It reuses WebhookLog, which is the part worth sharing.

    The handler validates and returns; the CRM work runs on the integrations
    queue, because Meta retries anything it considers slow.
    """

    source = LeadSource.META_CTWA

    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    # ---- Verification (Meta calls this once, on subscribe) ----
    def get(self, request, *args, **kwargs):
        from apps.integrations.meta_whatsapp import get_config, verify_token_for

        mode = request.GET.get("hub.mode")
        token = request.GET.get("hub.verify_token") or ""
        challenge = request.GET.get("hub.challenge") or ""

        expected = verify_token_for(get_config())

        if mode == "subscribe" and expected and hmac.compare_digest(token, expected):
            logger.info("[Meta CTWA] Webhook verified for schema=%s", connection.schema_name)
            return HttpResponse(challenge, content_type="text/plain")

        # Never say WHICH part was wrong — that turns this into a token oracle.
        logger.warning(
            "[Meta CTWA] Verification rejected | schema=%s mode=%s token_configured=%s",
            connection.schema_name, mode, bool(expected),
        )
        return HttpResponse("Forbidden", status=403)

    # ---- Deliveries -------------------------------------------
    def post(self, request, *args, **kwargs):
        from apps.integrations.meta_whatsapp import (
            app_secret_for, get_config, signature_required, verify_signature,
        )
        from apps.integrations.tasks import process_meta_whatsapp_webhook

        raw_body = request.body
        config = get_config()

        # 1. Authenticity, before anything is parsed or stored.
        signature = request.headers.get("X-Hub-Signature-256", "")
        app_secret = app_secret_for(config)
        if app_secret or signature or signature_required():
            if not verify_signature(raw_body, signature, app_secret):
                logger.warning(
                    "[Meta CTWA] Invalid signature | schema=%s has_secret=%s has_header=%s",
                    connection.schema_name, bool(app_secret), bool(signature),
                )
                return HttpResponse("Invalid signature", status=401)

        # 2. Parse. A body Meta could not have sent is dropped, not retried.
        try:
            payload = json.loads(raw_body)
        except json.JSONDecodeError:
            logger.warning("[Meta CTWA] Malformed JSON body | schema=%s", connection.schema_name)
            return JsonResponse({"status": "ignored", "reason": "malformed"}, status=400)

        if not isinstance(payload, dict):
            return JsonResponse({"status": "ignored", "reason": "malformed"}, status=400)

        # 3. Is this tenant actually receiving?
        if config is None or not config.inbound_enabled:
            logger.info(
                "[Meta CTWA] Inbound disabled — delivery discarded | schema=%s",
                connection.schema_name,
            )
            # 200: retrying will not turn the integration on, and Meta
            # disables an endpoint that keeps erroring.
            return JsonResponse({"status": "disabled"})

        # 4. Store the raw delivery, then hand off. Headers are filtered —
        #    the signature header is a credential-derived value and there is
        #    no reason to keep it once it has been checked.
        log = WebhookLog.objects.create(
            source=self.source,
            method="POST",
            headers=self._safe_headers(request),
            payload=payload,
        )

        process_meta_whatsapp_webhook.delay(connection.schema_name, str(log.pk))

        logger.info(
            "[Meta CTWA] Delivery accepted | schema=%s log=%s",
            connection.schema_name, log.pk,
        )
        return JsonResponse({"status": "ok"})

    @staticmethod
    def _safe_headers(request) -> dict:
        """Diagnostic headers only — nothing that authenticates a request."""
        keep = {"Content-Type", "User-Agent", "X-Forwarded-For", "Content-Length"}
        return {k: v for k, v in request.headers.items() if k in keep}
