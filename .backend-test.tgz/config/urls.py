"""
TeleCRM Backend — config/urls.py

URL configuration for TENANT schemas (served on tenant subdomains).
E.g.: acmerealty.telecrm.in → this URL conf

Routes:
  /api/v1/       → DRF REST API (React web app and Flutter mobile app)
  /health/       → Health check endpoint
  /ws/           → WebSocket connections (Django Channels)
"""
from django.conf import settings
from django.conf.urls.static import static
from django.urls import include, path, re_path
from django.views.static import serve as media_serve

from apps.core.views import ApiRootView, HealthCheckView

urlpatterns = [
    # ---- Root: to the React app, or a short note -----------
    # The old server-rendered UI (/crm/) is no longer mounted: none of its
    # templates exist, so every page of it was a 500. The CRM is the React app.
    path("", ApiRootView.as_view(), name="root"),

    # ---- REST API (for Flutter mobile app) -----------------
    path("api/v1/auth/", include(("apps.authentication.api_urls", "authentication"), namespace="api_auth")),
    path("api/v1/leads/", include(("apps.leads.api_urls", "leads"), namespace="api_leads")),
    path("api/v1/calls/", include(("apps.calls.api_urls", "calls"), namespace="api_calls")),
    path("api/v1/comms/", include(("apps.communications.api_urls", "communications"), namespace="api_comms")),
    path("api/v1/integrations/", include(("apps.integrations.api_urls", "integrations"), namespace="api_integrations")),
    path("api/v1/reports/", include(("apps.reports.api_urls", "reports"), namespace="api_reports")),
    path("api/v1/hrms/", include(("apps.hrms.api_urls", "hrms"), namespace="api_hrms")),
    path("api/v1/erp/", include(("apps.erp.api_urls", "erp"), namespace="api_erp")),
    path("api/v1/recruitment/", include(("apps.recruitment.api_urls", "recruitment"), namespace="api_recruitment")),
    path("api/v1/ai/", include(("apps.ai.api_urls", "ai"), namespace="api_ai")),
    path("api/v1/billing/", include(("apps.plans.api_urls", "plans"), namespace="api_billing")),

    # ---- Health Check (used by load balancer) --------------
    path("health/", HealthCheckView.as_view(), name="health_check"),
    path("api/v1/health/", HealthCheckView.as_view(), name="api_health_check"),
]

# ---- Media files ---------------------------------------------
# Served by Django in production too: the reverse proxy forwards ALL paths
# here, and locally-stored call recordings (Cloudinary fallback) live under
# MEDIA_ROOT. Static files are handled by WhiteNoise.
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

    # DRF browsable API — a development convenience, so it belongs here.
    urlpatterns += [
        path("api-auth/", include("rest_framework.urls", namespace="rest_framework")),
    ]

else:
    urlpatterns += [
        re_path(
            r"^media/(?P<path>.*)$",
            media_serve,
            {"document_root": settings.MEDIA_ROOT},
        ),
    ]

# ---- Django Debug Toolbar ------------------------------------
#
# Keyed off the middleware rather than DEBUG, because the toolbar breaks in
# exactly one way: when one of the two is present without the other. Its
# middleware reverses the "djdt" namespace on every response, so an installed
# middleware with unregistered URLs turns every request in the process into a
# 500 — "NoReverseMatch: 'djdt' is not a registered namespace". This block
# used to sit under `if settings.DEBUG`, which is a different condition from
# the one development.py installs the middleware on.
if "debug_toolbar.middleware.DebugToolbarMiddleware" in settings.MIDDLEWARE:
    urlpatterns = [
        path("__debug__/", include("debug_toolbar.urls")),
    ] + urlpatterns

# ============================================================
# WebSocket URL routing is handled in config/asgi.py
# WS routes: /ws/agent-monitor/, /ws/notifications/
# ============================================================
