import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'core/services/notification_service.dart';
import 'core/services/call_recording_service.dart';
import 'core/services/presence_service.dart';
import 'core/services/setup_service.dart';
import 'core/theme/app_theme.dart';
import 'core/theme/colors.dart';
import 'data/models/addon_models.dart';
import 'features/notifications/notifications_screen.dart';
import 'features/auth/auth_provider.dart';
import 'features/auth/login_screen.dart';
import 'features/calls/calls_screen.dart';
import 'features/communications/whatsapp_send_screen.dart';
import 'features/dashboard/dashboard_screen.dart';
import 'features/dialer/auto_dial_home.dart';
import 'features/dialer/dialer_screen.dart';
import 'features/dialer/dialer_state.dart';
import 'features/dialer/queue_starter_screen.dart';
import 'features/features_provider.dart';
import 'features/hrms/my_work_screen.dart';
import 'features/leads/followups_screen.dart';
import 'features/leads/lead_detail_screen.dart';
import 'features/leads/lead_form_screen.dart';
import 'features/leads/lead_import_screen.dart';
import 'features/leads/leads_list_screen.dart';
import 'features/profile/profile_screen.dart';
import 'features/reports/reports_screen.dart';
import 'features/setup/setup_wizard_screen.dart';
import 'features/work/work_session.dart';

final _rootKey = GlobalKey<NavigatorState>();
final _shellKey = GlobalKey<NavigatorState>();

/// Routes a tapped notification once the router exists.
///
/// The tap can arrive before the first frame — Android launches the app to
/// deliver it — so this holds the route until there is a navigator to send it
/// to, rather than dropping it.
StreamSubscription<String>? _notificationTapSub;
String? _pendingNotificationRoute;

void _bindNotificationTaps(GoRouter router, Ref ref) {
  _notificationTapSub?.cancel();
  _notificationTapSub = NotificationService.instance.onOpenRoute.listen((route) {
    if (route.isEmpty) return;
    final nav = _rootKey.currentState;
    if (nav == null) {
      _pendingNotificationRoute = route;
      return;
    }
    _openFromNotification(router, ref, route);
  });

  // Anything that arrived before the router was ready.
  final pending = _pendingNotificationRoute;
  if (pending != null) {
    _pendingNotificationRoute = null;
    WidgetsBinding.instance.addPostFrameCallback((_) => _openFromNotification(router, ref, pending));
  }
}

/// Open a tapped notification's screen — through the break rule.
///
/// Reminders open the lead, and leads open only on a break; the tap used to
/// be redirected silently to Auto Dial, so it never showed the lead. While
/// working, the agent is asked whether to take a break to open it.
Future<void> _openFromNotification(GoRouter router, Ref ref, String route) async {
  // A tap can launch the app: give the work session a moment to go live and
  // restore a break the agent was already on.
  for (var i = 0; i < 25 && !ref.read(workSessionProvider).live; i++) {
    if (!ref.read(authProvider).isAuthenticated) break;
    await Future<void>.delayed(const Duration(milliseconds: 200));
  }
  final work = ref.read(workSessionProvider);
  if (work.onBreak || allowedWhileWorking(route)) {
    router.push(route);
    return;
  }

  final ctx = _rootKey.currentContext;
  if (ctx == null) return;
  final open = await showDialog<bool>(
    context: ctx,
    builder: (dctx) => AlertDialog(
      title: const Text('Open this lead?'),
      content: const Text(
        'Leads, manual calls and WhatsApp open on a break. Take a break to open it now?'),
      actions: [
        TextButton(onPressed: () => Navigator.of(dctx).pop(false), child: const Text('Not now')),
        TextButton(onPressed: () => Navigator.of(dctx).pop(true), child: const Text('Take break & open')),
      ],
    ),
  );
  if (open != true) return;
  final took = await ref.read(workSessionProvider.notifier).takeBreak(reason: 'Follow-up');
  if (took) {
    router.push(route);
  } else if (_rootKey.currentContext != null) {
    ScaffoldMessenger.of(_rootKey.currentContext!).showSnackBar(const SnackBar(
      content: Text('Finish the current call and save its outcome first.'),
    ));
  }
}

/// Pokes the router to re-run its redirect when auth or the work session
/// changes. The router itself is built ONCE: it used to be rebuilt on every
/// auth change (ref.watch), which reset navigation to '/' — and while signing
/// in, let the dashboard mount before a token existed, so the app bounced to
/// the login screen and back ("logs out, then logs itself in").
class _RouterRefresh extends ChangeNotifier {
  void ping() => notifyListeners();
}

final _routerProvider = Provider<GoRouter>((ref) {
  final refresh = _RouterRefresh();
  ref.listen<AuthState>(authProvider, (prev, next) {
    if (prev?.status != next.status) refresh.ping();
  });
  ref.listen<WorkSessionState>(workSessionProvider, (prev, next) {
    if (prev?.onBreak != next.onBreak || prev?.live != next.live) refresh.ping();
  });
  ref.onDispose(refresh.dispose);

  final router = GoRouter(
    navigatorKey: _rootKey,
    initialLocation: '/splash',
    refreshListenable: refresh,
    redirect: (ctx, state) {
      final authState = ref.read(authProvider);
      final loc = state.matchedLocation;

      // Still reading the saved session: hold on the splash, so no screen
      // mounts and fires requests before we know who is signed in.
      if (authState.isLoading) return loc == '/splash' ? null : '/splash';

      final isAuth = authState.isAuthenticated;
      if (!isAuth) return loc == '/login' ? null : '/login';
      if (loc == '/login' || loc == '/splash') return '/';

      // First run: send the agent through permissions and call-recording setup
      // before they start dialling, rather than letting them discover later
      // that nothing was recorded.
      final isSetupPath = loc == '/setup';
      if (!SetupService.instance.isCompleteSync && !isSetupPath) {
        return '/setup';
      }

      // Working (not on break): auto-dialling only. Leads, manual calls,
      // WhatsApp and the rest open once the agent takes a break, and ending
      // the break brings them back here.
      final work = ref.read(workSessionProvider);
      if (work.live && !work.onBreak && !allowedWhileWorking(loc) && loc != '/') {
        return '/auto-dial';
      }
      return null;
    },
    routes: [
      GoRoute(path: '/splash', builder: (_, __) => const _Splash()),

      // Login (outside shell)
      GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),

      // First-run setup (outside the shell — no bottom nav during setup)
      GoRoute(path: '/setup', builder: (_, __) => const SetupWizardScreen()),

      // Bottom-nav shell
      ShellRoute(
        navigatorKey: _shellKey,
        builder: (ctx, state, child) => _MainShell(child: child),
        routes: [
          // Signing in lands on Auto Dial (or wherever a break allows).
          GoRoute(path: '/', redirect: (_, __) => '/auto-dial'),
          GoRoute(path: '/auto-dial', builder: (_, __) => const AutoDialHome()),
          GoRoute(path: '/dashboard', builder: (_, __) => const DashboardScreen()),
          GoRoute(
            path: '/leads',
            builder: (_, state) {
              final select = state.uri.queryParameters['select'] == 'true';
              return LeadsListScreen(selectMode: select);
            },
          ),
          GoRoute(path: '/calls', builder: (_, __) => const CallsScreen()),
          GoRoute(path: '/reports', builder: (_, __) => const ReportsScreen()),
          // Stays routable even without the HRMS module — the tab is hidden,
          // and the endpoints answer 402 if it's reached some other way.
          GoRoute(path: '/my-work', builder: (_, __) => const MyWorkScreen()),
        ],
      ),

      // Full-screen routes
      GoRoute(path: '/leads/new', builder: (_, __) => const LeadFormScreen()),
      GoRoute(path: '/leads/import', builder: (_, __) => const LeadImportScreen()),
      GoRoute(
        path: '/leads/:id',
        builder: (_, s) => LeadDetailScreen(leadId: int.parse(s.pathParameters['id']!)),
      ),
      GoRoute(
        path: '/leads/:id/edit',
        builder: (_, s) => LeadFormScreen(leadId: int.parse(s.pathParameters['id']!)),
      ),
      GoRoute(
        path: '/leads/:id/whatsapp',
        builder: (_, s) => WhatsAppSendScreen(leadId: int.parse(s.pathParameters['id']!)),
      ),
      GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
      GoRoute(path: '/followups', builder: (_, __) => const FollowupsScreen()),
      GoRoute(path: '/notifications', builder: (_, __) => const NotificationsScreen()),
      GoRoute(path: '/dialer/queue', builder: (_, __) => const QueueStarterScreen()),
      GoRoute(path: '/dialer', builder: (_, __) => const DialerScreen()),
    ],
    errorBuilder: (_, state) => Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('404', style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 72, color: AppColors.yellow)),
            const Text('Page not found', style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w600, fontSize: 18)),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: () => GoRouter.of(_).go('/'), child: const Text('Go Home')),
          ],
        ),
      ),
    ),
  );

  _bindNotificationTaps(router, ref);
  ref.onDispose(() => _notificationTapSub?.cancel());
  return router;
});

// ─── BOTTOM NAV SHELL ───────────────────────────────────────
class _MainShell extends ConsumerStatefulWidget {
  final Widget child;
  const _MainShell({required this.child});

  @override
  ConsumerState<_MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<_MainShell>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // Signed in and past setup: the agent is at work — live, available, idle
    // time running.
    Future.microtask(() => ref.read(workSessionProvider.notifier).start());
    // Catch anything left over from a previous session.
    _sweepRecordings();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Coming back from the dialer is exactly when a native call recording has
    // just finished being written. The post-call scan runs seconds after the
    // call and usually looks too early — OEM recorders finalise the file
    // later, and some not until their own app next runs — so this resume hook
    // is what actually collects most recordings.
    if (state == AppLifecycleState.resumed) {
      _sweepRecordings();
      // Back from the dialer or a locked screen: tell the server where we are
      // at once, rather than on the next 25-second heartbeat.
      PresenceService.instance.resync();
    }
  }

  void _sweepRecordings() {
    CallRecordingService.instance.sweepPending().then((count) {
      if (count > 0 && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$count call recording(s) uploaded'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }).catchError((_) {
      // Best-effort background work; never surface a failure here. The reason
      // is recorded on the service and shown in Profile.
    });
  }

  static const _coreTabs = [
    _Tab(path: '/auto-dial', icon: Icons.bolt_outlined,      activeIcon: Icons.bolt,      label: 'Auto Dial'),
    _Tab(path: '/dashboard', icon: Icons.dashboard_outlined, activeIcon: Icons.dashboard, label: 'Home'),
    _Tab(path: '/leads',     icon: Icons.people_outline,     activeIcon: Icons.people,    label: 'Leads'),
    _Tab(path: '/calls',     icon: Icons.history_outlined,   activeIcon: Icons.history,   label: 'History'),
    _Tab(path: '/reports',   icon: Icons.bar_chart_outlined, activeIcon: Icons.bar_chart, label: 'Reports'),
  ];

  static const _myWorkTab = _Tab(
    path: '/my-work', icon: Icons.badge_outlined, activeIcon: Icons.badge, label: 'My Work',
  );

  /// Add-on tabs are appended, never inserted, so the core tabs keep their
  /// places when the features request resolves after first paint.
  List<_Tab> get _tabs => [
        ..._coreTabs,
        if (ref.features.hasModule(Mod.hrms)) _myWorkTab,
      ];

  /// A locked tab explains itself instead of doing nothing.
  void _explainLocked(_Tab tab) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text('Take a break to open ${tab.label}. Auto-dialling comes first.'),
        action: SnackBarAction(
          label: 'TAKE BREAK',
          onPressed: () async {
            final ok = await ref.read(workSessionProvider.notifier)
                .takeBreak(reason: 'Manual calls & WhatsApp');
            if (!mounted) return;
            if (ok) {
              context.go(tab.path);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text('Finish the current call and save its outcome first.'),
              ));
            }
          },
        ),
      ));
  }

  @override
  Widget build(BuildContext context) {
    final tabs = _tabs;
    final work = ref.watch(workSessionProvider);
    final locked = work.live && !work.onBreak;
    // The highlighted tab follows the location, so a redirect (e.g. back to
    // Auto Dial when a break ends) moves it too.
    final loc = GoRouterState.of(context).matchedLocation;
    final found = tabs.indexWhere((t) => loc == t.path || loc.startsWith('${t.path}/'));
    final idx = found < 0 ? 0 : found;

    return Scaffold(
      body: widget.child,
      // The web app's forest-green sidebar, as a bottom bar: deep green
      // ground, pale-green labels, and the active tab on a mint pill.
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(gradient: AppColors.darkGradient),
        child: SafeArea(
          top: false,
          child: BottomNavigationBar(
            currentIndex: idx,
            onTap: (i) {
              if (locked && !allowedWhileWorking(tabs[i].path)) {
                _explainLocked(tabs[i]);
                return;
              }
              context.go(tabs[i].path);
            },
            backgroundColor: Colors.transparent,
            selectedItemColor: AppColors.mint,
            unselectedItemColor: const Color(0xFFB5D6C7),
            type: BottomNavigationBarType.fixed,
            elevation: 0,
            items: tabs.asMap().entries.map((e) => BottomNavigationBarItem(
              icon: Padding(
                padding: const EdgeInsets.only(bottom: 4, top: 2),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  curve: Curves.easeOut,
                  padding: EdgeInsets.symmetric(
                    horizontal: idx == e.key ? 16 : 0,
                    vertical: idx == e.key ? 5 : 0,
                  ),
                  decoration: idx == e.key
                      ? BoxDecoration(
                          gradient: AppColors.mintGradient,
                          borderRadius: BorderRadius.circular(999),
                          boxShadow: const [BoxShadow(color: Color(0x806FE0A6), blurRadius: 14, offset: Offset(0, 4), spreadRadius: -6)],
                        )
                      : null,
                  child: Icon(
                    idx == e.key ? e.value.activeIcon : e.value.icon,
                    size: 21,
                    color: idx == e.key ? AppColors.mintInk : null,
                  ),
                ),
              ),
              label: e.value.label,
            )).toList(),
            selectedLabelStyle: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 11),
            unselectedLabelStyle: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w500, fontSize: 11),
          ),
        ),
      ),
    );
  }
}

class _Tab {
  final String path, label;
  final IconData icon, activeIcon;
  const _Tab({required this.path, required this.icon, required this.activeIcon, required this.label});
}

// ─── ROOT APP ───────────────────────────────────────────────
class DialSathiApp extends ConsumerStatefulWidget {
  const DialSathiApp({super.key});

  @override
  ConsumerState<DialSathiApp> createState() => _DialSathiAppState();
}

class _DialSathiAppState extends ConsumerState<DialSathiApp>
    with WidgetsBindingObserver {
  /// Don't re-sync on every glance at the phone. Coming back from a ten
  /// second detour does not change what is scheduled.
  static const _minResyncGap = Duration(minutes: 10);
  DateTime? _lastSync;

  /// How often to ask whether the server has raised anything.
  ///
  /// Separate from the reminder re-sync above, and much more frequent: a
  /// follow-up someone books on your lead is news now, and with no push
  /// configured the only way this phone learns of it is by asking. Each ask
  /// costs one small unread-count request when there is nothing new.
  ///
  /// It keeps running while the app is in the background — that is the whole
  /// point, since an agent looking at the app does not need the shade — but
  /// more slowly, because there it is a background app spending someone's
  /// battery. Android freezing the process eventually stops it either way;
  /// the scheduled alarms are what survive that, and FCM is what would fix
  /// it properly (apps/authentication/push.py).
  static const _serverPollTick = Duration(minutes: 1);
  static const _foregroundPollGap = Duration(minutes: 1);
  static const _backgroundPollGap = Duration(minutes: 5);

  Timer? _serverPoll;
  DateTime? _lastServerPull;
  AppLifecycleState _lifecycle = AppLifecycleState.resumed;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _serverPoll = Timer.periodic(_serverPollTick, (_) => _pullServerNotifications());
  }

  @override
  void dispose() {
    _serverPoll?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// Raise anything the server has for this agent in the Android shade.
  ///
  /// Lives at app level rather than on the bell: the bell is only mounted on
  /// the dashboard, so an agent sitting on any other screen would be told
  /// nothing.
  void _pullServerNotifications({bool force = false}) {
    if (!ref.read(authProvider).isAuthenticated) return;

    final now = DateTime.now();
    final gap = _lifecycle == AppLifecycleState.resumed
        ? _foregroundPollGap
        : _backgroundPollGap;
    if (!force && _lastServerPull != null && now.difference(_lastServerPull!) < gap) {
      return;
    }
    _lastServerPull = now;

    unawaited(NotificationService.instance.syncServerNotifications());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _lifecycle = state;
    if (state != AppLifecycleState.resumed) return;

    // Reminders were armed once, at login. An app left open for days keeps
    // firing alarms for follow-ups that have since been completed or moved,
    // and never learns about one scheduled from the web this morning.
    // Resuming is the natural moment to reconcile: it is when the agent is
    // about to look at their day anyway.
    if (!ref.read(authProvider).isAuthenticated) return;

    // Regardless of the gaps above: picking the phone up is the moment the
    // badge and the shade are most likely to be behind.
    _pullServerNotifications(force: true);

    final now = DateTime.now();
    if (_lastSync != null && now.difference(_lastSync!) < _minResyncGap) return;
    _lastSync = now;

    // Not awaited: a slow or failed sync must not hold up the first frame
    // after a resume. It logs its own failures.
    unawaited(NotificationService.instance.syncFollowupReminders());
  }

  @override
  Widget build(BuildContext context) {
    // Signed out (logout or an expired session): reset the work session so
    // the next sign-in goes live again. See WorkSessionNotifier.signedOut.
    ref.listen<AuthState>(authProvider, (prev, next) {
      if (prev?.isAuthenticated == true && !next.isAuthenticated) {
        ref.read(workSessionProvider.notifier).signedOut();
        ref.read(dialerProvider.notifier).reset();
      }
    });
    final router = ref.watch(_routerProvider);
    return MaterialApp.router(
      title: 'DialSathi',
      theme: AppTheme.theme,
      routerConfig: router,
      debugShowCheckedModeBanner: false,
      builder: (ctx, child) => MediaQuery(
        data: MediaQuery.of(ctx).copyWith(textScaler: TextScaler.noScaling),
        child: child!,
      ),
    );
  }
}

/// Shown only while the saved session is being read at start-up.
class _Splash extends StatelessWidget {
  const _Splash();

  @override
  Widget build(BuildContext context) => const Scaffold(
    body: DecoratedBox(
      decoration: BoxDecoration(gradient: AppColors.darkGradient),
      child: Center(child: CircularProgressIndicator(color: AppColors.mint)),
    ),
  );
}
