import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'api_client.dart';
import '../models/models.dart';
import 'package:dio/dio.dart';

Dio get _dio => ApiClient.instance.dio;

// ─── AUTH ───────────────────────────────────────────────────
class AuthService {
  AuthService._();
  static final instance = AuthService._();

  Future<LoginResponse> login(String email, String password) async {
    final r = await _dio.post('/auth/login/', data: {'email': email, 'password': password});
    return LoginResponse.fromJson(r.data);
  }

  Future<void> logout(String refresh) async {
    await _dio.post('/auth/logout/', data: {'refresh': refresh});
  }

  Future<Agent> getProfile() async {
    final r = await _dio.get('/auth/me/');
    return Agent.fromJson(r.data);
  }

  Future<Agent> updateProfile(Map<String, dynamic> data) async {
    final r = await _dio.patch('/auth/me/', data: data);
    return Agent.fromJson(r.data);
  }

  Future<void> changePassword({required String oldPassword, required String newPassword, required String confirmPassword}) async {
    await _dio.post('/auth/change-password/', data: {
      'old_password': oldPassword, 'new_password': newPassword, 'confirm_password': confirmPassword,
    });
  }
}

// ─── LEADS ──────────────────────────────────────────────────
class LeadsService {
  LeadsService._();
  static final instance = LeadsService._();

  /// What this client's Add Lead form shows (standard money fields + custom
  /// fields). Falls back to the plain default form if the server is older.
  Future<LeadFormConfig> getFormConfig() async {
    try {
      final r = await _dio.get('/leads/form-config/');
      return LeadFormConfig.fromJson((r.data as Map).cast<String, dynamic>());
    } catch (_) {
      return const LeadFormConfig();
    }
  }

  Future<PaginatedResponse<Lead>> listLeads({
    int page = 1, int pageSize = 20,
    String? status, String? priority, String? source,
    String? search, String? assignedTo, bool? overdue,
    bool? followupDueToday,
  }) async {
    final r = await _dio.get('/leads/', queryParameters: {
      'page': page, 'page_size': pageSize,
      if (status != null && status.isNotEmpty) 'status': status,
      if (priority != null && priority.isNotEmpty) 'priority': priority,
      if (source != null && source.isNotEmpty) 'source': source,
      if (search != null && search.isNotEmpty) 'search': search,
      if (assignedTo != null && assignedTo.isNotEmpty) 'assigned_to': assignedTo,
      if (overdue == true) 'overdue': 'true',
      if (followupDueToday == true) 'followup_due_today': 'true',
      'order_by': '-created_at',
    });
    return PaginatedResponse.fromJson(r.data, Lead.fromJson);
  }

  Future<Lead> getLead(int id) async => Lead.fromJson((await _dio.get('/leads/$id/')).data);
  Future<Lead> createLead(Map<String, dynamic> data) async => Lead.fromJson((await _dio.post('/leads/', data: data)).data);
  Future<Lead> updateLead(int id, Map<String, dynamic> data) async => Lead.fromJson((await _dio.patch('/leads/$id/', data: data)).data);
  Future<void> deleteLead(int id) async => await _dio.delete('/leads/$id/');
  /// Lost and Invalid need a reason; so does Converted when an agent sets it.
  Future<void> updateStatus(int id, String status, {String? reason}) async =>
      await _dio.patch('/leads/$id/status/', data: {
        'status': status,
        if (reason != null && reason.trim().isNotEmpty) 'reason': reason.trim(),
      });

  Future<LeadStats> getStats() async => LeadStats.fromJson((await _dio.get('/leads/stats/')).data);
  Future<Map<String, dynamic>> getPipeline() async => (await _dio.get('/leads/pipeline/')).data;

  Future<PaginatedResponse<FollowUp>> listFollowups(int leadId) async =>
      PaginatedResponse.fromJson((await _dio.get('/leads/$leadId/followups/')).data, FollowUp.fromJson);

  Future<FollowUp> createFollowup(int leadId, Map<String, dynamic> data) async =>
      FollowUp.fromJson((await _dio.post('/leads/$leadId/followups/', data: data)).data);

  Future<void> completeFollowup(int id, {String notes = ''}) async =>
      await _dio.post('/leads/followups/$id/complete/', data: {'notes': notes});

  Future<PaginatedResponse<LeadNote>> listNotes(int leadId) async =>
      PaginatedResponse.fromJson((await _dio.get('/leads/$leadId/notes/')).data, LeadNote.fromJson);

  Future<LeadNote> createNote(int leadId, String content, {String? attachmentUrl}) async =>
      LeadNote.fromJson((await _dio.post('/leads/$leadId/notes/', data: {
        'content': content, if (attachmentUrl != null) 'attachment_url': attachmentUrl,
      })).data);
}

// ─── CALLS ──────────────────────────────────────────────────
class CallsService {
  CallsService._();
  static final instance = CallsService._();

  Future<PaginatedResponse<CallLog>> listCalls({
    int page = 1, String? leadId, String? direction, String? connected,
    String? dateFrom, String? dateTo, int? disposition,
    /// Only calls still waiting for an outcome.
    bool needsOutcome = false,
  }) async {
    final r = await _dio.get('/calls/', queryParameters: {
      'page': page, 'page_size': 25,
      if (leadId != null) 'lead': leadId,
      if (direction != null && direction.isNotEmpty) 'direction': direction,
      if (connected != null && connected.isNotEmpty) 'connected': connected,
      if (dateFrom != null) 'date_from': dateFrom,
      if (dateTo != null) 'date_to': dateTo,
      if (needsOutcome) 'disposition': 'none'
      else if (disposition != null) 'disposition': disposition,
    });
    return PaginatedResponse.fromJson(r.data, CallLog.fromJson);
  }

  /// Set the outcome of a call saved without one. The outcome must belong to
  /// the call status (answered / not) — the server refuses a mismatch.
  Future<CallLog> setOutcome(String callId, {
    required int disposition, required bool connected, int? durationSeconds, String? notes,
  }) async =>
      CallLog.fromJson((await _dio.patch('/calls/$callId/outcome/', data: {
        'disposition': disposition,
        'is_connected': connected,
        if (durationSeconds != null) 'duration_seconds': durationSeconds,
        if (notes != null && notes.trim().isNotEmpty) 'notes': notes.trim(),
      })).data);

  Future<CallLog> createCall(Map<String, dynamic> data) async =>
      CallLog.fromJson((await _dio.post('/calls/', data: data)).data);

  Future<Map<String, dynamic>> clickToCall(int leadId, {String? phoneNumber}) async {
    final r = await _dio.post('/calls/click-to-call/', data: {
      'lead_id': leadId, if (phoneNumber != null) 'phone_number': phoneNumber,
    });
    return r.data;
  }

  Future<List<CallDisposition>> getDispositions() async {
    final r = await _dio.get('/calls/dispositions/');
    final data = r.data;
    // A list today; tolerate a paginated shape too, rather than failing the
    // one screen an agent cannot skip.
    final list = data is Map ? (data['results'] as List? ?? const []) : data as List;
    return list.map((e) => CallDisposition.fromJson(e as Map<String, dynamic>)).toList();
  }

  static const _kDispositionsCache = 'cached_dispositions';

  /// Dispositions for the post-call screen: retried once, then the last list
  /// that loaded. Only fails when nothing has ever loaded on this phone.
  Future<List<CallDisposition>> getDispositionsResilient() async {
    final prefs = await SharedPreferences.getInstance();
    Object? lastError;
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        final fresh = await getDispositions();
        await prefs.setString(_kDispositionsCache, jsonEncode([
          for (final d in fresh)
            {'id': d.id, 'name': d.name, 'slug': d.slug,
             'is_positive': d.isPositive, 'auto_followup_hours': d.autoFollowupHours,
             'category': d.category, 'lead_status': d.leadStatus, 'sets_dnd': d.setsDnd},
        ]));
        return fresh;
      } catch (e) {
        lastError = e;
        await Future.delayed(const Duration(milliseconds: 800));
      }
    }
    final cached = prefs.getString(_kDispositionsCache);
    if (cached != null) {
      return (jsonDecode(cached) as List)
          .map((e) => CallDisposition.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    throw lastError!;
  }

  Future<Map<String, dynamic>> getStats() async => (await _dio.get('/calls/stats/')).data;
}

// ─── COMMUNICATIONS ─────────────────────────────────────────
class CommsService {
  CommsService._();
  static final instance = CommsService._();

  Future<List<WhatsAppTemplate>> listTemplates({bool approvedOnly = true}) async {
    final r = await _dio.get('/comms/whatsapp/templates/',
        queryParameters: approvedOnly ? {'approved_only': true} : null);
    return (r.data as List).map((e) => WhatsAppTemplate.fromJson(e)).toList();
  }

  Future<void> sendWhatsApp(int leadId, String message, {int? templateId}) async {
    await _dio.post('/comms/whatsapp/send/', data: {
      'lead_id': leadId, 'message': message,
      if (templateId != null) 'template_id': templateId,
    });
  }

  Future<void> sendSMS(int leadId, String message, {String? senderId}) async {
    await _dio.post('/comms/sms/send/', data: {
      'lead_id': leadId, 'message': message,
      if (senderId != null) 'sender_id': senderId,
    });
  }
}

// ─── REPORTS ────────────────────────────────────────────────
class ReportsService {
  ReportsService._();
  static final instance = ReportsService._();

  Future<Map<String, dynamic>> dailyActivity() async => (await _dio.get('/reports/daily-activity/')).data;
  Future<Map<String, dynamic>> callAnalytics() async => (await _dio.get('/reports/call-analytics/')).data;
  Future<Map<String, dynamic>> conversionFunnel() async => (await _dio.get('/reports/conversion-funnel/')).data;
}

// ============================================================
// QUEUE SERVICE  /api/v1/leads/queues/
// Pull-based calling queues: leads are checked out one at a time and locked
// to this agent, so no lead is ever served to two agents or repeated.
// ============================================================
class QueueService {
  QueueService._();
  static final instance = QueueService._();

  /// Queues this agent is a member of, with live pending-lead counts.
  Future<List<Map<String, dynamic>>> available() async {
    final res = await _dio.get('/leads/queues/available/');
    return ((res.data as List?) ?? []).cast<Map<String, dynamic>>();
  }

  /// Atomically check out the next lead from a queue.
  /// Returns {lead, lock_expires_at, queue, resumed} or {empty: true}.
  /// `resumed` is true when the lead is one this agent already had checked
  /// out from the queue (the app was restarted mid-call).
  Future<Map<String, dynamic>> pullNext(int queueId) async {
    final res = await _dio.post('/leads/queues/$queueId/pull/');
    return (res.data as Map).cast<String, dynamic>();
  }

  /// Release a checked-out lead.
  ///
  /// By default it is a skip: the lead stays out of this agent's queue until
  /// its lock time runs out, so the next pull moves on to another lead (it
  /// used to serve the same one again). `returnToQueue` (leaving the queue)
  /// puts it back at once. `markDialed` if it was dialled.
  Future<void> release(int leadId, {bool markDialed = false, bool returnToQueue = false}) async {
    await _dio.post('/leads/queues/release/', data: {
      'lead_id': leadId,
      'mark_dialed': markDialed,
      'return_to_queue': returnToQueue,
    });
  }
}

// ─── NOTIFICATIONS ──────────────────────────────────────────
/// The agent's own notifications, and the follow-ups a reminder is built from.
///
/// Everything here is scoped server-side to the caller — there is no agent
/// parameter to pass, and none that would be honoured.
class NotificationsService {
  NotificationsService._();
  static final instance = NotificationsService._();

  Future<List<AppNotification>> list({bool unreadOnly = false, int pageSize = 30}) async {
    final r = await _dio.get('/auth/notifications/', queryParameters: {
      if (unreadOnly) 'unread': 'true',
      'page_size': pageSize,
    });
    final results = (r.data['results'] as List?) ?? const [];
    return results
        .map((e) => AppNotification.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<int> unreadCount() async {
    final r = await _dio.get('/auth/notifications/unread-count/');
    return (r.data['unread'] as int?) ?? 0;
  }

  Future<void> markRead(int id) async {
    await _dio.post('/auth/notifications/$id/read/');
  }

  Future<int> markAllRead() async {
    final r = await _dio.post('/auth/notifications/read-all/');
    return (r.data['marked_read'] as int?) ?? 0;
  }

  /// Register this device for push, or unregister by sending an empty string.
  ///
  /// Call it with '' on logout: without that, the next person to sign in on
  /// the same handset inherits the previous agent's follow-up reminders.
  Future<void> registerDevice(String fcmToken) async {
    await _dio.post('/auth/notifications/device/', data: {'fcm_token': fcmToken});
  }

  /// Everything still open and assigned to me, soonest first.
  ///
  /// This is what the local reminders are built from, so it deliberately
  /// includes overdue follow-ups — those are the ones most worth surfacing.
  Future<List<FollowUp>> myUpcomingFollowups({int days = 14}) async {
    final r = await _dio.get('/leads/followups/mine/', queryParameters: {'days': days});
    final data = r.data;
    // The endpoint is unpaginated, but tolerate either shape rather than
    // crashing the reminder sync if that ever changes.
    final rows = data is List ? data : ((data['results'] as List?) ?? const []);
    return rows.map((e) => FollowUp.fromJson(e as Map<String, dynamic>)).toList();
  }
}
