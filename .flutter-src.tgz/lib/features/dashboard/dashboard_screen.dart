import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/theme/colors.dart';
import '../notifications/notification_bell.dart';
import '../../core/utils/utils.dart';
import '../../core/widgets/brand.dart';
import '../../core/widgets/widgets.dart';
import '../../data/models/models.dart';
import '../../data/services/services.dart';
import '../auth/auth_provider.dart';

final _statsProvider = FutureProvider.autoDispose<LeadStats>((_) => LeadsService.instance.getStats());
final _callStatsProvider = FutureProvider.autoDispose<Map<String, dynamic>>((_) => CallsService.instance.getStats());
final _recentLeadsProvider = FutureProvider.autoDispose<PaginatedResponse<Lead>>(
  (_) => LeadsService.instance.listLeads(pageSize: 5),
);

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final agent = ref.watch(currentAgentProvider);
    final statsAsync = ref.watch(_statsProvider);
    final callsAsync = ref.watch(_callStatsProvider);
    final leadsAsync = ref.watch(_recentLeadsProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: BrutalRefreshIndicator(
        onRefresh: () async {
          ref.invalidate(_statsProvider);
          ref.invalidate(_callStatsProvider);
          ref.invalidate(_recentLeadsProvider);
        },
        child: CustomScrollView(
          slivers: [
            // ─── Top bar ─────────────────────────────────────────
            SliverAppBar(
              pinned: true,
              backgroundColor: AppColors.white,
              elevation: 0,
              titleSpacing: 16,
              title: const Row(children: [
                BrandMark(size: 34),
                SizedBox(width: 8),
                BrandWordmark(size: 19),
              ]),
              actions: [
                const NotificationBell(),
                Padding(
                  padding: const EdgeInsets.only(right: 12, top: 8, bottom: 8),
                  child: GestureDetector(
                    onTap: () => context.go('/profile'),
                    child: BrutalAvatar(name: agent?.name ?? 'A', size: 36),
                  ),
                ),
              ],
              bottom: const PreferredSize(
                preferredSize: Size.fromHeight(1),
                child: Divider(height: 1, thickness: 1, color: AppColors.line),
              ),
            ),

            // ─── Hero band — greeting over the soft green wash ─────
            SliverToBoxAdapter(
              child: _Greeting(agent: agent).animate().fadeIn(duration: 250.ms),
            ),

            // ─── Content ──────────────────────────────────────────
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
              sliver: SliverList(delegate: SliverChildListDelegate([

                // KPI Cards (colorful)
                statsAsync.when(
                  loading: () => GridView.count(
                    crossAxisCount: 2, shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.4,
                    children: List.generate(4, (_) => const ShimmerCard(height: 80)),
                  ),
                  error: (_, __) => const SizedBox.shrink(),
                  data: (stats) => Column(children: [
                    Row(children: [
                      Expanded(child: CompactKpi(
                        label: 'New Today', value: '${stats.newLeadsToday}',
                        color: AppColors.brand, icon: Icons.group_rounded,
                      )),
                      const SizedBox(width: 10),
                      Expanded(child: CompactKpi(
                        // Everything that needs action today: overdue plus
                        // due later today (the Follow-ups screen's two tabs).
                        label: 'Follow-ups',
                        value: '${stats.overdueFollowups + stats.followupsDue}',
                        color: stats.overdueFollowups > 0 ? AppColors.hot : AppColors.warning,
                        icon: Icons.notifications_rounded,
                      )),
                    ]),
                    const SizedBox(height: 10),
                    Row(children: [
                      Expanded(child: CompactKpi(
                        label: 'Active Leads', value: '${stats.activeLeads}',
                        color: AppColors.blue, icon: Icons.layers_rounded,
                      )),
                      const SizedBox(width: 10),
                      Expanded(child: CompactKpi(
                        label: 'Conversion', value: '${stats.conversionRate.toStringAsFixed(1)}%',
                        color: AppColors.teal, icon: Icons.bar_chart_rounded,
                      )),
                    ]),
                  ]).animate().fadeIn(delay: 200.ms),
                ),

                const SizedBox(height: 20),

                // Quick actions
                _QuickActionsBar(
                  context: context,
                  canImport: const {'admin', 'manager'}.contains(ref.watch(currentAgentProvider)?.role),
                ).animate().fadeIn(delay: 280.ms),
                const SizedBox(height: 20),

                // Today's call stats card
                callsAsync.when(
                  loading: () => const ShimmerCard(height: 100),
                  error: (_, __) => const SizedBox.shrink(),
                  data: (s) => _TodayCallsCard(stats: s).animate().fadeIn(delay: 350.ms),
                ),

                const SizedBox(height: 14),

                // Today's tasks — overdue follow-ups
                statsAsync.when(
                  loading: () => const SizedBox.shrink(),
                  error: (_, __) => const SizedBox.shrink(),
                  data: (stats) {
                    if (stats.overdueFollowups == 0 && stats.followupsDue == 0) {
                      return const SizedBox.shrink();
                    }
                    return _TasksCard(
                      stats: stats,
                      // Back from the Follow-ups screen, where some may have
                      // been done: the counts here must not stay stale.
                      onReturn: () => ref.invalidate(_statsProvider),
                    ).animate().fadeIn(delay: 380.ms);
                  },
                ),

                const SizedBox(height: 20),

                // Pipeline mini-chart
                statsAsync.when(
                  loading: () => const ShimmerCard(height: 160),
                  error: (_, __) => const SizedBox.shrink(),
                  data: (stats) => _PipelineCard(stats: stats).animate().fadeIn(delay: 420.ms),
                ),

                const SizedBox(height: 20),

                // Recent leads
                SectionHeader(
                  title: 'Recent Leads',
                  icon: Icons.history,
                  action: TextButton(
                    onPressed: () => context.go('/leads'),
                    child: const Text('View all →', style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.brandInk)),
                  ),
                ),
                const SizedBox(height: 10),
                leadsAsync.when(
                  loading: () => Column(children: List.generate(3, (_) =>
                    const Padding(padding: EdgeInsets.only(bottom: 10), child: ShimmerCard(height: 80)),
                  )),
                  error: (_, __) => const SizedBox.shrink(),
                  data: (res) => res.results.isEmpty
                      ? const EmptyStateView(icon: Icons.people_outline, title: 'No leads yet')
                      : Column(children: res.results.asMap().entries.map((e) => Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: _RecentLeadTile(lead: e.value)
                              .animate().fadeIn(delay: Duration(milliseconds: 500 + e.key * 60))
                              .slideX(begin: 0.04, end: 0),
                        )).toList()),
                ),
                const SizedBox(height: 80),
              ])),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Greeting ───────────────────────────────────────────────
class _Greeting extends StatelessWidget {
  final Agent? agent;
  const _Greeting({this.agent});

  @override
  Widget build(BuildContext context) {
    final hour = DateTime.now().hour;
    final greet = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';
    // The web dashboard's hero band: a soft green wash across the full width,
    // the page title and greeting on the left, the illustration on the right.
    return Container(
      decoration: const BoxDecoration(gradient: AppColors.heroGradient),
      padding: const EdgeInsets.fromLTRB(16, 14, 8, 12),
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Dashboard', style: AppTextStyles.h1),
          const SizedBox(height: 4),
          Text('$greet, ${agent?.name.split(' ').first ?? 'Agent'}',
              style: AppTextStyles.bodyMedium.copyWith(color: AppColors.text2)),
          const SizedBox(height: 2),
          // Day and date together, right under the greeting.
          Text(DateFormat('EEEE, d MMMM yyyy').format(DateTime.now()),
              style: AppTextStyles.caption.copyWith(fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: AppColors.line),
            ),
            child: Text((agent?.role ?? 'agent').replaceAll('_', ' ').toUpperCase(),
                style: const TextStyle(fontFamily: kFontFamily, fontWeight: FontWeight.w700,
                    fontSize: 10, color: AppColors.brandInk, letterSpacing: 0.6)),
          ),
        ])),
        // The illustration is decorative; on a narrow phone it shrinks
        // rather than pushing the greeting onto three lines.
        const Flexible(child: HeroArt(height: 104)),
      ]),
    );
  }
}

// ─── Quick Actions Bar ──────────────────────────────────────
class _QuickActionsBar extends StatelessWidget {
  final BuildContext context;
  final bool canImport;
  const _QuickActionsBar({required this.context, this.canImport = false});

  @override
  Widget build(BuildContext _) {
    return Row(children: [
      Expanded(child: ActionButton(
        icon: Icons.call, label: 'CALL', color: AppColors.success, iconColor: AppColors.white,
        onTap: () => context.go('/leads'),
      )),
      Expanded(child: ActionButton(
        icon: Icons.chat, label: 'WHATSAPP', color: AppColors.tealBg, iconColor: AppColors.teal,
        onTap: () => context.go('/leads'),
      )),
      Expanded(child: ActionButton(
        icon: Icons.person_add, label: 'NEW LEAD', color: AppColors.purpleBg, iconColor: AppColors.purple,
        onTap: () => context.push('/leads/new'),
      )),
      // Bulk import is for managers and admins, as on the web.
      if (canImport)
        Expanded(child: ActionButton(
          icon: Icons.upload_file, label: 'IMPORT', color: AppColors.infoBg, iconColor: AppColors.info,
          onTap: () => context.push('/leads/import'),
        )),
    ]);
  }
}

// ─── Today's Calls Card ─────────────────────────────────────
class _TodayCallsCard extends StatelessWidget {
  final Map<String, dynamic> stats;
  const _TodayCallsCard({required this.stats});

  @override
  Widget build(BuildContext context) {
    final today = stats['today'] as Map<String, dynamic>? ?? {};
    final period = stats['period'] as Map<String, dynamic>? ?? {};
    return BrutalCard(
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: AppColors.brand50,
            borderRadius: BorderRadius.circular(9),
          ),
          child: const Icon(Icons.phone_in_talk, color: AppColors.brand, size: 22),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('TODAY\'S CALLS',
              style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 10, color: AppColors.text3, letterSpacing: 0.6)),
          const SizedBox(height: 3),
          Text('${today['total'] ?? 0} total · ${today['connected'] ?? 0} connected',
              style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.text)),
        ])),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: AppColors.brand,
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text('${period['connection_rate'] ?? 0}%',
              style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.white)),
        ),
      ]),
    );
  }
}

// ─── Pipeline Card ──────────────────────────────────────────
class _PipelineCard extends StatelessWidget {
  final LeadStats stats;
  const _PipelineCard({required this.stats});

  @override
  Widget build(BuildContext context) {
    final entries = [
      // Same stage colours as the web pipeline donut.
      ('New', stats.byStatus['new'] ?? 0, AppColors.brand),
      ('Interested', stats.byStatus['interested'] ?? 0, AppColors.teal),
      ('Negotiation', stats.byStatus['negotiation'] ?? 0, AppColors.visit),
      ('Converted', stats.byStatus['converted'] ?? 0, AppColors.won),
    ];
    final total = entries.fold<int>(0, (s, e) => s + e.$2);
    return BrutalCard(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SectionHeader(title: 'Pipeline Snapshot', icon: Icons.donut_large),
        const SizedBox(height: 14),
        ...entries.map((e) => Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(children: [
            SizedBox(width: 90, child: Text(e.$1, style: AppTextStyles.body)),
            Expanded(child: Stack(children: [
              Container(
                height: 8,
                decoration: BoxDecoration(
                  color: AppColors.sunken,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              if (total > 0) FractionallySizedBox(
                widthFactor: e.$2 / total,
                child: Container(
                  height: 8,
                  decoration: BoxDecoration(
                    color: e.$3,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ])),
            const SizedBox(width: 8),
            SizedBox(width: 28, child: Text('${e.$2}', textAlign: TextAlign.right, style: AppTextStyles.h5)),
          ]),
        )),
      ]),
    );
  }
}

// ─── Recent Lead Tile ───────────────────────────────────────
class _RecentLeadTile extends StatelessWidget {
  final Lead lead;
  const _RecentLeadTile({required this.lead});

  @override
  Widget build(BuildContext context) {
    final statusColor = AppColors.leadStatusColors[lead.status]?.border ?? AppColors.grey;
    return BrutalCard(
      onTap: () => context.push('/leads/${lead.id}'),
      padding: EdgeInsets.zero,
      child: IntrinsicHeight(
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          // The status rail runs the full height rather than a hardcoded 72,
          // so it cannot leave a gap when the text wraps to a taller row.
          Container(width: 3, color: statusColor),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 10, 12),
            child: BrutalAvatar(name: lead.name, size: 40),
          ),
          Expanded(child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(children: [
                  Expanded(child: Text(lead.name, style: AppTextStyles.h5,
                      maxLines: 1, overflow: TextOverflow.ellipsis)),
                  const SizedBox(width: 8),
                  StatusBadge(status: lead.status, label: lead.statusDisplay),
                ]),
                const SizedBox(height: 4),
                Row(children: [
                  // The number is the identifier and keeps its width; the
                  // city gives way first.
                  Text(Fmt.displayPhone(lead.phone), style: AppTextStyles.mono),
                  if (lead.city.isNotEmpty) Flexible(
                    child: Text(' · ${lead.city}',
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: AppTextStyles.caption),
                  ),
                ]),
                const SizedBox(height: 7),
                Row(children: [
                  // Only the source chip may shrink. Priority is short and
                  // fixed, and the score bar is the thing being pushed off
                  // the edge, so it keeps its width.
                  Flexible(child: TagChip(label: lead.sourceDisplay)),
                  const SizedBox(width: 6),
                  PriorityBadge(priority: lead.priority),
                  const SizedBox(width: 8),
                  const Spacer(),
                  ScoreBar(score: lead.score),
                ]),
              ],
            ),
          )),
          const Padding(
            padding: EdgeInsets.only(left: 4, right: 12),
            child: Icon(Icons.chevron_right, size: 18, color: AppColors.text3),
          ),
        ]),
      ),
    );
  }
}

// ─── Tasks / Follow-ups Card ────────────────────────────────
class _TasksCard extends StatelessWidget {
  final LeadStats stats;
  final VoidCallback onReturn;
  const _TasksCard({required this.stats, required this.onReturn});

  /// "2 overdue · 3 due later today". The counts are leads, each in one
  /// bucket — the same rule as the Follow-ups screen's two tabs, so the card
  /// and the list it opens agree. It used to show only the overdue number
  /// when there was one, hiding the rest of the day.
  static String summary(int overdue, int dueToday) {
    final parts = [
      if (overdue > 0) '$overdue overdue',
      if (dueToday > 0) '$dueToday due later today',
    ];
    return parts.isEmpty ? 'Nothing due today' : parts.join(' · ');
  }

  @override
  Widget build(BuildContext context) {
    final hasOverdue = stats.overdueFollowups > 0;
    return BrutalCard(
      padding: const EdgeInsets.all(14),
      color: hasOverdue ? AppColors.errorBg : AppColors.warningBg,
      borderColor: hasOverdue ? AppColors.error : AppColors.warning,
      onTap: () async {
        await context.push('/followups');
        onReturn();
      },
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: hasOverdue ? AppColors.error : AppColors.warning,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            hasOverdue ? Icons.warning_amber_rounded : Icons.event_available,
            color: AppColors.white, size: 22,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
            "TODAY'S TASKS",
            style: const TextStyle(
              fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700,
              fontSize: 11, color: AppColors.black, letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            summary(stats.overdueFollowups, stats.followupsDue),
            style: AppTextStyles.bodyMedium.copyWith(
              color: hasOverdue ? AppColors.error : AppColors.text,
              fontWeight: hasOverdue ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ])),
        const Icon(Icons.chevron_right, color: AppColors.black, size: 20),
      ]),
    );
  }
}
