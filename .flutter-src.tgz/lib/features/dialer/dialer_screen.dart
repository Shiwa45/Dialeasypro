import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/services/notification_service.dart';
import '../../core/services/phone_service.dart';
import '../../core/theme/colors.dart';
import '../../core/utils/utils.dart';
import '../../core/widgets/widgets.dart';
import '../../data/models/models.dart';
import '../leads/lead_custom_fields.dart';
import '../../data/services/api_client.dart';
import '../../data/services/services.dart';
import '../work/work_session.dart';
import '../calls/answered_toggle.dart';
import 'dialer_state.dart';
import 'lead_basics_card.dart';

// ============================================================
// DialSathi — Active Dialer Screen
// Full-screen experience for the auto-dialer flow:
//  - Pre-call: lead preview + countdown
//  - In-call: live timer + notes + quick actions
//  - Post-call: MANDATORY disposition before next
//  - Completed: queue summary
// ============================================================

class DialerScreen extends ConsumerStatefulWidget {
  const DialerScreen({super.key});

  @override
  ConsumerState<DialerScreen> createState() => _DialerScreenState();
}

class _DialerScreenState extends ConsumerState<DialerScreen> {
  @override
  Widget build(BuildContext context) {
    final state = ref.watch(dialerProvider);

    // Back is held while a call waits for its outcome, and while a queue is
    // running (it asks first). PopScope rather than WillPopScope: from
    // Android 16 (targetSdk 36) back is "predictive" — the system has to know
    // BEFORE the gesture whether this screen may close, and WillPopScope's
    // after-the-fact veto no longer runs.
    final holdBack = state.phase == DialerPhase.postCall ||
        (state.mode == DialerMode.queue && state.phase != DialerPhase.completed);

    return PopScope(
      canPop: !holdBack,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) {
          // Closed — by back, or by DONE/exit, which stopped it already.
          // stop() is safe to repeat.
          ref.read(dialerProvider.notifier).stop();
          return;
        }
        if (state.phase == DialerPhase.postCall) {
          AppToast.show(context, 'Please dispose this call first', isError: true);
          return;
        }
        final confirmed = await showBrutalConfirm(
          context: context,
          title: 'Stop Auto-Dialer?',
          message: 'You will exit the queue. Progress will be lost.',
          confirmLabel: 'Stop & Exit',
          danger: true,
        );
        if (confirmed == true && context.mounted) {
          ref.read(dialerProvider.notifier).stop();
          context.pop();
        }
      },
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: SafeArea(
          child: Column(
            children: [
              _TopBar(state: state),
              if (state.mode == DialerMode.queue) _QueueProgress(state: state),
              Expanded(child: _PhaseContent(state: state)),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── TOP BAR ────────────────────────────────────────────────
class _TopBar extends ConsumerWidget {
  final DialerState state;
  const _TopBar({required this.state});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: AppColors.line, width: 1)),
      ),
      child: Row(children: [
        IconButton(
          icon: const Icon(Icons.close, color: AppColors.white),
          onPressed: () async {
            if (state.phase == DialerPhase.postCall) {
              AppToast.show(context, 'Please dispose this call first', isError: true);
              return;
            }
            final canStop = state.mode != DialerMode.queue ||
                            state.phase == DialerPhase.completed ||
                            (await showBrutalConfirm(
                              context: context,
                              title: 'Exit Dialer?',
                              message: 'The auto-dialer queue will be stopped.',
                              confirmLabel: 'Exit',
                              danger: true,
                            )) == true;
            if (canStop && context.mounted) {
              ref.read(dialerProvider.notifier).stop();
              context.pop();
            }
          },
        ),
        const SizedBox(width: 4),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: AppColors.yellow,
            borderRadius: BorderRadius.circular(5),
          ),
          child: const Text('AUTO-DIALER',
              style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 10, letterSpacing: 0.6, color: AppColors.white)),
        ),
        const Spacer(),
        if (state.phase == DialerPhase.inCall || state.phase == DialerPhase.dialing)
          _LivePulse(),
        // Calling a hand-picked list from a break: the break is still on.
        if (!state.onBreak && ref.watch(workSessionProvider).onBreak) ...[
          const SizedBox(width: 8),
          const TagChip(label: 'ON BREAK', backgroundColor: AppColors.warning, textColor: AppColors.white),
        ] else
        // Break toggle — only between calls (not while dialing or in a call).
        if (state.mode == DialerMode.queue &&
            state.phase != DialerPhase.inCall &&
            state.phase != DialerPhase.dialing &&
            state.phase != DialerPhase.postCall) ...[
          const SizedBox(width: 8),
          GestureDetector(
            // One break for the whole app — see work/work_session.dart.
            onTap: () {
              final work = ref.read(workSessionProvider.notifier);
              if (state.onBreak) {
                work.endBreak();
              } else {
                work.takeBreak(reason: 'Break from auto-dialer');
              }
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
              decoration: BoxDecoration(
                color: state.onBreak ? AppColors.success : AppColors.purple,
                border: Border.all(color: AppColors.line, width: 1),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(state.onBreak ? Icons.play_arrow : Icons.free_breakfast,
                    size: 14, color: AppColors.white),
                const SizedBox(width: 4),
                Text(state.onBreak ? 'END BREAK' : 'BREAK',
                    style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 10, color: AppColors.white, letterSpacing: 0.4)),
              ]),
            ),
          ),
        ],
        if (state.mode == DialerMode.queue &&
            !state.onBreak &&
            state.phase != DialerPhase.completed &&
            state.phase != DialerPhase.postCall) ...[
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () {
              if (state.phase == DialerPhase.paused) {
                ref.read(dialerProvider.notifier).resume();
              } else {
                ref.read(dialerProvider.notifier).pause();
              }
            },
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: state.phase == DialerPhase.paused ? AppColors.success : AppColors.warning,
                border: Border.all(color: AppColors.line, width: 1),
              ),
              child: Icon(
                state.phase == DialerPhase.paused ? Icons.play_arrow : Icons.pause,
                size: 16, color: AppColors.white,
              ),
            ),
          ),
        ],
      ]),
    );
  }
}

class _LivePulse extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(
        width: 8, height: 8,
        decoration: const BoxDecoration(color: AppColors.error, shape: BoxShape.circle),
      ).animate(onPlay: (c) => c.repeat()).fade(begin: 1, end: 0.3, duration: 800.ms),
      const SizedBox(width: 6),
      const Text('LIVE',
          style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 11, color: AppColors.error, letterSpacing: 0.5)),
    ]);
  }
}

// ─── QUEUE PROGRESS ─────────────────────────────────────────
class _QueueProgress extends StatelessWidget {
  final DialerState state;
  const _QueueProgress({required this.state});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: const BoxDecoration(
        color: AppColors.white,
        border: Border(bottom: BorderSide(color: AppColors.line, width: 1)),
      ),
      child: Column(children: [
        Row(children: [
          Text(
            '${state.currentIndex + 1} / ${state.totalCalls}',
            style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 14),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 10,
              decoration: BoxDecoration(
                color: AppColors.greyLight,
                border: Border.all(color: AppColors.line, width: 1),
              ),
              child: FractionallySizedBox(
                alignment: Alignment.centerLeft,
                widthFactor: state.progress,
                child: Container(color: AppColors.yellow),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Text('${(state.progress * 100).toInt()}%',
              style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 12, color: AppColors.grey)),
        ]),
      ]),
    );
  }
}

// ─── PHASE CONTENT (router) ─────────────────────────────────
class _PhaseContent extends StatelessWidget {
  final DialerState state;
  const _PhaseContent({required this.state});

  @override
  Widget build(BuildContext context) {
    switch (state.phase) {
      case DialerPhase.preCall:
      case DialerPhase.dialing:
        return _PreCallView(state: state);
      case DialerPhase.inCall:
        return _InCallView(state: state);
      case DialerPhase.postCall:
        return _DispositionView(state: state);
      case DialerPhase.paused:
        return _PausedView(state: state);
      case DialerPhase.completed:
        return _CompletedView(state: state);
      case DialerPhase.idle:
      case DialerPhase.disposed:
        return const Center(child: CircularProgressIndicator());
    }
  }
}

// ─── PRE-CALL VIEW ──────────────────────────────────────────
class _PreCallView extends ConsumerWidget {
  final DialerState state;
  const _PreCallView({required this.state});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lead = state.currentLead;
    if (lead == null) return const SizedBox.shrink();

    final isDialing = state.phase == DialerPhase.dialing;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        // Big animated lead card
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: AppColors.yellowGradient,
            border: Border.all(color: AppColors.line, width: 1),
            boxShadow: const [BoxShadow(color: Color(0x33111A16), offset: Offset(0, 12), blurRadius: 28, spreadRadius: -14)],
          ),
          child: Column(children: [
            BrutalAvatar(name: lead.name, size: 80),
            const SizedBox(height: 14),
            Text(lead.name, style: AppTextStyles.h1, textAlign: TextAlign.center),
            const SizedBox(height: 4),
            Text(Fmt.displayPhone(lead.phone),
                style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 16, letterSpacing: 0.3)),
            const SizedBox(height: 12),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 6, runSpacing: 6,
              children: [
                StatusBadge(status: lead.status, label: lead.statusDisplay),
                PriorityBadge(priority: lead.priority),
                if (lead.city.isNotEmpty) TagChip(label: lead.city, backgroundColor: AppColors.white),
                if (lead.isDnd) const TagChip(label: 'DND', backgroundColor: AppColors.error, textColor: AppColors.white),
              ],
            ),
          ]),
        ).animate().scale(begin: const Offset(0.85, 0.85), curve: Curves.easeOutBack, duration: 400.ms),

        if (state.error != null) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.white,
              border: Border.all(color: AppColors.error, width: 1),
            ),
            child: Text(state.error!,
                style: const TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 12, color: AppColors.error)),
          ),
        ],

        const SizedBox(height: 28),

        LeadBasicsCard(lead: lead),
        const SizedBox(height: 12),

        LeadCustomFields(lead: lead, compact: true, title: 'What we know'),
        const SizedBox(height: 16),

        if (lead.requirement.isNotEmpty) ...[
          BrutalCard(
            padding: const EdgeInsets.all(14),
            color: AppColors.cream,
            child: Row(children: [
              const Icon(Icons.info_outline, size: 16, color: AppColors.warning),
              const SizedBox(width: 8),
              Expanded(child: Text(lead.requirement, style: AppTextStyles.body, maxLines: 3, overflow: TextOverflow.ellipsis)),
            ]),
          ),
          const SizedBox(height: 16),
        ],

        // Status
        if (isDialing) ...[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.successBg,
              border: Border.all(color: AppColors.success, width: 1),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.phone_callback, color: AppColors.success, size: 18),
              const SizedBox(width: 10),
              Text(
                'Dialing ${Fmt.displayPhone(lead.phone)}…',
                style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.success),
              ),
            ]),
          ).animate(onPlay: (c) => c.repeat(reverse: true)).fade(begin: 1, end: 0.5, duration: 1.seconds),
        ] else ...[
          BrutalButton(
            label: 'CALL NOW',
            iconData: Icons.phone,
            backgroundColor: AppColors.success,
            textColor: AppColors.white,
            isFullWidth: true,
            shadowOffset: 5,
            onPressed: () => ref.read(dialerProvider.notifier).dialCurrent(),
          ),
        ],

        const SizedBox(height: 12),

        Row(children: [
          Expanded(child: BrutalButton.secondary(
            label: 'SKIP',
            iconData: Icons.skip_next,
            isFullWidth: true,
            onPressed: () => ref.read(dialerProvider.notifier).skip(),
          )),
          if (state.mode == DialerMode.queue) ...[
            const SizedBox(width: 10),
            Expanded(child: BrutalButton.yellow(
              label: 'PAUSE',
              iconData: Icons.pause,
              isFullWidth: true,
              onPressed: () => ref.read(dialerProvider.notifier).pause(),
            )),
          ],
        ]),
      ]),
    );
  }
}

// ─── IN-CALL VIEW ───────────────────────────────────────────
class _InCallView extends ConsumerStatefulWidget {
  final DialerState state;
  const _InCallView({required this.state});

  @override
  ConsumerState<_InCallView> createState() => _InCallViewState();
}

class _InCallViewState extends ConsumerState<_InCallView> {
  final _notesCtrl = TextEditingController();

  @override
  void dispose() {
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final lead = widget.state.currentLead;
    final call = widget.state.currentCall;
    if (lead == null || call == null) return const SizedBox.shrink();

    return StreamBuilder<PhoneCallEvent>(
      stream: PhoneService.instance.events,
      builder: (ctx, snap) {
        final duration = snap.data?.durationSec ?? call.durationSec;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            // Big timer card
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: AppColors.successGradient,
                border: Border.all(color: AppColors.line, width: 1),
                boxShadow: const [BoxShadow(color: Color(0x33111A16), offset: Offset(0, 12), blurRadius: 28, spreadRadius: -14)],
              ),
              child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.center, children: const [
                  Icon(Icons.phone_in_talk, color: AppColors.white, size: 18),
                  SizedBox(width: 8),
                  Text('ON CALL',
                      style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.white, letterSpacing: 1.2)),
                ]),
                const SizedBox(height: 12),
                Text(
                  Fmt.timer(duration),
                  style: const TextStyle(
                    fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 48,
                    color: AppColors.white, letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 8),
                Text(lead.name, style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 18, color: AppColors.white)),
                Text(Fmt.displayPhone(lead.phone),
                    style: TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 13, color: AppColors.white.withOpacity(0.85))),
              ]),
            ),

            const SizedBox(height: 20),

            // While the call is live. This is where the agent needs the lead's
            // answers most — in front of them mid-conversation, not on a
            // screen they would have to leave the call to reach.
            LeadBasicsCard(lead: lead),
            const SizedBox(height: 12),

            LeadCustomFields(lead: lead, compact: true, title: 'What we know'),
            const SizedBox(height: 12),

            // Quick notes
            BrutalCard(
              padding: const EdgeInsets.all(12),
              color: AppColors.white,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('LIVE NOTES', style: AppTextStyles.label),
                const SizedBox(height: 8),
                TextField(
                  controller: _notesCtrl,
                  maxLines: 3,
                  minLines: 2,
                  onChanged: (v) => ref.read(dialerProvider.notifier).updateCallNotes(v),
                  style: const TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 14),
                  decoration: const InputDecoration(
                    hintText: 'Type notes during the call…',
                    hintStyle: TextStyle(fontFamily: 'PlusJakartaSans', color: AppColors.grey, fontSize: 13),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.zero,
                  ),
                ),
              ]),
            ),

            const SizedBox(height: 14),

            // The Cloudinary voice note was removed with its settings: the call
            // itself is recorded and uploaded by CallRecordingService.
            BrutalButton(
              label: 'END CALL',
              iconData: Icons.call_end,
              backgroundColor: AppColors.error,
              textColor: AppColors.white,
              isFullWidth: true,
              onPressed: () {
                HapticFeedback.heavyImpact();
                ref.read(dialerProvider.notifier).markCallEnded(
                  durationSec: duration,
                  wasConnected: duration > 5,
                );
              },
            ),
          ]),
        );
      },
    );
  }
}

// ─── DISPOSITION VIEW (MANDATORY) ───────────────────────────
/// The call outcomes, fetched fresh each time the disposition view opens.
///
/// This was a plain FutureProvider, which caches its FIRST result for the life
/// of the app — including a failure. One miss (the phone coming back from a
/// call before the network does, or a token refresh mid-call) left every later
/// call stuck on "Failed to load dispositions" until the app was killed.
/// Now it re-fetches, retries once, and falls back to the last list that did
/// load, so an agent can always finish a call.
final dispositionsProvider = FutureProvider.autoDispose<List<CallDisposition>>(
  (_) => CallsService.instance.getDispositionsResilient(),
);

class _DispositionView extends ConsumerStatefulWidget {
  final DialerState state;
  const _DispositionView({required this.state});

  @override
  ConsumerState<_DispositionView> createState() => _DispositionViewState();
}

class _DispositionViewState extends ConsumerState<_DispositionView> {
  CallDisposition? _selected;
  final _notesCtrl = TextEditingController();
  bool _scheduleFollowup = false;
  DateTime? _followupDate;
  bool _saving = false;
  /// Was the call answered? From the phone's call log when it could be read;
  /// null when it couldn't — the agent must say before an outcome is offered.
  bool? _wasConnected;

  @override
  void initState() {
    super.initState();
    final call = widget.state.currentCall;
    _wasConnected = call == null || call.outcomeSource == 'estimate' ? null : call.wasConnected;
    _notesCtrl.text = call?.notes ?? '';
  }

  /// Answered and unanswered calls have different outcomes; changing the
  /// answer clears an outcome picked from the other list.
  void _setConnected(bool v) {
    if (_wasConnected == v) return;
    HapticFeedback.selectionClick();
    setState(() {
      _wasConnected = v;
      if (_selected != null && _selected!.isConnectedOutcome != v) _selected = null;
    });
  }

  @override
  void dispose() {
    _notesCtrl.dispose();
    super.dispose();
  }

  bool _ready() {
    if (_wasConnected == null) {
      AppToast.show(context, 'Say whether the call was answered', isError: true);
      return false;
    }
    if (_selected == null) {
      AppToast.show(context, 'Select a disposition', isError: true);
      return false;
    }
    return true;
  }

  /// "Save & break": save this call, hold the queue on the next lead instead
  /// of dialling it, and go on break. There was no way to take a break in a
  /// queue except between calls — and between calls the next one was already
  /// being dialled — so an agent had to finish the whole queue first.
  Future<void> _saveAndBreak() async {
    if (!_ready()) return;
    final reason = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 4),
            child: Text('Save & take a break', style: AppTextStyles.h4),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text('This call is saved and the queue waits. The next number is dialled when you end the break.',
                style: AppTextStyles.caption),
          ),
          for (final r in breakReasons)
            ListTile(
              leading: const Icon(Icons.free_breakfast_outlined),
              title: Text(r),
              onTap: () => Navigator.of(ctx).pop(r),
            ),
          const SizedBox(height: 8),
        ]),
      ),
    );
    if (reason == null || !mounted) return; // changed their mind: nothing saved
    await _save(breakReason: reason);
  }

  Future<void> _save({String? breakReason}) async {
    if (!_ready()) return;
    final takingBreak = breakReason != null;
    setState(() => _saving = true);

    // Save disposition + call to backend. Stay here if it did not save.
    final leadId = widget.state.currentCall!.leadId;
    final saved = await ref.read(dialerProvider.notifier).dispose_(
      dispositionId: _selected!.id,
      dispositionName: _selected!.name,
      notes: _notesCtrl.text,
      wasConnected: _wasConnected!,
      holdNext: takingBreak,
    );
    if (!saved) {
      if (mounted) {
        setState(() => _saving = false);
        AppToast.show(context,
            ref.read(dialerProvider).error ?? 'Could not save this call. Check your connection and try again.',
            isError: true);
      }
      return;
    }

    // The follow-up the agent chose. The server books one automatically only
    // for Busy, Call back later and Voicemail; one scheduled here replaces it.
    // For any other outcome this is the only follow-up there is.
    if (_scheduleFollowup && _followupDate != null) {
      try {
        await LeadsService.instance.createFollowup(
          leadId,
          {
            'followup_type': 'call',
            'scheduled_at': _followupDate!.toUtc().toIso8601String(),
            'notes': _notesCtrl.text,
          },
        );
      } catch (_) {}
    }
    // Either way this lead now has a follow-up the phone should ring for.
    unawaited(NotificationService.instance.syncFollowupReminders());

    if (takingBreak) {
      // The call is saved and the queue is paused on the next lead; now the
      // break itself (reported on Live Agents and the Login Report).
      final onBreak = await ref.read(workSessionProvider.notifier).takeBreak(reason: breakReason);
      if (mounted) {
        setState(() => _saving = false);
        AppToast.show(
          context,
          onBreak
              ? 'Call saved. You are on break — the queue is paused.'
              : 'Call saved and the queue paused, but the break could not start. Try Break again.',
          isSuccess: onBreak,
          isError: !onBreak,
        );
      }
      return;
    }

    if (mounted) {
      setState(() => _saving = false);
      AppToast.show(context, 'Call disposed', isSuccess: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lead = widget.state.currentLead;
    final call = widget.state.currentCall;
    if (lead == null || call == null) return const SizedBox.shrink();
    final dispositionsAsync = ref.watch(dispositionsProvider);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        // Mandatory banner
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.warningBg,
            border: Border.all(color: AppColors.warning, width: 1),
            boxShadow: const [BoxShadow(color: Color(0x1F111A16), offset: Offset(0, 6), blurRadius: 18, spreadRadius: -8)],
          ),
          child: Row(children: const [
            Icon(Icons.warning_amber_rounded, color: AppColors.warning, size: 22),
            SizedBox(width: 10),
            Expanded(child: Text(
              'Disposition required before next call',
              style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 13, color: Color(0xFFB24A09)),
            )),
          ]),
        ),

        const SizedBox(height: 14),

        // Call summary
        BrutalCard(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(
              width: 50, height: 50,
              decoration: BoxDecoration(
                color: AppColors.hot,
                borderRadius: BorderRadius.circular(11),
              ),
              child: const Icon(Icons.call_end, color: AppColors.white, size: 24),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(lead.name, style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 16, color: AppColors.text)),
              const SizedBox(height: 2),
              Row(children: [
                Text(
                  Fmt.duration(call.durationSec),
                  style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.yellow),
                ),
                const SizedBox(width: 10),
                if (_wasConnected == true)
                  const TagChip(label: '✓ Answered', backgroundColor: AppColors.success, textColor: AppColors.white)
                else if (_wasConnected == false)
                  const TagChip(label: '✕ Not answered', backgroundColor: AppColors.greyLight)
                else
                  const TagChip(label: '? Confirm below', backgroundColor: AppColors.warningBg),
              ]),
            ])),
          ]),
        ),

        const SizedBox(height: 16),

        // Was the call answered? Asked first: it decides which outcomes are
        // offered. One flat list used to let an unanswered call be saved as
        // "Connected – Interested", which the server then counted as answered.
        BrutalCard(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Was the call answered? *', style: AppTextStyles.bodyMedium),
            if (widget.state.currentCall?.outcomeSource == 'estimate')
              const Text('Could not read this from the phone — please choose.',
                  style: AppTextStyles.caption),
            const SizedBox(height: 8),
            AnsweredToggle(value: _wasConnected, onChanged: _setConnected),
          ]),
        ),

        const SizedBox(height: 16),

        // Disposition selection
        const Text('CALL OUTCOME *', style: AppTextStyles.label),
        const SizedBox(height: 8),

        dispositionsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, __) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Could not load call outcomes: ${ApiClient.errorMessage(e)}',
                style: const TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 12, color: AppColors.error)),
            const SizedBox(height: 8),
            BrutalButton.secondary(
              label: 'RETRY',
              iconData: Icons.refresh,
              onPressed: () => ref.invalidate(dispositionsProvider),
            ),
          ]),
          data: (all) {
            if (_wasConnected == null) {
              return const Padding(
                padding: EdgeInsets.all(12),
                child: Text('Choose Answered or Not answered first.',
                    style: TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 12, color: AppColors.grey)),
              );
            }
            // Only the outcomes for this kind of call.
            final dispositions = all.where((d) => d.isConnectedOutcome == _wasConnected).toList();
            if (dispositions.isEmpty) {
              return const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'No dispositions configured. Ask admin to seed them.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 12, color: AppColors.grey),
                ),
              );
            }
            // One dropdown instead of a chip per outcome: a tenant with a
            // dozen dispositions used to fill the screen with them, pushing
            // the notes and the save button below the fold.
            return DropdownButtonFormField<int>(
              // Re-created when the list itself changes (e.g. after RETRY).
              key: ValueKey('$_wasConnected-${dispositions.map((d) => d.id).join(',')}'),
              initialValue: dispositions.any((d) => d.id == _selected?.id) ? _selected!.id : null,
              isExpanded: true,
              menuMaxHeight: 360,
              borderRadius: BorderRadius.circular(12),
              hint: const Text('Choose the call outcome'),
              icon: const Icon(Icons.keyboard_arrow_down_rounded),
              decoration: InputDecoration(
                prefixIcon: _selected == null
                    ? const Icon(Icons.flag_outlined, color: AppColors.text3)
                    : Icon(_selected!.isPositive ? Icons.thumb_up : Icons.thumb_down,
                        size: 18, color: _selected!.isPositive ? AppColors.success : AppColors.error),
                helperText: _selected == null ? null : _selected!.effectLine,
              ),
              items: dispositions.map((d) => DropdownMenuItem<int>(
                value: d.id,
                child: Row(children: [
                  Icon(d.isPositive ? Icons.thumb_up : Icons.thumb_down, size: 14,
                      color: d.isPositive ? AppColors.success : AppColors.error),
                  const SizedBox(width: 10),
                  Expanded(child: Text(d.name, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w600,
                          fontSize: 14, color: AppColors.text))),
                ]),
              )).toList(),
              // The selected value shows its name only; the field's own icon
              // already says positive or negative.
              selectedItemBuilder: (_) => dispositions.map((d) => Align(
                alignment: Alignment.centerLeft,
                child: Text(d.name, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700,
                        fontSize: 14, color: AppColors.text)),
              )).toList(),
              onChanged: (id) {
                HapticFeedback.selectionClick();
                setState(() {
                  _selected = dispositions.firstWhere((d) => d.id == id);
                  // "Call back later": offer the exact time straight away.
                  // Left empty, the server books it in the outcome's default
                  // hours (only Busy, Call back later and Voicemail book one).
                  if (_selected!.slug == 'callback') _scheduleFollowup = true;
                });
              },
            );
          },
        ),

        const SizedBox(height: 16),

        // Notes
        BrutalTextField(
          label: 'Call Notes',
          hint: 'What did the lead say? Outcome details…',
          controller: _notesCtrl,
          maxLines: 4, minLines: 3,
        ),

        const SizedBox(height: 14),

        // Schedule follow-up
        BrutalCard(
          padding: const EdgeInsets.all(12),
          color: _scheduleFollowup ? AppColors.warningBg : AppColors.white,
          child: Column(children: [
            Row(children: [
              const Expanded(child: Text('📅 Schedule a follow-up call', style: AppTextStyles.bodyBold)),
              Switch(
                value: _scheduleFollowup,
                onChanged: (v) => setState(() => _scheduleFollowup = v),
                activeColor: AppColors.warning,
              ),
            ]),
            if (_scheduleFollowup) ...[
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: BrutalButton.secondary(
                  label: '+1 hour',
                  isFullWidth: true,
                  onPressed: () => setState(() => _followupDate = DateTime.now().add(const Duration(hours: 1))),
                )),
                const SizedBox(width: 6),
                Expanded(child: BrutalButton.secondary(
                  label: 'Tomorrow',
                  isFullWidth: true,
                  onPressed: () => setState(() => _followupDate = DateTime.now().add(const Duration(days: 1))),
                )),
                const SizedBox(width: 6),
                Expanded(child: BrutalButton.secondary(
                  label: 'Pick',
                  isFullWidth: true,
                  onPressed: () async {
                    final date = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now().add(const Duration(days: 1)),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (date != null && mounted) {
                      final time = await showTimePicker(
                        context: context,
                        initialTime: const TimeOfDay(hour: 10, minute: 0),
                      );
                      if (time != null) {
                        setState(() => _followupDate = DateTime(date.year, date.month, date.day, time.hour, time.minute));
                      }
                    }
                  },
                )),
              ]),
              if (_followupDate != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Row(children: [
                    const Icon(Icons.event, size: 13, color: AppColors.warning),
                    const SizedBox(width: 4),
                    Text(
                      Fmt.dateTime(_followupDate!.toIso8601String()),
                      style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 12, color: AppColors.warning),
                    ),
                  ]),
                ),
            ],
          ]),
        ),

        const SizedBox(height: 20),

        // In an auto-dial queue the agent can stop after this call. Not for a
        // single call (nothing comes next), nor for a list being called by
        // hand on a break (already on one).
        if (widget.state.mode == DialerMode.queue && !ref.watch(workSessionProvider).onBreak)
          Row(children: [
            Expanded(child: BrutalButton(
              label: 'SAVE & BREAK',
              iconData: Icons.free_breakfast,
              backgroundColor: AppColors.warningBg,
              textColor: AppColors.warning,
              isFullWidth: true,
              shadowOffset: 5,
              onPressed: _saving ? null : _saveAndBreak,
            )),
            const SizedBox(width: 10),
            Expanded(child: BrutalButton(
              label: 'SAVE & NEXT →',
              iconData: Icons.check,
              backgroundColor: AppColors.black,
              textColor: AppColors.white,
              isFullWidth: true,
              shadowOffset: 5,
              isLoading: _saving,
              onPressed: _saving ? null : () => _save(),
            )),
          ])
        else
          BrutalButton(
            label: widget.state.mode == DialerMode.queue ? 'SAVE & NEXT →' : 'SAVE DISPOSITION',
            iconData: Icons.check,
            backgroundColor: AppColors.black,
            textColor: AppColors.white,
            isFullWidth: true,
            shadowOffset: 5,
            isLoading: _saving,
            onPressed: _saving ? null : () => _save(),
          ),
      ]),
    );
  }
}

// ─── PAUSED VIEW ────────────────────────────────────────────
class _PausedView extends ConsumerWidget {
  final DialerState state;
  const _PausedView({required this.state});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.warningBg,
              border: Border.all(color: AppColors.warning, width: 1),
              boxShadow: const [BoxShadow(color: Color(0x1F111A16), offset: Offset(0, 6), blurRadius: 18, spreadRadius: -8)],
            ),
            child: const Icon(Icons.pause_circle, size: 48, color: AppColors.warning),
          ),
          const SizedBox(height: 16),
          const Text('PAUSED', style: AppTextStyles.h1),
          const SizedBox(height: 4),
          Text(
            '${state.callsDone} of ${state.totalCalls} calls completed',
            style: AppTextStyles.body.copyWith(color: AppColors.grey),
          ),
          if (state.error != null) ...[
            const SizedBox(height: 12),
            Text(state.error!, textAlign: TextAlign.center,
                style: const TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 12, color: AppColors.error)),
          ],
          const SizedBox(height: 28),
          // No auto-dialling on a break: ending the break comes first.
          if (ref.watch(workSessionProvider).onBreak) ...[
            const Text('You are on a break', style: AppTextStyles.h5),
            const SizedBox(height: 10),
            BrutalButton(
              label: 'END BREAK & RESUME',
              iconData: Icons.play_arrow,
              backgroundColor: AppColors.success,
              textColor: AppColors.white,
              isFullWidth: false,
              onPressed: () async {
                await ref.read(workSessionProvider.notifier).endBreak();
                ref.read(dialerProvider.notifier).resume();
              },
            ),
          ] else
            BrutalButton(
              label: 'RESUME QUEUE',
              iconData: Icons.play_arrow,
              backgroundColor: AppColors.success,
              textColor: AppColors.white,
              isFullWidth: false,
              onPressed: () => ref.read(dialerProvider.notifier).resume(),
            ),
        ]),
      ),
    );
  }
}

// ─── COMPLETED VIEW ─────────────────────────────────────────
class _CompletedView extends ConsumerWidget {
  final DialerState state;
  const _CompletedView({required this.state});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final connected = state.completedCalls.where((c) => c.wasConnected).length;
    final connRate = state.completedCalls.isEmpty ? 0 : ((connected / state.completedCalls.length) * 100).round();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: AppColors.successGradient,
            border: Border.all(color: AppColors.line, width: 1),
            boxShadow: const [BoxShadow(color: Color(0x33111A16), offset: Offset(0, 12), blurRadius: 28, spreadRadius: -14)],
          ),
          child: Column(children: const [
            Icon(Icons.check_circle, size: 60, color: AppColors.white),
            SizedBox(height: 12),
            Text(
              'QUEUE COMPLETE',
              style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 22, color: AppColors.white, letterSpacing: 0.5),
            ),
          ]),
        ).animate().scale(begin: const Offset(0.7, 0.7), curve: Curves.easeOutBack),

        // Why it ended early: the queue was switched off or deleted, or the
        // agent was taken off it.
        if (state.error != null) ...[
          const SizedBox(height: 16),
          Text(state.error!, textAlign: TextAlign.center,
              style: const TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 13, color: AppColors.error)),
        ],

        const SizedBox(height: 24),
        // Summary stats
        Row(children: [
          Expanded(child: StatCard(
            label: 'Total Calls', value: '${state.completedCalls.length}', icon: Icons.call,
            accentColor: AppColors.info,
          )),
          const SizedBox(width: 10),
          Expanded(child: StatCard(
            label: 'Connected', value: '$connected', icon: Icons.check,
            accentColor: AppColors.success,
          )),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: StatCard(
            label: 'Connect Rate', value: '$connRate%', icon: Icons.percent,
            accentColor: AppColors.warning,
          )),
          const SizedBox(width: 10),
          Expanded(child: StatCard(
            label: 'Total Time',
            value: Fmt.duration(state.completedCalls.fold(0, (s, c) => s + c.durationSec)),
            icon: Icons.timer, accentColor: AppColors.purple,
          )),
        ]),
        const SizedBox(height: 24),
        BrutalButton.primary(
          label: 'DONE',
          isFullWidth: true,
          onPressed: () {
            ref.read(dialerProvider.notifier).stop();
            context.pop();
          },
        ),
      ]),
    );
  }
}
