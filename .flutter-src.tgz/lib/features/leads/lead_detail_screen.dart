import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/services/notification_service.dart';
import '../../core/services/whatsapp_service.dart';
import '../../core/theme/colors.dart';
import '../../core/utils/utils.dart';
import '../../core/widgets/widgets.dart';
import '../../data/models/models.dart';
import 'lead_custom_fields.dart';
import '../../data/services/services.dart';
import '../auth/auth_provider.dart';
import '../dialer/dialer_state.dart';
import '../../data/services/api_client.dart';
import '../calls/call_outcome_sheet.dart';

final _leadDetailProvider = FutureProvider.autoDispose.family<Lead, int>((_, id) => LeadsService.instance.getLead(id));
final _notesProvider = FutureProvider.autoDispose.family<List<LeadNote>, int>((_, id) => LeadsService.instance.listNotes(id).then((r) => r.results));
final _followupsProvider = FutureProvider.autoDispose.family<List<FollowUp>, int>((_, id) => LeadsService.instance.listFollowups(id).then((r) => r.results));
final _callsForLeadProvider = FutureProvider.autoDispose.family<List<CallLog>, int>((_, id) => CallsService.instance.listCalls(leadId: id.toString()).then((r) => r.results));

class LeadDetailScreen extends ConsumerStatefulWidget {
  final int leadId;
  const LeadDetailScreen({super.key, required this.leadId});

  @override
  ConsumerState<LeadDetailScreen> createState() => _LeadDetailScreenState();
}

class _LeadDetailScreenState extends ConsumerState<LeadDetailScreen> with SingleTickerProviderStateMixin {
  late TabController _tab;
  final _noteCtrl = TextEditingController();
  static const _tabs = ['Overview', 'Notes', 'Follow-ups', 'Calls'];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: _tabs.length, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _callLead(Lead lead) async {
    HapticFeedback.heavyImpact();
    await ref.read(dialerProvider.notifier).startSingleCall(lead);
    if (mounted) {
      await context.push('/dialer');
      // Refresh lead data after returning from dialer — the backend will have
      // advanced the status (e.g. new → attempted) when the call was logged.
      ref.invalidate(_leadDetailProvider(lead.id));
      ref.invalidate(_callsForLeadProvider(lead.id));
    }
  }

  Future<void> _whatsAppLead(Lead lead) async {
    final mode = await UserPrefs.getWhatsAppMode();
    if (!mounted) return;
    if (mode == 'cloud') {
      context.push('/leads/${lead.id}/whatsapp');
    } else {
      // Native — quick dialog with custom message
      _showNativeWAQuick(lead);
    }
  }

  void _showNativeWAQuick(Lead lead) {
    final msgCtrl = TextEditingController();
    showBrutalBottomSheet(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: AppColors.successBg, border: Border.all(color: AppColors.success, width: 1)),
              child: const Icon(Icons.chat_bubble, color: AppColors.success, size: 20),
            ),
            const SizedBox(width: 10),
            const Expanded(child: Text('Open in WhatsApp', style: AppTextStyles.h3)),
            const TagChip(label: 'NATIVE'),
          ]),
          const SizedBox(height: 14),
          Text(Fmt.displayPhone(lead.phone), style: AppTextStyles.mono),
          const SizedBox(height: 14),
          BrutalTextField(controller: msgCtrl, label: 'Message (optional)', hint: 'Type a quick message…', maxLines: 3),
          const SizedBox(height: 16),
          BrutalButton(
            label: 'OPEN WHATSAPP →',
            iconData: Icons.open_in_new,
            backgroundColor: AppColors.success, textColor: AppColors.white,
            isFullWidth: true,
            onPressed: () async {
              Navigator.pop(ctx);
              final ok = await WhatsAppService.instance.sendNative(
                phoneNumber: lead.phone,
                message: msgCtrl.text.isEmpty ? null : msgCtrl.text,
              );
              // Leave a trace on the lead — see LogNativeWhatsAppView.
              if (ok) {
                unawaited(WhatsAppService.instance.logNativeOpen(leadId: lead.id, message: msgCtrl.text));
              }
              if (mounted) {
                if (!ok) AppToast.show(context, 'WhatsApp not installed', isError: true);
              }
            },
          ),
        ]),
      ),
    );
  }

  Future<void> _updateStatus(int id, String status) async {
    // Lost / Invalid need a reason, and a sale a note (the server checks).
    String? reason;
    if (const ['lost', 'invalid', 'converted'].contains(status)) {
      reason = await _askReason(status);
      if (reason == null) return;
    }
    try {
      await LeadsService.instance.updateStatus(id, status, reason: reason);
      ref.invalidate(_leadDetailProvider(id));
      if (mounted) AppToast.show(context, 'Status updated', isSuccess: true);
    } catch (e) {
      if (mounted) AppToast.show(context, ApiClient.errorMessage(e), isError: true);
    }
  }

  Future<String?> _askReason(String status) {
    final ctrl = TextEditingController();
    final label = Fmt.leadStatusLabels[status] ?? status;
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Move to $label'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          maxLines: 3,
          decoration: InputDecoration(
            hintText: status == 'converted' ? 'What was sold / order number' : 'Reason',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              if (status != 'converted' && ctrl.text.trim().isEmpty) return;
              Navigator.pop(ctx, ctrl.text.trim());
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _addNote(int id) async {
    if (_noteCtrl.text.trim().isEmpty) return;
    try {
      await LeadsService.instance.createNote(id, _noteCtrl.text.trim());
      _noteCtrl.clear();
      ref.invalidate(_notesProvider(id));
      if (mounted) AppToast.show(context, 'Note added', isSuccess: true);
    } catch (e) {
      if (mounted) AppToast.show(context, ApiClient.errorMessage(e), isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(_leadDetailProvider(widget.leadId));
    return async.when(
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.yellow))),
      error: (e, _) => LeadUnavailableView(
        error: e,
        onRetry: () => ref.invalidate(_leadDetailProvider(widget.leadId)),
      ),
      data: (lead) => _build(lead),
    );
  }

  Widget _build(Lead lead) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: NestedScrollView(
        headerSliverBuilder: (_, __) => [
          SliverAppBar(
            pinned: true, expandedHeight: 200, backgroundColor: AppColors.white,
            leading: IconButton(icon: const Icon(Icons.arrow_back, color: AppColors.black), onPressed: () => context.pop()),
            actions: [
              IconButton(icon: const Icon(Icons.edit_outlined, color: AppColors.black), onPressed: () => context.push('/leads/${lead.id}/edit')),
              PopupMenuButton<String>(
                icon: const Icon(Icons.more_vert, color: AppColors.black),
                shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10)), side: BorderSide(color: AppColors.line, width: 1)),
                onSelected: (v) {
                  if (v == 'copy') {
                    Clipboard.setData(ClipboardData(text: lead.phone));
                    AppToast.show(context, 'Phone copied');
                  }
                  if (v == 'sms') {
                    // launch SMS
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'copy', child: Text('Copy Phone')),
                  PopupMenuItem(value: 'sms', child: Text('Send SMS')),
                ],
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(background: _Header(lead: lead, onStatus: _updateStatus)),
            bottom: TabBar(controller: _tab, isScrollable: true, tabs: _tabs.map((t) => Tab(text: t)).toList()),
          ),
        ],
        body: TabBarView(controller: _tab, children: [
          _OverviewTab(lead: lead),
          _NotesTab(leadId: lead.id, noteCtrl: _noteCtrl, onAdd: () => _addNote(lead.id)),
          _FollowupsTab(leadId: lead.id),
          _CallsTab(leadId: lead.id),
        ]),
      ),
      bottomNavigationBar: _ActionBar(lead: lead, onCall: () => _callLead(lead), onWhatsApp: () => _whatsAppLead(lead)),
    );
  }
}

// ─── Header ─────────────────────────────────────────────────
class _Header extends StatelessWidget {
  final Lead lead;
  final Function(int, String) onStatus;
  const _Header({required this.lead, required this.onStatus});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 70, 16, 0),
      color: AppColors.white,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          BrutalAvatar(name: lead.name, size: 60),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(lead.name, style: AppTextStyles.h2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            Text(Fmt.displayPhone(lead.phone), style: AppTextStyles.monoLg.copyWith(fontSize: 13, color: AppColors.greyDark)),
            const SizedBox(height: 6),
            Wrap(spacing: 6, runSpacing: 4, children: [
              StatusBadge(status: lead.status, label: lead.statusDisplay, large: true),
              PriorityBadge(priority: lead.priority),
              if (lead.isDnd) const TagChip(label: 'DND', backgroundColor: AppColors.error, textColor: AppColors.white),
            ]),
          ])),
        ]),
        const SizedBox(height: 10),
        SizedBox(height: 32, child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: Fmt.leadStatusLabels.entries.take(6).map((e) {
            final active = lead.status == e.key;
            return GestureDetector(
              onTap: () => onStatus(lead.id, e.key),
              child: Container(
                margin: const EdgeInsets.only(right: 6),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: active ? AppColors.black : AppColors.white,
                  border: Border.all(color: active ? AppColors.brand : AppColors.line, width: active ? 1.5 : 1),
                ),
                child: Text(e.value,
                    style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 10, color: active ? AppColors.white : AppColors.dark)),
              ),
            );
          }).toList()),
        )),
      ]),
    );
  }
}

// ─── Overview Tab ───────────────────────────────────────────
class _OverviewTab extends StatelessWidget {
  final Lead lead;
  const _OverviewTab({required this.lead});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        BrutalCard(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SectionHeader(title: 'Contact', icon: Icons.contact_mail),
          const SizedBox(height: 8), const Divider(),
          InfoRow(label: 'Phone', value: Fmt.displayPhone(lead.phone), icon: Icons.phone),
          if (lead.alternatePhone.isNotEmpty) ...[const Divider(), InfoRow(label: 'Alt Phone', value: Fmt.displayPhone(lead.alternatePhone))],
          const Divider(),
          InfoRow(label: 'Email', value: lead.email.isEmpty ? '—' : lead.email, icon: Icons.mail_outline),
          const Divider(), InfoRow(label: 'City', value: lead.city.isEmpty ? '—' : lead.city, icon: Icons.location_on_outlined),
          const Divider(), InfoRow(label: 'State', value: lead.state.isEmpty ? '—' : lead.state),
          const Divider(), InfoRow(label: 'Source', value: Fmt.sourceLabels[lead.source] ?? lead.source),
          const Divider(), InfoRow(label: 'Assigned To', value: lead.assignedToName ?? '—'),
        ])).animate().fadeIn(),
        const SizedBox(height: 12),
        BrutalCard(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SectionHeader(title: 'Sales', icon: Icons.trending_up),
          const SizedBox(height: 8), const Divider(),
          InfoRow(label: 'Budget', value: lead.budget != null ? Fmt.inr(lead.budget) : '—'),
          const Divider(), InfoRow(label: 'Deal Value', value: lead.dealValue != null ? Fmt.inr(lead.dealValue) : '—'),
          const Divider(),
          Row(children: [
            const Expanded(flex: 2, child: Text('SCORE', style: AppTextStyles.label)),
            Expanded(flex: 3, child: ScoreBar(score: lead.score)),
          ]),
          // Dials vs answered: the stage alone can't tell "never reached"
          // from "spoke to them".
          const Divider(), InfoRow(label: 'Calls', value: lead.dialAttempts == 0
              ? 'Not called yet'
              : '${lead.dialAttempts} dialled · ${lead.connectedCalls} answered'),
          if (lead.dialAttempts > 0) ...[
            const Divider(),
            InfoRow(label: 'Last Call', value: [
              lead.lastCallConnected == true ? 'Answered' : 'Not answered',
              if (lead.lastDispositionName != null) lead.lastDispositionName!,
              Fmt.relative(lead.lastDialedAt),
            ].join(' · ')),
          ],
          const Divider(), InfoRow(label: 'Last Spoke', value: Fmt.relative(lead.lastContactedAt)),
          const Divider(), InfoRow(label: 'Next F/U', value: lead.nextFollowupAt != null ? Fmt.dateTime(lead.nextFollowupAt) : '—'),
          const Divider(), InfoRow(label: 'Created', value: Fmt.date(lead.createdAt)),
        ])).animate().fadeIn(delay: 100.ms),
        // Custom fields: what the team qualifies on. Sent by the server on
        // this endpoint all along and never shown.
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: LeadCustomFields(lead: lead),
        ),
        if (lead.requirement.isNotEmpty) ...[
          const SizedBox(height: 12),
          BrutalCard(padding: const EdgeInsets.all(16), color: AppColors.cream, borderColor: AppColors.yellow,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SectionHeader(title: 'Requirement', icon: Icons.assignment),
              const SizedBox(height: 10),
              Text(lead.requirement, style: AppTextStyles.bodyLg.copyWith(height: 1.5)),
            ]),
          ).animate().fadeIn(delay: 150.ms),
        ],
        if (lead.tags.isNotEmpty) ...[
          const SizedBox(height: 12),
          BrutalCard(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('TAGS', style: AppTextStyles.label),
            const SizedBox(height: 10),
            Wrap(spacing: 6, runSpacing: 6, children: lead.tags.map((t) => TagChip(label: t)).toList()),
          ])).animate().fadeIn(delay: 200.ms),
        ],
        const SizedBox(height: 100),
      ]),
    );
  }
}

// ─── Notes Tab ──────────────────────────────────────────────
class _NotesTab extends ConsumerWidget {
  final int leadId;
  final TextEditingController noteCtrl;
  final VoidCallback onAdd;
  const _NotesTab({required this.leadId, required this.noteCtrl, required this.onAdd});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(_notesProvider(leadId));
    return Column(children: [
      Container(
        padding: const EdgeInsets.all(12),
        decoration: const BoxDecoration(color: AppColors.white, border: Border(bottom: BorderSide(color: AppColors.line, width: 1))),
        child: Row(children: [
          Expanded(child: BrutalTextField(controller: noteCtrl, hint: 'Add a note…', maxLines: 3, minLines: 1)),
          const SizedBox(width: 10),
          BrutalButton.primary(label: 'Add', isFullWidth: false, onPressed: onAdd, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12)),
        ]),
      ),
      Expanded(child: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => const EmptyStateView(icon: Icons.error_outline, title: 'Failed'),
        data: (notes) => notes.isEmpty
            ? const EmptyStateView(icon: Icons.note_add, title: 'No notes yet', message: 'Add the first note above')
            : ListView.builder(
                padding: const EdgeInsets.all(12), itemCount: notes.length,
                itemBuilder: (_, i) => Padding(padding: const EdgeInsets.only(bottom: 10),
                  child: BrutalCard(
                    padding: const EdgeInsets.all(14),
                    color: notes[i].isPinned ? AppColors.cream : AppColors.white,
                    borderColor: notes[i].isPinned ? AppColors.yellow : AppColors.black,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Text(notes[i].agentName ?? 'System', style: AppTextStyles.h5),
                        if (notes[i].isPinned) const Padding(padding: EdgeInsets.only(left: 6), child: Text('📌', style: TextStyle(fontSize: 12))),
                        const Spacer(),
                        Text(Fmt.relative(notes[i].createdAt), style: AppTextStyles.caption),
                      ]),
                      const SizedBox(height: 8),
                      Text(notes[i].content, style: AppTextStyles.body),
                    ]),
                  ).animate().fadeIn(delay: Duration(milliseconds: i * 50)),
                ),
              ),
      )),
    ]);
  }
}

// ─── Follow-ups Tab ─────────────────────────────────────────
class _FollowupsTab extends ConsumerWidget {
  final int leadId;
  const _FollowupsTab({required this.leadId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(_followupsProvider(leadId));
    return Column(children: [
      Container(
        padding: const EdgeInsets.all(12),
        decoration: const BoxDecoration(color: AppColors.white, border: Border(bottom: BorderSide(color: AppColors.line, width: 1))),
        child: BrutalButton.primary(label: '+ SCHEDULE FOLLOW-UP', iconData: Icons.event, onPressed: () => _showFollowupSheet(context, ref, leadId)),
      ),
      Expanded(child: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => const EmptyStateView(icon: Icons.error_outline, title: 'Failed'),
        data: (followups) => followups.isEmpty
            ? const EmptyStateView(icon: Icons.event_busy, title: 'No follow-ups')
            : ListView.builder(
                padding: const EdgeInsets.all(12), itemCount: followups.length,
                itemBuilder: (_, i) {
                  final fu = followups[i];
                  return Padding(padding: const EdgeInsets.only(bottom: 10), child: BrutalCard(
                    padding: const EdgeInsets.all(14),
                    color: fu.isCompleted ? AppColors.successBg : fu.isOverdue ? AppColors.errorBg : AppColors.white,
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          TagChip(label: fu.followupTypeDisplay.isEmpty ? fu.followupType : fu.followupTypeDisplay),
                          if (fu.isCompleted) const Padding(padding: EdgeInsets.only(left: 6), child: TagChip(label: '✓ Done', backgroundColor: AppColors.success, textColor: AppColors.white)),
                          if (fu.isOverdue && !fu.isCompleted) const Padding(padding: EdgeInsets.only(left: 6), child: TagChip(label: '⚠ Overdue', backgroundColor: AppColors.error, textColor: AppColors.white)),
                        ]),
                        const SizedBox(height: 6),
                        Text(Fmt.dateTime(fu.scheduledAt), style: AppTextStyles.bodyBold),
                        if (fu.notes.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(fu.notes, style: AppTextStyles.caption)),
                      ])),
                      if (!fu.isCompleted) BrutalButton.yellow(
                        label: '✓',
                        isFullWidth: false,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        onPressed: () async {
                          await LeadsService.instance.completeFollowup(fu.id);
                          ref.invalidate(_followupsProvider(leadId));
                          // Its alarms (and hourly overdue chases) are still
                          // armed on the phone until the reminders are rebuilt.
                          unawaited(NotificationService.instance.syncFollowupReminders());
                          if (context.mounted) AppToast.show(context, 'Marked done', isSuccess: true);
                        },
                      ),
                    ]),
                  ).animate().fadeIn(delay: Duration(milliseconds: i * 50)));
                },
              ),
      )),
    ]);
  }

  void _showFollowupSheet(BuildContext context, WidgetRef ref, int leadId) {
    String type = 'call';
    DateTime? when;
    final notesCtrl = TextEditingController();

    showBrutalBottomSheet(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setState) => Padding(
      padding: const EdgeInsets.all(20),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('Schedule Follow-up', style: AppTextStyles.h2),
        const SizedBox(height: 14),
        const Text('TYPE', style: AppTextStyles.label),
        const SizedBox(height: 6),
        Wrap(spacing: 6, children: ['call', 'whatsapp', 'email', 'visit', 'meeting'].map((t) {
          final sel = type == t;
          return GestureDetector(
            onTap: () => setState(() => type = t),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: sel ? AppColors.black : AppColors.white,
                border: Border.all(color: sel ? AppColors.brand : AppColors.line, width: sel ? 1.5 : 1),
              ),
              child: Text(t.toUpperCase(), style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 10, color: sel ? AppColors.white : AppColors.black)),
            ),
          );
        }).toList()),
        const SizedBox(height: 14),
        const Text('WHEN', style: AppTextStyles.label),
        const SizedBox(height: 6),
        Row(children: [
          Expanded(child: BrutalButton.secondary(label: '+1 hour', isFullWidth: true, onPressed: () => setState(() => when = DateTime.now().add(const Duration(hours: 1))))),
          const SizedBox(width: 6),
          Expanded(child: BrutalButton.secondary(label: 'Tomorrow', isFullWidth: true, onPressed: () => setState(() => when = DateTime.now().add(const Duration(days: 1))))),
          const SizedBox(width: 6),
          Expanded(child: BrutalButton.secondary(label: 'Pick', isFullWidth: true, onPressed: () async {
            final d = await showDatePicker(context: ctx, initialDate: DateTime.now().add(const Duration(days: 1)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)));
            if (d != null && ctx.mounted) {
              final t = await showTimePicker(context: ctx, initialTime: const TimeOfDay(hour: 10, minute: 0));
              if (t != null) setState(() => when = DateTime(d.year, d.month, d.day, t.hour, t.minute));
            }
          })),
        ]),
        if (when != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text('Scheduled: ${Fmt.dateTime(when!.toIso8601String())}', style: AppTextStyles.bodyBold.copyWith(color: AppColors.warning))),
        const SizedBox(height: 14),
        BrutalTextField(controller: notesCtrl, label: 'Notes', maxLines: 2),
        const SizedBox(height: 18),
        BrutalButton.primary(label: 'Schedule →', onPressed: when == null ? null : () async {
          try {
            await LeadsService.instance.createFollowup(leadId, {
              'followup_type': type,
              'scheduled_at': when!.toUtc().toIso8601String(),
              'notes': notesCtrl.text.trim(),
            });
            ref.invalidate(_followupsProvider(leadId));
            // Arm its reminder now rather than at the next app resume.
            unawaited(NotificationService.instance.syncFollowupReminders());
            if (ctx.mounted) { Navigator.pop(ctx); AppToast.show(context, 'Follow-up scheduled', isSuccess: true); }
          } catch (e) {
            if (ctx.mounted) AppToast.show(ctx, ApiClient.errorMessage(e), isError: true);
          }
        }),
      ]),
    )));
  }
}

// ─── Calls Tab ──────────────────────────────────────────────
class _CallsTab extends ConsumerWidget {
  final int leadId;
  const _CallsTab({required this.leadId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(_callsForLeadProvider(leadId));
    return async.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (_, __) => const EmptyStateView(icon: Icons.error_outline, title: 'Failed'),
      data: (calls) => calls.isEmpty
          ? const EmptyStateView(icon: Icons.phone_disabled, title: 'No calls yet', message: 'Tap CALL to dial')
          : ListView.builder(padding: const EdgeInsets.all(12), itemCount: calls.length, itemBuilder: (_, i) {
              final c = calls[i];
              return Padding(padding: const EdgeInsets.only(bottom: 10), child: BrutalCard(padding: const EdgeInsets.all(14), child: Row(children: [
                Container(width: 38, height: 38, decoration: BoxDecoration(
                  color: c.isConnected ? AppColors.successBg : AppColors.greyLight,
                  border: Border.all(color: AppColors.line, width: 1),
                ), child: Icon(c.direction == 'outbound' ? Icons.call_made : Icons.call_received,
                    size: 16, color: c.isConnected ? AppColors.success : AppColors.grey)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text(c.durationDisplay, style: AppTextStyles.h5),
                    const SizedBox(width: 8),
                    if (c.isConnected) const TagChip(label: 'Answered', backgroundColor: AppColors.success, textColor: AppColors.white)
                    else const TagChip(label: 'Not answered', backgroundColor: AppColors.greyLight),
                  ]),
                  Padding(padding: const EdgeInsets.only(top: 4), child: c.dispositionName != null
                      ? TagChip(label: c.dispositionName!)
                      : GestureDetector(
                          // Saved without an outcome (click-to-call, a
                          // provider call): set it here.
                          onTap: () async {
                            final updated = await showCallOutcomeSheet(context, c);
                            if (updated != null) {
                              ref.invalidate(_callsForLeadProvider(leadId));
                              ref.invalidate(_leadDetailProvider(leadId));
                            }
                          },
                          child: const TagChip(label: '⚠ Set outcome', backgroundColor: AppColors.warningBg),
                        )),
                  const SizedBox(height: 3),
                  Text(Fmt.relative(c.startedAt), style: AppTextStyles.caption),
                  if (c.notes.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(c.notes, style: AppTextStyles.caption, maxLines: 2, overflow: TextOverflow.ellipsis)),
                  if (c.recordingUrl != null) Padding(padding: const EdgeInsets.only(top: 4), child: Row(children: [
                    const Icon(Icons.mic, size: 12, color: AppColors.purple),
                    const SizedBox(width: 3),
                    const Text('Recording', style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 10, color: AppColors.purple)),
                  ])),
                ])),
              ])).animate().fadeIn(delay: Duration(milliseconds: i * 50)));
            }),
    );
  }
}

// ─── Action Bar (sticky bottom: CALL + WHATSAPP) ────────────
class _ActionBar extends StatelessWidget {
  final Lead lead;
  final VoidCallback onCall, onWhatsApp;
  const _ActionBar({required this.lead, required this.onCall, required this.onWhatsApp});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: const BoxDecoration(
        color: AppColors.white,
        border: Border(top: BorderSide(color: AppColors.line, width: 1)),
        boxShadow: [BoxShadow(color: Color(0x14111A16), offset: Offset(0, -2), blurRadius: 10, spreadRadius: -2)],
      ),
      child: SafeArea(
        child: Row(children: [
          Expanded(child: BrutalButton(
            label: 'CALL',
            iconData: Icons.phone,
            backgroundColor: AppColors.success, textColor: AppColors.white,
            isFullWidth: true, shadowOffset: 4,
            onPressed: onCall,
          )),
          const SizedBox(width: 10),
          Expanded(child: BrutalButton(
            label: 'WHATSAPP',
            iconData: Icons.chat_bubble,
            backgroundColor: AppColors.teal, textColor: AppColors.white,
            isFullWidth: true, shadowOffset: 4,
            onPressed: onWhatsApp,
          )),
        ]),
      ),
    );
  }
}

/// What the lead screen shows when the lead cannot be loaded.
///
/// It printed the raw DioException ("…status code of 404…"). Not having a
/// lead is usually ordinary — a notification or follow-up for a lead since
/// reassigned or deleted — and the server now says which (`error`:
/// lead_not_assigned / lead_deleted), so the agent is told in words.
class LeadUnavailableView extends StatelessWidget {
  final Object error;
  final VoidCallback onRetry;
  const LeadUnavailableView({super.key, required this.error, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    final response = error is DioException ? (error as DioException).response : null;
    final data = response?.data;
    final code = data is Map ? data['error'] as String? : null;
    final notFound = response?.statusCode == 404;

    final (IconData icon, String title, String message) = switch (code) {
      'lead_not_assigned' => (
          Icons.person_off_outlined,
          'This lead is no longer assigned to you',
          'It has been reassigned to another agent. Ask your manager if it should come back to you.',
        ),
      'lead_deleted' => (
          Icons.delete_outline,
          'This lead has been deleted',
          'It is no longer in the CRM.',
        ),
      _ when notFound => (
          Icons.search_off_outlined,
          'This lead could not be found',
          'It may have been removed. Check your leads list.',
        ),
      _ => (Icons.cloud_off_outlined, 'Could not load this lead', ApiClient.errorMessage(error)),
    };

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Lead')),
      body: EmptyStateView(
        icon: icon,
        title: title,
        message: message,
        buttonLabel: notFound ? 'Go to my leads' : 'Try again',
        onAction: notFound ? () => context.go('/leads') : onRetry,
      ),
    );
  }
}
