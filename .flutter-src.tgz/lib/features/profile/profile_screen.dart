import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../core/legal.dart';
import '../../core/services/call_recording_service.dart';
import '../../core/services/setup_service.dart';
import '../../core/services/tenant_config.dart';
import '../../core/theme/colors.dart';
import '../../core/utils/utils.dart';
import '../../core/widgets/widgets.dart';
import '../auth/auth_provider.dart';
import '../dialer/dialer_state.dart';
import '../setup/recording_disclosure.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  String _waMode = 'native';
  bool _callRecEnabled = false;
  bool _allFiles = true;
  int _pendingRecordings = 0;
  bool _scanning = false;
  bool _signingOut = false;
  String _micMode = 'auto';

  /// Force the deferred recording sync now.
  ///
  /// The sweep also runs automatically on every app resume; this exists so an
  /// agent hunting one specific missing recording gets a definite answer
  /// instead of waiting for a trigger they cannot see.
  Future<void> _scanRecordings() async {
    setState(() => _scanning = true);
    var uploaded = 0;
    try {
      uploaded = await CallRecordingService.instance.sweepPending();
    } catch (_) {
      // Reason is recorded on the service and rendered below.
    }
    final pending = await CallRecordingService.instance.pendingCount();
    if (!mounted) return;
    setState(() {
      _scanning = false;
      _pendingRecordings = pending;
    });
    AppToast.show(
      context,
      uploaded > 0
          ? '$uploaded recording(s) uploaded'
          : 'No new recordings found',
      isSuccess: uploaded > 0,
    );
  }

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final m = await UserPrefs.getWhatsAppMode();
    final recEnabled = await CallRecordingService.instance.isEnabled();
    final pending = await CallRecordingService.instance.pendingCount();
    final allFiles = await SetupService.instance.hasAllFilesAccessOption();
    final micMode = await CallRecordingService.instance.micMode();
    if (mounted) setState(() {
      _micMode = micMode;
      _allFiles = allFiles;
      _waMode = m;
      _callRecEnabled = recEnabled;
      _pendingRecordings = pending;
    });
  }

  @override
  Widget build(BuildContext context) {
    final agent = ref.watch(currentAgentProvider);
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('My Profile'),
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: AppColors.black), onPressed: () => context.pop()),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          // Avatar card
          BrutalCard(padding: const EdgeInsets.all(18), child: Row(children: [
            BrutalAvatar(name: agent?.name ?? 'A', size: 64, backgroundColor: AppColors.yellow),
            const SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(agent?.name ?? '', style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 18, color: AppColors.brand)),
              Text(agent?.email ?? '', style: const TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 12, color: AppColors.text2)),
              const SizedBox(height: 6),
              TagChip(label: agent?.roleDisplay ?? agent?.role ?? '',
                  backgroundColor: AppColors.brand50, textColor: AppColors.brand),
            ])),
          ])).animate().fadeIn(),

          const SizedBox(height: 16),

          // Workspace info
          BrutalCard(padding: const EdgeInsets.all(14), color: AppColors.infoBg, borderColor: AppColors.info,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: const [
                Icon(Icons.business, size: 18, color: AppColors.info),
                SizedBox(width: 8),
                Text('Workspace', style: AppTextStyles.h5),
              ]),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.surface2,
                  border: Border.all(color: AppColors.line, width: 1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(children: [
                  Expanded(child: Text(
                    TenantConfig.instance.summary,
                    style: const TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w600, fontSize: 13, color: AppColors.black),
                    overflow: TextOverflow.ellipsis,
                  )),
                  TagChip(
                    label: 'CONNECTED',
                    backgroundColor: AppColors.success,
                    textColor: AppColors.white,
                  ),
                ]),
              ),
              const SizedBox(height: 4),
              Text(
                TenantConfig.instance.apiBaseUrl,
                style: const TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 10, color: AppColors.greyDark),
                overflow: TextOverflow.ellipsis,
              ),
            ]),
          ).animate().fadeIn(delay: 50.ms),

          const SizedBox(height: 14),

          // WhatsApp Mode Preference
          BrutalCard(padding: const EdgeInsets.all(14), color: AppColors.tealBg, borderColor: AppColors.teal,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: const [
                Icon(Icons.chat_bubble_outline, size: 18, color: AppColors.teal),
                SizedBox(width: 8),
                Text('WhatsApp Default Mode', style: AppTextStyles.h5),
              ]),
              const SizedBox(height: 4),
              const Text('Used when you tap WhatsApp on a lead', style: AppTextStyles.caption),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _WaModeBox(
                  label: 'NATIVE',
                  subtitle: 'Opens device WhatsApp',
                  selected: _waMode == 'native',
                  color: AppColors.success,
                  onTap: () { setState(() => _waMode = 'native'); UserPrefs.setWhatsAppMode('native'); },
                )),
                const SizedBox(width: 10),
                Expanded(child: _WaModeBox(
                  label: 'CLOUD',
                  subtitle: 'Via Cloud API',
                  selected: _waMode == 'cloud',
                  color: AppColors.purple,
                  onTap: () { setState(() => _waMode = 'cloud'); UserPrefs.setWhatsAppMode('cloud'); },
                )),
              ]),
            ]),
          ).animate().fadeIn(delay: 80.ms),

          const SizedBox(height: 14),

          // Call recording (SIM-based)
          BrutalCard(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SectionHeader(title: 'Call Recording', icon: Icons.mic_external_on),
            const SizedBox(height: 4),
            Text(
              'Auto-upload call recordings to the lead. Uses your phone\'s built-in '
              'call recorder when available (${_allFiles ? '"All files access"' : 'audio access'} '
              'needed to read its recordings). On phones without one, the app '
              'records via the microphone during the call — use speakerphone to '
              'capture both sides.',
              style: AppTextStyles.caption,
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: Text(
                _callRecEnabled ? 'Enabled' : 'Disabled',
                style: AppTextStyles.h5,
              )),
              Switch(
                value: _callRecEnabled,
                activeColor: AppColors.success,
                onChanged: (val) async {
                  if (val) {
                    // What is recorded, and the agent's agreement, before any
                    // permission is asked for or anything recorded (Play's
                    // prominent-disclosure rule).
                    if (!await confirmRecordingDisclosure(context)) return;
                    // Best-effort: storage access improves quality (reads the
                    // OEM recorder's file), but the mic fallback works without
                    // it — so never block enabling on this permission.
                    final storageOk = await CallRecordingService.instance.requestStorageAccess();
                    final micOk = (await Permission.microphone.request()).isGranted;
                    if (!storageOk && !micOk && mounted) {
                      AppToast.show(context,
                          'Grant microphone or storage access to record calls', isError: true);
                      return;
                    }
                    if (!storageOk && mounted) {
                      AppToast.show(context,
                          'Mic-only mode: recordings capture your side (both on speaker)');
                    }
                  }
                  await CallRecordingService.instance.setEnabled(val);
                  if (mounted) setState(() => _callRecEnabled = val);
                  if (mounted) {
                    AppToast.show(context, val ? 'Call recording auto-upload ON' : 'Turned off',
                        isSuccess: val);
                  }
                },
              ),
            ]),
            if (_callRecEnabled) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(10),
                color: AppColors.infoBg,
                child: Text(
                  // Double-quoted: the copy contains an apostrophe, and a
                  // single-quoted Dart string would end at it.
                  "Best quality comes from your phone's own call recorder — turn it "
                  'on in the Dialer app settings and grant '
                  '${_allFiles ? '"All files access"' : 'audio access'} here. '
                  'Without one, the app records through the microphone; put the call '
                  'on speaker so both sides are captured.',
                  style: TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 11.5, height: 1.4),
                ),
              ),
              const SizedBox(height: 10),
              // The app's own microphone recording. On a phone with a call
              // recorder it must stay off: holding the microphone stops the
              // phone recording the call.
              Row(children: [
                const Expanded(child: Text('App microphone recording', style: AppTextStyles.caption)),
                DropdownButton<String>(
                  value: _micMode,
                  underline: const SizedBox.shrink(),
                  items: const [
                    DropdownMenuItem(value: 'auto', child: Text('Auto')),
                    DropdownMenuItem(value: 'never', child: Text('Off')),
                    DropdownMenuItem(value: 'always', child: Text('Always')),
                  ],
                  onChanged: (v) async {
                    if (v == null) return;
                    await CallRecordingService.instance.setMicMode(v);
                    if (mounted) setState(() => _micMode = v);
                  },
                ),
              ]),
              Text(
                _micMode == 'auto'
                    ? 'Only on phones without their own call recorder.'
                    : _micMode == 'never'
                        ? "Only your phone's call recorder is used."
                        : 'Records every call — on most phones this stops the '
                            "phone's own recorder from working.",
                style: AppTextStyles.caption.copyWith(fontSize: 11),
              ),
              const SizedBox(height: 6),
              // Manual trigger for the deferred sync. The automatic sweep runs
              // whenever the app resumes, but an agent chasing a specific
              // missing recording should not have to guess when that happened.
              Row(children: [
                Expanded(child: Text(
                  _pendingRecordings > 0
                      ? '$_pendingRecordings call(s) waiting for a recording file'
                      : 'No calls waiting',
                  style: AppTextStyles.caption,
                )),
                TextButton(
                  onPressed: _scanning ? null : _scanRecordings,
                  child: Text(_scanning ? 'Scanning…' : 'Scan now'),
                ),
              ]),
              const SizedBox(height: 4),
              // A permission can be revoked, or the agent may have skipped the
              // walkthrough on first run. Re-running it is the one place that
              // checks everything at once and says what is still missing.
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton(
                  onPressed: () => context.push('/setup'),
                  child: const Text('Re-run phone setup'),
                ),
              ),
              // Recording happens with the app in the background, so a failure
              // is otherwise completely invisible: the agent finishes a call
              // and no recording ever appears, with nothing to explain it.
              if (CallRecordingService.instance.lastError != null) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    border: Border.all(color: AppColors.error, width: 1),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('LAST RECORDING ISSUE', style: AppTextStyles.label),
                    const SizedBox(height: 4),
                    Text(
                      CallRecordingService.instance.lastError!,
                      style: const TextStyle(
                          fontFamily: 'PlusJakartaSans', fontSize: 11.5,
 height: 1.4),
                    ),
                  ]),
                ),
              ],
            ],
          ])).animate().fadeIn(delay: 180.ms),

          const SizedBox(height: 14),

          // Account info
          BrutalCard(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SectionHeader(title: 'Account', icon: Icons.info_outline),
            const SizedBox(height: 8), const Divider(),
            InfoRow(label: 'Employee ID', value: agent?.employeeId.isEmpty == true ? '—' : agent?.employeeId ?? '—'),
            const Divider(),
            InfoRow(label: 'Logins', value: '${agent?.totalLoginCount ?? 0}'),
            const Divider(),
            InfoRow(label: 'Last Active', value: Fmt.relative(agent?.lastActiveAt)),
            const Divider(),
            InfoRow(label: 'Joined', value: Fmt.date(agent?.createdAt)),
          ])).animate().fadeIn(delay: 240.ms),

          const SizedBox(height: 20),

          BrutalButton.danger(
            label: '⏻  Sign Out',
            isFullWidth: true,
            isLoading: _signingOut,
            onPressed: _signingOut ? null : () async {
              final ok = await showBrutalConfirm(
                context: context, title: 'Sign Out?',
                message: 'You will be logged out and need to sign in again.',
                confirmLabel: 'Sign Out', danger: true,
              );
              if (ok == true && context.mounted) {
                setState(() => _signingOut = true);
                // While the token still works: close any queue so its locked
                // lead is released on the server, not held until it times out.
                ref.read(dialerProvider.notifier).stop();
                await ref.read(authProvider.notifier).logout();
                if (context.mounted) context.go('/login');
              }
            },
          ),
          const SizedBox(height: 8),
          Center(
            child: TextButton(
              onPressed: () async {
                if (!await openPrivacyPolicy() && context.mounted) {
                  AppToast.show(context, 'Could not open $kPrivacyPolicyUrl', isError: true);
                }
              },
              child: const Text('Privacy policy'),
            ),
          ),
          const SizedBox(height: 32),
        ]),
      ),
    );
  }
}

class _WaModeBox extends StatelessWidget {
  final String label, subtitle;
  final bool selected;
  final Color color;
  final VoidCallback onTap;
  const _WaModeBox({required this.label, required this.subtitle, required this.selected, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return BrutalCard(
      onTap: onTap,
      padding: const EdgeInsets.all(10),
      color: selected ? color : AppColors.white,
      shadowOffset: selected ? 3 : 4,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 12, height: 12,
            decoration: BoxDecoration(
              color: selected ? AppColors.white : AppColors.white,
              border: Border.all(color: AppColors.line, width: 1),
            ),
            child: selected ? const Icon(Icons.check, size: 8, color: AppColors.black) : null,
          ),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(fontFamily: 'PlusJakartaSans', fontWeight: FontWeight.w700, fontSize: 11, color: selected ? AppColors.white : AppColors.black)),
        ]),
        const SizedBox(height: 3),
        Text(subtitle, style: TextStyle(fontFamily: 'PlusJakartaSans', fontSize: 10, color: selected ? AppColors.white.withOpacity(0.85) : AppColors.grey)),
      ]),
    );
  }
}
