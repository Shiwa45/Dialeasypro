// ============================================================
// DialSathi — App.tsx
// Routing + auth guard + React Query provider
// ============================================================
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from './queryClient';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { Layout } from './components/Layout';
import { ToastProvider } from './components/ui';
import { MODULE_AREA, RequireFeature, UpgradePrompts } from './components/UpgradeGate';
import PlanExpiredGate from './components/PlanExpiredGate';
import { useAuthStore } from './store/authStore';
import { WorkspaceGuard } from './components/WorkspaceGuard';

// Pages
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import MyPerformancePage from './pages/agent/MyPerformancePage';
import { useWorkspace } from './hooks/useWorkspace';
import Leads from './pages/Leads';
import LeadDetail from './pages/LeadDetail';
import AgentsPage from './pages/AgentsPage';
import LiveAgents from './pages/LiveAgents';
import AgentLoginReport from './pages/AgentLoginReport';
import CallsPage from './pages/CallsPage';
import CommunicationsPage from './pages/CommunicationsPage';
import CampaignsPage from './pages/CampaignsPage';
import ReportsPage from './pages/ReportsPage';
import QueuesPage from './pages/QueuesPage';
import IntegrationsPage from './pages/IntegrationsPage';
import SettingsPage from './pages/SettingsPage';
import LeadImportPage from './pages/LeadImportPage';
import LeadBatchesPage from './pages/LeadBatchesPage';
import ProfilePage from './pages/ProfilePage';
// Paid features and add-on modules. Every route stays mounted and every menu
// entry is shown whatever the plan; RequireFeature swaps a page the plan does
// not cover for an upgrade screen. The backend answers 402 `upgrade_required`
// regardless, so this is the courteous layer, not the secure one.
import CallInsightsPage from './pages/CallInsightsPage';
import { MODULE_GROUPS } from './pages/moduleSections';
import ModuleSectionPage, { ModuleIndexRedirect } from './components/ModuleSectionPage';


// A session is valid only if the store says so AND a real access token exists.
// Checking the token too prevents the /login ↔ /dashboard reload loop that
// happens if the persisted flag and the tokens ever get out of sync.
function hasValidSession(isAuthenticated: boolean) {
  return isAuthenticated && !!localStorage.getItem('access_token');
}

/** The agent workspace's home is their own performance; everyone else keeps the console dashboard. */
function DashboardRoute() {
  const { isAgentWorkspace } = useWorkspace();
  return isAgentWorkspace ? <MyPerformancePage /> : <Dashboard />;
}

function AuthGuard() {
  const { isAuthenticated } = useAuthStore();
  if (!hasValidSession(isAuthenticated)) return <Navigate to="/login" replace />;
  return (
    <Layout>
      <WorkspaceGuard>
        <Outlet />
      </WorkspaceGuard>
    </Layout>
  );
}

function PublicGuard() {
  const { isAuthenticated } = useAuthStore();
  if (hasValidSession(isAuthenticated)) return <Navigate to="/dashboard" replace />;
  return <Outlet />;
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <BrowserRouter>
          {/* Inside the router: the upgrade dialog links to billing. */}
          <UpgradePrompts />
          <PlanExpiredGate />
          <Routes>
            {/* Public routes */}
            <Route element={<PublicGuard />}>
              <Route path="/login" element={<Login />} />
            </Route>

            {/* Root redirect */}
            <Route path="/" element={<Navigate to="/dashboard" replace />} />

            {/* Protected routes */}
            <Route element={<AuthGuard />}>
              <Route path="/dashboard"         element={<DashboardRoute />} />
              <Route path="/leads"             element={<Leads />} />
              <Route path="/leads/import"      element={<RequireFeature area="leadImport"><LeadImportPage /></RequireFeature>} />
              <Route path="/leads/batches"     element={<LeadBatchesPage />} />
              <Route path="/leads/:id"         element={<LeadDetail />} />
              <Route path="/calls"             element={<CallsPage />} />
              <Route path="/queues"            element={<QueuesPage />} />
              <Route path="/agents"            element={<AgentsPage />} />
              <Route path="/live-agents"       element={<RequireFeature area="liveAgents"><LiveAgents /></RequireFeature>} />
              <Route path="/login-report"      element={<RequireFeature area="loginReport"><AgentLoginReport /></RequireFeature>} />
              <Route path="/communications"    element={<CommunicationsPage />} />
              <Route path="/campaigns"         element={<RequireFeature area="campaigns"><CampaignsPage /></RequireFeature>} />
              <Route path="/insights"          element={<RequireFeature area="insights"><CallInsightsPage /></RequireFeature>} />
              {/* HRMS / Sales & Billing / Recruitment: one route per section,
                  generated from MODULE_GROUPS so the sidebar submenu and the
                  router can never disagree about what exists. The bare module
                  root redirects to the first section the user may open. */}
              {MODULE_GROUPS.map(group => [
                <Route
                  key={group.base}
                  path={group.base}
                  element={
                    <RequireFeature area={MODULE_AREA[group.base]}>
                      <ModuleIndexRedirect sections={group.sections} base={group.base} />
                    </RequireFeature>
                  }
                />,
                ...group.sections.map(section => (
                  <Route
                    key={`${group.base}/${section.path}`}
                    path={`${group.base}/${section.path}`}
                    element={
                      <RequireFeature area={MODULE_AREA[group.base]}>
                        <ModuleSectionPage
                          section={section}
                          siblings={group.sections}
                          base={group.base}
                        />
                      </RequireFeature>
                    }
                  />
                )),
              ])}
              <Route path="/reports"           element={<ReportsPage />} />
              <Route path="/integrations"      element={<IntegrationsPage />} />
              <Route path="/settings"          element={<SettingsPage />} />
              <Route path="/profile"           element={<ProfilePage />} />
            </Route>

            {/* 404 fallback */}
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </BrowserRouter>
      </ToastProvider>
      {typeof import.meta !== "undefined" && (import.meta as { env?: { DEV?: boolean } }).env?.DEV && <ReactQueryDevtools initialIsOpen={false} />}
    </QueryClientProvider>
  );
}
