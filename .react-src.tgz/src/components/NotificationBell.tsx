// ============================================================
// DialSathi — Notification bell
//
// The topbar had a bell with no behaviour: an icon button, no badge, no
// handler, nothing behind it. Follow-up reminders were pushed down a
// WebSocket that no client had ever opened, so an agent whose lead had a
// follow-up scheduled was never told anything, anywhere.
//
// This opens that socket, shows what is waiting, and falls back to polling
// so a dropped connection degrades to "a minute late" rather than "silent".
// ============================================================
import { useCallback, useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { authApi, type AppNotification } from '../api';
import { openTenantSocket } from '../api/client';
import { fmtRelative } from '../utils/fmt';

const Ico = ({ d, size = 16 }: { d: React.ReactNode; size?: number }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor"
       strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{d}</svg>
);
const I = {
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 0 1-3.4 0" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  warn: <><path d="M12 9v4M12 17h.01" /><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" /></>,
  user: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /></>,
  info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" /></>,
};

/** Each kind means one thing, and borrows the colour that already means it. */
const KIND: Record<string, { icon: React.ReactNode; fg: string; bg: string }> = {
  followup_scheduled: { icon: <Ico d={I.clock} size={13} />, fg: 'var(--brand)', bg: 'var(--brand-50)' },
  followup_due:       { icon: <Ico d={I.clock} size={13} />, fg: 'var(--warm-ink)',      bg: 'var(--warm-50)' },
  followup_overdue:   { icon: <Ico d={I.warn} size={13} />,  fg: 'var(--hot)',   bg: 'var(--hot-50)' },
  lead_assigned:      { icon: <Ico d={I.user} size={13} />,  fg: 'var(--visit)', bg: 'var(--visit-50)' },
  system:             { icon: <Ico d={I.info} size={13} />,  fg: 'var(--text-2)', bg: 'var(--sunken)' },
};

export default function NotificationBell() {
  const nav = useNavigate();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  // Close on navigation — it stayed open over the next page.
  const { pathname } = useLocation();
  useEffect(() => { setOpen(false); }, [pathname]);
  const panelRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const retryRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const attemptRef = useRef(0);
  const closedRef = useRef(false);

  // The badge. Polled slowly as a floor under the socket: if the connection
  // drops the count is a minute stale rather than frozen.
  const { data: count } = useQuery({
    queryKey: ['notif-unread'],
    queryFn: () => authApi.unreadCount().then(r => r.data.unread),
    refetchInterval: 60_000,
    retry: false,
  });

  // The list is only fetched when the panel is open. There is no reason to
  // pull twenty rows to render a number.
  const { data, isLoading } = useQuery({
    queryKey: ['notif-list'],
    queryFn: () => authApi.notifications({ page_size: 20 }).then(r => r.data),
    enabled: open,
  });

  const refresh = useCallback(() => {
    qc.invalidateQueries({ queryKey: ['notif-unread'] });
    qc.invalidateQueries({ queryKey: ['notif-list'] });
  }, [qc]);

  const readOne = useMutation({
    mutationFn: (id: number) => authApi.markNotificationRead(id),
    onSuccess: refresh,
  });
  const readAll = useMutation({
    mutationFn: () => authApi.markAllNotificationsRead(),
    onSuccess: refresh,
  });

  // ---- Live feed ----
  useEffect(() => {
    closedRef.current = false;

    const connect = () => {
      const ws = openTenantSocket('/ws/notifications/');
      wsRef.current = ws;

      ws.onopen = () => { attemptRef.current = 0; };
      ws.onclose = () => {
        if (closedRef.current) return;
        const wait = Math.min(30_000, 1000 * 2 ** attemptRef.current);
        attemptRef.current += 1;
        retryRef.current = setTimeout(connect, wait);
      };
      ws.onerror = () => ws.close();
      ws.onmessage = e => {
        try {
          const msg = JSON.parse(e.data);
          // `notification` is the current event. The older per-kind events
          // are still emitted by parts of the backend that predate the
          // Notification model, and they also mean "something arrived".
          if (msg.type === 'notification' || msg.type === 'followup_reminder'
              || msg.type === 'new_lead') {
            refresh();
          }
        } catch { /* ignore malformed frames */ }
      };
    };
    connect();

    const ping = setInterval(() => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'ping' }));
      }
    }, 25_000);

    return () => {
      closedRef.current = true;
      clearInterval(ping);
      if (retryRef.current) clearTimeout(retryRef.current);
      wsRef.current?.close();
    };
  }, [refresh]);

  // Close on an outside click or Escape.
  useEffect(() => {
    if (!open) return;
    const away = (e: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) setOpen(false);
    };
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', away);
    document.addEventListener('keydown', esc);
    return () => {
      document.removeEventListener('mousedown', away);
      document.removeEventListener('keydown', esc);
    };
  }, [open]);

  const rows = data?.results ?? [];
  const unread = count ?? 0;

  const openRow = (n: AppNotification) => {
    if (!n.is_read) readOne.mutate(n.id);
    setOpen(false);
    if (n.url) nav(n.url);
  };

  return (
    <div ref={panelRef} style={{ position: 'relative' }}>
      <button className="icon-btn" title="Notifications"
              aria-label={unread ? `Notifications, ${unread} unread` : 'Notifications'}
              onClick={() => setOpen(o => !o)}>
        <Ico d={I.bell} />
        {unread > 0 && <span className="notif-dot">{unread > 99 ? '99+' : unread}</span>}
      </button>

      {open && (
        <div className="notif-panel">
          <div className="notif-head">
            <span style={{ fontSize: 13.5, fontWeight: 600 }}>Notifications</span>
            {unread > 0 && (
              <button className="notif-clear" disabled={readAll.isPending}
                      onClick={() => readAll.mutate()}>
                Mark all read
              </button>
            )}
          </div>

          <div className="notif-body">
            {isLoading ? (
              <div className="notif-blank">Loading…</div>
            ) : !rows.length ? (
              <div className="notif-blank">
                Nothing yet. Follow-ups scheduled on your leads show up here.
              </div>
            ) : rows.map(n => {
              const k = KIND[n.kind] ?? KIND.system;
              return (
                <button key={n.id} className={`notif-row ${n.is_read ? '' : 'unread'}`}
                        onClick={() => openRow(n)}>
                  <span className="notif-ic" style={{ background: k.bg, color: k.fg }}>{k.icon}</span>
                  <span style={{ minWidth: 0, flex: 1, textAlign: 'left' }}>
                    <span className="notif-title">{n.title}</span>
                    {n.body && <span className="notif-sub">{n.body}</span>}
                    <span className="notif-time">{fmtRelative(n.created_at)}</span>
                  </span>
                  {!n.is_read && <i className="notif-pip" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
