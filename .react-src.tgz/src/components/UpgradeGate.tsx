// ============================================================
// DialSathi — Locked features
//
// Every feature is visible whatever the plan. Opening one the plan does not
// include shows an upgrade screen in place of the page — never a half-loaded
// page full of 402s — and a refused action (export, send, …) opens the same
// message as a dialog.
//
// Plan names come from the server's catalogue (/auth/features/ → upgrade),
// so nothing about pricing tiers is hardcoded here. Only admins can change
// the plan, so only they are pointed at billing and sales; everyone else is
// told to ask their admin.
// ============================================================
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';

import { onUpgradeRequired, type UpgradeRequired } from '../api/client';
import { Feature, Module, useFeatures, type FeatureGate } from '../hooks/useFeatures';
import { useAuthStore } from '../store/authStore';
import { isAdmin } from '../utils/roles';
import { Modal, Spinner, useToast } from './ui';

/** A part of the app that can be locked, with what to say about it. */
export type LockedArea = {
  gate: FeatureGate;
  title: string;
  blurb: string;
  highlights: string[];
};

export const AREAS = {
  leadImport: {
    gate: { anyOf: [Feature.LEAD_IMPORT] },
    title: 'Lead Import',
    blurb: 'Bring in leads in bulk from Excel or CSV instead of typing them one by one.',
    highlights: ['Map your columns, including custom fields', 'Duplicates skipped or updated automatically', 'Every upload tracked as a batch'],
  },
  liveAgents: {
    gate: { anyOf: [Feature.AGENT_MONITORING] },
    title: 'Live Agent Monitoring',
    blurb: 'Watch your calling floor in real time.',
    highlights: ['Who is available, on a call, on break or offline', 'Live talk time and idle time', 'Spot idle agents as it happens'],
  },
  loginReport: {
    gate: { anyOf: [Feature.AGENT_MONITORING] },
    title: 'Agent Login Report',
    blurb: "Every agent's working day, live for today and kept for every day after.",
    highlights: ['First login and last logout', 'Break, talk and idle time', 'Export to CSV for payroll'],
  },
  campaigns: {
    gate: { anyOf: [Feature.BULK_WHATSAPP, Feature.BULK_EMAIL, Feature.BULK_SMS] },
    title: 'Bulk Campaigns',
    blurb: 'Reach a whole segment of leads at once on WhatsApp, email or SMS.',
    highlights: ['Target by status, source, tags or batch', 'Approved WhatsApp templates', 'Delivery and reply tracking'],
  },
  insights: {
    gate: { module: Module.AI_SUITE },
    title: 'AI Call Summary',
    blurb: 'AI that listens to recorded calls so managers don’t have to.',
    highlights: ['Automatic call transcription', 'Summaries, sentiment and next steps', 'Coaching insights per agent'],
  },
  hrms: {
    gate: { module: Module.HRMS },
    title: 'HRMS',
    blurb: 'Run your team’s HR from the same place they call from.',
    highlights: ['Attendance straight from dialer sessions', 'Leave, payroll and payslips', 'Expenses and sales incentives'],
  },
  erp: {
    gate: { module: Module.ERP_SALES },
    title: 'Sales & Billing',
    blurb: 'Turn a converted lead into a quotation, an order and a GST invoice.',
    highlights: ['Product catalogue and price lists', 'Quotations and sales orders', 'GST invoices and payments'],
  },
  recruitment: {
    gate: { module: Module.RECRUITMENT },
    title: 'Recruitment',
    blurb: 'Hire your next agents without spreadsheets.',
    highlights: ['Job openings and a candidate pipeline', 'Interview scheduling and feedback', 'Offers, then onboarding into HRMS'],
  },
  agentWeb: {
    gate: { anyOf: [Feature.AGENT_WEB_ACCESS] },
    title: 'Agent Web Panel',
    blurb: 'Let your agents work from a browser as well as the mobile app.',
    highlights: ['Agents see only their own leads and calls', 'A personal performance dashboard', 'You decide whether it is on or off'],
  },
  whatsappSettings: {
    gate: { anyOf: [Feature.ONE_CLICK_WHATSAPP, Feature.BULK_WHATSAPP] },
    title: 'WhatsApp Business',
    blurb: 'Message leads from the CRM through your WhatsApp Business account.',
    highlights: ['One-click WhatsApp from any lead', 'Approved message templates', 'Conversations saved on the lead'],
  },
  // Actions rather than screens: shown in the dialog when one is refused.
  leadExport: {
    gate: { anyOf: [Feature.LEAD_EXPORT] },
    title: 'Lead Export',
    blurb: 'Download your leads as a spreadsheet whenever you need them.',
    highlights: ['Export with your filters applied', 'Custom fields included', 'Opens in Excel or Google Sheets'],
  },
  callRecordings: {
    gate: { anyOf: [Feature.CALL_RECORDING_ACCESS] },
    title: 'Call Recordings',
    blurb: 'Listen back to any call from the lead it belongs to.',
    highlights: ['Recordings attached to the call and lead', 'Play in the browser', 'Review calls for quality and training'],
  },
} satisfies Record<string, LockedArea>;

export type AreaKey = keyof typeof AREAS;

/** The module group of a route base (e.g. "/hrms"), for the router. */
export const MODULE_AREA: Record<string, AreaKey> = {
  '/hrms': 'hrms',
  '/erp': 'erp',
  '/recruitment': 'recruitment',
};

/* ---- Route wrapper ------------------------------------------ */

/** Renders `children` when the plan covers `area`, the upgrade screen otherwise. */
export function RequireFeature({ area, children }: { area: AreaKey; children: ReactNode }) {
  const { isLoading, isLocked } = useFeatures();
  if (isLoading) return <div style={{ padding: 40 }}><Spinner /></div>;
  if (isLocked(AREAS[area].gate)) return <UpgradeScreen area={AREAS[area]} />;
  return <>{children}</>;
}

/* ---- The screen ---------------------------------------------- */

export function UpgradeScreen({ area, compact = false }: { area: LockedArea; compact?: boolean }) {
  return (
    <div className={compact ? 'upgrade-wrap compact' : 'upgrade-wrap'}>
      <div className="upgrade-card">
        <UpgradeBody area={area} />
      </div>
    </div>
  );
}

function LockIcon({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
         strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="4" y="11" width="16" height="10" rx="2.5" />
      <path d="M8 11V7.5a4 4 0 0 1 8 0V11" />
    </svg>
  );
}

function UpgradeBody({ area, onDone }: { area: LockedArea; onDone?: () => void }) {
  const { plan, plansFor, support } = useFeatures();
  const { agent } = useAuthStore();
  const navigate = useNavigate();
  const admin = isAdmin(agent);
  const plans = plansFor(area.gate);
  const isModule = Boolean(area.gate.module);

  const subject = encodeURIComponent(`Upgrade request: ${area.title}`);
  const body = encodeURIComponent(
    `Hi,\n\nWe'd like to add ${area.title} to our workspace` +
    (plan ? ` (currently on the ${plan.name} plan)` : '') + '.\n\nThanks',
  );

  return (
    <>
      <div className="upgrade-badge"><LockIcon /></div>
      <div className="upgrade-eyebrow">Upgrade to unlock</div>
      <h2 className="upgrade-title">{area.title}</h2>
      <p className="upgrade-lead">
        {area.blurb}{' '}
        <span style={{ color: 'var(--text-3)' }}>
          {isModule ? 'This add-on is' : 'This feature is'} not included in{' '}
          {plan ? <>your <b style={{ color: 'var(--text-2)' }}>{plan.name}</b> plan</> : 'your current plan'}.
        </span>
      </p>

      <ul className="upgrade-list">
        {area.highlights.map(h => (
          <li key={h}>
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
                 strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="m5 12 5 5 9-10" />
            </svg>
            {h}
          </li>
        ))}
      </ul>

      {(plans.length > 0 || isModule) && (
        <div className="upgrade-plans">
          <span className="upgrade-plans-k">Available on</span>
          {plans.map(p => <span key={p} className="upgrade-chip">{p}</span>)}
          {isModule && <span className="upgrade-chip ghost">{plans.length ? 'or as an add-on' : 'As an add-on to any plan'}</span>}
        </div>
      )}

      {admin ? (
        <div className="upgrade-actions">
          <button className="btn btn-p" onClick={() => { onDone?.(); navigate('/settings?tab=billing'); }}>
            See plan &amp; billing
          </button>
          {support?.email && (
            <a className="btn btn-g" href={`mailto:${support.email}?subject=${subject}&body=${body}`}>
              Contact sales
            </a>
          )}
          {support?.whatsapp && (
            <a className="btn btn-g" target="_blank" rel="noreferrer"
               href={`https://wa.me/${support.whatsapp.replace(/[^0-9]/g, '')}?text=${subject}`}>
              WhatsApp us
            </a>
          )}
        </div>
      ) : (
        <div className="upgrade-note">
          Only your workspace admin can change the plan. Ask them to upgrade to use {area.title}.
        </div>
      )}

      {!onDone && (
        <Link to="/dashboard" className="upgrade-back">← Back to dashboard</Link>
      )}
    </>
  );
}

/* ---- Refused actions ------------------------------------------ */

/** Which area a refused feature belongs to, for the dialog's copy. */
function areaForFeature(featureKey: string, module: string | null): LockedArea | null {
  for (const area of Object.values(AREAS) as LockedArea[]) {
    if (module && area.gate.module === module) return area;
    if (area.gate.anyOf?.includes(featureKey)) return area;
  }
  return null;
}

/**
 * Listens for 402 `upgrade_required` from the API.
 *
 * Something the user just did (a POST, an export…) opens the upgrade dialog.
 * A screen loading data (GET) gets a quiet toast instead, once per feature a
 * minute — a page that polls must not stack dialogs or toasts.
 */
export function UpgradePrompts() {
  const { showToast } = useToast();
  const [refused, setRefused] = useState<UpgradeRequired | null>(null);
  const lastToast = useRef<Record<string, number>>({});

  useEffect(() => {
    const handler = (e: Event) => {
      const d = (e as CustomEvent<UpgradeRequired>).detail;
      if (d.request_method && d.request_method !== 'get') {
        setRefused(prev => prev ?? d);
        return;
      }
      const now = Date.now();
      if (now - (lastToast.current[d.feature_key] ?? 0) < 60_000) return;
      lastToast.current[d.feature_key] = now;
      showToast('info', 'Upgrade required', `${d.feature_label} is not included in your plan.`);
    };
    onUpgradeRequired.addEventListener('upgrade', handler);
    return () => onUpgradeRequired.removeEventListener('upgrade', handler);
  }, [showToast]);

  if (!refused) return null;
  const known = areaForFeature(refused.feature_key, refused.module);
  const area: LockedArea = known ?? {
    gate: { anyOf: [refused.feature_key] },
    title: refused.feature_label,
    blurb: `${refused.feature_label} needs a higher plan.`,
    highlights: [],
  };
  const close = () => setRefused(null);

  return (
    <Modal title="Upgrade required" onClose={close} maxWidth="520px">
      <div className="upgrade-dialog">
        <UpgradeBody area={area} onDone={close} />
      </div>
    </Modal>
  );
}

/** A small lock for menus and tabs. */
export function LockMark({ title = 'Upgrade to unlock' }: { title?: string }) {
  return (
    <span className="lock-mark" title={title} aria-label={title}>
      <LockIcon size={12} />
    </span>
  );
}
