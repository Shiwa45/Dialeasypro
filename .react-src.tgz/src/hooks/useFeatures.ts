import { useQuery } from '@tanstack/react-query';
import { authApi, type TenantFeatures, type SupportContacts } from '../api';

// ============================================================
// Tenant plan features / add-on modules.
//
// Every feature is SHOWN whatever the plan. A feature the plan does not
// include is locked: its menu entry carries a lock and opening it shows an
// upgrade screen. Locking is a UX courtesy, not security — the backend
// re-checks every gated endpoint and answers 402 `upgrade_required`
// regardless of what the client believes.
// ============================================================

/** What a screen needs: at least one of `anyOf`, and/or the whole `module`. */
export type FeatureGate = { anyOf?: readonly string[]; module?: string };

export function useFeatures() {
  const { data, isLoading, isError } = useQuery<TenantFeatures>({
    queryKey: ['tenant-features'],
    queryFn: () => authApi.features().then(r => r.data),
    staleTime: 5 * 60_000, // features change rarely; backend caches them anyway
    retry: 1,
  });

  const has = (key: string) => Boolean(data?.features?.[key]);
  const hasModule = (key: string) => Boolean(data?.modules?.[key]);

  /**
   * True when the plan does not cover `gate`. Never true until the feature
   * map has loaded: a slow or failed fetch must not paint every paid screen
   * as locked for a customer who owns them (the backend still refuses
   * anything they really don't have).
   */
  const isLocked = (gate?: FeatureGate) => {
    if (!gate || !data) return false;
    if (gate.anyOf?.length && !gate.anyOf.some(has)) return true;
    if (gate.module && !hasModule(gate.module)) return true;
    return false;
  };

  /**
   * Public plans that would unlock `gate`, cheapest first. The tenant's own
   * plan is left out: when it is listed, the feature was withheld from this
   * workspace specifically, and "available on Business" said to a Business
   * customer is no help.
   */
  const plansFor = (gate?: FeatureGate): string[] => {
    const up = data?.upgrade;
    if (!gate || !up) return [];
    const seen: string[] = [];
    const keys = gate.module ? [] : gate.anyOf ?? [];
    const lists = gate.module
      ? [up.modules?.[gate.module]?.plans ?? []]
      : keys.map(key => up.features?.[key]?.plans ?? []);
    for (const names of lists) {
      for (const name of names) {
        if (!seen.includes(name) && name !== data?.plan?.name) seen.push(name);
      }
    }
    return seen;
  };

  return {
    isLoading,
    isError,
    plan: data?.plan ?? null,
    limits: data?.plan?.limits ?? {},
    /** True when the tenant's plan (+ add-ons) includes this feature. */
    has,
    /** True when every feature of an add-on module is enabled. */
    hasModule,
    isLocked,
    plansFor,
    /** Display name of a locked feature, from the server's catalogue. */
    featureLabel: (key: string) => data?.upgrade?.features?.[key]?.label ?? null,
    support: (data?.upgrade?.support ?? null) as SupportContacts | null,
  };
}

/** Feature keys the web app gates on. Mirrors apps/core/constants.py FeatureKey. */
export const Feature = {
  AGENT_MONITORING: 'agent_monitoring',
  LEAD_IMPORT: 'lead_import',
  LEAD_EXPORT: 'lead_export',
  CUSTOM_FIELDS: 'custom_fields',
  CALL_RECORDING_ACCESS: 'call_recording_access',
  CLOUD_TELEPHONY: 'cloud_telephony',
  AUTO_DIALER: 'auto_dialer',
  BULK_WHATSAPP: 'bulk_whatsapp',
  BULK_EMAIL: 'bulk_email',
  BULK_SMS: 'bulk_sms',
  ONE_CLICK_WHATSAPP: 'one_click_whatsapp',
  ONE_CLICK_EMAIL: 'one_click_email',
  ONE_CLICK_SMS: 'one_click_sms',
  BASIC_REPORTS: 'basic_reports',
  ADVANCED_REPORTS: 'advanced_reports',
  AGENT_PERFORMANCE_REPORTS: 'agent_performance',
  // Agents / read-only users may sign in to the web app
  AGENT_WEB_ACCESS: 'agent_web_access',
  // Recruitment (ATS) add-on
  ATS_JOB_OPENINGS: 'ats_job_openings',
  ATS_CANDIDATES: 'ats_candidates',
  ATS_INTERVIEWS: 'ats_interviews',
  ATS_OFFERS: 'ats_offers',
} as const;

/**
 * Paid add-on modules. Mirrors apps/core/constants.py ModuleKey.
 * A module counts as active only when every feature it bundles is enabled —
 * the backend decides that; `hasModule` just reads the answer.
 */
export const Module = {
  AI_SUITE: 'ai_suite',
  HRMS: 'hrms',
  ERP_SALES: 'erp_sales',
  RECRUITMENT: 'recruitment',
} as const;

/** True if the tenant can run bulk campaigns on ANY channel. */
export function hasAnyBulk(has: (k: string) => boolean): boolean {
  return has(Feature.BULK_WHATSAPP) || has(Feature.BULK_EMAIL) || has(Feature.BULK_SMS);
}
