// ============================================================
// DialSathi — Bulk campaigns
//
// Two things were wrong here.
//
// The form validated one field. The labels said a WhatsApp template, an email
// subject and body, and SMS text were required, but the submit button only
// checked the campaign name — so a half-filled campaign posted, the server
// rejected it, and the reason came back as a toast with no idea which input
// was at fault. Every rule the server enforces is now checked next to the
// field it belongs to, before the request goes out.
//
// The screen listed page one and nothing else. listCampaigns is paginated and
// there was no pager, so campaign 26 onwards was unreachable, and the header
// counted the visible rows rather than the total. It also polled every five
// seconds forever, whether or not anything was sending.
//
// Since then, two more:
//
// The template dropdown was always empty, for everyone. It asked for approved
// templates only, templates are created "pending", and nothing in the product
// could approve one — so bulk WhatsApp could not be set up at all. It now
// lists every template with its status, and an admin can record Meta's
// approval without leaving the form.
//
// The audience was every active lead, always: audience_filters went out as
// {}. The server has supported filtering on status, source, city and owner
// all along, and now the form does too, with a live count of who it reaches.
// ============================================================
import { useMemo, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { authApi, commsApi, leadsApi } from '../api';
import {
  ConfirmDialog, EmptyState, Input, Modal, Pagination, SectionHeader,
  Select, Spinner, Textarea, useToast,
} from '../components/ui';
import { fmtDate, fmtDateTime, LEAD_SOURCES, LEAD_STATUSES, localISODateTime } from '../utils/fmt';
import { useAuthStore } from '../store/authStore';
import { getErrorMessage } from '../utils/errors';
import type { BulkCampaign, WhatsAppTemplate } from '../types';
import { isAdmin as isAdminRole } from '../utils/roles';

// ---- Icons ---------------------------------------------------
const Ico = ({ d, size = 15 }: { d: React.ReactNode; size?: number }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor"
       strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{d}</svg>
);
const I = {
  whatsapp: <><path d="M21 11.5a8.4 8.4 0 0 1-12.6 7.3L3 20.5l1.8-5.2A8.4 8.4 0 1 1 21 11.5Z" /></>,
  email: <><rect x="2" y="4" width="20" height="16" rx="2" /><path d="m2 7 10 6 10-6" /></>,
  sms: <><rect x="6" y="2" width="12" height="20" rx="2.5" /><path d="M11 18.5h2" /></>,
  play: <><path d="m7 4 13 8-13 8V4Z" /></>,
  pause: <><path d="M9 4v16M15 4v16" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  check: <><path d="M20 6 9 17l-5-5" /></>,
  warn: <><path d="M12 9v4M12 17h.01" /><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" /></>,
  plus: <><path d="M12 5v14M5 12h14" /></>,
};

type Channel = 'whatsapp' | 'email' | 'sms';

const CHANNELS: Array<{ key: Channel; label: string; icon: React.ReactNode }> = [
  { key: 'whatsapp', label: 'WhatsApp', icon: <Ico d={I.whatsapp} size={14} /> },
  { key: 'email',    label: 'Email',    icon: <Ico d={I.email} size={14} /> },
  { key: 'sms',      label: 'SMS',      icon: <Ico d={I.sms} size={14} /> },
];

const STATUS_CHIP: Record<BulkCampaign['status'], string> = {
  draft: 'c-mute', scheduled: 'c-warm', running: 'c-brand',
  paused: 'c-brass', completed: 'c-won', failed: 'c-lost', cancelled: 'c-mute',
};

const STATUS_FILTERS = [
  { key: '', label: 'All' },
  { key: 'draft', label: 'Drafts' },
  { key: 'scheduled', label: 'Scheduled' },
  { key: 'running', label: 'Running' },
  { key: 'paused', label: 'Paused' },
  { key: 'completed', label: 'Completed' },
  { key: 'failed', label: 'Failed' },
];

const EMPTY_FORM = {
  name: '', channel: 'whatsapp' as Channel, email_subject: '', email_body: '',
  sms_text: '', sms_sender_id: '', scheduled_at: '',
  // Audience. Blank means "do not narrow on this"; the server reads exactly
  // these keys (see _resolve_campaign_audience in communications/tasks.py).
  aud_status: '', aud_source: '', aud_city: '', aud_assigned_to: '', aud_batch: '',
};

/** The filters the server understands, with the blanks dropped. */
function audienceFilters(form: typeof EMPTY_FORM) {
  const f: Record<string, string | number> = {};
  if (form.aud_status) f.status = form.aud_status;
  if (form.aud_source) f.source = form.aud_source;
  if (form.aud_city.trim()) f.city = form.aud_city.trim();
  if (form.aud_assigned_to) f.assigned_to = Number(form.aud_assigned_to);
  if (form.aud_batch) f.batch = Number(form.aud_batch);
  return f;
}

const TEMPLATE_STATUS_NOTE: Record<string, string> = {
  pending: 'Waiting on Meta. Mark it approved here once Meta has approved it.',
  rejected: 'Meta rejected this template. Edit it and resubmit before using it.',
  disabled: 'This template is switched off.',
};

/** A GSM-7 message is 160 characters alone, then 153 per part once it splits. */
function smsParts(text: string) {
  const len = text.length;
  if (len === 0) return { parts: 0, limit: 160 };
  if (len <= 160) return { parts: 1, limit: 160 };
  return { parts: Math.ceil(len / 153), limit: 153 };
}

/** Every rule apps/communications/serializers.py enforces, checked here first
 *  so the message lands on the field rather than in a toast. */
function validate(
  form: typeof EMPTY_FORM,
  template: string,
  chosen?: WhatsAppTemplate,
) {
  const errors: Record<string, string> = {};
  if (!form.name.trim()) errors.name = 'Give the campaign a name.';

  if (form.channel === 'whatsapp' && !template) {
    errors.template = 'WhatsApp campaigns must use an approved template.';
  }
  // The server refuses a template that is not approved, so say it here
  // rather than letting the admin fill the rest of the form first.
  if (form.channel === 'whatsapp' && chosen && chosen.status !== 'approved') {
    errors.template = `"${chosen.name}" is ${chosen.status}. `
      + 'WhatsApp only delivers bulk sends on an approved template.';
  }
  if (form.channel === 'email') {
    if (!form.email_subject.trim()) errors.email_subject = 'A subject is required.';
    if (!form.email_body.trim()) errors.email_body = 'A body is required, or every recipient gets a blank email.';
  }
  if (form.channel === 'sms' && !form.sms_text.trim()) {
    errors.sms_text = 'Message text is required.';
  }
  if (form.scheduled_at && new Date(form.scheduled_at).getTime() <= Date.now()) {
    errors.scheduled_at = 'Pick a time in the future, or leave it blank and launch it yourself.';
  }
  return errors;
}

export default function Campaigns() {
  const { showToast } = useToast();
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [confirmLaunch, setConfirmLaunch] = useState<BulkCampaign | null>(null);
  const [viewing, setViewing] = useState<BulkCampaign | null>(null);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('');
  const [channel, setChannel] = useState('');

  const { data, isLoading } = useQuery({
    queryKey: ['campaigns', page, status, channel],
    queryFn: () => commsApi.listCampaigns({
      page: String(page),
      ...(status ? { status } : {}),
      ...(channel ? { channel } : {}),
    }).then(r => r.data),
    placeholderData: prev => prev,
    // Poll only while something is actually moving. The old five-second
    // interval ran for as long as the tab was open, on a screen whose rows
    // are static unless a campaign is sending.
    refetchInterval: q => {
      const rows = q.state.data?.results ?? [];
      return rows.some(c => c.status === 'running' || c.status === 'scheduled') ? 5000 : false;
    },
  });

  const campaigns = data?.results ?? [];

  const launchMut = useMutation({
    mutationFn: (id: string) => commsApi.launchCampaign(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['campaigns'] });
      setConfirmLaunch(null);
      showToast('success', 'Campaign launched', 'Messages are going out now.');
    },
    onError: e => showToast('error', 'Launch failed', getErrorMessage(e)),
  });

  const pauseMut = useMutation({
    mutationFn: (id: string) => commsApi.pauseCampaign(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['campaigns'] });
      showToast('info', 'Campaign paused', 'In-flight messages stop within a few seconds.');
    },
    onError: e => showToast('error', 'Could not pause', getErrorMessage(e)),
  });

  const dirty = Boolean(status || channel);

  return (
    <div style={{ padding: 20 }}>
      <SectionHeader title="Bulk campaigns"
                     sub={`${data?.count ?? 0} campaign${(data?.count ?? 0) === 1 ? '' : 's'}`}>
        <button className="btn btn-p" onClick={() => setShowCreate(true)}>
          <Ico d={I.plus} size={14} />
          New campaign
        </button>
      </SectionHeader>

      {/* ---- Filters ---- */}
      <div className="flex gap-3 items-center flex-wrap mb-4">
        <div className="seg">
          {STATUS_FILTERS.map(s => (
            <button key={s.key} className={`seg-btn ${status === s.key ? 'on' : ''}`}
                    onClick={() => { setStatus(s.key); setPage(1); }}>
              {s.label}
            </button>
          ))}
        </div>
        <div style={{ minWidth: 160 }}>
          <Select label="Channel" value={channel}
                  onChange={e => { setChannel(e.target.value); setPage(1); }}>
            <option value="">Every channel</option>
            {CHANNELS.map(c => <option key={c.key} value={c.key}>{c.label}</option>)}
          </Select>
        </div>
      </div>

      {isLoading && !data ? (
        <div className="flex justify-center py-16"><Spinner /></div>
      ) : !campaigns.length ? (
        <EmptyState
          icon="▣"
          title={dirty ? 'Nothing matches' : 'No campaigns yet'}
          message={dirty
            ? 'No campaign matches these filters.'
            : 'A campaign sends one WhatsApp, email or SMS message to many leads at once.'}
          action={dirty
            ? { label: 'Clear filters', onClick: () => { setStatus(''); setChannel(''); setPage(1); } }
            : { label: 'New campaign', onClick: () => setShowCreate(true) }}
        />
      ) : (
        <>
          <div className="flex flex-col gap-3">
            {campaigns.map(c => (
              <CampaignCard key={c.id} campaign={c}
                            onOpen={() => setViewing(c)}
                            onLaunch={() => setConfirmLaunch(c)}
                            onPause={() => pauseMut.mutate(c.id)}
                            pausing={pauseMut.isPending} />
            ))}
          </div>
          <Pagination page={page} totalPages={data?.total_pages ?? 1} onPageChange={setPage} />
        </>
      )}

      {showCreate && (
        <CreateCampaign onClose={() => setShowCreate(false)}
                        onCreated={() => { setShowCreate(false); setPage(1); setStatus(''); }} />
      )}

      {viewing && <CampaignResults campaign={viewing} onClose={() => setViewing(null)} />}
      {confirmLaunch && (
        <ConfirmDialog
          title={confirmLaunch.status === 'paused' ? 'Resume this campaign?' : 'Launch this campaign?'}
          message={
            confirmLaunch.status === 'paused'
              ? `Sending resumes for the ${confirmLaunch.pending_count} recipient(s) not yet attempted.`
              : `This sends immediately to an estimated ${confirmLaunch.estimated_recipients} recipient(s). Messages already sent cannot be recalled.`
          }
          confirmLabel={confirmLaunch.status === 'paused' ? 'Resume' : 'Launch now'}
          onConfirm={() => launchMut.mutate(confirmLaunch.id)}
          onCancel={() => setConfirmLaunch(null)}
        />
      )}
    </div>
  );
}

// ---- One campaign --------------------------------------------
function CampaignCard({ campaign: c, onOpen, onLaunch, onPause, pausing }: {
  campaign: BulkCampaign;
  onOpen: () => void;
  onLaunch: () => void;
  onPause: () => void;
  pausing: boolean;
}) {
  const meta = CHANNELS.find(x => x.key === c.channel) ?? CHANNELS[0];
  const done = c.sent_count + c.failed_count;
  const total = c.total_recipients || c.estimated_recipients || 0;

  return (
    // No status wash across the whole card. The old version tinted the plate
    // by status, which put five different background colours down the page
    // and made the chips saying the same thing redundant.
    <div className="plate no-ticks" style={{ padding: '16px 18px' }}>
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div style={{ minWidth: 0, flex: 1 }}>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="kpi-ic" style={{ background: 'var(--brand-50)', color: 'var(--brand)' }}>
              {meta.icon}
            </span>
            <span style={{ fontSize: 14.5, fontWeight: 600 }}>{c.name}</span>
            <span className="chip c-mute">{meta.label}</span>
            <span className={`chip ${STATUS_CHIP[c.status]}`}>
              <i className="pip" />{c.status}
            </span>
          </div>

          {/* Progress, and the figures under it. The counts used to be a row
              of inline spans with no relationship shown between them. */}
          {total > 0 && (
            <div style={{ marginTop: 12, maxWidth: 520 }}>
              <div className="cmp-bar">
                <span style={{ width: `${(c.sent_count / total) * 100}%`, background: 'var(--won)' }} />
                <span style={{ width: `${(c.failed_count / total) * 100}%`, background: 'var(--hot)' }} />
              </div>
              <div className="cmp-figs">
                <span><i style={{ background: 'var(--won)' }} />Sent <b className="num">{c.sent_count}</b></span>
                {c.delivered_count > 0 && (
                  <span><i style={{ background: 'var(--brand)' }} />Delivered <b className="num">{c.delivered_count}</b></span>
                )}
                {c.replied_count > 0 && (
                  <span><i style={{ background: 'var(--visit)' }} />Replied <b className="num">{c.replied_count}</b></span>
                )}
                {c.failed_count > 0 && (
                  <span><i style={{ background: 'var(--hot)' }} />Failed <b className="num">{c.failed_count}</b></span>
                )}
                <span style={{ marginLeft: 'auto' }} className="num">
                  {done} of {total}
                  {c.delivery_rate > 0 && ` · ${c.delivery_rate}% delivered`}
                </span>
              </div>
            </div>
          )}
          {total === 0 && (
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 10 }}>
              Estimated audience: {c.estimated_recipients} lead(s)
            </div>
          )}

          <div className="cmp-meta">
            {c.status === 'scheduled' && c.scheduled_at && (
              <span><Ico d={I.clock} size={12} />Sends {fmtDateTime(c.scheduled_at)}</span>
            )}
            {c.completed_at && (
              <span><Ico d={I.check} size={12} />Finished {fmtDateTime(c.completed_at)}</span>
            )}
            {c.status === 'paused' && c.pending_count > 0 && (
              <span><Ico d={I.pause} size={12} />{c.pending_count} left if resumed</span>
            )}
            <span>Created {fmtDate(c.created_at)}{c.created_by_name ? ` by ${c.created_by_name}` : ''}</span>
          </div>

          {c.status === 'failed' && c.failure_reason && (
            <div className="ci-callout" style={{ background: 'var(--lost-50)', borderColor: 'var(--lost)' }}>
              <div className="ci-block-h" style={{ color: 'var(--lost)', marginBottom: 4 }}>
                <Ico d={I.warn} size={12} />Stopped
              </div>
              <div style={{ fontSize: 12.5, lineHeight: 1.6 }}>{c.failure_reason}</div>
            </div>
          )}
        </div>

        <div className="flex gap-2 flex-wrap" style={{ flex: 'none' }}>
          {(c.total_recipients ?? 0) > 0 && (
            <button className="btn btn-g" onClick={onOpen}>Results</button>
          )}
          {c.status === 'draft' && (
            <button className="btn btn-p" onClick={onLaunch}>
              <Ico d={I.play} size={13} />Launch
            </button>
          )}
          {c.status === 'paused' && (
            <button className="btn btn-p" onClick={onLaunch}>
              <Ico d={I.play} size={13} />Resume
            </button>
          )}
          {c.status === 'running' && (
            <button className="btn btn-g" disabled={pausing} onClick={onPause}>
              <Ico d={I.pause} size={13} />Pause
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ---- Results: who it went to ---------------------------------
function CampaignResults({ campaign, onClose }: { campaign: BulkCampaign; onClose: () => void }) {
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const { data, isLoading } = useQuery({
    queryKey: ['campaign-recipients', campaign.id, status, page],
    queryFn: () => commsApi.campaignRecipients(campaign.id, { status: status || undefined, page }).then(r => r.data),
    placeholderData: prev => prev,
  });
  return (
    <Modal title={campaign.name} subtitle={`${campaign.sent_count} sent · ${campaign.failed_count} failed · ${campaign.delivered_count} delivered`}
           onClose={onClose} maxWidth="760px">
      <div className="flex gap-2 mb-3 flex-wrap">
        {['', 'pending', 'sent', 'delivered', 'read', 'replied', 'failed'].map(s => (
          <button key={s || 'all'} className={`btn ${status === s ? 'btn-p' : 'btn-g'}`} style={{ fontSize: '0.75rem' }}
                  onClick={() => { setStatus(s); setPage(1); }}>
            {s ? s[0].toUpperCase() + s.slice(1) : 'All'}
          </button>
        ))}
      </div>
      {isLoading ? <Spinner /> : !(data?.results ?? []).length ? (
        <div style={{ padding: 24, textAlign: 'center', color: 'var(--text-3)', fontSize: '0.85rem' }}>Nobody in this view.</div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table className="table-brutal">
            <thead><tr><th>Lead</th><th>Phone</th><th>Status</th><th>Sent</th><th>Reason</th></tr></thead>
            <tbody>
              {(data?.results ?? []).map(r => (
                <tr key={r.id}>
                  <td><a href={`/leads/${r.lead_id}`} style={{ fontWeight: 600 }}>{r.lead_name || `Lead #${r.lead_id}`}</a></td>
                  <td className="font-mono" style={{ fontSize: '0.78rem' }}>{r.phone}</td>
                  <td><span className="tag">{r.status}</span></td>
                  <td style={{ fontSize: '0.78rem' }}>{r.sent_at ? fmtDateTime(r.sent_at) : '—'}</td>
                  <td style={{ fontSize: '0.75rem', color: 'var(--hot)' }}>{r.error_message || ''}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} totalPages={data?.total_pages ?? 1} onPageChange={setPage} />
    </Modal>
  );
}

// ---- The form ------------------------------------------------
function CreateCampaign({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const { showToast } = useToast();
  const qc = useQueryClient();
  const [form, setForm] = useState(EMPTY_FORM);
  const [template, setTemplate] = useState('');
  const [touched, setTouched] = useState(false);
  // Only an admin may record an approval — the API says the same.
  const isAdmin = isAdminRole(useAuthStore(st => st.agent));

  // Every template, not just approved ones. Asking for approved-only left the
  // dropdown empty on every tenant — nothing in the product could approve one
  // — so an admin had no way to tell "none written yet" from "none approved".
  const { data: templates, isLoading: templatesLoading } = useQuery({
    queryKey: ['wa-templates'],
    queryFn: () => commsApi.listTemplates().then(r => r.data),
  });

  const { data: agentPage } = useQuery({
    queryKey: ['agents-for-audience'],
    queryFn: () => authApi.listAgents({ page_size: 200 }).then(r => r.data),
  });
  const { data: batchPage } = useQuery({
    queryKey: ['batches-for-audience'],
    queryFn: () => leadsApi.batches({ page_size: 100 }).then(r => r.data),
  });

  const filters = useMemo(() => audienceFilters(form), [form]);

  // What this audience actually reaches, answered before the campaign is
  // created rather than after. Same resolver the send uses.
  const { data: audience, isFetching: counting } = useQuery({
    queryKey: ['audience-preview', filters],
    queryFn: () => commsApi.previewAudience(filters).then(r => r.data),
    placeholderData: prev => prev,
  });

  const chosen = (templates ?? []).find(t => String(t.id) === template);
  const errors = validate(form, template, chosen);
  const invalid = Object.keys(errors).length > 0;
  // Errors appear once you have tried to submit, not while you are still typing
  // the first character of the first field.
  const err = (k: string) => (touched ? errors[k] : undefined);

  // Recording Meta's approval without leaving the form. The alternative was
  // to abandon a half-filled campaign, go to Communications, and come back.
  const approve = useMutation({
    mutationFn: (id: number) => commsApi.updateTemplate(id, { status: 'approved' }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['wa-templates'] });
      showToast('success', 'Template marked approved', 'You can now send with it.');
    },
    onError: e => showToast('error', 'Could not update the template', getErrorMessage(e)),
  });

  const create = useMutation({
    mutationFn: () => commsApi.createCampaign({
      name: form.name.trim(),
      channel: form.channel,
      audience_filters: audienceFilters(form),
      // Only the fields this channel uses. Switching channel used to leave the
      // previous one's content in state and post it alongside.
      template: form.channel === 'whatsapp' && template ? Number(template) : null,
      email_subject: form.channel === 'email' ? form.email_subject : '',
      email_body: form.channel === 'email' ? form.email_body : '',
      sms_text: form.channel === 'sms' ? form.sms_text : '',
      sms_sender_id: form.channel === 'sms' ? form.sms_sender_id : '',
      // Omit rather than send '' — the backend treats a blank datetime as a
      // validation error, and an unscheduled campaign must stay a draft.
      scheduled_at: form.scheduled_at ? new Date(form.scheduled_at).toISOString() : undefined,
    }),
    // The 201 carries the whole campaign now, including how many leads the
    // server actually resolved. That number is the one worth seeing before
    // launching, and it used to require closing the dialog and reading the
    // card to find it.
    onSuccess: r => {
      const made = r.data;
      qc.invalidateQueries({ queryKey: ['campaigns'] });
      showToast('success',
        made.status === 'scheduled' ? 'Campaign scheduled' : 'Draft saved',
        `${made.estimated_recipients} recipient(s) in the audience. `
        + (made.status === 'scheduled'
          ? 'It sends at the time you set.'
          : 'Launch it when you are ready.'));
      onCreated();
    },
    // The server names the field it rejected; "Could not create campaign"
    // threw that away and left the admin guessing which input was wrong.
    onError: e => showToast('error', 'Could not create', getErrorMessage(e)),
  });

  const set = (k: keyof typeof EMPTY_FORM) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
      setForm(p => ({ ...p, [k]: e.target.value }));

  const submit = () => {
    setTouched(true);
    if (Object.keys(validate(form, template, chosen)).length) return;
    create.mutate();
  };

  const sms = useMemo(() => smsParts(form.sms_text), [form.sms_text]);
  // datetime-local wants a local ISO string without the zone.
  const soonest = localISODateTime(new Date(Date.now() + 5 * 60_000));
  // Switched-off templates are not offered; the rest are, with their status,
  // so "none written" and "none approved" read differently.
  const usable = (templates ?? []).filter(t => t.is_active !== false);

  return (
    <Modal title="New bulk campaign"
           subtitle="One message, sent to every lead in the audience"
           onClose={onClose} maxWidth="600px">
      <div className="flex flex-col gap-4">
        <Input label="Campaign name" required value={form.name} onChange={set('name')}
               error={err('name')} placeholder="Diwali offer 2026" />

        {/* Channel as a picker rather than a dropdown of emoji. It changes
            which half of this form you see, so it should be visible at a
            glance rather than folded into a select. */}
        <div>
          <label className="field-label">
            Channel<span style={{ color: 'var(--hot)', marginLeft: 3 }}>*</span>
          </label>
          <div className="seg" style={{ display: 'flex' }}>
            {CHANNELS.map(c => (
              <button key={c.key} type="button"
                      className={`seg-btn ${form.channel === c.key ? 'on' : ''}`}
                      style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}
                      onClick={() => setForm(p => ({ ...p, channel: c.key }))}>
                {c.icon}{c.label}
              </button>
            ))}
          </div>
        </div>

        {form.channel === 'whatsapp' && (
          <div>
            <Select label="Template" required value={template}
                    onChange={e => setTemplate(e.target.value)}
                    error={err('template')}
                    hint={!templatesLoading && !usable.length
                      ? 'No templates yet. Write one under Communications first.'
                      : 'Meta only delivers bulk sends on a template it has approved.'}>
              <option value="">Select a template…</option>
              {usable.map(t => (
                <option key={t.id} value={t.id}>
                  {t.name} · {t.language}
                  {t.status === 'approved' ? '' : ` — ${t.status}`}
                  {(t.unmapped ?? []).length > 0 ? ' — variables not mapped' : ''}
                </option>
              ))}
            </Select>

            {chosen && (chosen.unmapped ?? []).length > 0 && (
              <div className="ci-callout" style={{ background: 'var(--hot-50)', borderColor: 'var(--hot)', marginTop: 8 }}>
                <div style={{ fontSize: 12.5, lineHeight: 1.6 }}>
                  {(chosen.unmapped ?? []).map(n => `{{${n}}}`).join(', ')} in this template {(chosen.unmapped ?? []).length === 1 ? "isn't" : "aren't"} linked
                  to a lead field, so every customer would receive the placeholder text. Map {(chosen.unmapped ?? []).length === 1 ? 'it' : 'them'} under
                  Communications → Templates → <b>Map variables</b>.
                </div>
              </div>
            )}

            {chosen && chosen.status !== 'approved' && (
              <div className="ci-callout" style={{ background: 'var(--hot-50)', borderColor: 'var(--hot)', marginTop: 8 }}>
                <div style={{ fontSize: 12.5, lineHeight: 1.6 }}>
                  {TEMPLATE_STATUS_NOTE[chosen.status] ?? `This template is ${chosen.status}.`}
                </div>
                {chosen.status === 'pending' && isAdmin && (
                  <button type="button" className="btn btn-g" style={{ marginTop: 8, fontSize: '0.78rem' }}
                          disabled={approve.isPending}
                          onClick={() => approve.mutate(chosen.id)}>
                    {approve.isPending ? 'Saving…' : 'Meta has approved it — mark approved'}
                  </button>
                )}
              </div>
            )}

            {chosen?.body_text && (
              <div style={{ marginTop: 8, padding: '10px 12px', background: 'var(--surface-2)',
                            border: '1px solid var(--line)', fontSize: 12.5, lineHeight: 1.6,
                            whiteSpace: 'pre-wrap' }}>
                {chosen.body_text}
              </div>
            )}
          </div>
        )}

        {form.channel === 'email' && (
          <>
            <Input label="Subject" required value={form.email_subject}
                   onChange={set('email_subject')} error={err('email_subject')} />
            <Textarea label="Body" required rows={6} value={form.email_body}
                      onChange={set('email_body')} error={err('email_body')} />
          </>
        )}

        {form.channel === 'sms' && (
          <>
            <Input label="Sender ID" value={form.sms_sender_id} onChange={set('sms_sender_id')}
                   placeholder="TELCRM"
                   hint="Your TRAI-approved six-character header. Leave blank to use the account default." />
            <Textarea label="Message" required rows={4} value={form.sms_text}
                      onChange={set('sms_text')} error={err('sms_text')}
                      hint={form.sms_text.length === 0
                        ? 'Numbers on the DND registry are skipped automatically.'
                        : `${form.sms_text.length} characters · ${sms.parts} SMS${sms.parts === 1 ? '' : ' parts'} · billed per part`} />
          </>
        )}

        <Input label="Schedule for later" type="datetime-local" min={soonest}
               value={form.scheduled_at} onChange={set('scheduled_at')}
               error={err('scheduled_at')}
               hint="Leave blank to save it as a draft and launch it yourself." />

        <div>
          <label className="field-label">Audience</label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(150px,1fr))', gap: 8 }}>
            <Select value={form.aud_status} onChange={set('aud_status')}>
              <option value="">Any status</option>
              {LEAD_STATUSES.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </Select>
            <Select value={form.aud_source} onChange={set('aud_source')}>
              <option value="">Any source</option>
              {LEAD_SOURCES.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </Select>
            <Select value={form.aud_assigned_to} onChange={set('aud_assigned_to')}>
              <option value="">Any owner</option>
              {(agentPage?.results ?? []).map(a => (
                <option key={a.id} value={a.id}>{a.name}</option>
              ))}
            </Select>
            <Select value={form.aud_batch} onChange={set('aud_batch')}>
              <option value="">Any batch</option>
              {(batchPage?.results ?? []).map(b => (
                <option key={b.id} value={b.id}>#{b.number} {b.name || b.label}</option>
              ))}
            </Select>
            <Input value={form.aud_city} onChange={set('aud_city')} placeholder="Any city" />
          </div>

          <div className="ci-callout" style={{ background: 'var(--brass-50)', borderColor: 'var(--brass)', marginTop: 8 }}>
            <div style={{ fontSize: 12.5, lineHeight: 1.6 }}>
              {counting && !audience ? 'Counting…' : (
                <>
                  <strong>{audience?.count ?? 0}</strong> lead{audience?.count === 1 ? '' : 's'} match.
                  {' '}
                  {/* A count alone would overstate an email campaign to an
                      audience that mostly has no email address. */}
                  {form.channel === 'email'
                    ? <><strong>{audience?.with_email ?? 0}</strong> have an email address and will be sent to.</>
                    : <><strong>{audience?.with_phone ?? 0}</strong> have a phone number and will be sent to.</>}
                  {(audience?.dnd ?? 0) > 0 && form.channel !== 'email' && (
                    <> {audience?.dnd} {audience?.dnd === 1 ? 'is' : 'are'} on Do-Not-Disturb and will be skipped.</>
                  )}
                </>
              )}
            </div>
            {audience?.count === 0 && (
              <div style={{ fontSize: 12.5, marginTop: 4, color: 'var(--hot)' }}>
                Nothing matches these filters — the campaign would send to nobody.
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="flex gap-3 mt-5">
        <button className="btn btn-g flex-1" onClick={onClose}>Cancel</button>
        <button className="btn btn-p flex-1"
                disabled={create.isPending || (touched && invalid)}
                onClick={submit}>
          {create.isPending ? 'Creating…' : form.scheduled_at ? 'Schedule campaign' : 'Save as draft'}
        </button>
      </div>
    </Modal>
  );
}
