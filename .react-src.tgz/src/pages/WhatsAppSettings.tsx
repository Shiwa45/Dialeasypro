// ============================================================
// Settings → WhatsApp: the tenant's WhatsApp Business connection.
//
// Pick a provider, enter that provider's credentials, and send a real test
// message. The connection only goes "active" (and sends start flowing) once a
// test send succeeds — so a wrong key never silently swallows a campaign.
//
// Gated: only rendered when the plan has a WhatsApp feature. The backend
// re-checks and answers 402 regardless.
// ============================================================
import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { commsApi, type WhatsAppProviderSlug } from '../api';
import { getErrorMessage } from '../utils/errors';
import { Spinner, useToast } from '../components/ui';

const PROVIDERS: Array<{ slug: WhatsAppProviderSlug; name: string; blurb: string }> = [
  { slug: 'meta_cloud', name: 'Meta Cloud API (direct)', blurb: 'Straight from Meta — cheapest, no reseller.' },
  { slug: 'interakt',   name: 'Interakt',                blurb: 'Popular Indian BSP.' },
  { slug: 'aisensy',    name: 'AiSensy',                 blurb: 'Budget Indian BSP.' },
  { slug: 'wati',       name: 'WATI',                    blurb: 'SMB-focused BSP.' },
  { slug: 'gupshup',    name: 'Gupshup',                 blurb: 'Enterprise BSP.' },
];

// Human labels + whether a field is a secret (rendered as password + masked).
const FIELD_META: Record<string, { label: string; secret: boolean; hint?: string }> = {
  access_token:        { label: 'Access token', secret: true },
  phone_number_id:     { label: 'Phone number ID', secret: false, hint: 'From Meta → WhatsApp → API Setup' },
  business_account_id: { label: 'Business account ID (optional)', secret: false },
  api_key:             { label: 'API key', secret: true },
  api_endpoint:        { label: 'API endpoint', secret: false, hint: 'e.g. https://live-server-12345.wati.io' },
  app_name:            { label: 'App name', secret: false },
  source_number:       { label: 'Sender number', secret: false, hint: 'Your approved WhatsApp number' },
  text_campaign:       { label: 'Text campaign name (optional)', secret: false, hint: 'AiSensy campaign used for free-text sends' },
};

export default function WhatsAppSettings() {
  const qc = useQueryClient();
  const { showToast } = useToast();

  const { data: config, isLoading } = useQuery({
    queryKey: ['wa-config'],
    queryFn: () => commsApi.getWhatsAppConfig().then(r => r.data),
  });

  const [provider, setProvider] = useState<WhatsAppProviderSlug>('meta_cloud');
  const [creds, setCreds] = useState<Record<string, string>>({});
  const [testPhone, setTestPhone] = useState('');

  // Seed the form from the saved config once it loads. Secrets come back
  // masked; leaving them masked means "don't change", so we start blank.
  useEffect(() => {
    if (config) setProvider(config.provider);
  }, [config]);

  const requiredFields = PROVIDER_FIELDS[provider] ?? config?.required_fields ?? [];

  const save = useMutation({
    mutationFn: () =>
      commsApi.saveWhatsAppConfig({
        provider,
        default_language: config?.default_language || 'en',
        credentials: creds,
      }),
    onSuccess: () => {
      showToast('success', 'Saved', 'Now send a test message to activate it.');
      setCreds({});
      qc.invalidateQueries({ queryKey: ['wa-config'] });
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not save the configuration.')),
  });

  const test = useMutation({
    mutationFn: () => commsApi.testWhatsAppConfig(testPhone.trim()),
    onSuccess: (r) => {
      if (r.data.ok) {
        showToast('success', 'Sent ✓', 'WhatsApp is now active. Campaigns will send through this provider.');
      } else {
        showToast('error', 'Test failed', r.data.message ?? 'The provider rejected the message.');
      }
      qc.invalidateQueries({ queryKey: ['wa-config'] });
    },
    onError: (e: unknown) => {
      showToast('error', 'Test failed', getErrorMessage(e, 'Could not reach the provider.'));
      qc.invalidateQueries({ queryKey: ['wa-config'] });
    },
  });

  if (isLoading) return <div className="flex justify-center py-16"><Spinner /></div>;

  const active = config?.is_active;

  return (
    <div style={{ maxWidth: 640 }}>
      {/* Status banner */}
      <div className="card-brutal" style={{
        padding: '12px 14px', marginBottom: 16,
        background: active ? 'var(--won-50)' : 'var(--warm-50)',
      }}>
        <div className="font-heading font-bold" style={{ fontSize: '0.85rem' }}>
          {active
            ? `● Connected via ${labelFor(config!.provider)}`
            : '○ Not connected — send a test message to activate'}
        </div>
        {config?.last_error && !active && (
          <div style={{ fontSize: '0.78rem', color: 'var(--lost)', marginTop: 4 }}>
            Last error: {config.last_error}
          </div>
        )}
        {config?.last_verified_at && active && (
          <div style={{ fontSize: '0.75rem', color: '#166534', marginTop: 2 }}>
            Verified {new Date(config.last_verified_at).toLocaleString('en-IN')}
          </div>
        )}
      </div>

      {/* Provider picker */}
      <label className="font-heading font-bold" style={{ fontSize: '0.72rem', letterSpacing: '0.06em' }}>PROVIDER</label>
      <div style={{ display: 'grid', gap: 8, gridTemplateColumns: '1fr 1fr', margin: '8px 0 18px' }}>
        {PROVIDERS.map(p => (
          <button key={p.slug}
                  onClick={() => { setProvider(p.slug); setCreds({}); }}
                  className="card-brutal"
                  style={{
                    textAlign: 'left', padding: '10px 12px', cursor: 'pointer',
                    background: provider === p.slug ? 'var(--brass-50)' : 'var(--surface)',
                  }}>
            <div className="font-heading font-bold" style={{ fontSize: '0.82rem' }}>{p.name}</div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-2)', marginTop: 2 }}>{p.blurb}</div>
          </button>
        ))}
      </div>

      {/* Credential fields */}
      <label className="font-heading font-bold" style={{ fontSize: '0.72rem', letterSpacing: '0.06em' }}>CREDENTIALS</label>
      <div style={{ margin: '8px 0 6px' }}>
        {requiredFields.map(field => {
          const meta = FIELD_META[field] ?? { label: field, secret: false };
          const savedVal = config?.configured_fields?.[field];
          const isSet = savedVal && savedVal.length > 0;
          return (
            <div key={field} style={{ marginBottom: 10 }}>
              <label style={{ fontSize: '0.75rem', fontWeight: 600 }}>{meta.label}</label>
              <input
                className="input-brutal"
                type={meta.secret ? 'password' : 'text'}
                value={creds[field] ?? ''}
                placeholder={meta.secret && isSet ? '•••••••• (leave blank to keep)' : (isSet ? savedVal : '')}
                onChange={e => setCreds(c => ({ ...c, [field]: e.target.value }))}
                style={{ width: '100%', marginTop: 4 }}
              />
              {meta.hint && <div style={{ fontSize: '0.68rem', color: 'var(--text-3)', marginTop: 2 }}>{meta.hint}</div>}
            </div>
          );
        })}
      </div>

      <button
        className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
        style={{ fontSize: '0.82rem', marginTop: 6 }}
        disabled={save.isPending}
        onClick={() => save.mutate()}
      >
        {save.isPending ? 'Saving…' : 'Save credentials'}
      </button>

      {/* Where a BSP sends delivery statuses and customer replies. Meta Cloud
          uses its own signed callback, set up under Integrations. The URL
          carries this workspace's secret token: posts without it are refused. */}
      {config && config.provider === provider && provider !== 'meta_cloud' && config.webhook?.status_url && (
        <div className="card-brutal" style={{ padding: '12px 14px', marginTop: 18, background: 'var(--surface)' }}>
          <div className="font-heading font-bold" style={{ fontSize: '0.85rem' }}>Delivery &amp; reply webhook</div>
          <p style={{ fontSize: '0.75rem', color: 'var(--text-2)', margin: '4px 0 8px' }}>
            Paste this into {labelFor(provider)}&rsquo;s webhook settings so delivery ticks and customer
            replies reach the CRM. Keep it private — it contains a secret token.
          </p>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <div className="font-mono" style={{
              flex: 1, fontSize: '0.7rem', wordBreak: 'break-all', padding: '6px 8px',
              border: '1px solid var(--line-2)', background: 'var(--paper)',
            }}>
              {config.webhook.status_url}
            </div>
            <button
              className="btn-brutal btn-secondary px-3 py-1 font-heading font-bold"
              style={{ fontSize: '0.72rem', whiteSpace: 'nowrap' }}
              onClick={() => navigator.clipboard.writeText(config.webhook.status_url)
                .then(() => showToast('success', 'Copied', 'Webhook URL copied.'))
                .catch(() => showToast('error', 'Copy failed', 'Select the URL and copy it by hand.'))}
            >
              Copy
            </button>
          </div>
        </div>
      )}

      {/* Test send */}
      <div style={{ borderTop: '1px solid var(--line)', marginTop: 24, paddingTop: 18 }}>
        <div className="font-heading font-bold" style={{ fontSize: '0.85rem' }}>Send a test message</div>
        <p style={{ fontSize: '0.75rem', color: 'var(--text-2)', margin: '4px 0 10px' }}>
          A real message goes to this number through the saved credentials. On success the
          connection is activated.
        </p>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            className="input-brutal"
            placeholder="+91 98765 43210"
            value={testPhone}
            onChange={e => setTestPhone(e.target.value)}
            style={{ flex: 1 }}
          />
          <button
            className="btn-brutal btn-secondary px-4 py-2 font-heading font-bold"
            style={{ fontSize: '0.8rem', whiteSpace: 'nowrap' }}
            disabled={test.isPending || !testPhone.trim()}
            onClick={() => test.mutate()}
          >
            {test.isPending ? 'Sending…' : 'Send test'}
          </button>
        </div>
      </div>
    </div>
  );
}

// Client-side copy of the backend's PROVIDER_CREDENTIAL_FIELDS so the form can
// render the right inputs before (and after) a provider switch, without a
// round-trip. Kept in sync with apps/communications/serializers.py.
const PROVIDER_FIELDS: Record<WhatsAppProviderSlug, string[]> = {
  meta_cloud: ['access_token', 'phone_number_id', 'business_account_id'],
  interakt: ['api_key'],
  aisensy: ['api_key', 'text_campaign'],
  wati: ['access_token', 'api_endpoint'],
  gupshup: ['api_key', 'app_name', 'source_number'],
  twilio: ['account_sid', 'auth_token', 'from_number'],
  '360dialog': ['api_key'],
};

function labelFor(slug: WhatsAppProviderSlug): string {
  return PROVIDERS.find(p => p.slug === slug)?.name ?? slug;
}
