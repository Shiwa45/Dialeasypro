// ============================================================
// Integrations → Meta Click-to-WhatsApp
//
// A customer taps "WhatsApp" on a Meta ad, sends a message, and becomes a lead
// with the ad's attribution attached. No Meta Lead Form is involved.
//
// This is NOT the "Meta Lead Ads" card beside it. That one fires on the
// `leadgen` webhook field and pulls Lead Form answers from the Graph API; this
// one listens on `messages` and builds the lead from the WhatsApp conversation
// itself. They share a Meta app and nothing else, and configuring one does not
// configure the other.
//
// Its settings live on the tenant's WhatsAppConfig (the same record the
// WhatsApp sending screen uses), not on a LeadSourceConfig row — which is why
// this card talks to commsApi rather than integrationsApi like its neighbours.
// ============================================================
import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { commsApi, authApi } from '../../api';
import type { WhatsAppConfig } from '../../api';
import type { Agent } from '../../types';
import { Modal, Spinner, useToast } from '../../components/ui';
import { fmtRelative } from '../../utils/fmt';
import { getErrorMessage } from '../../utils/errors';

// Credentials this integration needs, beyond what the sending setup already
// stores. Secrets are write-only: the backend returns them masked and we never
// echo a masked value back, or it would overwrite the real one with dots.
const CREDENTIAL_FIELDS: Array<{
  key: string; label: string; secret: boolean; hint: string; optional?: boolean;
}> = [
  { key: 'access_token', label: 'System user access token', secret: true,
    hint: 'Business settings → Users → System users → Generate token. The API Setup token expires in 24h.' },
  { key: 'phone_number_id', label: 'Phone number ID', secret: false,
    hint: 'Meta app → WhatsApp → API Setup. A long number, not your phone number.' },
  { key: 'business_account_id', label: 'WhatsApp Business Account ID', secret: false,
    hint: 'Same API Setup screen.' },
  { key: 'app_secret', label: 'App secret', secret: true,
    hint: 'App settings → Basic → Show. Signs every webhook delivery.' },
  { key: 'ads_access_token', label: 'Ads token (optional)', secret: true, optional: true,
    hint: 'Only needed if your main token lacks ads_read. Without it, campaign and ad NAMES stay blank.' },
];

export default function ClickToWhatsAppCard() {
  const qc = useQueryClient();
  const { showToast } = useToast();

  const [open, setOpen] = useState(false);
  const [creds, setCreds] = useState<Record<string, string>>({});
  const [copied, setCopied] = useState('');
  // Held in state, not refetched: the backend returns a new verify token
  // exactly once and never again.
  const [freshToken, setFreshToken] = useState<string | null>(null);

  const { data: config, isLoading } = useQuery({
    queryKey: ['wa-config'],
    queryFn: () => commsApi.getWhatsAppConfig().then((r) => r.data),
  });

  const { data: agents } = useQuery({
    queryKey: ['agents-for-inbound'],
    queryFn: () => authApi.listAgents({ page_size: 200 }).then((r) => r.data),
    enabled: open,
  });

  const [form, setForm] = useState({
    inbound_enabled: false,
    create_leads_from_inbound: true,
    ctwa_leads_only: false,
    reopen_lead_on_inbound: true,
    inbound_assign_to: '' as string,
    graph_api_version: '',
  });

  // Seed the form whenever the saved config arrives or the modal reopens, so a
  // cancelled edit never leaks into the next one.
  useEffect(() => {
    if (!config) return;
    setForm({
      inbound_enabled: config.inbound_enabled,
      create_leads_from_inbound: config.create_leads_from_inbound,
      ctwa_leads_only: config.ctwa_leads_only,
      reopen_lead_on_inbound: config.reopen_lead_on_inbound,
      inbound_assign_to: config.inbound_assign_to ? String(config.inbound_assign_to) : '',
      graph_api_version: config.graph_api_version || '',
    });
    setCreds({});
  }, [config, open]);

  const save = useMutation({
    mutationFn: () => commsApi.saveWhatsAppConfig({
      provider: 'meta_cloud',
      ...form,
      inbound_assign_to: form.inbound_assign_to ? Number(form.inbound_assign_to) : null,
      credentials: creds,
    }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['wa-config'] });
      showToast('success', 'Saved', 'Now point the Meta webhook at the callback URL.');
      setCreds({});
      setOpen(false);
    },
    onError: (e) => showToast('error', 'Could not save', getErrorMessage(e, 'Check the values and try again.')),
  });

  const rotate = useMutation({
    mutationFn: () => commsApi.rotateWebhookVerifyToken().then((r) => r.data),
    onSuccess: (data) => {
      setFreshToken(data.verify_token);
      qc.invalidateQueries({ queryKey: ['wa-config'] });
    },
    onError: (e) => showToast('error', 'Could not generate', getErrorMessage(e, 'Try again.')),
  });

  const toggleInbound = useMutation({
    mutationFn: (next: boolean) =>
      commsApi.saveWhatsAppConfig({ provider: config!.provider, inbound_enabled: next }),
    onSuccess: (_r, next) => {
      qc.invalidateQueries({ queryKey: ['wa-config'] });
      showToast(next ? 'success' : 'info',
        next ? 'Receiving enabled' : 'Receiving paused',
        next ? 'Inbound WhatsApp messages will now create leads.'
             : 'Deliveries from Meta will be acknowledged and discarded.');
    },
  });

  const copy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(''), 1500);
  };

  if (isLoading) {
    return <div className="card p-5 flex justify-center"><Spinner size={28} /></div>;
  }
  if (!config) return null;

  const wh = config.webhook;
  const live = config.inbound_enabled;
  // Meta cannot deliver until all three exist: a URL it can reach, a token to
  // verify with, and a secret to sign with.
  const ready = wh.verify_token_set && wh.app_secret_set && wh.access_token_set;

  return (
    <>
      <div className="card p-5">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div style={{
              fontSize: '2rem', width: '48px', height: '48px', display: 'flex',
              alignItems: 'center', justifyContent: 'center', background: '#25d366',
              border: '1px solid var(--line)', boxShadow: 'var(--shadow)',
            }}>💬</div>
            <div>
              <div className="font-heading font-black" style={{ fontSize: '0.95rem' }}>
                Meta — Click to WhatsApp
              </div>
              <div style={{
                fontSize: '0.7rem', fontWeight: 700,
                color: live ? 'var(--won)' : ready ? 'var(--warm)' : 'var(--text-3)',
              }}>
                ● {live ? 'Receiving' : ready ? 'Configured — not receiving' : 'Not configured'}
              </div>
            </div>
          </div>
          <button
            onClick={() => toggleInbound.mutate(!live)}
            disabled={toggleInbound.isPending || (!ready && !live)}
            title={!ready && !live ? 'Add the credentials first' : undefined}
            className="btn-brutal px-3 py-1 font-heading font-bold"
            style={{
              fontSize: '0.72rem', boxShadow: 'var(--shadow)',
              background: live ? 'var(--won-50)' : 'var(--surface-2)',
              opacity: !ready && !live ? 0.5 : 1,
            }}
          >
            {live ? 'Active ✓' : 'Inactive'}
          </button>
        </div>

        <p style={{ fontSize: '0.78rem', color: 'var(--text-2)', marginBottom: 12, lineHeight: 1.4 }}>
          Turns WhatsApp conversations started from a Meta ad into leads, with the
          campaign and ad they came from. Your customer fills in nothing — no lead form.
        </p>

        <div style={{ fontSize: '0.78rem', color: 'var(--text-2)', marginBottom: 10 }}>
          <div>Messages received: <strong>{config.total_inbound_messages}</strong></div>
          <div>Last webhook: {config.last_webhook_at ? fmtRelative(config.last_webhook_at) : 'Never'}</div>
          {config.last_webhook_error && (
            <div style={{ color: 'var(--hot)', marginTop: 4 }}>⚠ {config.last_webhook_error}</div>
          )}
        </div>

        {/* The value that goes into Meta's webhook configuration. */}
        <div style={{ background: 'var(--surface-2)', border: '1px solid var(--line)', padding: '8px 10px', marginBottom: 12 }}>
          <div className="flex items-center justify-between" style={{ marginBottom: 4 }}>
            <div style={{ fontSize: '0.65rem', color: 'var(--text-3)', fontWeight: 700, textTransform: 'uppercase' }}>
              Webhook / Callback URL
            </div>
            <button onClick={() => copy(wh.callback_url, 'ctwa-url')}
                    style={{ fontSize: '0.6rem', border: '1px solid var(--line)', background: copied === 'ctwa-url' ? 'var(--won-50)' : 'var(--surface)', cursor: 'pointer', padding: '2px 6px', fontWeight: 700 }}>
              {copied === 'ctwa-url' ? 'Copied ✓' : 'Copy'}
            </button>
          </div>
          <div className="font-mono" style={{ fontSize: '0.68rem', wordBreak: 'break-all', color: 'var(--text)' }}>
            {wh.callback_url}
          </div>
          {!wh.https && (
            <div style={{ fontSize: '0.66rem', color: 'var(--hot)', marginTop: 4, fontWeight: 600 }}>
              ⚠ Meta only accepts an HTTPS callback URL.
            </div>
          )}
        </div>

        <ReadinessRow label="Access token" ok={wh.access_token_set} />
        <ReadinessRow label="App secret" ok={wh.app_secret_set} />
        <ReadinessRow label="Verify token" ok={wh.verify_token_set} />
        <ReadinessRow label="Campaign & ad names (ads_read)" ok={wh.ads_token_set} optional />

        <button onClick={() => setOpen(true)}
                className="btn-brutal btn-primary px-3 py-1 font-heading font-bold w-full"
                style={{ fontSize: '0.72rem', boxShadow: 'var(--shadow)', marginTop: 10 }}>
          ⚙ Configure
        </button>
      </div>

      {open && (
        <Modal title="Meta Click-to-WhatsApp"
               subtitle="Credentials and lead rules for ad-driven WhatsApp conversations"
               onClose={() => setOpen(false)}
               maxWidth="620px">
          <div className="flex flex-col gap-4">
            {/* ---- Step 1: what goes into Meta ---- */}
            <section>
              <SubHeading>1 · Point Meta at this CRM</SubHeading>
              <FieldLabel>Callback URL</FieldLabel>
              <div className="flex gap-2" style={{ marginBottom: 10 }}>
                <input className="input-brutal font-mono" readOnly value={wh.callback_url}
                       style={{ flex: 1, fontSize: '0.7rem' }} />
                <button onClick={() => copy(wh.callback_url, 'modal-url')}
                        className="btn-brutal px-3 font-heading font-bold"
                        style={{ fontSize: '0.7rem', background: copied === 'modal-url' ? 'var(--won-50)' : 'var(--surface)' }}>
                  {copied === 'modal-url' ? '✓' : 'Copy'}
                </button>
              </div>

              <FieldLabel>Verify token</FieldLabel>
              {freshToken ? (
                <div style={{ background: 'var(--brass-50)', border: '1px solid var(--brass-600)', padding: '10px 12px' }}>
                  <div className="font-mono" style={{ fontSize: '0.72rem', wordBreak: 'break-all', marginBottom: 6 }}>
                    {freshToken}
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => copy(freshToken, 'token')}
                            className="btn-brutal px-3 py-1 font-heading font-bold"
                            style={{ fontSize: '0.68rem', background: copied === 'token' ? 'var(--won-50)' : 'var(--surface)' }}>
                      {copied === 'token' ? 'Copied ✓' : 'Copy token'}
                    </button>
                    <span style={{ fontSize: '0.68rem', color: 'var(--warm-ink)', fontWeight: 600 }}>
                      Shown once. Copy it into Meta now.
                    </span>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <button onClick={() => rotate.mutate()} disabled={rotate.isPending}
                          className="btn-brutal btn-yellow px-3 py-1.5 font-heading font-bold"
                          style={{ fontSize: '0.7rem' }}>
                    {rotate.isPending ? 'Generating…'
                      : wh.verify_token_set ? '⟳ Generate a new token' : '+ Generate verify token'}
                  </button>
                  <span style={{ fontSize: '0.68rem', color: 'var(--text-3)' }}>
                    {wh.verify_token_set
                      ? 'A token is set. Generating a new one breaks Meta until you update it there.'
                      : 'Required before Meta can verify the webhook.'}
                  </span>
                </div>
              )}

              <div style={{ fontSize: '0.7rem', color: 'var(--text-2)', marginTop: 10, lineHeight: 1.5 }}>
                In Meta: <strong>WhatsApp → Configuration → Webhook → Edit</strong>, paste both,
                then subscribe to the <strong>{wh.subscribe_fields.join(', ')}</strong> field.
                Verification succeeds without that subscription and nothing arrives — it is the
                most common thing to miss.
              </div>
            </section>

            {/* ---- Step 2: credentials ---- */}
            <section style={{ borderTop: '1px solid var(--line)', paddingTop: 14 }}>
              <SubHeading>2 · Credentials</SubHeading>
              {CREDENTIAL_FIELDS.map(f => {
                const saved = config.configured_fields?.[f.key];
                const isSet = Boolean(saved && saved.length > 0);
                return (
                  <div key={f.key} style={{ marginBottom: 10 }}>
                    <FieldLabel>
                      {f.label} {isSet && <span style={{ color: 'var(--won)', fontWeight: 700 }}>· set</span>}
                    </FieldLabel>
                    <input
                      className="input-brutal"
                      type={f.secret ? 'password' : 'text'}
                      value={creds[f.key] ?? ''}
                      placeholder={f.secret
                        ? (isSet ? '•••••••• (leave blank to keep)' : '')
                        : (isSet ? saved : '')}
                      onChange={e => setCreds(c => ({ ...c, [f.key]: e.target.value }))}
                      style={{ width: '100%' }}
                    />
                    <div style={{ fontSize: '0.66rem', color: 'var(--text-3)', marginTop: 2 }}>{f.hint}</div>
                  </div>
                );
              })}
            </section>

            {/* ---- Step 3: lead rules ---- */}
            <section style={{ borderTop: '1px solid var(--line)', paddingTop: 14 }}>
              <SubHeading>3 · What happens to inbound messages</SubHeading>

              <Toggle
                checked={form.inbound_enabled}
                onChange={v => setForm(f => ({ ...f, inbound_enabled: v }))}
                label="Receive inbound messages"
                hint="Off = Meta's deliveries are acknowledged and discarded."
              />
              <Toggle
                checked={form.create_leads_from_inbound}
                onChange={v => setForm(f => ({ ...f, create_leads_from_inbound: v }))}
                label="Create a lead from an unknown number"
                hint="Off = only messages from people already in the CRM are recorded."
              />
              <Toggle
                checked={form.ctwa_leads_only}
                onChange={v => setForm(f => ({ ...f, ctwa_leads_only: v }))}
                label="Only create leads for ad clicks"
                hint="On = someone messaging you directly, without clicking an ad, does not open a lead."
              />
              <Toggle
                checked={form.reopen_lead_on_inbound}
                onChange={v => setForm(f => ({ ...f, reopen_lead_on_inbound: v }))}
                label="Reopen a lost lead when they message again"
                hint="Moves Lost / Not Interested back to New. A won deal is never dragged back."
              />

              <div style={{ marginTop: 12 }}>
                <FieldLabel>Assign new leads to</FieldLabel>
                <select className="input-brutal" style={{ width: '100%' }}
                        value={form.inbound_assign_to}
                        onChange={e => setForm(f => ({ ...f, inbound_assign_to: e.target.value }))}>
                  <option value="">— Leave unassigned —</option>
                  {(agents?.results ?? []).map((a: Agent) => (
                    <option key={a.id} value={a.id}>{a.name}</option>
                  ))}
                </select>
              </div>

              <div style={{ marginTop: 12 }}>
                <FieldLabel>Graph API version (optional)</FieldLabel>
                <input className="input-brutal" style={{ width: '100%' }}
                       placeholder={wh.graph_api_version}
                       value={form.graph_api_version}
                       onChange={e => setForm(f => ({ ...f, graph_api_version: e.target.value }))} />
                <div style={{ fontSize: '0.66rem', color: 'var(--text-3)', marginTop: 2 }}>
                  Blank uses the platform default ({wh.graph_api_version}). Override only to pin a version.
                </div>
              </div>
            </section>

            <div className="flex gap-2" style={{ borderTop: '1px solid var(--line)', paddingTop: 14 }}>
              <button onClick={() => save.mutate()} disabled={save.isPending}
                      className="btn-brutal btn-primary px-4 py-2 font-heading font-black flex-1"
                      style={{ fontSize: '0.82rem' }}>
                {save.isPending ? 'Saving…' : 'Save'}
              </button>
              <button onClick={() => setOpen(false)}
                      className="btn-brutal px-4 py-2 font-heading font-bold" style={{ fontSize: '0.82rem' }}>
                Cancel
              </button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
}

// ---- small presentational helpers -------------------------

function ReadinessRow({ label, ok, optional }: { label: string; ok: boolean; optional?: boolean }) {
  return (
    <div className="flex items-center gap-2" style={{ fontSize: '0.72rem', marginBottom: 3 }}>
      <span style={{ color: ok ? 'var(--won)' : optional ? '#c4c4c4' : 'var(--hot)', fontWeight: 900 }}>
        {ok ? '✓' : optional ? '○' : '✗'}
      </span>
      <span style={{ color: ok ? 'var(--text)' : 'var(--text-3)' }}>{label}</span>
      {optional && !ok && <span style={{ color: 'var(--text-3)', fontSize: '0.66rem' }}>optional</span>}
    </div>
  );
}

function SubHeading({ children }: { children: React.ReactNode }) {
  return (
    <div className="font-heading font-black" style={{ fontSize: '0.8rem', marginBottom: 8 }}>
      {children}
    </div>
  );
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <label className="font-heading font-bold"
           style={{ fontSize: '0.7rem', display: 'block', marginBottom: 3 }}>
      {children}
    </label>
  );
}

function Toggle({ checked, onChange, label, hint }: {
  checked: boolean; onChange: (v: boolean) => void; label: string; hint: string;
}) {
  return (
    <label style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginBottom: 10, cursor: 'pointer' }}>
      <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)}
             style={{ marginTop: 3, width: 16, height: 16, accentColor: 'var(--text)', cursor: 'pointer' }} />
      <span>
        <span className="font-heading font-bold" style={{ fontSize: '0.78rem' }}>{label}</span>
        <span style={{ display: 'block', fontSize: '0.68rem', color: 'var(--text-3)', lineHeight: 1.4 }}>{hint}</span>
      </span>
    </label>
  );
}

export type { WhatsAppConfig };
