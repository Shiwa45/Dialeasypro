import { QueryClient } from '@tanstack/react-query';

// One client for the whole app, in its own module so the auth store can clear
// it. Every cached answer — features, capabilities, workspace, leads — belongs
// to whoever was signed in when it was fetched; see authStore.
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
      refetchOnWindowFocus: false,
    },
  },
});
