// ============================================================
// DialSathi — TypeScript Types
// Mirrors the Django backend models exactly
// ============================================================

// ---- Auth ----
export interface Agent {
  id: number;
  email: string;
  name: string;
  phone: string;
  employee_id: string;
  role: AgentRole;
  role_display: string;
  is_tenant_admin: boolean;
  is_active: boolean;
  profile_photo_url: string | null;
  timezone: string;
  language_preference: string;
  shift_start: string | null;
  shift_end: string | null;
  working_days: number[];
  is_online: boolean;
  last_active_at: string | null;
  last_login: string | null;
  total_login_count: number;
  teams: AgentTeamMembership[];
  created_at: string;
}

// Mirrors apps/core/constants.py :: AgentRole. 'trainee' used to appear here
// and in the Agents role picker, but no such role has ever existed on the
// backend — creating one was rejected by the serializer. The real fifth role
// is 'readonly'; 'hr', 'accounts' and 'recruiter' are the back-office roles.
export type AgentRole =
  | 'admin' | 'manager' | 'hr' | 'accounts' | 'recruiter' | 'senior_agent' | 'agent' | 'readonly';

export interface AgentTeamMembership {
  team_id: number;
  team_name: string;
  is_team_lead: boolean;
}

export interface TeamMember {
  agent_id: number;
  name: string;
  email: string;
  role: string;
  is_active: boolean;
  /** A team lead can see the leads of everyone in the team. */
  is_team_lead: boolean;
  joined_at: string;
}

export interface Team {
  id: number;
  name: string;
  description: string;
  is_active: boolean;
  member_count: number;
  members: TeamMember[];
  created_at: string;
}

export interface LoginResponse {
  access: string;
  refresh: string;
  access_expires_in: number;
  token_type: string;
  agent: Agent;
  must_change_password: boolean;
}

// ---- Leads ----
export type LeadStatus =
  | 'new' | 'attempted' | 'contacted' | 'interested'
  | 'not_interested' | 'follow_up' | 'negotiation'
  | 'converted' | 'lost' | 'duplicate' | 'invalid';

export type LeadPriority = 'hot' | 'warm' | 'cold';
export type LeadSource =
  | 'manual' | 'indiamart' | 'meta_facebook' | 'meta_instagram'
  // meta_ctwa = Click-to-WhatsApp ad (no lead form); whatsapp = organic inbound.
  | 'meta_ctwa' | 'whatsapp' | 'google_ads'
  | 'website' | 'referral' | 'csv_import' | 'webhook' | 'other';

export interface LeadBatch {
  id: number;
  /** Per-tenant running number — what an admin says out loud: "batch 7". */
  number: number;
  /** Admin-chosen name. Empty when they never set one — use `label`. */
  name: string;
  /** Display name: their name if set, otherwise a generated one. */
  label: string;
  kind: 'import' | 'webhook' | 'manual';
  source: string;
  source_display: string;
  status: 'open' | 'closed';
  /** Set for webhook batches (the day they collect); null for file imports. */
  collection_date: string | null;
  import_job: string | null;
  created_by: number | null;
  created_by_name: string | null;
  total_leads: number;
  assigned_count: number;
  unassigned_count: number;
  notes: string;
  closed_at: string | null;
  created_at: string;
}

export interface Lead {
  id: number;
  name: string;
  phone: string;
  alternate_phone: string;
  email: string;
  city: string;
  state: string;
  pincode: string;
  address?: string;
  source: LeadSource;
  source_display: string;
  status: LeadStatus;
  status_display: string;
  priority: LeadPriority;
  priority_display: string;
  score: number;
  assigned_to: number | null;
  assigned_to_name: string | null;
  assigned_at: string | null;
  budget: string | null;
  requirement: string;
  deal_value: string | null;
  expected_close_date: string | null;
  pipeline_stage: number;
  next_followup_at: string | null;
  followup_overdue: boolean;
  last_contacted_at: string | null;
  days_since_last_contact: number | null;
  /** Answered calls (unanswered dials are in dial_attempts). */
  contact_count: number;
  is_dnd: boolean;
  // ---- Summary of the lead's calls (kept up to date by the server) ----
  last_disposition?: number | null;
  last_disposition_name?: string | null;
  last_disposition_category?: DispositionCategory | null;
  last_call_connected?: boolean | null;
  last_dialed_at?: string | null;
  last_connected_at?: string | null;
  /** Latest note on the lead, or the notes saved with its latest call (list only). */
  latest_note?: string | null;
  latest_note_at?: string | null;
  dial_attempts?: number;
  connected_calls?: number;
  campaign_name?: string;
  ad_name?: string;
  /**
   * Present only on a lead with an ad-referred WhatsApp conversation; null
   * otherwise. See CtwaAttribution in ../api — the nested `attribution`
   * object holds only the fields Meta actually supplied.
   */
  whatsapp_attribution?: LeadWhatsAppAttribution | null;
  /** The consignment this lead arrived in. Null for leads created by hand. */
  batch?: number | null;
  batch_number?: number | null;
  batch_label?: string | null;
  tags: string[];
  followups?: FollowUp[];
  notes?: LeadNote[];
  activities?: LeadActivity[];
  custom_field_values?: CustomFieldValue[];
  created_at: string;
  updated_at: string;
}

export interface LeadWhatsAppAttribution {
  conversation_id: string;
  channel: string;
  /** Always "Meta Click-to-WhatsApp" — the human label for the lead's origin. */
  source: string;
  /** Sparse by design: absent keys mean Meta never sent that value. */
  attribution: Record<string, string>;
  first_message: string;
  first_message_at: string | null;
}

export interface FollowUp {
  id: number;
  lead: number;
  assigned_to: number;
  assigned_to_name: string;
  followup_type: string;
  followup_type_display: string;
  scheduled_at: string;
  notes: string;
  is_completed: boolean;
  completed_at: string | null;
  completion_notes: string;
  is_overdue: boolean;
  created_at: string;
}

export interface LeadNote {
  id: number;
  lead: number;
  agent: number | null;
  agent_name: string | null;
  agent_photo: string | null;
  content: string;
  is_pinned: boolean;
  attachment: string | null;
  created_at: string;
}

export interface LeadActivity {
  id: number;
  activity_type: string;
  description: string;
  performed_by: number | null;
  performed_by_name: string | null;
  meta: Record<string, unknown>;
  timestamp: string;
}

export interface CustomField {
  id: number;
  name: string;
  field_key: string;
  field_type: string;
  is_required: boolean;
  is_active: boolean;
  sort_order: number;
  options: string[];
  placeholder: string;
}

export interface CustomFieldValue {
  field: number;
  field_key: string;
  field_name: string;
  value: string;
}

export interface LeadImportJob {
  id: string;
  original_filename: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'partial';
  imported_by_name: string;
  total_rows: number;
  processed_rows: number;
  successful_rows: number;
  failed_rows: number;
  duplicate_rows: number;
  progress_percent: number;
  duplicate_action: string;
  created_at: string;
  completed_at: string | null;
  batch_name: string;
  batch_id: number | null;
  batch_number: number | null;
  batch_label: string | null;
  auto_assign: boolean;
  assign_method: string;
  assign_to_agents: number[];
  assign_max_per_agent: number | null;
  /** Filled in by the import task once auto-assign has run. */
  assignment_result: {
    distributed?: number;
    unassigned?: number;
    per_agent?: Record<string, number>;
    message?: string;
    error?: string;
  };
}

export interface LeadStats {
  today: { new_leads: number; followups_due: number; overdue_followups: number; };
  total: { total_leads: number; active_leads: number; won: number; lost: number; conversion_rate: number; pipeline_value: number; };
  by_status: Record<string, number>;
}

export interface PipelineData {
  [status: string]: Array<{
    id: number; name: string; phone: string; city: string;
    priority: string; score: number; deal_value: string | null;
    next_followup_at: string | null; 'assigned_to__name': string; created_at: string;
  }>;
}

// ---- Calls ----
/** Mirrors apps/core/constants.py :: CallDirection. 'missed' was absent here
 *  and is a real value the API returns. */
export type CallDirection = 'outbound' | 'inbound' | 'missed';

export interface CallLog {
  id: string;
  agent: number | null;
  agent_name: string | null;
  lead: number | null;
  lead_name: string | null;
  direction: CallDirection;
  phone_number: string;
  started_at: string;
  ended_at: string | null;
  duration_seconds: number;
  duration_display: string;
  is_connected: boolean;
  disposition: number | null;
  disposition_name: string | null;
  disposition_category?: DispositionCategory | null;
  notes: string;
  provider: string;
  provider_call_id: string;
  call_cost_paise: number;
  recording: CallRecording | null;
  created_at: string;
}

export interface CallRecording {
  id: string;
  duration_seconds: number;
  format: string;
  transcript: string;
  transcript_status: 'pending' | 'processing' | 'done' | 'failed';
  transcript_language: string;
  transcribed_at: string | null;
  playback_url: string | null;
}

export type Sentiment = 'positive' | 'neutral' | 'negative';

export interface CallInsight {
  id: number;
  call: string;
  status: 'pending' | 'processing' | 'done' | 'failed' | 'skipped';
  error: string;
  summary: string;
  sentiment: Sentiment | '';
  sentiment_score: number | null;
  key_points: string[];
  objections: string[];
  next_action: string;
  suggested_disposition: number | null;
  suggested_disposition_name: string | null;
  suggested_disposition_slug: string | null;
  coaching_notes: string;
  model: string;
  input_tokens: number;
  output_tokens: number;
  generated_at: string | null;
  // Context from the call the insight was drawn from. A review queue that
  // cannot say whose call it was is not reviewable.
  agent: number | null;
  agent_name: string | null;
  lead: number | null;
  lead_name: string | null;
  phone_number: string;
  direction: CallDirection | '';
  call_started_at: string | null;
  duration_seconds: number;
}

export interface CallDisposition {
  id: number;
  name: string;
  slug: string;
  is_positive: boolean;
  is_active: boolean;
  sort_order: number;
  auto_followup_hours: number | null;
  /** Lead status a call with this outcome moves the lead to; '' = leave it. */
  lead_status: string;
  /** Which call status the outcome is for. The agent only sees one group. */
  category: DispositionCategory;
  category_display?: string;
  /** Marks the lead Do Not Disturb. */
  sets_dnd: boolean;
  /** A built-in outcome: its slug and group are fixed and it can't be deleted. */
  is_system?: boolean;
  /** Derived from category; kept for older app builds. */
  marks_connected?: boolean | null;
}

export type DispositionCategory = 'connected' | 'not_connected';

// ---- Billing (tenant's own subscription) ----------------------------
export interface UsageMetric {
  // null used = not measured (storage is not metered yet);
  // null limit = no cap on this plan.
  used: number | null;
  limit: number | null;
}

export interface BillingOverview {
  plan: {
    name: string;
    slug: string;
    description: string;
    price_monthly: string;
    price_yearly: string;
  } | null;
  subscription: {
    status: string;
    billing_cycle: string;
    current_period_start: string | null;
    current_period_end: string | null;
    trial_end: string | null;
    days_until_renewal: number | null;
    cancel_at_period_end: boolean;
    is_active: boolean;
  };
  usage: {
    agents: UsageMetric;
    leads: UsageMetric;
    leads_per_day: UsageMetric;
    custom_fields: UsageMetric;
    storage_gb: UsageMetric;
  };
  features: { key: string; label: string; enabled: boolean }[];
  invoices: {
    id: string;
    invoice_number: string;
    invoice_date: string;
    base_amount: string;
    total_amount: string;
    payment_status: string;
    billing_period_start: string | null;
    billing_period_end: string | null;
    paid_at: string | null;
  }[];
  support: { platform_name: string; email: string; phone: string; whatsapp: string };
}

export interface CallStats {
  today: { total: number; connected: number; total_duration_seconds: number; };
  period: { total_calls: number; connected_calls: number; connection_rate: number; total_duration_seconds: number; avg_duration_seconds: number; total_cost_rupees: number; };
  by_disposition: Array<{ disposition__name: string; disposition__is_positive: boolean; count: number }>;
}

// ---- Communications ----
export interface WhatsAppTemplate {
  id: number;
  name: string;
  category: string;
  language: string;
  header_text: string;
  body_text: string;
  footer_text: string;
  variable_mapping: Record<string, string>;
  provider: string;
  /** What the provider knows the template as; blank → the template name. */
  provider_template_id?: string;
  status: 'pending' | 'approved' | 'rejected' | 'paused';
  is_active: boolean;
  usage_count: number;
  /** {{N}} numbers used in the body (server-computed). */
  placeholders?: number[];
  /** Placeholders with no lead field mapped — sending is refused until empty. */
  unmapped?: number[];
}

export interface BulkCampaign {
  id: string;
  name: string;
  channel: 'whatsapp' | 'email' | 'sms';
  created_by: number;
  created_by_name: string;
  audience_filters: Record<string, unknown>;
  estimated_recipients: number;
  template: number | null;
  email_subject: string;
  email_body: string;
  sms_text: string;
  sms_sender_id: string;
  status: 'draft' | 'scheduled' | 'running' | 'paused' | 'completed' | 'failed' | 'cancelled';
  /** Why a failed campaign stopped. Empty unless status is 'failed'. */
  failure_reason: string;
  /** Recipients not yet attempted — what resuming a paused campaign would send. */
  pending_count: number;
  scheduled_at: string | null;
  started_at: string | null;
  completed_at: string | null;
  total_recipients: number;
  sent_count: number;
  delivered_count: number;
  failed_count: number;
  replied_count: number;
  delivery_rate: number;
  progress_percent: number;
  created_at: string;
}

// ---- Reports ----
export interface AgentPerformanceReport {
  period: { date_from: string; date_to: string };
  agents: AgentPerformanceRow[];
}

export interface AgentPerformanceRow {
  agent_id: number;
  agent_name: string;
  agent_role: string;
  leads: { total: number; owned?: number; assigned?: number; not_called?: number; new: number; interested: number; converted: number; lost: number; conversion_rate: number; avg_score: number };
  calls: { total: number; connected: number; connection_rate: number; total_duration_seconds: number };
}

export interface FunnelRow { status: string; label: string; count: number; pct_of_total: number }

export interface ConversionFunnelReport {
  period: { date_from: string; date_to: string } | null;
  funnel: FunnelRow[];
  /** Not interested, Lost, Invalid, Duplicate. */
  closed?: FunnelRow[];
  /** funnel + closed: every lead. */
  pipeline?: FunnelRow[];
  total: number;
  lost: number;
}

export interface DispositionCount {
  disposition_id?: number | null;
  disposition__name: string;
  disposition__is_positive: boolean;
  disposition__category?: DispositionCategory | null;
  count: number;
}

export interface AgentOutcomeReport {
  period: { date_from: string; date_to: string };
  dispositions: Array<{ id: number; name: string; category: DispositionCategory; is_positive: boolean }>;
  agents: Array<{
    agent_id: number; agent_name: string;
    dials: number; connected: number; connection_rate: number; talk_seconds: number;
    no_outcome: number;
    /** disposition id → calls */
    outcomes: Record<string, number>;
  }>;
}

export interface CallAnalyticsReport {
  period: { date_from: string; date_to: string };
  summary: {
    total_calls: number; connected_calls: number; connection_rate: number;
    total_duration_seconds: number; avg_duration_seconds: number; total_cost_rupees: number;
    /** Answered calls with 0 s of talk time — a data-quality flag. */
    connected_without_duration?: number;
    no_outcome_calls?: number;
  };
  daily_trend: Array<{ date: string; total: number; connected: number; connection_rate: number }>;
  by_disposition: DispositionCount[];
}

// ---- Integrations ----
export interface IntegrationConfig {
  id: number;
  source: string;
  source_display: string;
  is_active: boolean;
  status: 'active' | 'inactive' | 'error';
  options: Record<string, unknown>;
  webhook_token: string;
  webhook_url: string;
  credentials_status: {
    verify_token: string;
    has_app_secret: boolean;
    has_access_token: boolean;
    has_api_key: boolean;
    /** Google Ads lead-form webhook key (credentials.google_key). */
    has_google_key: boolean;
  };
  total_leads_received: number;
  last_received_at: string | null;
  error_message: string;
}

export interface WebhookLog {
  id: string;
  source: string;
  source_display: string;
  processed: boolean;
  leads_created: number;
  leads_updated: number;
  error: string;
  created_at: string;
}

// ---- Plans ----
export interface Plan {
  id: number;
  name: string;
  slug: string;
  description: string;
  price_monthly: string;
  price_yearly: string;
  yearly_savings_percent: number;
  max_agents: number;
  max_leads: number;
  max_leads_per_day: number;
  max_whatsapp_bulk_per_day: number;
  max_email_bulk_per_day: number;
  max_sms_per_day: number;
  storage_gb: number;
  custom_fields_limit: number;
  data_retention_days: number;
  features: Array<{ feature_key: string; feature_label: string; is_enabled: boolean }>;
}

// ---- Pagination ----
export interface PaginatedResponse<T> {
  count: number;
  total_pages: number;
  current_page: number;
  page_size: number;
  next: string | null;
  previous: string | null;
  results: T[];
}

// ---- Daily Activity ----
export interface DailyActivity {
  date: string;
  leads: { new_today: number; overdue_followups: number };
  calls: { total: number; connected: number; total_duration_seconds: number };
  followups: { due_today: number; completed_today: number };
}

// ---- Call Queue ----
export type QueueOrderBy = 'priority' | 'oldest' | 'newest' | 'score' | 'followup_due';
export type QueueMode = 'manual' | 'auto';

export interface CallQueue {
  id: number;
  name: string;
  description: string;
  is_active: boolean;
  filter_statuses: string[];
  filter_priorities: string[];
  filter_sources: string[];
  filter_tags: string[];
  only_unworked: boolean;
  only_followup_due: boolean;
  exclude_dnd: boolean;
  order_by: QueueOrderBy;
  mode: QueueMode;
  redial_cooldown_hours: number;
  lock_ttl_minutes: number;
  agents: { id: number; name: string; role: string; is_active?: boolean }[];
  created_by_name: string | null;
  created_at: string;
  /** Leads ready to be served to the queue's active members right now. */
  waiting?: number;
  /** Leads checked out from the queue (being worked) right now. */
  checked_out?: number;
}

// ============================================================
// HRMS  (add-on module: hrms)
// ============================================================
export type LeaveStatus = 'pending' | 'approved' | 'rejected' | 'cancelled';
export type ExpenseStatus = 'pending' | 'approved' | 'rejected' | 'reimbursed';
export type AttendanceStatus = 'present' | 'absent' | 'half_day' | 'on_leave' | 'holiday' | 'week_off';

export interface Employee {
  id: number;
  agent: number;
  /** Whether the person's CRM login is active (independent of employment). */
  login_active?: boolean;
  name: string;
  email: string;
  role: string;
  employee_code: string;
  designation: string;
  department: string;
  employment_type: string;
  reporting_to: number | null;
  reporting_to_name: string | null;
  date_of_joining: string;
  date_of_exit: string | null;
  is_active: boolean;
  pan: string;
  uan: string;
  esi_number: string;
  bank_account_number: string;
  bank_ifsc: string;
}

export interface Attendance {
  id: number;
  employee: number;
  employee_code: string;
  employee_name: string;
  date: string;
  status: AttendanceStatus;
  source: string;
  check_in: string | null;
  check_out: string | null;
  worked_seconds: number;
  worked_hours: number;
  break_seconds: number;
  note: string;
}

export interface LeaveBalance {
  id: number;
  employee: number;
  leave_type: number;
  leave_type_name: string;
  year: number;
  allocated_days: string;
  used_days: string;
  remaining_days: string;
  employee_name?: string;
  employee_code?: string;
}

export interface LeaveRequest {
  id: number;
  employee: number;
  employee_name: string;
  leave_type: number;
  leave_type_name: string;
  start_date: string;
  end_date: string;
  /** Counted by the server from the dates, holidays and week-offs. */
  days: string;
  half_day?: boolean;
  /** What approval took from each year's balance, e.g. {"2026": "2"}. */
  charged_days?: Record<string, string>;
  reason: string;
  status: LeaveStatus;
  decided_by: number | null;
  decided_at: string | null;
  decision_note: string;
  created_at: string;
}

export interface ExpenseClaim {
  id: number;
  employee: number;
  employee_name: string;
  date: string;
  category: string;
  amount: string;
  description: string;
  receipt: string | null;
  status: ExpenseStatus;
  decided_by: number | null;
  decided_at: string | null;
  decision_note: string;
  reimbursed_in: string | null;
  created_at: string;
}

export interface IncentiveEarning {
  id: number;
  employee: number;
  employee_name: string;
  rule: number;
  rule_name: string;
  metric: string;
  period_month: string;
  units: string;
  amount: string;
  paid_in: string | null;
}

export interface Payslip {
  id: number;
  employee: number;
  employee_code: string;
  employee_name: string;
  period_month: string;
  payable_days: string;
  total_days: string;
  gross_earnings: string;
  incentives_amount: string;
  reimbursements_amount: string;
  total_deductions: string;
  net_pay: string;
  breakdown: Record<string, unknown>;
  status: string;
  finalized_at: string | null;
  paid_at: string | null;
  // Employment details, for the printed payslip.
  designation: string;
  department: string;
  date_of_joining: string | null;
  pan: string;
  uan: string;
  bank_account_masked: string;
  bank_ifsc: string;
}

export interface Holiday {
  id: number;
  date: string;
  name: string;
}

export interface LeaveTypeConfig {
  id: number;
  name: string;
  annual_quota_days: string;
  is_paid: boolean;
  carry_forward: boolean;
  is_active: boolean;
}

export type IncentiveMetric = 'converted_leads' | 'connected_calls' | 'talk_minutes' | 'revenue';

export interface IncentiveRuleConfig {
  id: number;
  name: string;
  metric: IncentiveMetric;
  /** ₹ per unit, except for `revenue` where this is a percentage. */
  per_unit_amount: string;
  min_units: string;
  max_payout: string | null;
  applies_to_roles: string[];
  is_active: boolean;
}

export interface SalaryStructureConfig {
  id: number;
  employee: number;
  effective_from: string;
  basic: string;
  hra: string;
  special_allowance: string;
  other_allowances: string;
  pf_employee: string;
  esi_employee: string;
  professional_tax: string;
  tds: string;
  gross: string;
  total_deductions: string;
}

// ============================================================
// ERP  (add-on module: erp_sales)
// ============================================================
export type InvoiceStatus = 'draft' | 'issued' | 'partially_paid' | 'paid' | 'cancelled';

export interface ErpCustomer {
  id: number;
  name: string;
  lead: number | null;
  email: string;
  phone: string;
  gstin: string;
  state_code: string;
  billing_address: string;
  shipping_address: string;
  is_active: boolean;
}

export interface ErpProduct {
  id: number;
  name: string;
  sku: string;
  description: string;
  hsn_sac: string;
  is_service: boolean;
  unit: string;
  unit_price: string;
  gst_rate: string;
  track_stock: boolean;
  stock_quantity: string;
  is_active: boolean;
}

export interface ErpLineItem {
  id: number;
  product: number | null;
  product_name: string | null;
  description: string;
  hsn_sac: string;
  quantity: string;
  unit_price: string;
  discount_percent: string;
  gst_rate: string;
  taxable_value: string;
  cgst_amount: string;
  sgst_amount: string;
  igst_amount: string;
  line_total: string;
}

/** Fields every ERP document (quotation, order, invoice) carries. */
interface ErpDocumentBase {
  id: number;
  number: string;
  customer: number;
  customer_name: string;
  notes: string;
  items: ErpLineItem[];
  created_by: number | null;
  subtotal: string;
  cgst_amount: string;
  sgst_amount: string;
  igst_amount: string;
  total_tax: string;
  round_off: string;
  total_amount: string;
  is_interstate: boolean;
  seller_state: string;
  buyer_state: string;
}

export interface ErpQuotation extends ErpDocumentBase {
  quotation_date: string;
  valid_until: string | null;
  status: 'draft' | 'sent' | 'accepted' | 'rejected' | 'expired' | 'converted';
  // Read live off the customer. An invoice freezes the address into
  // billing_address_snapshot because it is a legal record; a quotation is an
  // offer, so it shows the customer as they stand today.
  customer_gstin: string;
  customer_billing_address: string;
  customer_email: string;
  customer_phone: string;
}

export interface ErpSalesOrder extends ErpDocumentBase {
  order_date: string;
  quotation: number | null;
  expected_delivery: string | null;
  status: string;
}

export interface ErpInvoice extends ErpDocumentBase {
  invoice_date: string;
  due_date: string | null;
  sales_order: number | null;
  status: InvoiceStatus;
  seller_gstin: string;
  buyer_gstin: string;
  billing_address_snapshot: string;
  amount_paid: string;
  amount_due: string;
  issued_at: string | null;
  cancelled_at: string | null;
  cancellation_reason: string;
}

// ============================================================
// Recruitment / ATS  (add-on module: recruitment)
// ============================================================
export type OpeningStatus = 'draft' | 'open' | 'on_hold' | 'closed';
export type ApplicationStatus = 'active' | 'hired' | 'rejected' | 'withdrawn' | 'on_hold';
export type InterviewMode = 'phone' | 'video' | 'onsite';
export type InterviewStatus = 'scheduled' | 'completed' | 'cancelled' | 'no_show';
export type Recommendation = 'strong_no' | 'no' | 'maybe' | 'yes' | 'strong_yes';
export type OfferStatus = 'draft' | 'sent' | 'accepted' | 'declined' | 'revoked';

export interface JobOpening {
  id: number;
  title: string;
  code: string;
  department: string;
  location: string;
  employment_type: string;
  openings: number;
  min_experience_years: string;
  max_experience_years: string | null;
  salary_min: string | null;
  salary_max: string | null;
  description: string;
  hiring_manager: number | null;
  hiring_manager_name: string | null;
  status: OpeningStatus;
  opened_on: string | null;
  closed_on: string | null;
  hired_count: number;
  is_filled: boolean;
  application_count: number;
  created_at: string;
}

export interface PipelineStage {
  id: number;
  name: string;
  order: number;
  is_terminal: boolean;
  is_active: boolean;
  application_count: number;
}

export interface Candidate {
  id: number;
  name: string;
  email: string;
  phone: string;
  source: string;
  referred_by: number | null;
  referred_by_name: string | null;
  current_company: string;
  current_designation: string;
  total_experience_years: string;
  current_ctc: string | null;
  expected_ctc: string | null;
  notice_period_days: number;
  location: string;
  skills: string[];
  resume: string | null;
  notes: string;
  is_active: boolean;
  application_count: number;
  created_at: string;
}

export interface Application {
  id: number;
  candidate: number;
  candidate_name: string;
  candidate_email: string;
  candidate_phone: string;
  candidate_experience: string;
  opening: number;
  opening_title: string;
  opening_code: string;
  stage: number;
  stage_name: string;
  stage_order: number;
  status: ApplicationStatus;
  owner: number | null;
  owner_name: string | null;
  applied_on: string;
  rating: number | null;
  rejection_reason: string;
  stage_changed_at: string;
  days_in_stage: number;
  interview_count: number;
  has_offer: boolean;
  created_at: string;
}

export interface ApplicationActivity {
  id: number;
  kind: string;
  summary: string;
  detail: string;
  actor: number | null;
  actor_name: string | null;
  created_at: string;
}

export interface InterviewFeedback {
  id: number;
  interview: number;
  interviewer: number;
  interviewer_name: string;
  recommendation: Recommendation;
  score: number;
  scores: Record<string, number>;
  strengths: string;
  concerns: string;
  comments: string;
  created_at: string;
}

export interface Interview {
  id: number;
  application: number;
  candidate_name: string;
  opening_title: string;
  round_number: number;
  title: string;
  scheduled_at: string;
  duration_minutes: number;
  mode: InterviewMode;
  location_or_link: string;
  interviewers: number[];
  interviewer_names: string[];
  status: InterviewStatus;
  notes: string;
  feedback: InterviewFeedback[];
  average_score: number | null;
  feedback_pending: number;
  created_at: string;
}

export interface Offer {
  id: number;
  application: number;
  candidate_name: string;
  candidate_email: string;
  opening_title: string;
  annual_ctc: string;
  fixed_component: string;
  variable_component: string;
  joining_bonus: string;
  designation: string;
  department: string;
  employment_type: string;
  reporting_to: number | null;
  reporting_to_name: string | null;
  joining_date: string;
  valid_until: string | null;
  offer_letter: string | null;
  notes: string;
  status: OfferStatus;
  sent_at: string | null;
  responded_at: string | null;
  converted_employee: number | null;
  converted_employee_code: string | null;
  created_at: string;
}
