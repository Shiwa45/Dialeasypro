/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        heading: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
        display: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
        body: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
        mono: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
      },
      colors: {
        // Point at the CSS custom properties in index.css, so a utility
        // follows the light/dark theme instead of freezing the light value.
        paper:   'var(--paper)',
        surface: 'var(--surface)',
        line:    'var(--line)',
        ink:     'var(--text)',
        brand: {
          DEFAULT: 'var(--brand)',
          600: 'var(--brand-600)',
          700: 'var(--brand-700)',
          50:  'var(--brand-50)',
        },
        brass: {
          DEFAULT: 'var(--brass)',
          600: 'var(--brass-600)',
          50:  'var(--brass-50)',
        },
        hot:   'var(--hot)',
        warm:  'var(--warm)',
        cold:  'var(--cold)',
        won:   'var(--won)',
        lost:  'var(--lost)',
        visit: 'var(--visit)',
      },
      boxShadow: {
        // The old brutal shadow names are aliased rather than removed: they
        // are referenced in markup across the app.
        brutal: 'var(--shadow)',
        'brutal-sm': 'var(--shadow-sm)',
        'brutal-lg': 'var(--shadow-lg)',
      },
      borderRadius: { plate: '14px' },
    },
  },
  plugins: [],
};
