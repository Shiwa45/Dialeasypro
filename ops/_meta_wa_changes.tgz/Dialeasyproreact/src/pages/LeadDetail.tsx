import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { leadsApi, callsApi, commsApi, senderLabel, senderSuffix } from '../api';
import {
  Spinner, StatusBadge, PriorityBadge, ScoreBar, Modal,
  Input, Select, Textarea, ConfirmDialog, useToast, EmptyState,
} from '../components/ui';
import { fmtDate, fmtDateTime, fmtRelative, LEAD_STATUSES, STATUS_NEEDS_REASON } from '../utils/fmt';
import LeadFormModal from './LeadFormModal';
import CallOutcomeModal from '../components/CallOutcomeModal';
import { getErrorMessage } from '../utils/errors';
import { useWorkspace } from '../hooks/useWorkspace';

const TABS = ['Overview', 'Documents', 'Notes', 'Follow-ups', 'Activity', 'Calls', 'WhatsApp'] as const;

/** The file name out of a stored attachment URL, without the query string. */
const fileNameOf = (url: string) => {
  try {
    const path = new URL(url, window.location.origin).pathname;
    return decodeURIComponent(path.split('/').pop() || 'attachment');
  } catch {
    return url.split('/').pop() || 'attachment';
  }
};

const isImage = (name: string) => /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(name);
type Tab = (typeof TABS)[number];

export default function LeadDetail() {
  const { id } = useParams<{ id: string }>();
  const nav = useNavigate();
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [tab, setTab] = useState<Tab>('Overview');
  const [showEdit, setShowEdit] = useState(false);
  // Read-only users open a lead but never change it. Every write control on
  // this page hides behind `canWork`; the API refuses the writes regardless
  // (IsNotReadOnly), so this is the courteous layer, not the secure one.
  const { isReadOnly, isAgentWorkspace } = useWorkspace();
  const canWork = !isReadOnly;
  // Messaging leads from the web is not part of the agent workspace (agents
  // message from the app), so the WhatsApp tab — which can send — is dropped.
  const tabs = isAgentWorkspace ? TABS.filter(t => t !== 'WhatsApp') : TABS;
  const [noteFile, setNoteFile] = useState<File | null>(null);
  const [noteText, setNoteText] = useState('');
  const [showFollowupModal, setShowFollowupModal] = useState(false);
  const [followupForm, setFollowupForm] = useState({ followup_type: 'call', scheduled_at: '', notes: '' });
  const [showCallModal, setShowCallModal] = useState(false);
  // A call placed with ☎ Call (or one in the list with no outcome) waiting
  // for its outcome.
  const [pendingCall, setPendingCall] = useState<{ id: string; lead: number | null; lead_name: string | null;
    phone_number: string; is_connected: boolean; duration_seconds: number } | null>(null);
  const [outcomeFor, setOutcomeFor] = useState<typeof pendingCall>(null);
  const [statusAsk, setStatusAsk] = useState<{ value: string; label: string } | null>(null);
  const [statusReason, setStatusReason] = useState('');
  const [waMessage, setWaMessage] = useState('');
  // The number to send from; '' = automatic (the number this lead last wrote
  // to, else the default). Only offered when several numbers are connected.
  const [waFrom, setWaFrom] = useState<string>('');

  const { data: lead, isLoading, error: leadError } = useQuery({
    queryKey: ['lead', id],
    queryFn: () => leadsApi.get(Number(id)).then(r => r.data),
    enabled: !!id,
    // A 404 will not change on retry; anything else gets the default retry.
    retry: (count, e) => (e as { response?: { status?: number } })?.response?.status !== 404 && count < 1,
  });
  // The tab said "Leads" for every lead; name it once it has loaded.
  useEffect(() => {
    if (lead?.name) document.title = `${lead.name} · DialSathi TeleCRM`;
  }, [lead?.name]);
  const { data: notesData } = useQuery({
    queryKey: ['lead-notes', id],
    queryFn: () => leadsApi.listNotes(Number(id)).then(r => r.data),
    // Documents are the files attached to notes, so both tabs read this.
    enabled: !!id && (tab === 'Notes' || tab === 'Documents'),
  });
  const { data: followupsData } = useQuery({
    queryKey: ['lead-followups', id],
    queryFn: () => leadsApi.listFollowups(Number(id)).then(r => r.data),
    enabled: !!id && (tab === 'Follow-ups' || tab === 'Overview'),
  });
  const { data: activitiesData } = useQuery({
    queryKey: ['lead-activities', id],
    queryFn: () => leadsApi.listActivities(Number(id)).then(r => r.data),
    enabled: !!id && tab === 'Activity',
  });
  const { data: callsData } = useQuery({
    queryKey: ['lead-calls', id],
    queryFn: () => callsApi.list({ lead: id }).then(r => r.data),
    enabled: !!id && tab === 'Calls',
  });
  const { data: waMessages } = useQuery({
    queryKey: ['lead-wa', id],
    queryFn: () => commsApi.listMessages(Number(id)).then(r => r.data),
    enabled: !!id && tab === 'WhatsApp',
  });
  // Reading the thread here answers it in the WhatsApp inbox too.
  const unreadOnLead = (waMessages as { results?: Array<{ direction: string; seen_at?: string | null }> } | undefined)
    ?.results?.some(m => m.direction === 'inbound' && !m.seen_at);
  useEffect(() => {
    if (tab !== 'WhatsApp' || !unreadOnLead || !id) return;
    commsApi.inboxMarkRead(Number(id))
      .then(() => {
        qc.invalidateQueries({ queryKey: ['wa-inbox-summary'] });
        qc.invalidateQueries({ queryKey: ['wa-inbox'] });
        qc.invalidateQueries({ queryKey: ['lead-wa', id] });
      })
      .catch(() => { /* the badge just stays until the inbox is opened */ });
  }, [tab, unreadOnLead, id, qc]);
  const { data: waSenders } = useQuery({
    queryKey: ['wa-senders'],
    queryFn: () => commsApi.listWhatsAppSenders().then(r => r.data),
    enabled: !!id && tab === 'WhatsApp',
  });
  const activeSenders = (waSenders ?? []).filter(x => x.is_active);
  const { data: allCustomFields } = useQuery({
    queryKey: ['custom-fields'],
    queryFn: () => leadsApi.listCustomFields().then(r => r.data),
  });

  // The API has always accepted a file here; nothing in the UI ever sent
  // one, and nothing displayed the ones that arrived by other routes.
  const addNoteMut = useMutation({
    mutationFn: () => leadsApi.createNote(Number(id), noteText || noteFile?.name || 'Document', noteFile ?? undefined),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['lead-notes', id] });
      setNoteText('');
      setNoteFile(null);
      showToast('success', noteFile ? 'Document uploaded' : 'Note added', '');
    },
    onError: (e: unknown) => showToast('error', 'Could not save', getErrorMessage(e, 'Please try again.')),
  });
  const statusMut = useMutation({
    mutationFn: ({ status, reason }: { status: string; reason?: string }) =>
      leadsApi.updateStatus(Number(id), status, reason),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['lead', id] });
      qc.invalidateQueries({ queryKey: ['lead-activities', id] });
      setStatusAsk(null); setStatusReason('');
      showToast('success', 'Stage updated', '');
    },
    onError: (e: unknown) => showToast('error', 'Could not change the stage', getErrorMessage(e, 'Please try again.')),
  });
  // Lost and Invalid need a reason; a sale needs a note (the server enforces
  // it for agents, managers may leave it blank).
  const chooseStatus = (s: { value: string; label: string }) => {
    if (s.value === lead?.status) return;
    if (STATUS_NEEDS_REASON.includes(s.value) || s.value === 'converted') { setStatusAsk(s); return; }
    statusMut.mutate({ status: s.value });
  };
  const addFollowupMut = useMutation({
    mutationFn: () => {
      const dateVal = followupForm.scheduled_at
        ? new Date(followupForm.scheduled_at).toISOString()
        : new Date().toISOString();
      return leadsApi.createFollowup(Number(id), {
        ...followupForm,
        scheduled_at: dateVal,
      });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['lead-followups', id] });
      qc.invalidateQueries({ queryKey: ['lead', id] });
      setShowFollowupModal(false);
      setFollowupForm({ followup_type: 'call', scheduled_at: '', notes: '' });
      showToast('success', 'Follow-up scheduled', '');
    },
    onError: (err: any) => {
      const data = err?.response?.data;
      let msg = 'Failed to schedule follow-up.';
      if (data) {
        if (typeof data === 'string') msg = data;
        else if (data.message) msg = data.message;
        else if (data.scheduled_at) msg = Array.isArray(data.scheduled_at) ? data.scheduled_at.join(' ') : String(data.scheduled_at);
        else if (typeof data === 'object') msg = Object.entries(data).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(', ') : v}`).join(' | ');
      }
      showToast('error', 'Error', msg);
    },
  });
  const completeFuMut = useMutation({
    mutationFn: (fuId: number) => leadsApi.completeFollowup(fuId, ''),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['lead-followups', id] }),
  });
  const sendWaMut = useMutation({
    mutationFn: () => commsApi.sendWhatsApp(Number(id), waMessage, undefined, waFrom ? Number(waFrom) : null),
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ['lead-wa', id] });
      setWaMessage('');
      showToast('success', 'WhatsApp sent', r.data.sent_from ? `From ${r.data.sent_from}` : '');
    },
  });
  const clickToCallMut = useMutation({
    mutationFn: () => callsApi.clickToCall(Number(id)),
    // The API says whether anything was dialled: in manual mode it only logs
    // the call, so promising a ring was wrong.
    onSuccess: (res: { data?: { dialed?: boolean; message?: string; call_id?: string } }) => {
      showToast('success', res.data?.dialed ? 'Call initiated' : 'Call logged', res.data?.message ?? '');
      // The call has no outcome yet: ask for it once the agent has spoken.
      if (res.data?.call_id && lead) {
        setPendingCall({ id: res.data.call_id, lead: lead.id, lead_name: lead.name, phone_number: lead.phone,
                         is_connected: false, duration_seconds: 0 });
      }
      qc.invalidateQueries({ queryKey: ['lead', id] });
      qc.invalidateQueries({ queryKey: ['lead-calls', id] });
    },
    onError: (e: unknown) => showToast('error', 'Call failed', getErrorMessage(e, 'Check your calling integration settings.')),
  });

  // A lead the caller cannot have used to leave this page on a spinner forever
  // (`!lead` never became false). The server says why — reassigned or deleted —
  // and the page says it in words.
  if (leadError) {
    const res = (leadError as { response?: { status?: number; data?: { error?: string } } }).response;
    const code = res?.data?.error;
    const [title, message] =
      code === 'lead_not_assigned' ? ['This lead is no longer assigned to you',
        'It has been reassigned to another agent. Ask your manager if it should come back to you.']
      : code === 'lead_deleted' ? ['This lead has been deleted', 'It is no longer in the CRM.']
      : res?.status === 404 ? ['This lead could not be found', 'It may have been removed.']
      : ['Could not load this lead', getErrorMessage(leadError, 'Please try again.')];
    return (
      <div className="p-6" style={{ background: 'var(--paper)', minHeight: '100%' }}>
        <div className="card">
          <EmptyState icon="○" title={title} message={message}
                      action={{ label: 'Go to Leads', onClick: () => nav('/leads') }} />
        </div>
      </div>
    );
  }
  if (isLoading || !lead) return <Spinner />;

  return (
    <div className="p-6 flex flex-col gap-5" style={{ background: 'var(--paper)', minHeight: '100%' }}>
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 font-medium" style={{ fontSize: '0.78rem', color: 'var(--text-3)' }}>
        <button onClick={() => nav('/leads')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-3)' }}>Leads</button>
        <span>›</span>
        <span style={{ color: 'var(--text)', fontWeight: 700 }}>{lead.name}</span>
      </div>

      {/* Header */}
      <div className="card p-5 flex flex-wrap items-start gap-4 justify-between">
        <div className="flex items-start gap-4">
          <div className="avt" style={{ width: 52, height: 52, fontSize: '1.05rem' }}>
            {lead.name.split(' ').map(n => n[0]).join('').slice(0,2).toUpperCase()}
          </div>
          <div>
            <h2 className="font-heading font-black" style={{ fontSize: '1.3rem' }}>{lead.name}</h2>
            <div className="flex items-center gap-2 flex-wrap mt-1">
              <StatusBadge status={lead.status} label={lead.status_display} />
              <PriorityBadge priority={lead.priority} />
              {lead.is_dnd && <span className="badge" style={{ background: 'var(--hot)', color: 'var(--surface)', borderColor: 'var(--hot)' }}>DND</span>}
              <ScoreBar score={lead.score} />
            </div>
            <div className="flex gap-4 mt-2 flex-wrap" style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>
              <span>☎ {lead.phone}</span>
              {lead.email && <span>✉ {lead.email}</span>}
              {lead.city && <span>📍 {lead.city}</span>}
            </div>
            {/* What happened on the last call — the lead's stage alone can't
                tell "never reached" from "spoke to them". */}
            {!!lead.dial_attempts && (
              <div className="flex gap-2 mt-2 flex-wrap items-center" style={{ fontSize: '0.75rem', color: 'var(--text-2)' }}>
                <span className="font-heading font-bold" style={{ fontSize: '0.68rem', textTransform: 'uppercase' }}>Last call</span>
                <span className={`badge ${lead.last_call_connected ? 'status-active' : 'status-inactive'}`}>
                  {lead.last_call_connected ? 'Answered' : 'Not answered'}
                </span>
                {lead.last_disposition_name && <span className="tag">{lead.last_disposition_name}</span>}
                <span>{fmtRelative(lead.last_dialed_at ?? null)}</span>
                <span>· {lead.dial_attempts} dial{lead.dial_attempts === 1 ? '' : 's'}, {lead.connected_calls ?? 0} answered</span>
              </div>
            )}
          </div>
        </div>
        {canWork && <div className="flex gap-2 flex-wrap">
          <button onClick={() => clickToCallMut.mutate()}
                  className="btn-brutal btn-primary px-3 py-2 font-heading font-black" style={{ fontSize: '0.8rem' }}>
            ☎ Call
          </button>
          <button onClick={() => setShowFollowupModal(true)}
                  className="btn-brutal btn-yellow px-3 py-2 font-heading font-black" style={{ fontSize: '0.8rem' }}>
            + Follow-up
          </button>
          <button onClick={() => setShowEdit(true)}
                  className="btn-brutal btn-secondary px-3 py-2 font-heading font-bold" style={{ fontSize: '0.8rem' }}>
            ✏ Edit
          </button>
        </div>}
      </div>

      {pendingCall && (
        <div className="card card-sm p-3 flex items-center justify-between gap-3 flex-wrap"
             style={{ background: 'var(--warm-50, var(--brass-50))', borderColor: 'var(--warm)' }}>
          <span style={{ fontSize: '0.82rem' }}>
            <b>Your call to {lead.name} needs an outcome.</b> Set it when the call is over.
          </span>
          <div className="flex gap-2">
            <button className="btn btn-p" onClick={() => setOutcomeFor(pendingCall)}>Set call outcome</button>
            <button className="btn btn-g" onClick={() => setPendingCall(null)}>Later</button>
          </div>
        </div>
      )}

      {/* Pipeline stage — set by call outcomes; change it by hand here */}
      {canWork && <div className="card card-sm p-3 flex items-center gap-3 flex-wrap">
        <span className="font-heading font-bold" style={{ fontSize: '0.75rem' }}>Pipeline stage:</span>
        {LEAD_STATUSES.map(s => (
          <button key={s.value} onClick={() => chooseStatus(s)} disabled={statusMut.isPending}
                  className="btn-brutal px-2.5 py-1 font-heading font-bold"
                  style={{ fontSize: '0.68rem', background: lead.status === s.value ? 'var(--brass-50)' : 'var(--surface)', boxShadow: 'var(--shadow)' }}>
            {s.label}
          </button>
        ))}
      </div>}

      {/* Tabs */}
      <div>
        <div style={{ display: 'flex', borderBottom: '1px solid var(--line)', overflowX: 'auto' }}>
          {tabs.map(t => (
            <button key={t} onClick={() => setTab(t)}
                    className="font-heading font-bold px-4 py-2.5"
                    style={{ background: tab === t ? 'var(--brass-50)' : 'var(--surface)', border: 'none', borderRight: '1px solid var(--line)', cursor: 'pointer', fontSize: '0.8rem', whiteSpace: 'nowrap', borderBottom: tab === t ? '2px solid var(--brass-50)' : 'none' }}>
              {t}
            </button>
          ))}
        </div>

        <div className="card mt-0" style={{ borderTop: 'none' }}>
          {/* Overview */}
          {tab === 'Overview' && (
            <div className="p-5 flex flex-col gap-4">
              <div className="grid grid-cols-2 gap-x-8 gap-y-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))' }}>
                {[
                  ['Source', lead.source_display],
                  ['Assigned To', lead.assigned_to_name ?? '—'],
                  ['Email', lead.email || '—'],
                  ['City', lead.city || '—'],
                  ['Score', lead.score],
                  ['Batch', lead.batch_label || '—'],
                  ['Budget', lead.budget ? `₹${Number(lead.budget).toLocaleString('en-IN')}` : '—'],
                  ['Deal Value', lead.deal_value ? `₹${Number(lead.deal_value).toLocaleString('en-IN')}` : '—'],
                  ['Answered Calls', `${lead.connected_calls ?? lead.contact_count} of ${lead.dial_attempts ?? 0} dials`],
                  ['Last Spoke To', fmtRelative(lead.last_contacted_at)],
                  ['Next Follow-up', lead.next_followup_at ? fmtDateTime(lead.next_followup_at) : '—'],
                  ['Created', fmtDate(lead.created_at)],
                  ['Phone', lead.phone],
                  ['Alternate Phone', lead.alternate_phone || '—'],
                  ['State', lead.state || '—'],
                  ['Pincode', lead.pincode || '—'],
                  ['Campaign', lead.campaign_name || '—'],
                  ['Ad Name', lead.ad_name || '—'],
                  ['Requirement', lead.requirement || '—'],
                  ['Do not disturb', lead.is_dnd ? 'Yes — do not call' : 'No'],
                ].map(([k,v]) => (
                  <div key={String(k)}>
                    <div className="font-heading font-bold" style={{ fontSize: '0.68rem', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{k}</div>
                    <div className="font-medium mt-0.5" style={{ fontSize: '0.85rem' }}>{String(v)}</div>
                  </div>
                ))}
              </div>

              {/* Meta ad attribution — only for a lead that came from a
                  Click-to-WhatsApp ad. Rendered by iterating what the backend
                  sent: campaign / ad-set / ad NAMES are absent unless the Meta
                  token has ads_read, and showing a blank row for a name we do
                  not have would read as missing data rather than as
                  "Meta never told us". */}
              {lead.whatsapp_attribution && (
                <div className="p-3" style={{ background: '#f0fdf4', border: '1px solid var(--won)' }}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-heading font-bold" style={{ fontSize: '0.72rem', color: '#166534', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                      💬 {lead.whatsapp_attribution.source}
                    </div>
                    {lead.whatsapp_attribution.first_message_at && (
                      <div style={{ fontSize: '0.68rem', color: 'var(--text-3)' }}>
                        {fmtRelative(lead.whatsapp_attribution.first_message_at)}
                      </div>
                    )}
                  </div>

                  {Object.keys(lead.whatsapp_attribution.attribution).length > 0 ? (
                    <div className="grid gap-x-8 gap-y-2" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))' }}>
                      {ATTRIBUTION_ORDER
                        .filter(([key]) => lead.whatsapp_attribution!.attribution[key])
                        .map(([key, label]) => (
                          <div key={key}>
                            <div className="font-heading font-bold" style={{ fontSize: '0.66rem', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</div>
                            <div className="font-medium mt-0.5" style={{ fontSize: '0.82rem', wordBreak: 'break-word' }}>
                              {lead.whatsapp_attribution!.attribution[key]}
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div style={{ fontSize: '0.76rem', color: 'var(--text-2)' }}>
                      Meta did not send ad details for this conversation.
                    </div>
                  )}

                  {lead.whatsapp_attribution.first_message && (
                    <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px dashed #86efac' }}>
                      <div className="font-heading font-bold" style={{ fontSize: '0.66rem', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>First message</div>
                      <p style={{ fontSize: '0.85rem', lineHeight: 1.6, marginTop: 2 }}>
                        “{lead.whatsapp_attribution.first_message}”
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Requirement section */}
              {lead.requirement && (
                <div className="p-3" style={{ background: 'var(--brass-50)', border: '1px solid var(--brass-600)' }}>
                  <div className="font-heading font-bold mb-1" style={{ fontSize: '0.72rem', color: 'var(--text-3)', textTransform: 'uppercase' }}>Requirement</div>
                  <p style={{ fontSize: '0.85rem', lineHeight: 1.6 }}>{lead.requirement}</p>
                </div>
              )}

              {/* Custom Fields section — Always rendered if workspace has custom fields OR lead has values */}
              {((allCustomFields && allCustomFields.length > 0) || (lead.custom_field_values && lead.custom_field_values.length > 0)) && (
                <div className="p-4" style={{ background: 'var(--surface)', border: '1px solid var(--line)' }}>
                  <div className="flex items-center justify-between mb-3 border-b pb-2" style={{ borderColor: 'var(--line)' }}>
                    <div className="font-heading font-black" style={{ fontSize: '0.9rem' }}>
                      ⚙️ Custom Fields & Additional Details
                    </div>
                    {canWork && (
                      <button
                        onClick={() => setShowEdit(true)}
                        className="btn-brutal px-2.5 py-1 font-heading font-bold"
                        style={{ fontSize: '0.72rem', background: 'var(--brass-50)' }}
                      >
                        ✏ Edit Details
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))' }}>
                    {/* 1. Map all workspace-defined custom fields */}
                    {allCustomFields?.map(cf => {
                      const valObj = lead.custom_field_values?.find(
                        v => v.field_key === cf.field_key || v.field === cf.id
                      );
                      return (
                        <div key={cf.id}>
                          <div className="font-heading font-bold" style={{ fontSize: '0.7rem', color: 'var(--text-2)', textTransform: 'uppercase' }}>
                            {cf.name}
                          </div>
                          <div className="font-medium mt-0.5" style={{ fontSize: '0.88rem', wordBreak: 'break-word', color: valObj?.value ? 'var(--text)' : 'var(--text-3)' }}>
                            {valObj?.value || '—'}
                          </div>
                        </div>
                      );
                    })}

                    {/* 2. Any extra custom field values not in workspace definitions */}
                    {lead.custom_field_values?.filter(
                      cfv => !allCustomFields?.some(cf => cf.field_key === cfv.field_key || cf.id === cfv.field)
                    ).map((cfv, i) => (
                      <div key={cfv.field_key || i}>
                        <div className="font-heading font-bold" style={{ fontSize: '0.7rem', color: 'var(--text-2)', textTransform: 'uppercase' }}>
                          {cfv.field_name || cfv.field_key}
                        </div>
                        <div className="font-medium mt-0.5" style={{ fontSize: '0.88rem', wordBreak: 'break-word' }}>
                          {cfv.value || '—'}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {lead.tags?.length > 0 && (
                <div className="mt-3 flex gap-1 flex-wrap">
                  {lead.tags.map(t => <span key={t} className="tag">{t}</span>)}
                </div>
              )}
              {/* Upcoming follow-ups */}
              {(followupsData?.results?.filter(f => !f.is_completed) ?? []).length > 0 && (
                <div className="mt-4">
                  <div className="font-heading font-black mb-2" style={{ fontSize: '0.85rem' }}>Open Follow-ups</div>
                  {followupsData!.results.filter(f => !f.is_completed).slice(0,3).map(fu => (
                    <div key={fu.id} className="flex items-center justify-between p-2 mb-1"
                         style={{ background: fu.is_overdue ? 'var(--lost-50)' : '#f0fdf4', border: '1px solid var(--line)' }}>
                      <span style={{ fontSize: '0.8rem' }}>
                        {fu.followup_type_display} — {fmtDateTime(fu.scheduled_at)}
                        {fu.is_overdue && <b style={{ color: 'var(--hot)', marginLeft: 6 }}>⚠ Overdue</b>}
                      </span>
                      {canWork && (
                        <button onClick={() => completeFuMut.mutate(fu.id)}
                                className="btn-brutal px-2 py-0.5 font-heading font-bold" style={{ fontSize: '0.65rem', background: 'var(--won)', color: 'var(--surface)', boxShadow: 'var(--shadow)' }}>
                          ✓ Done
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Notes */}
          {tab === 'Documents' && (
            <div className="p-5">
              {/* Documents are files attached to notes — the same records,
                  gathered in one place instead of scattered down a thread. */}
              {canWork && <div className="flex items-center gap-2 mb-4 flex-wrap">
                <input type="file" onChange={e => setNoteFile(e.target.files?.[0] ?? null)}
                       style={{ fontSize: '0.8rem' }} />
                <button onClick={() => addNoteMut.mutate()}
                        disabled={!noteFile || addNoteMut.isPending}
                        className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                        style={{ fontSize: '0.8rem' }}>
                  {addNoteMut.isPending ? 'Uploading…' : 'Upload document'}
                </button>
                {noteFile && (
                  <span style={{ fontSize: '0.78rem', color: 'var(--text-2)' }}>{noteFile.name}</span>
                )}
              </div>}

              {(() => {
                const docs = (notesData?.results ?? []).filter(nt => !!nt.attachment);
                if (!docs.length) {
                  return <EmptyState icon="📎" title="No documents yet"
                                     message="Upload an ID, an agreement or a site-visit photo. Anything attached to a note on this lead shows up here." />;
                }
                return (
                  <div className="grid gap-3"
                       style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))' }}>
                    {docs.map(doc => {
                      const name = fileNameOf(doc.attachment!);
                      return (
                        <a key={doc.id} href={doc.attachment!} target="_blank" rel="noreferrer"
                           className="card p-3" style={{ display: 'block' }}>
                          {isImage(name) ? (
                            <img src={doc.attachment!} alt={name}
                                 style={{ width: '100%', height: 120, objectFit: 'cover',
                                          borderRadius: 'var(--r-sm)', marginBottom: 8 }} />
                          ) : (
                            <div style={{ height: 120, display: 'grid', placeItems: 'center',
                                          background: 'var(--sunken)', borderRadius: 'var(--r-sm)',
                                          marginBottom: 8, fontSize: 34 }}>📄</div>
                          )}
                          <div className="font-heading font-bold"
                               style={{ fontSize: '0.78rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
                               title={name}>{name}</div>
                          <div style={{ fontSize: '0.7rem', color: 'var(--text-3)', marginTop: 2 }}>
                            {doc.agent_name ?? 'System'} · {fmtRelative(doc.created_at)}
                          </div>
                        </a>
                      );
                    })}
                  </div>
                );
              })()}
            </div>
          )}

          {tab === 'Notes' && (
            <div className="p-5">
              {canWork && <>
              <div className="flex gap-2 mb-2">
                <textarea value={noteText} onChange={e => setNoteText(e.target.value)}
                          className="input-brutal flex-1" rows={2} placeholder="Add a note…" />
                <button onClick={() => addNoteMut.mutate()}
                        disabled={(!noteText.trim() && !noteFile) || addNoteMut.isPending}
                        className="btn-brutal btn-primary px-4 font-heading font-black"
                        style={{ fontSize: '0.85rem', alignSelf: 'stretch' }}>
                  {addNoteMut.isPending ? '…' : 'Add'}
                </button>
              </div>
              <div className="flex items-center gap-2 mb-4" style={{ fontSize: '0.78rem' }}>
                <input type="file" onChange={e => setNoteFile(e.target.files?.[0] ?? null)}
                       style={{ fontSize: '0.78rem' }} />
                {noteFile && (
                  <button className="btn-brutal px-2 py-1 font-heading font-bold"
                          style={{ fontSize: '0.68rem' }}
                          onClick={() => setNoteFile(null)}>Clear</button>
                )}
              </div>
              </>}
              {(notesData?.results ?? []).length === 0 ? <EmptyState icon="✎" title="No notes yet" message={canWork ? 'Add the first note.' : undefined} /> :
                (notesData!.results.map(note => (
                  <div key={note.id} className="p-3 mb-2" style={{ border: '1px solid var(--line)', background: note.is_pinned ? 'var(--brass-50)' : 'var(--surface)' }}>
                    <div className="flex justify-between mb-1">
                      <span className="font-heading font-bold" style={{ fontSize: '0.75rem' }}>{note.agent_name ?? 'System'}{note.is_pinned && ' 📌'}</span>
                      <span style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>{fmtRelative(note.created_at)}</span>
                    </div>
                    <p style={{ fontSize: '0.85rem', lineHeight: 1.6 }}>{note.content}</p>
                    {note.attachment && (
                      <a href={note.attachment} target="_blank" rel="noreferrer"
                         className="font-heading font-bold"
                         style={{ display: 'inline-block', marginTop: 6, fontSize: '0.75rem', color: 'var(--brass-ink)' }}>
                        📎 {fileNameOf(note.attachment)}
                      </a>
                    )}
                  </div>
                )))}
            </div>
          )}

          {/* Follow-ups */}
          {tab === 'Follow-ups' && (
            <div className="p-5">
              {canWork && (
                <button onClick={() => setShowFollowupModal(true)}
                        className="btn-brutal btn-primary px-3 py-2 font-heading font-black mb-4" style={{ fontSize: '0.82rem' }}>
                  + Schedule Follow-up
                </button>
              )}
              {(followupsData?.results ?? []).length === 0 ? <EmptyState icon="⏰" title="No follow-ups" /> :
                followupsData!.results.map(fu => (
                  <div key={fu.id} className="flex items-center justify-between p-3 mb-2"
                       style={{ border: '1px solid var(--line)', background: fu.is_completed ? '#f0fdf4' : fu.is_overdue ? 'var(--lost-50)' : 'var(--surface)' }}>
                    <div>
                      <div className="font-heading font-bold" style={{ fontSize: '0.82rem' }}>{fu.followup_type_display} — {fmtDateTime(fu.scheduled_at)}</div>
                      {fu.notes && <p style={{ fontSize: '0.75rem', color: 'var(--text-2)', marginTop: '2px' }}>{fu.notes}</p>}
                      <span className="font-medium" style={{ fontSize: '0.7rem', color: fu.is_completed ? 'var(--won)' : fu.is_overdue ? 'var(--hot)' : 'var(--text-2)' }}>
                        {fu.is_completed ? '✓ Completed' : fu.is_overdue ? '⚠ Overdue' : 'Pending'}
                      </span>
                    </div>
                    {canWork && !fu.is_completed && (
                      <button onClick={() => completeFuMut.mutate(fu.id)}
                              className="btn-brutal px-2 py-1 font-heading font-bold" style={{ fontSize: '0.68rem', background: 'var(--won)', color: 'var(--surface)', boxShadow: 'var(--shadow)' }}>
                        ✓ Done
                      </button>
                    )}
                  </div>
                ))}
            </div>
          )}

          {/* Activity */}
          {tab === 'Activity' && (
            <div className="p-5">
              {(activitiesData as { results?: unknown[] } | undefined)?.results?.length === 0 ? <EmptyState icon="○" title="No activity yet" /> :
                ((activitiesData as { results?: Array<{id:number;activity_type:string;description:string;performed_by_name:string|null;timestamp:string}> } | undefined)?.results ?? []).map(a => (
                  <div key={a.id} className="flex gap-3 mb-3 pb-3" style={{ borderBottom: '1px solid var(--line)' }}>
                    <div style={{ width: '28px', height: '28px', background: 'var(--brass-50)', border: '1px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.8rem', flexShrink: 0 }}>
                      {a.activity_type === 'call' ? '☎' : a.activity_type === 'whatsapp' ? '✉' : a.activity_type === 'status_change' ? '→' : '○'}
                    </div>
                    <div>
                      <p style={{ fontSize: '0.83rem', lineHeight: 1.5 }}>{a.description}</p>
                      <div style={{ fontSize: '0.7rem', color: 'var(--text-3)', marginTop: '2px' }}>
                        {a.performed_by_name ?? 'System'} · {fmtRelative(a.timestamp)}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          )}

          {/* Calls */}
          {tab === 'Calls' && (
            <div className="p-5">
              <button onClick={() => setShowCallModal(true)}
                      className="btn-brutal btn-primary px-3 py-2 font-heading font-black mb-4" style={{ fontSize: '0.82rem' }}>
                + Log Manual Call
              </button>
              {(callsData?.results ?? []).length === 0 ? <EmptyState icon="☎" title="No calls logged" /> :
                callsData!.results.map(c => (
                  <div key={c.id} className="flex items-center justify-between p-3 mb-2" style={{ border: '1px solid var(--line)', background: 'var(--surface)' }}>
                    <div>
                      <div className="flex items-center gap-2">
                        <span style={{ fontSize: '1rem' }}>{c.direction === 'outbound' ? '↗' : '↙'}</span>
                        <span className="font-heading font-bold" style={{ fontSize: '0.82rem' }}>{c.duration_display}</span>
                        {c.is_connected ? <span className="badge status-active">Connected</span> : <span className="badge status-inactive">No Answer</span>}
                        {c.disposition_name
                          ? <span className="tag">{c.disposition_name}</span>
                          : canWork && <button className="tag" style={{ cursor: 'pointer', color: 'var(--hot)' }}
                                               onClick={() => setOutcomeFor(c)}>Set outcome</button>}
                      </div>
                      {c.notes && <p style={{ fontSize: '0.75rem', color: 'var(--text-2)', marginTop: '2px' }}>{c.notes}</p>}
                      <div style={{ fontSize: '0.7rem', color: 'var(--text-3)', marginTop: '2px' }}>{c.agent_name} · {fmtRelative(c.started_at)}</div>
                    </div>
                    {c.recording?.playback_url && (
                      <audio controls src={c.recording.playback_url} style={{ height: '32px' }} />
                    )}
                  </div>
                ))}
            </div>
          )}

          {/* WhatsApp */}
          {tab === 'WhatsApp' && (
            <div className="p-5">
              <div style={{ maxHeight: '320px', overflowY: 'auto', marginBottom: '16px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {(waMessages as { results?: Array<{id:string;direction:string;content:string;status:string;sent_at:string|null;created_at?:string;sent_by_name:string|null;account_label?:string|null;error_message?:string}> } | undefined)?.results?.map(msg => (
                  <div key={msg.id} style={{
                    maxWidth: '80%', padding: '10px 14px', border: '1px solid var(--line)',
                    // Theme tokens: a fixed light blue made inbound messages
                    // white-on-near-white in dark mode.
                    background: msg.direction === 'outbound' ? 'var(--brass-50)' : 'var(--cold-50)',
                    color: 'var(--text)',
                    alignSelf: msg.direction === 'outbound' ? 'flex-end' : 'flex-start',
                  }}>
                    <p style={{ fontSize: '0.85rem' }}>{msg.content}</p>
                    <div style={{ fontSize: '0.65rem', color: 'var(--text-3)', marginTop: '4px', textAlign: msg.direction === 'outbound' ? 'right' : 'left' }}>
                      {msg.sent_by_name ?? (msg.direction === 'inbound' ? 'Customer' : 'System')} · {fmtRelative(msg.sent_at ?? msg.created_at ?? null)} · {msg.status}
                      {msg.status === 'failed' && msg.error_message && <> · {msg.error_message}</>}
                      {(waSenders?.length ?? 0) > 1 && msg.account_label && <> · {msg.direction === 'outbound' ? 'from' : 'to'} {msg.account_label}</>}
                    </div>
                  </div>
                ))}
              </div>
              {activeSenders.length > 1 && (
                <div className="flex items-center gap-2" style={{ marginBottom: 8, fontSize: '0.75rem' }}>
                  <span style={{ fontWeight: 600 }}>Send from</span>
                  <select className="input-brutal" value={waFrom} onChange={e => setWaFrom(e.target.value)}
                          style={{ fontSize: '0.78rem', padding: '4px 8px' }}>
                    <option value="">Automatic — the number they last wrote to</option>
                    {activeSenders.map(x => (
                      <option key={x.id} value={x.id}>{senderLabel(x)}{senderSuffix(x)}</option>
                    ))}
                  </select>
                </div>
              )}
              <div className="flex gap-2">
                <textarea value={waMessage} onChange={e => setWaMessage(e.target.value)}
                          className="input-brutal flex-1" rows={2} placeholder="Type WhatsApp message…" />
                <button onClick={() => sendWaMut.mutate()} disabled={!waMessage.trim() || sendWaMut.isPending}
                        className="btn-brutal btn-primary px-4 font-heading font-black" style={{ fontSize: '0.85rem', alignSelf: 'stretch' }}>
                  Send ✉
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      {showEdit && <LeadFormModal lead={lead} onClose={() => setShowEdit(false)} onSuccess={() => { qc.invalidateQueries({ queryKey: ['lead', id] }); setShowEdit(false); showToast('success', 'Lead updated', ''); }} />}

      {showFollowupModal && (
        <Modal title="Schedule Follow-up" onClose={() => setShowFollowupModal(false)}>
          <div className="flex flex-col gap-3">
            <Select label="Type" value={followupForm.followup_type} onChange={e => setFollowupForm(p => ({ ...p, followup_type: e.target.value }))}>
              {['call','email','whatsapp','visit','meeting'].map(t => <option key={t} value={t}>{t.charAt(0).toUpperCase()+t.slice(1)}</option>)}
            </Select>
            <Input label="Scheduled At *" type="datetime-local" value={followupForm.scheduled_at} onChange={e => setFollowupForm(p => ({ ...p, scheduled_at: e.target.value }))} />
            <Textarea label="Notes" value={followupForm.notes} onChange={e => setFollowupForm(p => ({ ...p, notes: e.target.value }))} />
          </div>
          <div className="flex gap-3 mt-4"><button onClick={() => setShowFollowupModal(false)} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">Cancel</button>
          <button
            onClick={() => addFollowupMut.mutate()}
            disabled={addFollowupMut.isPending || !followupForm.scheduled_at}
            className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black"
            style={{ boxShadow: 'var(--shadow)' }}
          >
            {addFollowupMut.isPending ? '◌ Scheduling…' : 'Schedule →'}
          </button></div>
        </Modal>
      )}

      {showCallModal && lead && (
        <CallOutcomeModal mode="log" leadId={lead.id} phone={lead.phone} onClose={() => setShowCallModal(false)} />
      )}
      {outcomeFor && (
        <CallOutcomeModal mode="set" call={outcomeFor}
                          onClose={() => setOutcomeFor(null)}
                          onSaved={() => { if (pendingCall?.id === outcomeFor.id) setPendingCall(null); }} />
      )}
      {statusAsk && (
        <Modal title={`Move to "${statusAsk.label}"`} onClose={() => { setStatusAsk(null); setStatusReason(''); }}>
          <Textarea label={statusAsk.value === 'converted' ? 'Sale note (what was sold, order or invoice no.)' : 'Reason'}
                    required={STATUS_NEEDS_REASON.includes(statusAsk.value)}
                    value={statusReason} onChange={e => setStatusReason(e.target.value)} />
          <div className="flex gap-3 mt-4">
            <button onClick={() => { setStatusAsk(null); setStatusReason(''); }}
                    className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">Cancel</button>
            <button disabled={statusMut.isPending || (STATUS_NEEDS_REASON.includes(statusAsk.value) && !statusReason.trim())}
                    onClick={() => statusMut.mutate({ status: statusAsk.value, reason: statusReason.trim() || undefined })}
                    className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black">
              {statusMut.isPending ? 'Saving…' : 'Save'}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// Attribution keys in the order a salesperson reads them: the campaign first,
// then narrowing to the exact ad, then the creative they actually tapped.
// Anything the backend omitted is skipped, never rendered blank.
const ATTRIBUTION_ORDER: Array<[string, string]> = [
  ['campaign_name', 'Campaign'],
  ['adset_name', 'Ad Set'],
  ['ad_name', 'Ad'],
  ['headline', 'Ad Headline'],
  ['body', 'Ad Text'],
  ['source_type', 'Referral Type'],
  ['ad_id', 'Ad ID'],
  ['campaign_id', 'Campaign ID'],
  ['adset_id', 'Ad Set ID'],
];
