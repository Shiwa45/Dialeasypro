// ============================================================
// Settings → WhatsApp: the workspace's WhatsApp numbers.
//
// A workspace can connect several WhatsApp numbers (a Sales number and a
// Support number, or two Meta WhatsApp Business Accounts). Each one has its
// own provider, credentials and test send; one is the default, used whenever
// nothing picks another number. A number only goes "active" (and sends start
// flowing) once a test send succeeds — so a wrong key never silently swallows
// a campaign.
//
// More than one number needs the "Multiple WhatsApp numbers" plan feature;
// the backend says so in `can_add` and re-checks on create.
//
// Gated: only rendered when the plan has a WhatsApp feature. The backend
// re-checks and answers 402 regardless.
// ============================================================
import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { authApi, commsApi, type MetaBusinessNumber, type WhatsAppConfig, type WhatsAppProviderSlug } from '../api';
import { getErrorMessage } from '../utils/errors';
import { Spinner, useToast } from '../components/ui';

const PROVIDERS: Array<{ slug: WhatsAppProviderSlug; name: string; blurb: string }> = [
  { slug: 'meta_cloud', name: 'Meta Cloud API (direct)', blurb: 'Straight from Meta — cheapest, no reseller.' },
  { slug: 'interakt',   name: 'Interakt',                blurb: 'Popular Indian BSP.' },
  { slug: 'aisensy',    name: 'AiSensy',                 blurb: 'Budget Indian BSP.' },
  { slug: 'wati',       name: 'WATI',                    blurb: 'SMB-focused BSP.' },
  { slug: 'gupshup',    name: 'Gupshup',                 blurb: 'Enterprise BSP.' },
];

// Human labels + whether a field is a secret (rendered as password + masked).
const FIELD_META: Record<string, { label: string; secret: boolean; hint?: string }> = {
  access_token:        { label: 'Access token', secret: true },
  phone_number_id:     { label: 'Phone number ID', secret: false, hint: 'From Meta → WhatsApp → API Setup' },
  business_account_id: { label: 'Business account ID (optional)', secret: false },
  api_key:             { label: 'API key', secret: true },
  api_endpoint:        { label: 'API endpoint', secret: false, hint: 'e.g. https://live-server-12345.wati.io' },
  app_name:            { label: 'App name', secret: false },
  source_number:       { label: 'Sender number', secret: false, hint: 'Your approved WhatsApp number' },
  text_campaign:       { label: 'Text campaign name (optional)', secret: false, hint: 'AiSensy campaign used for free-text sends' },
};

const NEW = 'new' as const;

export default function WhatsAppSettings() {
  const { data, isLoading } = useQuery({
    queryKey: ['wa-accounts'],
    queryFn: () => commsApi.listWhatsAppAccounts().then(r => r.data),
  });
  const accounts = data?.results ?? [];
  const [selected, setSelected] = useState<number | typeof NEW | null>(null);

  // Open the default number first; a workspace with none starts on "new".
  useEffect(() => {
    if (!data) return;
    const stillThere = typeof selected === 'number' && accounts.some(a => a.id === selected);
    if (selected === NEW || stillThere) return;
    setSelected(accounts[0]?.id ?? NEW);
  }, [data]); // eslint-disable-line react-hooks/exhaustive-deps

  if (isLoading) return <div className="flex justify-center py-16"><Spinner /></div>;

  const current = typeof selected === 'number' ? accounts.find(a => a.id === selected) ?? null : null;

  return (
    <div style={{ maxWidth: 720 }}>
      {/* The numbers */}
      <div className="flex items-center justify-between" style={{ marginBottom: 8 }}>
        <label className="font-heading font-bold" style={{ fontSize: '0.72rem', letterSpacing: '0.06em' }}>
          WHATSAPP NUMBERS
        </label>
        {accounts.length > 0 && (
          <button
            className="btn-brutal btn-secondary px-3 py-1 font-heading font-bold"
            style={{ fontSize: '0.72rem', opacity: data?.can_add ? 1 : 0.55 }}
            disabled={!data?.can_add}
            title={data?.can_add ? undefined : 'Your plan includes one WhatsApp number. Upgrade to add more.'}
            onClick={() => setSelected(NEW)}
          >
            + Add number
          </button>
        )}
      </div>
      {accounts.length > 0 && !data?.can_add && (
        <div style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginBottom: 8 }}>
          Your plan includes one WhatsApp number. Upgrade to the plan with
          &ldquo;Multiple WhatsApp numbers&rdquo; to connect a second one.
        </div>
      )}
      <div style={{ display: 'grid', gap: 8, gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', marginBottom: 18 }}>
        {accounts.map(a => (
          <button key={a.id} onClick={() => setSelected(a.id)} className="card-brutal"
                  style={{
                    textAlign: 'left', padding: '10px 12px', cursor: 'pointer',
                    background: selected === a.id ? 'var(--brass-50)' : 'var(--surface)',
                  }}>
            <div className="flex items-center justify-between gap-2">
              <span className="font-heading font-bold" style={{ fontSize: '0.84rem' }}>{a.label}</span>
              {a.is_default && (
                <span className="font-heading font-bold" style={{
                  fontSize: '0.6rem', padding: '1px 6px', border: '1px solid var(--line)',
                  background: 'var(--won-50)',
                }}>DEFAULT</span>
              )}
            </div>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-2)', marginTop: 2 }}>
              {a.display_phone || labelFor(a.provider)}
            </div>
            <div style={{ fontSize: '0.68rem', marginTop: 4, color: a.is_active ? 'var(--won)' : 'var(--warm)' }}>
              {a.is_active ? '● Connected' : '○ Not connected'}
            </div>
            {(a.agent_names?.length ?? 0) > 0 && (
              <div style={{ fontSize: '0.66rem', marginTop: 2, color: 'var(--text-3)' }}
                   title={a.agent_names.map(x => x.name).join(', ')}>
                {a.agent_names.length} agent{a.agent_names.length === 1 ? '' : 's'} assigned
              </div>
            )}
          </button>
        ))}
        {selected === NEW && (
          <div className="card-brutal" style={{ padding: '10px 12px', background: 'var(--brass-50)' }}>
            <div className="font-heading font-bold" style={{ fontSize: '0.84rem' }}>New number</div>
            <div style={{ fontSize: '0.72rem', color: 'var(--text-2)', marginTop: 2 }}>Fill in the details below</div>
          </div>
        )}
      </div>

      <AccountEditor
        key={selected === NEW ? 'new' : current?.id ?? 'none'}
        account={selected === NEW ? null : current}
        isOnly={accounts.length <= 1}
        canAdd={!!data?.can_add}
        onCreated={(id) => setSelected(id)}
        onRemoved={() => setSelected(null)}
        onCancelNew={accounts.length ? () => setSelected(accounts[0].id) : undefined}
      />
    </div>
  );
}

// ------------------------------------------------------------
// One number: name, provider, credentials, test, default, remove.
// ------------------------------------------------------------
function AccountEditor({ account, isOnly, canAdd, onCreated, onRemoved, onCancelNew }: {
  account: WhatsAppConfig | null;
  isOnly: boolean;
  canAdd: boolean;
  onCreated: (id: number) => void;
  onRemoved: () => void;
  onCancelNew?: () => void;
}) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const isNew = account === null;

  const [label, setLabel] = useState(account?.label ?? (isOnly && isNew ? 'Main number' : ''));
  const [displayPhone, setDisplayPhone] = useState(account?.display_phone ?? '');
  const [provider, setProvider] = useState<WhatsAppProviderSlug>(account?.provider ?? 'meta_cloud');
  const [creds, setCreds] = useState<Record<string, string>>({});
  const [testPhone, setTestPhone] = useState('');
  const [confirmRemove, setConfirmRemove] = useState(false);

  const requiredFields = PROVIDER_FIELDS[provider] ?? account?.required_fields ?? [];

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['wa-accounts'] });
    qc.invalidateQueries({ queryKey: ['wa-config'] });
    qc.invalidateQueries({ queryKey: ['wa-senders'] });
  };

  const save = useMutation({
    mutationFn: () => {
      const payload = {
        label: label.trim(),
        display_phone: displayPhone.trim(),
        provider,
        default_language: account?.default_language || 'en',
        credentials: creds,
      };
      return isNew
        ? commsApi.createWhatsAppAccount(payload)
        : commsApi.updateWhatsAppAccount(account!.id, payload);
    },
    onSuccess: (r) => {
      const credsChanged = Object.values(creds).some(v => v.trim()) || provider !== account?.provider;
      showToast('success', 'Saved', credsChanged
        ? 'Now send a test message to activate this number.'
        : 'Changes saved.');
      setCreds({});
      refresh();
      if (isNew) onCreated(r.data.id);
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not save this number.')),
  });

  const test = useMutation({
    mutationFn: () => commsApi.testWhatsAppAccount(account!.id, testPhone.trim()),
    onSuccess: (r) => {
      if (r.data.ok) {
        showToast('success', 'Sent ✓', `${account!.label} is now active and can send messages.`);
      } else {
        showToast('error', 'Test failed', r.data.message ?? 'The provider rejected the message.');
      }
      refresh();
    },
    onError: (e: unknown) => {
      showToast('error', 'Test failed', getErrorMessage(e, 'Could not reach the provider.'));
      refresh();
    },
  });

  const makeDefault = useMutation({
    mutationFn: () => commsApi.makeDefaultWhatsAppAccount(account!.id),
    onSuccess: () => {
      showToast('success', 'Default changed', `Messages now go out from ${account!.label} unless another number is picked.`);
      refresh();
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not change the default.')),
  });

  const remove = useMutation({
    mutationFn: () => commsApi.deleteWhatsAppAccount(account!.id),
    onSuccess: () => {
      showToast('success', 'Disconnected', `${account!.label} was removed. Its message history is kept.`);
      setConfirmRemove(false);
      refresh();
      onRemoved();
    },
    onError: (e: unknown) => {
      setConfirmRemove(false);
      showToast('error', 'Could not remove', getErrorMessage(e, 'Try again.'));
    },
  });

  const active = account?.is_active;

  return (
    <div>
      {/* Status banner */}
      {!isNew && (
        <div className="card-brutal" style={{
          padding: '12px 14px', marginBottom: 16,
          background: active ? 'var(--won-50)' : 'var(--warm-50)',
        }}>
          <div className="flex items-center justify-between gap-2" style={{ flexWrap: 'wrap' }}>
            <div className="font-heading font-bold" style={{ fontSize: '0.85rem' }}>
              {active
                ? `● ${account!.label} connected via ${labelFor(account!.provider)}`
                : `○ ${account!.label} not connected — send a test message to activate`}
            </div>
            {!account!.is_default && (
              <button
                className="btn-brutal btn-secondary px-3 py-1 font-heading font-bold"
                style={{ fontSize: '0.7rem' }}
                disabled={makeDefault.isPending}
                onClick={() => makeDefault.mutate()}
              >
                {makeDefault.isPending ? 'Saving…' : 'Make default'}
              </button>
            )}
          </div>
          {account!.last_error && !active && (
            <div style={{ fontSize: '0.78rem', color: 'var(--lost)', marginTop: 4 }}>
              Last error: {account!.last_error}
            </div>
          )}
          {account!.last_verified_at && active && (
            <div style={{ fontSize: '0.75rem', color: '#166534', marginTop: 2 }}>
              Verified {new Date(account!.last_verified_at).toLocaleString('en-IN')}
            </div>
          )}
        </div>
      )}

      {/* Name and number */}
      <div style={{ display: 'grid', gap: 10, gridTemplateColumns: '1fr 1fr', marginBottom: 16 }}>
        <div>
          <label style={{ fontSize: '0.75rem', fontWeight: 600 }}>Name</label>
          <input className="input-brutal" value={label} placeholder="Sales, Support…"
                 onChange={e => setLabel(e.target.value)} style={{ width: '100%', marginTop: 4 }} />
          <div style={{ fontSize: '0.68rem', color: 'var(--text-3)', marginTop: 2 }}>
            Shown when agents choose which number to send from.
          </div>
        </div>
        <div>
          <label style={{ fontSize: '0.75rem', fontWeight: 600 }}>WhatsApp number</label>
          <input className="input-brutal" value={displayPhone} placeholder="+91 98765 43210"
                 onChange={e => setDisplayPhone(e.target.value)} style={{ width: '100%', marginTop: 4 }} />
          <div style={{ fontSize: '0.68rem', color: 'var(--text-3)', marginTop: 2 }}>
            The number customers see.
          </div>
        </div>
      </div>

      {/* Provider picker */}
      <label className="font-heading font-bold" style={{ fontSize: '0.72rem', letterSpacing: '0.06em' }}>PROVIDER</label>
      <div style={{ display: 'grid', gap: 8, gridTemplateColumns: '1fr 1fr', margin: '8px 0 18px' }}>
        {PROVIDERS.map(p => (
          <button key={p.slug}
                  onClick={() => { setProvider(p.slug); setCreds({}); }}
                  className="card-brutal"
                  style={{
                    textAlign: 'left', padding: '10px 12px', cursor: 'pointer',
                    background: provider === p.slug ? 'var(--brass-50)' : 'var(--surface)',
                  }}>
            <div className="font-heading font-bold" style={{ fontSize: '0.82rem' }}>{p.name}</div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-2)', marginTop: 2 }}>{p.blurb}</div>
          </button>
        ))}
      </div>

      {/* Credential fields */}
      <label className="font-heading font-bold" style={{ fontSize: '0.72rem', letterSpacing: '0.06em' }}>CREDENTIALS</label>
      <div style={{ margin: '8px 0 6px' }}>
        {requiredFields.map(field => {
          const meta = FIELD_META[field] ?? { label: field, secret: false };
          const savedVal = account?.provider === provider ? account?.configured_fields?.[field] : undefined;
          const isSet = savedVal && savedVal.length > 0;
          return (
            <div key={field} style={{ marginBottom: 10 }}>
              <label style={{ fontSize: '0.75rem', fontWeight: 600 }}>{meta.label}</label>
              <input
                className="input-brutal"
                type={meta.secret ? 'password' : 'text'}
                autoComplete={meta.secret ? 'new-password' : 'off'}
                value={creds[field] ?? ''}
                placeholder={meta.secret && isSet ? '•••••••• (leave blank to keep)' : (isSet ? savedVal : '')}
                onChange={e => setCreds(c => ({ ...c, [field]: e.target.value }))}
                style={{ width: '100%', marginTop: 4 }}
              />
              {meta.hint && <div style={{ fontSize: '0.68rem', color: 'var(--text-3)', marginTop: 2 }}>{meta.hint}</div>}
            </div>
          );
        })}
      </div>

      <div className="flex items-center gap-2" style={{ marginTop: 6 }}>
        <button
          className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
          style={{ fontSize: '0.82rem' }}
          disabled={save.isPending || !label.trim()}
          onClick={() => save.mutate()}
        >
          {save.isPending ? 'Saving…' : isNew ? 'Add number' : 'Save'}
        </button>
        {isNew && onCancelNew && (
          <button className="btn-brutal btn-secondary px-4 py-2 font-heading font-bold"
                  style={{ fontSize: '0.8rem' }} onClick={onCancelNew}>
            Cancel
          </button>
        )}
      </div>

      {/* Where a BSP sends delivery statuses and customer replies. Meta Cloud
          uses its own signed callback, set up under Integrations. The URL
          carries this number's secret token: posts without it are refused. */}
      {account && account.provider === provider && provider !== 'meta_cloud' && account.webhook?.status_url && (
        <div className="card-brutal" style={{ padding: '12px 14px', marginTop: 18, background: 'var(--surface)' }}>
          <div className="font-heading font-bold" style={{ fontSize: '0.85rem' }}>Delivery &amp; reply webhook</div>
          <p style={{ fontSize: '0.75rem', color: 'var(--text-2)', margin: '4px 0 8px' }}>
            Paste this into {labelFor(provider)}&rsquo;s webhook settings for {account.label} so delivery
            ticks and customer replies reach the CRM. Each number has its own URL. Keep it private —
            it contains a secret token.
          </p>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <div className="font-mono" style={{
              flex: 1, fontSize: '0.7rem', wordBreak: 'break-all', padding: '6px 8px',
              border: '1px solid var(--line-2)', background: 'var(--paper)',
            }}>
              {account.webhook.status_url}
            </div>
            <button
              className="btn-brutal btn-secondary px-3 py-1 font-heading font-bold"
              style={{ fontSize: '0.72rem', whiteSpace: 'nowrap' }}
              onClick={() => navigator.clipboard.writeText(account.webhook.status_url)
                .then(() => showToast('success', 'Copied', 'Webhook URL copied.'))
                .catch(() => showToast('error', 'Copy failed', 'Select the URL and copy it by hand.'))}
            >
              Copy
            </button>
          </div>
        </div>
      )}

      {/* Other numbers in the same Meta WhatsApp Business Account */}
      {account && account.provider === 'meta_cloud' && account.business_account_id && (
        <SameAccountNumbers account={account} canAdd={canAdd} onCreated={onCreated} />
      )}

      {/* Which agents send from this number */}
      {!isNew && account && <NumberAgents account={account} />}

      {/* Test send */}
      {!isNew && (
        <div style={{ borderTop: '1px solid var(--line)', marginTop: 24, paddingTop: 18 }}>
          <div className="font-heading font-bold" style={{ fontSize: '0.85rem' }}>Send a test message</div>
          <p style={{ fontSize: '0.75rem', color: 'var(--text-2)', margin: '4px 0 10px' }}>
            A real message goes to this number through {account!.label}&rsquo;s saved credentials.
            On success the number is activated.
          </p>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              className="input-brutal"
              placeholder="+91 98765 43210"
              value={testPhone}
              onChange={e => setTestPhone(e.target.value)}
              style={{ flex: 1 }}
            />
            <button
              className="btn-brutal btn-secondary px-4 py-2 font-heading font-bold"
              style={{ fontSize: '0.8rem', whiteSpace: 'nowrap' }}
              disabled={test.isPending || !testPhone.trim()}
              onClick={() => test.mutate()}
            >
              {test.isPending ? 'Sending…' : 'Send test'}
            </button>
          </div>
        </div>
      )}

      {/* Disconnect */}
      {!isNew && (
        <div style={{ borderTop: '1px solid var(--line)', marginTop: 24, paddingTop: 14 }}>
          {confirmRemove ? (
            <div className="flex items-center gap-2" style={{ flexWrap: 'wrap' }}>
              <span style={{ fontSize: '0.78rem' }}>
                Disconnect {account!.label}? Messages already sent and received are kept.
              </span>
              <button className="btn-brutal px-3 py-1 font-heading font-bold"
                      style={{ fontSize: '0.72rem', background: 'var(--hot)', color: '#fff' }}
                      disabled={remove.isPending} onClick={() => remove.mutate()}>
                {remove.isPending ? 'Removing…' : 'Disconnect'}
              </button>
              <button className="btn-brutal btn-secondary px-3 py-1 font-heading font-bold"
                      style={{ fontSize: '0.72rem' }} onClick={() => setConfirmRemove(false)}>
                Keep
              </button>
            </div>
          ) : (
            <button className="btn-brutal btn-secondary px-3 py-1 font-heading font-bold"
                    style={{ fontSize: '0.72rem', color: 'var(--hot)' }}
                    onClick={() => setConfirmRemove(true)}>
              Disconnect this number
            </button>
          )}
        </div>
      )}
    </div>
  );
}

// ------------------------------------------------------------
// Agents tied to a number. An agent given one or more numbers sends only from
// those (their number is pre-selected everywhere they send); an agent given
// none can use any number. Replies to a customer still go from the number the
// customer wrote to — WhatsApp allows no other — so this decides which number
// starts new conversations and sends templates.
// ------------------------------------------------------------
function NumberAgents({ account }: { account: WhatsAppConfig }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [picked, setPicked] = useState<number[]>(account.agents ?? []);
  const [filter, setFilter] = useState('');
  useEffect(() => { setPicked(account.agents ?? []); }, [account.id, account.agents]);

  const { data: agents, isLoading } = useQuery({
    queryKey: ['agents-active-min'],
    queryFn: () => authApi.listAgents({ page_size: 500, is_active: 'true' }).then(r => r.data.results),
  });
  // Admins and managers can always use every number; listing them would
  // suggest a restriction that does not apply.
  const sendingAgents = (agents ?? []).filter(a => a.role !== 'admin' && a.role !== 'manager');
  const shown = sendingAgents.filter(a => !filter || a.name.toLowerCase().includes(filter.toLowerCase()));

  const save = useMutation({
    mutationFn: () => commsApi.updateWhatsAppAccount(account.id, { agents: picked }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['wa-accounts'] });
      qc.invalidateQueries({ queryKey: ['wa-senders'] });
      showToast('success', 'Saved', picked.length
        ? `${picked.length} agent${picked.length === 1 ? '' : 's'} now send from ${account.label}.`
        : `No agent is tied to ${account.label}.`);
    },
    onError: (e: unknown) => showToast('error', 'Not saved', getErrorMessage(e, 'Try again.')),
  });

  const dirty = [...picked].sort().join(',') !== [...(account.agents ?? [])].sort().join(',');
  const toggle = (id: number) => setPicked(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  return (
    <div style={{ borderTop: '1px solid var(--line)', marginTop: 24, paddingTop: 18 }}>
      <div className="font-heading font-bold" style={{ fontSize: '0.85rem' }}>Agents who send from {account.label}</div>
      <p style={{ fontSize: '0.75rem', color: 'var(--text-2)', margin: '4px 0 10px', lineHeight: 1.5 }}>
        Ticked agents can send <strong>only</strong> from the numbers they're ticked on, and this one is picked for
        them automatically. Agents you don't tick anywhere can use any number. Replies to a customer always go
        from the number the customer wrote to. Admins and managers can use every number.
      </p>
      {isLoading ? <Spinner size={20} /> : sendingAgents.length === 0 ? (
        <div style={{ fontSize: '0.75rem', color: 'var(--text-3)' }}>No agents yet.</div>
      ) : (
        <>
          {sendingAgents.length > 8 && (
            <input className="input-brutal" placeholder="Find an agent…" value={filter}
                   onChange={e => setFilter(e.target.value)} style={{ width: '100%', marginBottom: 8 }} />
          )}
          <div style={{ display: 'grid', gap: 4, gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
                        maxHeight: 220, overflowY: 'auto', padding: 2 }}>
            {shown.map(a => (
              <label key={a.id} className="flex items-center gap-2"
                     style={{ fontSize: '0.78rem', cursor: 'pointer', padding: '4px 6px',
                              border: '1px solid var(--line)', background: picked.includes(a.id) ? 'var(--won-50)' : 'var(--surface)' }}>
                <input type="checkbox" checked={picked.includes(a.id)} onChange={() => toggle(a.id)} />
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.name}</span>
              </label>
            ))}
          </div>
          <div className="flex items-center gap-2" style={{ marginTop: 10 }}>
            <button className="btn-brutal btn-primary px-4 py-1.5 font-heading font-bold"
                    style={{ fontSize: '0.78rem' }} disabled={!dirty || save.isPending}
                    onClick={() => save.mutate()}>
              {save.isPending ? 'Saving…' : 'Save agents'}
            </button>
            <span style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>
              {picked.length} ticked
            </span>
          </div>
        </>
      )}
    </div>
  );
}

// ------------------------------------------------------------
// One Meta WhatsApp Business Account can hold several phone numbers. They
// share the account's token, app secret, webhook and approved templates, so
// adding another one is: pick it from Meta's list, give it a name.
// ------------------------------------------------------------
function SameAccountNumbers({ account, canAdd, onCreated }: {
  account: WhatsAppConfig;
  canAdd: boolean;
  onCreated: (id: number) => void;
}) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [show, setShow] = useState(false);
  const [adding, setAdding] = useState<{ pnid: string; phone: string; label: string } | null>(null);

  const list = useQuery({
    queryKey: ['wa-meta-numbers', account.id],
    queryFn: () => commsApi.listMetaBusinessNumbers(account.id).then(r => r.data),
    enabled: show,
    retry: false,
  });

  const connect = useMutation({
    mutationFn: () => commsApi.createWhatsAppAccount({
      label: adding!.label.trim(),
      display_phone: adding!.phone,
      copy_credentials_from: account.id,
      credentials: { phone_number_id: adding!.pnid.trim() },
    }),
    onSuccess: (r) => {
      showToast('success', 'Number added', `${r.data.label} uses ${account.label}'s account details. Send it a test message to activate it.`);
      setAdding(null);
      qc.invalidateQueries({ queryKey: ['wa-accounts'] });
      qc.invalidateQueries({ queryKey: ['wa-senders'] });
      qc.invalidateQueries({ queryKey: ['wa-meta-numbers', account.id] });
      onCreated(r.data.id);
    },
    onError: (e: unknown) => showToast('error', 'Could not add', getErrorMessage(e, 'Check the Phone number ID and try again.')),
  });

  const startAdding = (n?: MetaBusinessNumber) =>
    setAdding({ pnid: n?.phone_number_id ?? '', phone: n?.display_phone ?? '', label: '' });

  return (
    <div className="card-brutal" style={{ padding: '12px 14px', marginTop: 18, background: 'var(--surface)' }}>
      <div className="flex items-center justify-between gap-2" style={{ flexWrap: 'wrap' }}>
        <div>
          <div className="font-heading font-bold" style={{ fontSize: '0.85rem' }}>
            Numbers in this WhatsApp Business Account
          </div>
          <div style={{ fontSize: '0.72rem', color: 'var(--text-2)', marginTop: 2 }}>
            Account {account.business_account_id}. Other numbers in it share its token, webhook and
            approved templates — add one by picking it, no new credentials needed.
          </div>
        </div>
        {!show && (
          <button className="btn-brutal btn-secondary px-3 py-1 font-heading font-bold"
                  style={{ fontSize: '0.72rem' }} onClick={() => setShow(true)}>
            Show numbers
          </button>
        )}
      </div>

      {show && (
        <div style={{ marginTop: 10 }}>
          {list.isLoading && <div className="flex justify-center py-3"><Spinner /></div>}
          {list.isError && (
            <div style={{ fontSize: '0.75rem', color: 'var(--lost)' }}>
              {getErrorMessage(list.error, 'Could not read the numbers from Meta.')} You can still add a
              number by its Phone number ID below.
            </div>
          )}
          {(list.data?.numbers ?? []).map(n => (
            <div key={n.phone_number_id} className="flex items-center justify-between gap-2"
                 style={{ padding: '8px 0', borderTop: '1px solid var(--line)' }}>
              <div style={{ minWidth: 0 }}>
                <div className="font-heading font-bold" style={{ fontSize: '0.8rem' }}>
                  {n.display_phone || n.phone_number_id}
                  {n.verified_name && <span style={{ fontWeight: 400, color: 'var(--text-2)' }}> · {n.verified_name}</span>}
                </div>
                <div style={{ fontSize: '0.68rem', color: 'var(--text-3)' }}>
                  ID {n.phone_number_id}{n.quality_rating ? ` · quality ${n.quality_rating.toLowerCase()}` : ''}
                </div>
              </div>
              {n.connected_as ? (
                <span style={{ fontSize: '0.7rem', color: 'var(--won)', whiteSpace: 'nowrap' }}>✓ {n.connected_as}</span>
              ) : (
                <button className="btn-brutal btn-secondary px-3 py-1 font-heading font-bold"
                        style={{ fontSize: '0.7rem', whiteSpace: 'nowrap', opacity: canAdd ? 1 : 0.55 }}
                        disabled={!canAdd}
                        title={canAdd ? undefined : 'Your plan includes one WhatsApp number.'}
                        onClick={() => startAdding(n)}>
                  Add this number
                </button>
              )}
            </div>
          ))}
          {list.data && list.data.numbers.length === 0 && (
            <div style={{ fontSize: '0.75rem', color: 'var(--text-3)' }}>Meta lists no numbers in this account.</div>
          )}
          {!adding && canAdd && (
            <button className="btn btn-g" style={{ fontSize: '0.72rem', marginTop: 8 }} onClick={() => startAdding()}>
              Add by Phone number ID instead
            </button>
          )}
        </div>
      )}

      {adding && (
        <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid var(--line)' }}>
          <div style={{ display: 'grid', gap: 8, gridTemplateColumns: '1fr 1fr' }}>
            <div>
              <label style={{ fontSize: '0.75rem', fontWeight: 600 }}>Name</label>
              <input className="input-brutal" value={adding.label} placeholder="Support, Branch 2…" autoFocus
                     onChange={e => setAdding(a => a && { ...a, label: e.target.value })}
                     style={{ width: '100%', marginTop: 4 }} />
            </div>
            <div>
              <label style={{ fontSize: '0.75rem', fontWeight: 600 }}>Phone number ID</label>
              <input className="input-brutal" value={adding.pnid}
                     onChange={e => setAdding(a => a && { ...a, pnid: e.target.value })}
                     style={{ width: '100%', marginTop: 4 }} />
            </div>
          </div>
          <div className="flex gap-2" style={{ marginTop: 8 }}>
            <button className="btn-brutal btn-primary px-4 py-1 font-heading font-black" style={{ fontSize: '0.78rem' }}
                    disabled={connect.isPending || !adding.label.trim() || !adding.pnid.trim()}
                    onClick={() => connect.mutate()}>
              {connect.isPending ? 'Adding…' : 'Add number'}
            </button>
            <button className="btn-brutal btn-secondary px-4 py-1 font-heading font-bold" style={{ fontSize: '0.78rem' }}
                    onClick={() => setAdding(null)}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// Client-side copy of the backend's PROVIDER_CREDENTIAL_FIELDS so the form can
// render the right inputs before (and after) a provider switch, without a
// round-trip. Kept in sync with apps/communications/serializers.py.
const PROVIDER_FIELDS: Record<WhatsAppProviderSlug, string[]> = {
  meta_cloud: ['access_token', 'phone_number_id', 'business_account_id'],
  interakt: ['api_key'],
  aisensy: ['api_key', 'text_campaign'],
  wati: ['access_token', 'api_endpoint'],
  gupshup: ['api_key', 'app_name', 'source_number'],
  twilio: ['account_sid', 'auth_token', 'from_number'],
  '360dialog': ['api_key'],
};

function labelFor(slug: WhatsAppProviderSlug): string {
  return PROVIDERS.find(p => p.slug === slug)?.name ?? slug;
}
