// ============================================================
// Integrations → Facebook & Instagram Lead Ads ("Continue with Facebook")
//
// The admin signs in with Facebook in a popup, ticks the Pages to connect,
// and chooses per form whether it takes leads and who gets them. Leads then
// arrive on their own: Meta posts each one to the platform's webhook within
// seconds, and the CRM also checks every 5 minutes for anything missed.
//
// Nobody creates a Meta app or copies a token. The older manual card (Page
// token + app secret) still works for workspaces already using it.
// ============================================================
import { useEffect, useMemo, useRef, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { authApi, integrationsApi } from '../../api';
import type { MetaLeadForm, MetaLeadPage } from '../../api';
import { Spinner, useToast } from '../../components/ui';
import { fmtRelative } from '../../utils/fmt';
import { getErrorMessage } from '../../utils/errors';

const FB_BLUE = '#1877f2';

/** "default" | "agent:12" | "team:3" — one select for the three choices. */
function ownerValue(f: MetaLeadForm): string {
  if (f.assign_mode === 'agent' && f.assign_agent) return `agent:${f.assign_agent}`;
  if (f.assign_mode === 'team' && f.assign_team) return `team:${f.assign_team}`;
  return 'default';
}

export default function FacebookLeadsCard() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [signingIn, setSigningIn] = useState(false);
  const popup = useRef<Window | null>(null);

  const { data: st, isLoading } = useQuery({
    queryKey: ['meta-connect'],
    queryFn: () => integrationsApi.metaConnectStatus().then(r => r.data),
  });
  const anyConnected = (st?.pages ?? []).some(p => p.connected);

  const { data: agents } = useQuery({
    queryKey: ['agents-active-min'],
    queryFn: () => authApi.listAgents({ page_size: 500, is_active: 'true' }).then(r => r.data.results),
    enabled: anyConnected,
  });
  const { data: teams } = useQuery({
    queryKey: ['teams-min'],
    queryFn: () => authApi.listTeams().then(r => r.data.results),
    enabled: anyConnected,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['meta-connect'] });
    qc.invalidateQueries({ queryKey: ['integrations'] });
  };

  // The popup reports back with postMessage when Facebook returns. It carries
  // no token — only "done" — and the Pages are re-read from our own API.
  useEffect(() => {
    const onMessage = (e: MessageEvent) => {
      const d = e.data as { source?: string; ok?: boolean; pages?: number; error?: string; missing_permissions?: string[] };
      if (!d || d.source !== 'dialsathi-meta') return;
      setSigningIn(false);
      refresh();
      if (d.ok) {
        showToast('success', 'Facebook connected',
          d.pages ? `Found ${d.pages} Page${d.pages === 1 ? '' : 's'}. Connect the ones you advertise from.`
                  : 'No Pages were shared. Sign in again and tick your Pages.');
        if (d.missing_permissions?.length) {
          showToast('warning', 'Some permissions were not granted',
            `Missing: ${d.missing_permissions.join(', ')}. Sign in again and allow all of them.`);
        }
      } else {
        showToast('error', 'Facebook sign-in failed', d.error || 'Please try again.');
      }
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // If the person closes the popup without finishing, stop the spinner.
  useEffect(() => {
    if (!signingIn) return;
    const t = window.setInterval(() => {
      if (popup.current && popup.current.closed) {
        setSigningIn(false);
        refresh();
        window.clearInterval(t);
      }
    }, 800);
    return () => window.clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [signingIn]);

  const signIn = async () => {
    // Open the window first, in the click itself, so popup blockers allow it;
    // then point it at Facebook once the server has made the login URL.
    const w = window.open('about:blank', 'dialsathi-facebook', 'width=620,height=740');
    popup.current = w;
    setSigningIn(true);
    try {
      const { data } = await integrationsApi.metaConnectStart();
      if (w) w.location.href = data.url;
      else window.location.href = data.url;
    } catch (e) {
      w?.close();
      setSigningIn(false);
      showToast('error', 'Could not start Facebook sign-in', getErrorMessage(e, 'Try again.'));
    }
  };

  const pageAction = useMutation({
    mutationFn: ({ page, action }: { page: MetaLeadPage; action: 'connect' | 'disconnect' | 'refresh-forms' }) =>
      integrationsApi.metaPageAction(page.page_id, action).then(r => r.data),
    onSuccess: (_d, { page, action }) => {
      refresh();
      if (action === 'connect') showToast('success', `${page.name} connected`, 'New leads from its forms now arrive automatically.');
      if (action === 'disconnect') showToast('info', `${page.name} disconnected`, 'Its leads no longer come in.');
    },
    onError: (e) => showToast('error', 'Facebook said no', getErrorMessage(e, 'Try again.')),
  });

  const pageUpdate = useMutation({
    mutationFn: ({ page, auto }: { page: MetaLeadPage; auto: boolean }) =>
      integrationsApi.metaPageUpdate(page.page_id, { auto_add_new_forms: auto }),
    onSuccess: refresh,
  });

  const formUpdate = useMutation({
    mutationFn: ({ form, data }: { form: MetaLeadForm; data: Parameters<typeof integrationsApi.metaFormUpdate>[1] }) =>
      integrationsApi.metaFormUpdate(form.form_id, data),
    onSuccess: refresh,
    onError: (e) => showToast('error', 'Not saved', getErrorMessage(e, 'Try again.')),
  });

  const fetchNow = useMutation({
    mutationFn: () => integrationsApi.metaFetchNow(2).then(r => r.data),
    onSuccess: (d) => { refresh(); showToast(d.created ? 'success' : 'info', 'Checked Facebook', d.message); },
    onError: (e) => showToast('error', 'Could not fetch', getErrorMessage(e, 'Try again.')),
  });

  const setOwner = (form: MetaLeadForm, value: string) => {
    if (value === 'default') formUpdate.mutate({ form, data: { assign_mode: 'default' } });
    else {
      const [kind, id] = value.split(':');
      formUpdate.mutate({
        form,
        data: kind === 'agent'
          ? { assign_mode: 'agent', assign_agent: Number(id) }
          : { assign_mode: 'team', assign_team: Number(id) },
      });
    }
  };

  const connectedPages = useMemo(() => (st?.pages ?? []).filter(p => p.connected), [st]);
  const otherPages = useMemo(() => (st?.pages ?? []).filter(p => !p.connected), [st]);

  if (isLoading) {
    return <div className="card p-5 flex justify-center" style={{ gridColumn: '1 / -1' }}><Spinner size={28} /></div>;
  }
  if (!st) return null;

  const statusText = connectedPages.length
    ? `Receiving from ${connectedPages.length} Page${connectedPages.length === 1 ? '' : 's'}`
    : st.signed_in ? 'Signed in — connect a Page' : 'Not connected';

  return (
    <div className="card p-5" style={{ gridColumn: '1 / -1' }}>
      <div className="flex items-start justify-between gap-3 flex-wrap mb-3">
        <div className="flex items-center gap-3">
          <div style={{
            width: 48, height: 48, display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: FB_BLUE, color: '#fff', fontWeight: 900, fontSize: '1.6rem',
            border: '1px solid var(--line)', boxShadow: 'var(--shadow)', fontFamily: 'Georgia, serif',
          }}>f</div>
          <div>
            <div className="font-heading font-black" style={{ fontSize: '0.95rem' }}>Facebook &amp; Instagram Lead Ads</div>
            <div style={{ fontSize: '0.7rem', fontWeight: 700, color: connectedPages.length ? 'var(--won)' : 'var(--text-3)' }}>
              ● {statusText}
            </div>
          </div>
        </div>
        {st.available && (
          <div className="flex gap-2 flex-wrap">
            {anyConnected && (
              <button onClick={() => fetchNow.mutate()} disabled={fetchNow.isPending}
                      className="btn-brutal btn-yellow px-3 py-1.5 font-heading font-bold"
                      style={{ fontSize: '0.72rem', boxShadow: 'var(--shadow)' }}
                      title="Check Facebook now for leads from the last 2 days. Leads already in the CRM are skipped.">
                {fetchNow.isPending ? '◌ Checking…' : '⟳ Fetch recent leads'}
              </button>
            )}
            <button onClick={signIn} disabled={signingIn}
                    className="btn-brutal px-4 py-1.5 font-heading font-black"
                    style={{ fontSize: '0.78rem', background: FB_BLUE, color: '#fff', boxShadow: 'var(--shadow)' }}>
              {signingIn ? '◌ Waiting for Facebook…' : st.signed_in ? 'Sign in again / add Pages' : 'Continue with Facebook'}
            </button>
          </div>
        )}
      </div>

      <p style={{ fontSize: '0.78rem', color: 'var(--text-2)', lineHeight: 1.5, marginBottom: 12 }}>
        Sign in with the Facebook account that manages your Page, pick the Page and its lead forms, and
        new leads arrive in the CRM by themselves — usually within seconds. The CRM also checks every
        5 minutes, so nothing is missed and nobody has to press Sync.
      </p>

      {!st.available && (
        <div style={{ background: 'var(--brass-50)', border: '1px solid var(--brass-600)', padding: '10px 12px', fontSize: '0.74rem', lineHeight: 1.5 }}>
          Facebook sign-in isn't switched on for this server yet. Until it is, use the manual Meta set-up
          (<strong>+ Add Integration → Meta</strong>).
        </div>
      )}

      {st.available && st.signed_in && (
        <div style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginBottom: 10 }}>
          Signed in as <strong style={{ color: 'var(--text-2)' }}>{st.signed_in_as}</strong>
          {st.signed_in_at && <> · {fmtRelative(st.signed_in_at)}</>}
        </div>
      )}
      {st.missing_permissions.length > 0 && (
        <div style={{ background: 'var(--hot-50, #fff1f0)', border: '1px solid var(--hot)', padding: '8px 10px', fontSize: '0.72rem', marginBottom: 10 }}>
          ⚠ Facebook did not grant: <strong>{st.missing_permissions.join(', ')}</strong>. Leads can't be read
          without them — click <em>Sign in again</em> and allow every permission.
        </div>
      )}

      {/* ---- Connected Pages, with their forms ---- */}
      {connectedPages.map(page => (
        <div key={page.page_id} style={{ border: '1px solid var(--line)', marginBottom: 12 }}>
          <div className="flex items-center justify-between gap-3 flex-wrap"
               style={{ padding: '10px 12px', background: 'var(--surface-2)', borderBottom: '1px solid var(--line)' }}>
            <div className="flex items-center gap-2">
              <PageAvatar page={page} />
              <div>
                <div className="font-heading font-black" style={{ fontSize: '0.85rem' }}>{page.name}</div>
                <div style={{ fontSize: '0.68rem', color: 'var(--text-3)' }}>
                  {page.leads_received} lead{page.leads_received === 1 ? '' : 's'}
                  {page.last_lead_at && <> · last {fmtRelative(page.last_lead_at)}</>}
                  {page.last_polled_at && <> · checked {fmtRelative(page.last_polled_at)}</>}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <label className="flex items-center gap-1" style={{ fontSize: '0.7rem', color: 'var(--text-2)', cursor: 'pointer' }}
                     title="A lead form you create later on this Page starts sending leads without a visit here">
                <input type="checkbox" checked={page.auto_add_new_forms}
                       onChange={e => pageUpdate.mutate({ page, auto: e.target.checked })} />
                New forms start automatically
              </label>
              <button onClick={() => pageAction.mutate({ page, action: 'refresh-forms' })}
                      className="btn-brutal btn-secondary px-2 py-1 font-heading font-bold" style={{ fontSize: '0.66rem' }}>
                ⟳ Forms
              </button>
              <button onClick={() => pageAction.mutate({ page, action: 'disconnect' })}
                      className="btn-brutal btn-danger px-2 py-1 font-heading font-bold" style={{ fontSize: '0.66rem' }}>
                Disconnect
              </button>
            </div>
          </div>
          {page.last_error && (
            <div style={{ fontSize: '0.7rem', color: 'var(--hot)', padding: '6px 12px' }}>⚠ {page.last_error}</div>
          )}
          {page.forms.length === 0 ? (
            <div style={{ fontSize: '0.74rem', color: 'var(--text-3)', padding: '10px 12px' }}>
              No lead forms on this Page yet. Create one in Meta Ads Manager — it will appear here.
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.76rem' }}>
                <thead>
                  <tr style={{ textAlign: 'left', color: 'var(--text-3)', fontSize: '0.64rem', textTransform: 'uppercase' }}>
                    <th style={{ padding: '6px 12px' }}>On</th>
                    <th style={{ padding: '6px 8px' }}>Form</th>
                    <th style={{ padding: '6px 8px' }}>Leads</th>
                    <th style={{ padding: '6px 12px', minWidth: 200 }}>Leads go to</th>
                  </tr>
                </thead>
                <tbody>
                  {page.forms.map(form => (
                    <tr key={form.form_id} style={{ borderTop: '1px solid var(--line)', opacity: form.enabled ? 1 : 0.6 }}>
                      <td style={{ padding: '6px 12px' }}>
                        <input type="checkbox" checked={form.enabled} aria-label={`Take leads from ${form.name}`}
                               onChange={e => formUpdate.mutate({ form, data: { enabled: e.target.checked } })} />
                      </td>
                      <td style={{ padding: '6px 8px' }}>
                        <div style={{ fontWeight: 600 }}>{form.name || form.form_id}</div>
                        {form.status && form.status !== 'ACTIVE' && (
                          <div style={{ fontSize: '0.64rem', color: 'var(--text-3)' }}>{form.status.toLowerCase()} in Meta</div>
                        )}
                      </td>
                      <td style={{ padding: '6px 8px', whiteSpace: 'nowrap' }}>
                        {form.leads_received}
                        {form.last_lead_at && <span style={{ color: 'var(--text-3)' }}> · {fmtRelative(form.last_lead_at)}</span>}
                      </td>
                      <td style={{ padding: '6px 12px' }}>
                        <select className="input-brutal" style={{ width: '100%', fontSize: '0.74rem', padding: '4px 6px' }}
                                value={ownerValue(form)} disabled={!form.enabled}
                                onChange={e => setOwner(form, e.target.value)}>
                          <option value="default">Your usual assignment rules</option>
                          {(teams ?? []).filter(t => t.is_active !== false).length > 0 && (
                            <optgroup label="A team, taking turns">
                              {(teams ?? []).filter(t => t.is_active !== false).map(t => (
                                <option key={`t${t.id}`} value={`team:${t.id}`}>Team: {t.name}</option>
                              ))}
                            </optgroup>
                          )}
                          <optgroup label="One agent">
                            {(agents ?? []).map(a => (
                              <option key={`a${a.id}`} value={`agent:${a.id}`}>{a.name}</option>
                            ))}
                          </optgroup>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ))}

      {/* ---- Pages the person can connect ---- */}
      {otherPages.length > 0 && (
        <div>
          <div className="font-heading font-black" style={{ fontSize: '0.78rem', marginBottom: 6 }}>
            {connectedPages.length ? 'Other Pages you manage' : 'Pick the Page you advertise from'}
          </div>
          <div className="grid gap-2" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(240px,1fr))' }}>
            {otherPages.map(page => (
              <div key={page.page_id} className="flex items-center justify-between gap-2"
                   style={{ border: '1px solid var(--line)', padding: '8px 10px' }}>
                <div className="flex items-center gap-2" style={{ minWidth: 0 }}>
                  <PageAvatar page={page} />
                  <div style={{ fontSize: '0.78rem', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {page.name}
                  </div>
                </div>
                {page.connected_elsewhere ? (
                  <span style={{ fontSize: '0.64rem', color: 'var(--text-3)' }} title="Disconnect it in the other workspace first">
                    In another workspace
                  </span>
                ) : (
                  <button onClick={() => pageAction.mutate({ page, action: 'connect' })}
                          disabled={pageAction.isPending || !page.has_token}
                          className="btn-brutal btn-primary px-2 py-1 font-heading font-bold"
                          style={{ fontSize: '0.68rem', whiteSpace: 'nowrap' }}>
                    {pageAction.isPending && pageAction.variables?.page.page_id === page.page_id ? '◌' : 'Connect'}
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function PageAvatar({ page }: { page: MetaLeadPage }) {
  return page.picture_url ? (
    <img src={page.picture_url} alt="" width={28} height={28}
         style={{ borderRadius: 4, border: '1px solid var(--line)', flexShrink: 0 }} />
  ) : (
    <div style={{ width: 28, height: 28, borderRadius: 4, background: FB_BLUE, color: '#fff', flexShrink: 0,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: '0.8rem' }}>
      {page.name.slice(0, 1).toUpperCase()}
    </div>
  );
}
