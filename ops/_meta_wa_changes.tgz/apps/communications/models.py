"""
TeleCRM Backend — apps/communications/models.py

Per-tenant communication models. All in TENANT schemas.

WhatsAppMessage   : Single WhatsApp message sent to or received from a lead.
WhatsAppTemplate  : Pre-approved message templates (required by Meta/providers).
BulkCampaign      : A bulk communication campaign (WhatsApp / Email / SMS).
CampaignRecipient : Per-recipient tracking row for a bulk campaign.
EmailLog          : Record of individual transactional/bulk emails.
SMSLog            : Record of individual SMS messages.

Indian context:
  WhatsApp providers: Interakt, AiSensy, Wati, Gupshup, 2Factor
  SMS providers: MSG91, TextLocal, Fast2SMS, Kaleyra
  TRAI DND rules enforced for SMS (WhatsApp exempt)
"""
import uuid
from django.db import models
from django.utils import timezone
from apps.core.crypto import EncryptedJSONField
from apps.core.models import TimeStampedModel, TimeStampedUUIDModel
from apps.core.constants import WhatsAppProvider


# ============================================================
# WhatsApp
# ============================================================
class WhatsAppConfig(TimeStampedModel):
    """
    One WhatsApp Business connection — a "WhatsApp account" in the app.

    A tenant can connect several: a Sales number and a Support number, or two
    Meta WhatsApp Business Accounts. Each holds which provider it sends
    through and that provider's credentials — encrypted at rest, so a
    database dump never exposes a tenant's API keys. Each provider needs a
    different bag of credentials; the shape is documented per-provider in
    providers/whatsapp.py.

    Exactly one is the default: it sends whenever nothing chooses another
    number (a campaign without a sender, a reply to a lead who never wrote
    in). This used to be a singleton, so every caller that only needs "the"
    connection asks for the default via `get_solo()` and keeps working.

    More than one account needs the WHATSAPP_MULTI_PROVIDER plan feature.
    """

    label = models.CharField(
        max_length=60, default="Main number",
        help_text='How this number is shown when choosing a sender, e.g. "Sales".',
    )
    is_default = models.BooleanField(
        default=False, db_index=True,
        help_text="Sends from this account unless another one is chosen.",
    )
    # Not a secret, and copied out of `credentials` on save so an inbound
    # Meta delivery (which names the number it reached) can find its account
    # with a query. The encrypted credentials can't be searched.
    phone_number_id = models.CharField(max_length=50, blank=True, default="", db_index=True)
    # The Meta WhatsApp Business Account (WABA) the number belongs to, copied
    # out of the credentials the same way. One WABA can hold several numbers,
    # and its templates are approved once for all of them.
    business_account_id = models.CharField(max_length=50, blank=True, default="", db_index=True)
    display_phone = models.CharField(
        max_length=25, blank=True, default="",
        help_text="The number customers see, e.g. +91 98765 43210.",
    )

    provider = models.CharField(
        max_length=30, choices=WhatsAppProvider.CHOICES, default=WhatsAppProvider.INTERAKT,
        help_text="Which WhatsApp Business API the tenant sends through.",
    )
    is_active = models.BooleanField(
        default=False, db_index=True,
        help_text="Off until credentials are verified. Sends fall back to a no-op while off.",
    )

    # Provider-specific secrets, e.g. Meta Cloud:
    #   {"access_token": "...", "phone_number_id": "...", "business_account_id": "..."}
    # Interakt / AiSensy: {"api_key": "..."}; WATI: {"access_token": "...", "api_endpoint": "..."};
    # Gupshup: {"api_key": "...", "app_name": "...", "source_number": "..."}
    credentials = EncryptedJSONField(default=dict, blank=True)

    # Default language code for template sends (Meta requires it per template).
    default_language = models.CharField(max_length=10, default="en")

    # Populated by the test-send / webhook so an admin can see it's working.
    last_verified_at = models.DateTimeField(null=True, blank=True)
    last_error = models.CharField(max_length=500, blank=True, default="")

    # ---- Inbound (Meta Cloud API webhook) ------------------
    # Receiving is a separate switch from sending: a tenant can be live on
    # outbound templates long before anyone points a Meta webhook at them, and
    # an inbound flood must never start just because sending was configured.
    inbound_enabled = models.BooleanField(
        default=False, db_index=True,
        help_text="Accept inbound WhatsApp webhooks from Meta for this tenant.",
    )
    create_leads_from_inbound = models.BooleanField(
        default=True,
        help_text="Create a CRM lead when an unknown number messages in.",
    )
    ctwa_leads_only = models.BooleanField(
        default=False,
        help_text=(
            "Only open leads for conversations carrying Click-to-WhatsApp ad "
            "attribution. Organic inbound is still logged against an existing "
            "lead, but does not create a new one."
        ),
    )
    inbound_assign_to = models.ForeignKey(
        "authentication.Agent", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="inbound_whatsapp_leads",
        help_text="Agent new inbound leads are assigned to. Unset = unassigned.",
    )
    # Which agents send from this number. An agent given one or more numbers
    # may send only from those (their first one is pre-selected); an agent
    # given none can use any number, as before this existed. Admins and
    # managers are never restricted. A reply inside WhatsApp's 24-hour window
    # still goes out from the number the customer wrote to — Meta refuses free
    # text from any other number — so this governs new conversations.
    agents = models.ManyToManyField(
        "authentication.Agent", blank=True, related_name="whatsapp_numbers",
        help_text="Agents who send from this number. Empty = no agent is tied to it.",
    )
    reopen_lead_on_inbound = models.BooleanField(
        default=True,
        help_text=(
            "When a closed/lost lead messages again, move it back to New so it "
            "resurfaces in the queue instead of staying buried."
        ),
    )
    graph_api_version = models.CharField(
        max_length=10, blank=True, default="",
        help_text="Override the platform Graph API version, e.g. v26.0. Blank = platform default.",
    )

    # ---- Inbound health (surfaced on the integrations screen) ----
    last_webhook_at = models.DateTimeField(
        null=True, blank=True,
        help_text="When Meta last delivered any webhook to this tenant.",
    )
    last_webhook_error = models.CharField(max_length=500, blank=True, default="")
    total_inbound_messages = models.PositiveIntegerField(default=0)

    # Secret the provider's status/reply webhook URL carries (?token=). The
    # BSP webhook (Interakt, WATI, Gupshup, …) accepted anything, so anyone
    # could mark messages read or inject "customer replies" into a thread.
    webhook_token = models.CharField(max_length=64, blank=True, default="")

    class Meta:
        verbose_name = "WhatsApp Account"
        verbose_name_plural = "WhatsApp Accounts"
        ordering = ["-is_default", "label", "pk"]
        constraints = [
            models.UniqueConstraint(
                fields=["is_default"], condition=models.Q(is_default=True),
                name="one_default_whatsapp_account",
            ),
        ]

    def __str__(self):
        state = "active" if self.is_active else "inactive"
        return f"{self.label} — WhatsApp via {self.get_provider_display()} ({state})"

    def shares_business_account_with(self, other) -> bool:
        """Both numbers are in the same Meta WhatsApp Business Account."""
        return bool(
            other is not None
            and self.business_account_id
            and self.business_account_id == other.business_account_id
            and self.provider == other.provider
        )

    def same_business_account(self):
        """This account and every other number in its WhatsApp Business Account."""
        if not self.business_account_id:
            return type(self).objects.filter(pk=self.pk)
        return type(self).objects.filter(
            business_account_id=self.business_account_id, provider=self.provider,
        )

    @property
    def sender_label(self) -> str:
        """ "Sales (+91 98765 43210)" — what a send-from picker shows. """
        return f"{self.label} ({self.display_phone})" if self.display_phone else self.label

    def save(self, *args, **kwargs):
        from django.db import transaction

        update_fields = kwargs.get("update_fields")
        extra = set()
        if not self.webhook_token:
            import secrets

            self.webhook_token = secrets.token_urlsafe(32)
            extra.add("webhook_token")
        creds = self.credentials or {}
        pnid = str(creds.get("phone_number_id") or "").strip()[:50]
        if pnid != self.phone_number_id:
            self.phone_number_id = pnid
            extra.add("phone_number_id")
        waba = str(creds.get("business_account_id") or "").strip()[:50]
        if waba != self.business_account_id:
            self.business_account_id = waba
            extra.add("business_account_id")
        if not type(self).objects.exclude(pk=self.pk).filter(is_default=True).exists():
            # The first account — or the only one left — is the default.
            if not self.is_default:
                self.is_default = True
                extra.add("is_default")
        if update_fields is not None and extra:
            kwargs["update_fields"] = set(update_fields) | extra
        with transaction.atomic():
            if self.is_default:
                type(self).objects.exclude(pk=self.pk).filter(is_default=True).update(is_default=False)
            super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        from django.db import transaction

        with transaction.atomic():
            was_default = self.is_default
            result = super().delete(*args, **kwargs)
            if was_default:
                heir = type(self).objects.order_by("-is_active", "pk").first()
                if heir is not None:
                    type(self).objects.filter(pk=heir.pk).update(is_default=True)
        return result

    @classmethod
    def get_default(cls) -> "WhatsAppConfig | None":
        """The default account, or None when nothing has been connected."""
        return cls.objects.filter(is_default=True).first() or cls.objects.order_by("pk").first()

    @classmethod
    def get_solo(cls) -> "WhatsAppConfig":
        """
        The default account, created inactive on first access.

        Kept for every caller written when a tenant had exactly one
        connection: "the" connection is now the default one.
        """
        obj = cls.get_default()
        if obj is None:
            obj = cls(is_default=True)
            obj.save()
        return obj

    @classmethod
    def for_phone_number_id(cls, phone_number_id: str) -> "WhatsAppConfig | None":
        """The account a Meta delivery to this business number belongs to."""
        pnid = str(phone_number_id or "").strip()
        if not pnid:
            return None
        return cls.objects.filter(phone_number_id=pnid).order_by("-is_active", "pk").first()


class WhatsAppTemplate(TimeStampedModel):
    """
    Pre-approved WhatsApp message template.
    Must be approved by Meta before use in bulk messaging.
    """

    CATEGORY_CHOICES = [
        ("marketing", "Marketing"),
        ("utility", "Utility / Transactional"),
        ("authentication", "Authentication (OTP)"),
    ]
    STATUS_CHOICES = [
        ("pending", "Pending Approval"),
        ("approved", "Approved"),
        ("rejected", "Rejected"),
        ("paused", "Paused by Meta"),
    ]

    # Which WhatsApp account the template was approved on. Meta approves a
    # template per WhatsApp Business Account, so two accounts can each have a
    # "welcome" — the name is unique per account, not per tenant. Blank means
    # usable from any account (templates made before accounts existed, or a
    # provider that shares templates across numbers).
    account = models.ForeignKey(
        WhatsAppConfig, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="templates",
    )
    name = models.CharField(max_length=100)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default="marketing")
    language = models.CharField(max_length=10, default="en", help_text="e.g. en, hi, mr")

    # ---- Header (text OR media) ----
    HEADER_TYPE_CHOICES = [
        ("none", "No header"),
        ("text", "Text"),
        ("image", "Image"),
        ("video", "Video"),
        ("document", "Document"),
    ]
    header_type = models.CharField(
        max_length=12, choices=HEADER_TYPE_CHOICES, default="none",
        help_text="WhatsApp template header type. 'image' shows a banner image.",
    )
    header_text = models.CharField(max_length=60, blank=True, default="")
    header_media_url = models.URLField(
        max_length=600, blank=True, default="",
        help_text="Image/video/document URL for a media header (e.g. Cloudinary).",
    )

    # Template body with {{1}}, {{2}} variable placeholders
    body_text = models.TextField(help_text="Use {{1}}, {{2}} for variables.")
    footer_text = models.CharField(max_length=60, blank=True, default="")

    # Variable mapping: {"1": "name", "2": "phone"} → maps {{1}} to lead.name
    variable_mapping = models.JSONField(
        default=dict, blank=True,
        help_text='Map {{N}} to Lead fields. e.g. {"1": "name", "2": "city"}',
    )

    # Provider-specific template ID (after approval)
    provider = models.CharField(max_length=30, choices=WhatsAppProvider.CHOICES, default=WhatsAppProvider.INTERAKT)
    provider_template_id = models.CharField(max_length=200, blank=True, default="")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending", db_index=True)

    is_active = models.BooleanField(default=True)
    usage_count = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = "WhatsApp Template"
        verbose_name_plural = "WhatsApp Templates"
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(
                fields=["account", "name"], name="whatsapp_template_name_per_account",
            ),
            models.UniqueConstraint(
                fields=["name"], condition=models.Q(account__isnull=True),
                name="whatsapp_template_name_shared",
            ),
        ]

    def usable_from(self, account) -> bool:
        """
        A shared template goes out from any number; others from their own
        number and from every other number in the same WhatsApp Business
        Account, because Meta approves a template for the whole account.
        """
        if self.account_id is None:
            return True
        if account is None:
            return False
        return self.account_id == account.pk or self.account.shares_business_account_with(account)

    def __str__(self):
        return f"{self.name} [{self.get_status_display()}]"

    def render_with(self, values) -> str:
        """Body with {{1}}, {{2}}, ... replaced by `values`, in order."""
        text = self.body_text
        for i, value in enumerate(values, start=1):
            text = text.replace(f"{{{{{i}}}}}", str(value))
        return text

    @property
    def provider_name(self) -> str:
        """
        What the provider knows this template as. Meta and the BSPs identify
        a template by the name it was approved under, so that is the default;
        provider_template_id overrides it where a provider issues its own id.
        It used to be provider_template_id only — a field no screen could set —
        so every real send went out with an empty template id.
        """
        return (self.provider_template_id or self.name or "").strip()

    def render(self, lead) -> str:
        """Render the body for this lead using the variable mapping."""
        from apps.communications.whatsapp_ready import template_values

        return self.render_with(template_values(self, lead))


class WhatsAppConversation(TimeStampedModel):
    """
    One WhatsApp thread between a customer's number and one of the tenant's
    business numbers.

    Messages were always threaded implicitly by `WhatsAppMessage.lead`; this
    model exists because a Click-to-WhatsApp conversation carries state a
    per-message row cannot: which business number it landed on, whether it is
    still open, and — the point of the whole integration — the Meta ad that
    started it. Attribution lives here rather than on Lead so a lead that
    replies to three different ads keeps three honest attributions instead of
    overwriting one column twice.

    Idempotency: at most one OPEN conversation per (contact, business number),
    enforced by a partial unique index, so a retried webhook cannot fork a
    second thread.
    """

    STATUS_OPEN = "open"
    STATUS_CLOSED = "closed"
    STATUS_CHOICES = [(STATUS_OPEN, "Open"), (STATUS_CLOSED, "Closed")]

    SOURCE_TYPE_AD = "ad"
    SOURCE_TYPE_POST = "post"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    lead = models.ForeignKey(
        "leads.Lead", on_delete=models.CASCADE, related_name="whatsapp_conversations"
    )

    # ---- Parties -------------------------------------------
    contact_wa_id = models.CharField(
        max_length=25, db_index=True,
        help_text="Customer's WhatsApp ID exactly as Meta sends it (digits, no +).",
    )
    contact_phone = models.CharField(
        max_length=15, blank=True, default="",
        help_text="Normalized E.164 form of contact_wa_id.",
    )
    whatsapp_profile_name = models.CharField(
        max_length=200, blank=True, default="",
        help_text="Display name from the customer's WhatsApp profile.",
    )
    business_phone_number_id = models.CharField(
        max_length=50, db_index=True,
        help_text="Meta phone_number_id the message was delivered to.",
    )
    business_display_phone = models.CharField(max_length=25, blank=True, default="")
    whatsapp_business_id = models.CharField(
        max_length=50, blank=True, default="",
        help_text="WABA id (webhook entry.id).",
    )

    provider = models.CharField(
        max_length=30, choices=WhatsAppProvider.CHOICES,
        default=WhatsAppProvider.META_CLOUD,
    )
    status = models.CharField(
        max_length=10, choices=STATUS_CHOICES, default=STATUS_OPEN, db_index=True,
    )

    # ---- Activity ------------------------------------------
    first_message_at = models.DateTimeField(null=True, blank=True)
    last_message_at = models.DateTimeField(null=True, blank=True, db_index=True)
    last_inbound_at = models.DateTimeField(null=True, blank=True)
    message_count = models.PositiveIntegerField(default=0)

    # ---- Meta ad attribution (Click-to-WhatsApp) -----------
    # Every field here can legitimately stay empty: Meta sends `referral` only
    # on the FIRST message of an ad-referred conversation, a user may decline
    # to share it, and the campaign/ad-set/ad NAMES are never in the webhook at
    # all — they come from the optional Marketing API enrichment. Absent stays
    # absent; nothing here is ever guessed.
    is_ad_referred = models.BooleanField(default=False, db_index=True)
    referral_source_type = models.CharField(
        max_length=20, blank=True, default="",
        help_text='Meta referral.source_type — "ad" or "post".',
    )
    referral_source_id = models.CharField(
        max_length=100, blank=True, default="", db_index=True,
        help_text="Meta referral.source_id — the ad id (or post id).",
    )
    referral_source_url = models.URLField(max_length=800, blank=True, default="")
    referral_headline = models.CharField(max_length=500, blank=True, default="")
    referral_body = models.TextField(blank=True, default="")
    referral_media_type = models.CharField(max_length=20, blank=True, default="")
    ctwa_clid = models.CharField(
        max_length=512, blank=True, default="",
        help_text="Click-to-WhatsApp click id, for Conversions API attribution.",
    )

    # Marketing API enrichment — stays empty unless the lookup succeeds.
    meta_ad_id = models.CharField(max_length=100, blank=True, default="", db_index=True)
    meta_ad_name = models.CharField(max_length=300, blank=True, default="")
    meta_adset_id = models.CharField(max_length=100, blank=True, default="")
    meta_adset_name = models.CharField(max_length=300, blank=True, default="")
    meta_campaign_id = models.CharField(max_length=100, blank=True, default="", db_index=True)
    meta_campaign_name = models.CharField(max_length=300, blank=True, default="")
    attribution_enriched_at = models.DateTimeField(null=True, blank=True)
    attribution_error = models.CharField(max_length=300, blank=True, default="")

    # Untouched copy of Meta's referral object, so a field not modelled yet is
    # still recoverable without replaying the webhook.
    referral_payload = models.JSONField(default=dict, blank=True)

    class Meta:
        verbose_name = "WhatsApp Conversation"
        verbose_name_plural = "WhatsApp Conversations"
        ordering = ["-last_message_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["contact_wa_id", "business_phone_number_id"],
                condition=models.Q(status="open"),
                name="uniq_open_wa_conversation_per_contact",
            ),
        ]
        indexes = [
            models.Index(fields=["lead", "status"]),
            models.Index(fields=["is_ad_referred", "created_at"]),
        ]

    def __str__(self):
        tag = " [ad]" if self.is_ad_referred else ""
        return f"WhatsApp {self.contact_wa_id} to {self.business_display_phone}{tag}"

    @property
    def channel(self) -> str:
        return "whatsapp"

    @property
    def attribution(self) -> dict:
        """
        Only the attribution Meta actually gave us. Keys never populated are
        omitted rather than returned empty, so a UI can render "Campaign: ..."
        strictly when a campaign is genuinely known.
        """
        fields = {
            "source_type": self.referral_source_type,
            "source_id": self.referral_source_id,
            "source_url": self.referral_source_url,
            "headline": self.referral_headline,
            "body": self.referral_body,
            "media_type": self.referral_media_type,
            "ctwa_clid": self.ctwa_clid,
            "ad_id": self.meta_ad_id,
            "ad_name": self.meta_ad_name,
            "adset_id": self.meta_adset_id,
            "adset_name": self.meta_adset_name,
            "campaign_id": self.meta_campaign_id,
            "campaign_name": self.meta_campaign_name,
        }
        return {k: v for k, v in fields.items() if v}


class WhatsAppMessage(TimeStampedModel):
    """
    A single WhatsApp message sent to or received from a lead.
    Maintains conversation thread per lead.
    """

    DIRECTION_CHOICES = [("outbound", "Outbound"), ("inbound", "Inbound")]
    STATUS_CHOICES = [
        ("queued", "Queued"),
        ("sent", "Sent"),
        ("delivered", "Delivered"),
        ("read", "Read"),
        ("failed", "Failed"),
        ("received", "Received"),
    ]
    # Outbound uses text/template. The rest are inbound kinds Meta can deliver;
    # only text is interpreted today, but an unmodelled kind must still be
    # storable — a webhook that drops a customer's voice note because the CRM
    # had no row for it is a lost lead.
    MESSAGE_TYPES = [
        ("text", "Text"),
        ("template", "Template"),
        ("image", "Image"),
        ("document", "Document"),
        ("audio", "Audio"),
        ("video", "Video"),
        ("sticker", "Sticker"),
        ("location", "Location"),
        ("contacts", "Contact card"),
        ("button", "Button reply"),
        ("interactive", "Interactive reply"),
        ("reaction", "Reaction"),
        ("order", "Order"),
        ("system", "System"),
        ("unsupported", "Unsupported"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    lead = models.ForeignKey(
        "leads.Lead", on_delete=models.CASCADE, related_name="whatsapp_messages"
    )
    sent_by = models.ForeignKey(
        "authentication.Agent", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="whatsapp_sent",
        help_text="Null for inbound messages or bulk sends.",
    )

    direction = models.CharField(max_length=10, choices=DIRECTION_CHOICES, default="outbound", db_index=True)
    message_type = models.CharField(max_length=20, choices=MESSAGE_TYPES, default="text")
    content = models.TextField(blank=True, default="")
    template = models.ForeignKey(
        WhatsAppTemplate, on_delete=models.SET_NULL, null=True, blank=True,
        help_text="Template used (for outbound template messages).",
    )

    # Which of the tenant's WhatsApp accounts sent or received it. A reply to
    # the customer goes out from the number they last wrote to.
    account = models.ForeignKey(
        WhatsAppConfig, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="messages",
    )

    # Provider tracking
    provider = models.CharField(max_length=30, choices=WhatsAppProvider.CHOICES, default=WhatsAppProvider.INTERAKT)
    provider_message_id = models.CharField(max_length=200, blank=True, default="", db_index=True)

    # Status & timing
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="queued", db_index=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    delivered_at = models.DateTimeField(null=True, blank=True)
    read_at = models.DateTimeField(null=True, blank=True)
    error_message = models.CharField(max_length=500, blank=True, default="")

    # Inbox: when someone in the CRM opened an inbound message. `read_at` is
    # the customer reading OUR message (a provider receipt); this is the other
    # way round. Null on an inbound message = unread in the inbox. Shared by
    # the team: once anyone opens the thread it is read for everyone.
    seen_at = models.DateTimeField(null=True, blank=True)

    # Media attachment
    media_url = models.URLField(blank=True, default="")

    # Campaign reference (for bulk messages)
    campaign = models.ForeignKey(
        "BulkCampaign", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="whatsapp_messages",
    )

    # ---- Conversation threading (inbound / Meta Cloud) -----
    # Nullable: every message written before this model existed, and every
    # outbound send that does not go through the Cloud API, has no
    # conversation and must keep working exactly as it did.
    conversation = models.ForeignKey(
        "WhatsAppConversation", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="messages",
    )
    wa_timestamp = models.DateTimeField(
        null=True, blank=True,
        help_text="Meta's own message timestamp — authoritative ordering, "
                  "which created_at (our receive time) is not.",
    )
    metadata = models.JSONField(
        default=dict, blank=True,
        help_text="Media ids/mime types, reply context, and the normalized "
                  "inbound envelope. No credentials are ever stored here.",
    )

    class Meta:
        verbose_name = "WhatsApp Message"
        verbose_name_plural = "WhatsApp Messages"
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["lead", "created_at"]),
            models.Index(fields=["status", "created_at"]),
            models.Index(fields=["conversation", "wa_timestamp"]),
            models.Index(fields=["lead", "direction", "seen_at"], name="wa_msg_inbox_unread"),
        ]

    def __str__(self):
        return (
            f"[WA {self.direction}] {self.lead.name} — "
            f"{self.content[:50]} [{self.status}]"
        )


# ============================================================
# Bulk Campaigns
# ============================================================

class BulkCampaign(TimeStampedUUIDModel):
    """
    A bulk communication campaign targeting multiple leads.
    Supports WhatsApp, Email, and SMS channels.
    """

    CHANNEL_CHOICES = [
        ("whatsapp", "WhatsApp"),
        ("email", "Email"),
        ("sms", "SMS"),
    ]
    STATUS_CHOICES = [
        ("draft", "Draft"),
        ("scheduled", "Scheduled"),
        ("running", "Running"),
        ("paused", "Paused"),
        ("completed", "Completed"),
        ("failed", "Failed"),
        ("cancelled", "Cancelled"),
    ]

    name = models.CharField(max_length=200)
    channel = models.CharField(max_length=15, choices=CHANNEL_CHOICES, db_index=True)
    created_by = models.ForeignKey(
        "authentication.Agent", on_delete=models.SET_NULL, null=True,
        related_name="created_campaigns",
    )

    # Targeting
    # Lead IDs are resolved at send time from filters stored here
    audience_filters = models.JSONField(
        default=dict,
        help_text='Filter criteria: {"status": "interested", "city": "Mumbai"}',
    )
    estimated_recipients = models.PositiveIntegerField(default=0)

    # WhatsApp
    template = models.ForeignKey(
        WhatsAppTemplate, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="campaigns",
    )
    # The number the campaign sends from. Blank = the template's own account,
    # else the default account.
    whatsapp_account = models.ForeignKey(
        WhatsAppConfig, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="campaigns",
    )

    # Email
    email_subject = models.CharField(max_length=200, blank=True, default="")
    email_body = models.TextField(blank=True, default="")

    # SMS
    sms_text = models.CharField(max_length=160, blank=True, default="",
                                help_text="Max 160 chars for single SMS.")
    sms_sender_id = models.CharField(max_length=11, blank=True, default="",
                                     help_text="TRAI-approved 6-char sender ID.")

    # Scheduling
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="draft", db_index=True)
    scheduled_at = models.DateTimeField(null=True, blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    # Results (updated in real-time during send)
    total_recipients = models.PositiveIntegerField(default=0)
    sent_count = models.PositiveIntegerField(default=0)
    delivered_count = models.PositiveIntegerField(default=0)
    failed_count = models.PositiveIntegerField(default=0)
    replied_count = models.PositiveIntegerField(default=0)

    # Celery task
    celery_task_id = models.CharField(max_length=100, blank=True, default="")

    # Why the campaign stopped, when it stopped badly.
    #
    # A coordinator that raises leaves status="failed" and nothing else, so an
    # admin saw a red badge and no reason — and now that the daily plan caps
    # actually enforce (they previously compared against a hard-coded zero),
    # "failed" is a state real tenants will hit on an ordinary day. The cause
    # has to be readable without a log search.
    failure_reason = models.CharField(max_length=500, blank=True, default="")

    class Meta:
        verbose_name = "Bulk Campaign"
        verbose_name_plural = "Bulk Campaigns"
        ordering = ["-created_at"]

    def __str__(self):
        return f"[{self.channel.upper()}] {self.name} [{self.get_status_display()}]"

    @property
    def delivery_rate(self) -> float:
        if not self.sent_count:
            return 0.0
        return round(self.delivered_count / self.sent_count * 100, 1)

    @property
    def progress_percent(self) -> int:
        if not self.total_recipients:
            return 0
        return int((self.sent_count + self.failed_count) / self.total_recipients * 100)


class CampaignRecipient(models.Model):
    """Per-lead row in a bulk campaign — tracks individual delivery status."""

    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("sent", "Sent"),
        ("delivered", "Delivered"),
        ("failed", "Failed"),
        ("skipped", "Skipped (DND/Invalid)"),
    ]

    campaign = models.ForeignKey(BulkCampaign, on_delete=models.CASCADE, related_name="recipients")
    lead = models.ForeignKey("leads.Lead", on_delete=models.CASCADE, related_name="campaign_recipients")
    phone = models.CharField(max_length=15)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending", db_index=True)
    error_message = models.CharField(max_length=500, blank=True, default="")
    sent_at = models.DateTimeField(null=True, blank=True)
    provider_message_id = models.CharField(max_length=200, blank=True, default="")

    class Meta:
        unique_together = ("campaign", "lead")
        verbose_name = "Campaign Recipient"
        indexes = [models.Index(fields=["campaign", "status"])]


# ============================================================
# Email & SMS Logs
# ============================================================

class EmailLog(TimeStampedModel):
    """Record of a single email sent from the CRM."""

    STATUS_CHOICES = [
        ("queued", "Queued"),
        ("sent", "Sent"),
        ("delivered", "Delivered"),
        ("opened", "Opened"),
        ("clicked", "Clicked"),
        ("bounced", "Bounced"),
        ("failed", "Failed"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    lead = models.ForeignKey(
        "leads.Lead", on_delete=models.CASCADE, related_name="emails", null=True, blank=True
    )
    sent_by = models.ForeignKey(
        "authentication.Agent", on_delete=models.SET_NULL, null=True, blank=True
    )
    campaign = models.ForeignKey(
        BulkCampaign, on_delete=models.SET_NULL, null=True, blank=True, related_name="emails"
    )

    to_email = models.EmailField()
    subject = models.CharField(max_length=300)
    body = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="queued", db_index=True)
    provider = models.CharField(max_length=30, blank=True, default="",
                                 help_text="e.g. mailgun, sendgrid, ses")
    provider_message_id = models.CharField(max_length=200, blank=True, default="")
    sent_at = models.DateTimeField(null=True, blank=True)
    opened_at = models.DateTimeField(null=True, blank=True)
    error_message = models.CharField(max_length=500, blank=True, default="")

    class Meta:
        verbose_name = "Email Log"
        verbose_name_plural = "Email Logs"
        ordering = ["-created_at"]

    def __str__(self):
        return f"Email to {self.to_email}: {self.subject[:50]} [{self.status}]"


class SMSLog(TimeStampedModel):
    """Record of a single SMS sent from the CRM."""

    STATUS_CHOICES = [
        ("queued", "Queued"),
        ("sent", "Sent"),
        ("delivered", "Delivered"),
        ("failed", "Failed"),
        ("dnd_blocked", "Blocked (DND)"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    lead = models.ForeignKey(
        "leads.Lead", on_delete=models.CASCADE, related_name="sms_messages", null=True, blank=True
    )
    sent_by = models.ForeignKey(
        "authentication.Agent", on_delete=models.SET_NULL, null=True, blank=True
    )
    campaign = models.ForeignKey(
        BulkCampaign, on_delete=models.SET_NULL, null=True, blank=True, related_name="sms_messages"
    )

    phone_number = models.CharField(max_length=15)
    message = models.CharField(max_length=1600)   # 10x concatenated SMS
    sender_id = models.CharField(max_length=11, blank=True, default="")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="queued", db_index=True)
    provider = models.CharField(max_length=30, blank=True, default="",
                                 help_text="e.g. msg91, textlocal, fast2sms")
    provider_message_id = models.CharField(max_length=200, blank=True, default="")
    sent_at = models.DateTimeField(null=True, blank=True)
    delivered_at = models.DateTimeField(null=True, blank=True)
    error_message = models.CharField(max_length=500, blank=True, default="")
    cost_paise = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = "SMS Log"
        verbose_name_plural = "SMS Logs"
        ordering = ["-created_at"]

    def __str__(self):
        return f"SMS to {self.phone_number}: {self.message[:40]} [{self.status}]"
