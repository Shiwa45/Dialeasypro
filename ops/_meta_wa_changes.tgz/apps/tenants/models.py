"""
TeleCRM Backend — apps/tenants/models.py

Tenant and Domain models — the core of the multi-tenant architecture.

Tenant  : Extends django-tenants TenantMixin. Each row = one client company.
          Creating a Tenant record auto-creates a PostgreSQL schema.
Domain  : Subdomain or custom domain mapping to a Tenant.
          e.g. acmerealty.telecrm.in → Tenant(schema_name='acme_realty')

These models live in the PUBLIC schema (shared across all tenants).
"""
import logging
import re
import unicodedata

from django.core.validators import RegexValidator
from django.db import models
from django.utils import timezone
from django_tenants.models import DomainMixin, TenantMixin

from apps.core.constants import Industry, SubscriptionStatus
from apps.core.models import TimeStampedModel

logger = logging.getLogger(__name__)


class Tenant(TenantMixin, TimeStampedModel):
    """
    Represents one CRM client company (tenant).

    Key fields:
      schema_name   : PostgreSQL schema name. Must be unique, lowercase,
                      no spaces. Auto-set from company name at creation.
      is_active     : Master switch — if False, all logins blocked.
      plan          : FK to Plan (in plans app). May be null before subscription.

    django-tenants behaviour:
      auto_create_schema = True → Calling .save() creates the PG schema
                                   and runs all TENANT_APPS migrations.
    """

    auto_create_schema = True
    # Deleting a tenant drops its PostgreSQL schema — every lead, call, agent
    # and setting in it. It used to leave the schema behind, so a "deleted"
    # tenant's data stayed in the database for good. See delete().
    auto_drop_schema = True

    # ---- Company Info --------------------------------------
    company_name = models.CharField(max_length=200, db_index=True)
    industry = models.CharField(
        max_length=50,
        choices=Industry.CHOICES,
        default=Industry.OTHER,
        blank=True,
    )
    gstin = models.CharField(
        max_length=15,
        blank=True,
        default="",
        help_text="GST Identification Number (15 chars). Optional.",
    )

    # ---- Billing Address (for GST invoices) ----------------
    billing_address = models.TextField(blank=True, default="")
    city = models.CharField(max_length=100, blank=True, default="")
    state = models.CharField(
        max_length=2,
        blank=True,
        default="",
        help_text="2-letter Indian state code for GST (e.g., MH, DL, KA).",
    )
    pincode = models.CharField(max_length=6, blank=True, default="")

    # ---- Primary Contact -----------------------------------
    primary_contact_name = models.CharField(max_length=150)
    primary_contact_email = models.EmailField(db_index=True)
    primary_contact_phone = models.CharField(
        max_length=15,
        validators=[
            RegexValidator(
                r"^\+91[6-9]\d{9}$",
                "Enter a valid Indian mobile number (+91XXXXXXXXXX).",
            )
        ],
    )

    # ---- Plan & Subscription --------------------------------
    # ForeignKey to plans.Plan — set when subscription is created.
    # Deliberately kept as a simple FK to avoid circular import complexity.
    plan = models.ForeignKey(
        "plans.Plan",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="tenants",
    )
    subscription_status = models.CharField(
        max_length=20,
        choices=SubscriptionStatus.CHOICES,
        default=SubscriptionStatus.TRIAL,
        db_index=True,
    )
    # Which standard money fields this client's lead form shows, and what they
    # are called — "Budget" means nothing to a distributor, "Order Value" does.
    # Set from the platform panel (Tenants → Import fields). Missing keys fall
    # back to LEAD_FORM_DEFAULTS, so an empty dict is the old form.
    lead_form_settings = models.JSONField(default=dict, blank=True)

    # Whether agent and read-only users may sign in on the WEB app. They get a
    # deliberately narrow workspace there (own dashboard, own leads, own
    # calls); some companies still want their floor on the mobile app only.
    # Default on. This governs the web client, not the API — see
    # apps/authentication/web_access.py for why that line is drawn there.
    agent_web_access = models.BooleanField(
        default=True,
        verbose_name="Agents may sign in on the web",
    )

    # Phone call tracking: the mobile app saves every incoming and outgoing
    # call on the agent's phone (from the phone's own call log) and uploads
    # its recording. Off by default — it reaches beyond calls made in the
    # app, so a company turns it on deliberately, and can then switch it off
    # for individual agents (Agent.call_tracking_enabled).
    call_tracking_enabled = models.BooleanField(
        default=False,
        verbose_name="Track all phone calls from the mobile app",
    )

    max_agents_override = models.PositiveIntegerField(
        null=True,
        blank=True,
        verbose_name="Agent seat cap (override)",
        help_text=(
            "Cap on ACTIVE agents for this tenant only. Leave blank to use the "
            "plan's limit. Set it to sell extra seats without moving the tenant "
            "to a bigger plan, or to hold one below their plan's allowance. "
            "0 blocks any new agent."
        ),
    )
    trial_ends_at = models.DateTimeField(null=True, blank=True)

    # ---- Platform Status -----------------------------------
    is_active = models.BooleanField(
        default=True,
        db_index=True,
        help_text="Master kill-switch. Set to False to block all logins.",
    )
    # Why the tenant is suspended. A payment may lift a BILLING suspension
    # (an expired trial) but never an ADMIN one — the super admin's kill
    # switch, e.g. for abuse. Both used to look the same, so the next
    # recurring charge silently re-enabled a tenant suspended for abuse.
    SUSPENDED_BILLING = "billing"
    SUSPENDED_ADMIN = "admin"
    suspension_kind = models.CharField(
        max_length=10, blank=True, default="",
        choices=[(SUSPENDED_BILLING, "Billing"), (SUSPENDED_ADMIN, "Super admin")],
        help_text="Set by suspend(); cleared by activate().",
    )
    onboarding_completed = models.BooleanField(default=False)
    onboarding_step = models.PositiveSmallIntegerField(
        default=0,
        help_text="Current onboarding step (1–5).",
    )

    # ---- Branding (for white-label tenants) ----------------
    logo = models.ImageField(
        upload_to="tenant_logos/",
        blank=True,
        null=True,
    )
    primary_color = models.CharField(
        max_length=7,
        default="#4F46E5",
        help_text="Hex color code for brand primary color.",
    )

    # ---- Locale --------------------------------------------
    timezone = models.CharField(
        max_length=50,
        default="Asia/Kolkata",
    )
    language_preference = models.CharField(
        max_length=5,
        choices=[("en", "English"), ("hi", "Hindi")],
        default="en",
    )

    # ---- Custom Domain (for white-label) -------------------
    custom_domain = models.CharField(
        max_length=253,
        blank=True,
        default="",
        help_text="Custom domain for white-label tenants (e.g., crm.acmerealty.in).",
    )

    # ---- Internal Notes (Super Admin only) -----------------
    internal_notes = models.TextField(
        blank=True,
        default="",
        help_text="Internal notes visible only to TeleCRM super admins.",
    )

    # ---- Usage Stats (updated daily by Celery) -------------
    total_agents = models.PositiveIntegerField(default=0)
    total_leads = models.PositiveIntegerField(default=0)
    total_calls_today = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = "Tenant"
        verbose_name_plural = "Tenants"
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.company_name} ({self.schema_name})"

    # ---- Properties ----------------------------------------

    @property
    def is_trial(self) -> bool:
        return self.subscription_status == SubscriptionStatus.TRIAL

    def agent_limit(self) -> int | None:
        """
        How many active agents this tenant may have. None = no cap.

        The per-tenant override wins over the plan when it is set, including
        when it is 0 — "this tenant gets no more seats" is a decision someone
        made, not a missing value, which is why the field is nullable rather
        than defaulting to zero.

        Reads the plan off the tenant row. Enforcement at request time
        resolves the plan from the active subscription instead (see
        apps/core/quotas.py) — normally the same plan, and the override is
        read from here either way.
        """
        if self.max_agents_override is not None:
            return self.max_agents_override
        return getattr(self.plan, "max_agents", None) or None

    @property
    def is_trial_expired(self) -> bool:
        if not self.is_trial:
            return False
        if not self.trial_ends_at:
            return False
        return timezone.now() > self.trial_ends_at

    @property
    def trial_days_remaining(self) -> int:
        if not self.trial_ends_at or not self.is_trial:
            return 0
        delta = self.trial_ends_at - timezone.now()
        return max(0, delta.days)

    @property
    def is_subscription_active(self) -> bool:
        return self.subscription_status in SubscriptionStatus.ACTIVE_STATUSES

    @property
    def subdomain_url(self) -> str:
        from django.conf import settings
        return f"https://{self.schema_name}.{settings.BASE_DOMAIN}"

    # ---- Methods -------------------------------------------

    @staticmethod
    def _slugify_schema(company_name: str) -> str:
        """Convert a company name into a valid PostgreSQL schema name."""
        normalized = unicodedata.normalize("NFKD", company_name)
        ascii_name = normalized.encode("ascii", "ignore").decode("ascii")
        lowered = ascii_name.lower()
        slug = re.sub(r"[^a-z0-9]+", "_", lowered).strip("_")
        if not slug:
            slug = "tenant"
        if slug[0].isdigit():
            slug = "t_" + slug
        return slug

    def _unique_schema_name(self, base: str) -> str:
        """Append a counter to make the schema name unique."""
        name = base[:60]
        if not Tenant.objects.filter(schema_name=name).exists():
            return name
        counter = 1
        while Tenant.objects.filter(schema_name=f"{base[:57]}_{counter}").exists():
            counter += 1
        return f"{base[:57]}_{counter}"

    def save(self, *args, **kwargs):
        if not self.schema_name:
            base = self._slugify_schema(self.company_name)
            self.schema_name = self._unique_schema_name(base)
        super().save(*args, **kwargs)

    LEAD_FORM_FIELDS = ("budget", "deal_value")
    LEAD_FORM_DEFAULTS = {
        "budget": {"show": True, "label": "Budget (₹)"},
        "deal_value": {"show": True, "label": "Deal Value (₹)"},
    }

    def lead_form(self) -> dict:
        """The lead form's standard money fields: {key: {"show", "label"}}."""
        saved = self.lead_form_settings or {}
        out = {}
        for key, default in self.LEAD_FORM_DEFAULTS.items():
            entry = saved.get(key) or {}
            label = str(entry.get("label") or "").strip()[:40]
            out[key] = {
                "show": bool(entry.get("show", default["show"])),
                "label": label or default["label"],
            }
        return out

    # ---- Access ------------------------------------------------

    @property
    def can_use_platform(self) -> bool:
        """
        Whether this tenant's people may sign in and use anything at all.

        Every signal must agree: the master switch, a usable subscription
        status, and — for a trial — a trial that has not run out (the nightly
        job that suspends expired trials may not have run yet).
        """
        if not self.is_active:
            return False
        if self.subscription_status not in SubscriptionStatus.ACTIVE_STATUSES:
            return False
        if self.is_trial_expired:
            return False
        return True

    def _sync_subscriptions(self, to_status: str | None = None, **extra) -> None:
        """
        Bring the Subscription rows in line with the tenant.

        Uses update() so the subscription→tenant sync signal does not fire:
        that signal is what used to flip a suspended tenant back to "active"
        the next time anything touched its (still active) subscription.
        """
        from apps.plans.models import Subscription

        subs = Subscription.objects.filter(tenant=self)
        if to_status is None:  # suspending: nothing stays usable
            subs.filter(status__in=SubscriptionStatus.ACTIVE_STATUSES).update(
                status=SubscriptionStatus.SUSPENDED,
            )
            return
        latest = subs.order_by("-pk").first()
        if latest is not None:
            Subscription.objects.filter(pk=latest.pk).update(status=to_status, **extra)

    def invalidate_access_cache(self) -> None:
        from apps.core.middleware import TenantFeatureFlagMiddleware

        TenantFeatureFlagMiddleware.invalidate_cache(self.schema_name)

    def suspend(self, reason: str = "", kind: str = SUSPENDED_ADMIN):
        """
        Suspend the tenant account: every sign-in and every API call is then
        answered "plan expired" until it is activated again.

        `kind` is ADMIN unless billing is the reason: only a BILLING
        suspension is lifted by the tenant paying.
        """
        self.subscription_status = SubscriptionStatus.SUSPENDED
        self.is_active = False
        self.suspension_kind = kind
        if reason:
            self.internal_notes += f"\n[SUSPENDED {timezone.now().date()}] {reason}"
        self.save(update_fields=["subscription_status", "is_active", "suspension_kind", "internal_notes"])
        # The subscription went on saying "active", and feature checks read
        # it: plan features stayed on for a suspended tenant.
        self._sync_subscriptions()
        # Effective at once, not when the cached "active" answer runs out.
        self.invalidate_access_cache()
        logger.info(f"[Tenant] Suspended: {self.schema_name} — {reason}")

    def activate(self):
        """Activate (or reactivate) the tenant account."""
        self.subscription_status = SubscriptionStatus.ACTIVE
        self.is_active = True
        self.suspension_kind = ""
        self.save(update_fields=["subscription_status", "is_active", "suspension_kind"])
        self._sync_subscriptions(SubscriptionStatus.ACTIVE)
        self.invalidate_access_cache()
        logger.info(f"[Tenant] Activated: {self.schema_name}")

    def delete(self, force_drop=False, *args, **kwargs):
        """
        Delete the tenant and DROP its schema (auto_drop_schema), in one
        transaction: if the row can't be deleted, the schema stays too.
        """
        from django.db import transaction

        schema = self.schema_name
        if schema == "public":
            raise ValueError("The public schema is never deleted.")
        with transaction.atomic():
            result = super().delete(force_drop, *args, **kwargs)
        try:
            from apps.core.middleware import TenantFeatureFlagMiddleware

            TenantFeatureFlagMiddleware.invalidate_cache(schema)
        except Exception:  # noqa: BLE001 — cache only
            pass
        logger.warning(f"[Tenant] Deleted with its schema: {schema}")
        return result

    def set_trial(self, days: int = 14):
        """Set or reset the trial period."""
        from datetime import timedelta
        self.subscription_status = SubscriptionStatus.TRIAL
        self.trial_ends_at = timezone.now() + timedelta(days=days)
        self.is_active = True
        self.suspension_kind = ""
        self.save(update_fields=["subscription_status", "trial_ends_at", "is_active", "suspension_kind"])
        if self.pk:
            self._sync_subscriptions(SubscriptionStatus.TRIAL, trial_end=self.trial_ends_at)
            self.invalidate_access_cache()

    def has_feature(self, feature_key: str) -> bool:
        """
        Check if tenant's plan has a specific feature enabled.
        NOTE: In request context, use request.has_feature() instead
        (it's cached in Redis). This method always hits the DB.
        """
        from apps.plans.models import PlanFeature, Subscription

        try:
            subscription = Subscription.objects.filter(
                tenant=self,
                status__in=SubscriptionStatus.ACTIVE_STATUSES,
            ).select_related("plan").first()

            if not subscription:
                return False

            return PlanFeature.objects.filter(
                plan=subscription.plan,
                feature_key=feature_key,
                is_enabled=True,
            ).exists()
        except Exception:
            return False


class Domain(DomainMixin):
    """
    Maps a domain/subdomain to a Tenant.

    django-tenants uses this to route requests:
    1. Request hits acmerealty.telecrm.in
    2. django-tenants queries Domain for this domain
    3. Sets connection schema to tenant.schema_name
    4. Request proceeds in tenant's PostgreSQL schema

    Multiple domains can map to one tenant (e.g., custom domain + subdomain).
    Only one should have is_primary=True.
    """

    class Meta:
        verbose_name = "Domain"
        verbose_name_plural = "Domains"

    def __str__(self):
        return f"{self.domain} → {self.tenant.company_name}"


class MetaPageRoute(models.Model):
    """
    Which tenant a Facebook Page's Lead Ads belong to.

    Every tenant that connects with "Continue with Facebook" shares the
    platform's one Meta app, so Meta posts every tenant's leads to the same
    webhook URL on the public domain. A leadgen event names only the Page;
    this table (in the public schema, where that webhook runs) turns the Page
    into the tenant whose schema the lead belongs in.

    One Page, one tenant: a second workspace trying to connect the same Page
    is refused rather than silently taking its leads.
    """

    page_id = models.CharField(max_length=40, unique=True)
    tenant = models.ForeignKey(Tenant, on_delete=models.CASCADE, related_name="meta_pages")
    page_name = models.CharField(max_length=200, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Meta Page route"
        verbose_name_plural = "Meta Page routes"

    def __str__(self):
        return f"Page {self.page_name or self.page_id} → {self.tenant.schema_name}"
