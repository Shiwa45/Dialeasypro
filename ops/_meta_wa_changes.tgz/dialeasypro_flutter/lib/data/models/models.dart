// ============================================================
// DialSathi — Data Models
// ============================================================
import '../../core/utils/utils.dart';

class Agent {
  final int id;
  final String email, name, phone, employeeId, role, roleDisplay;
  final bool isTenantAdmin, isActive, isOnline;
  final String? profilePhotoUrl, lastActiveAt, createdAt;
  final String timezone;
  final int totalLoginCount;
  /// The admin has turned phone call tracking on for this agent: the app
  /// saves every call on the phone and uploads its recording.
  final bool callTracking;

  const Agent({
    required this.id, required this.email, required this.name,
    this.phone = '', this.employeeId = '', required this.role,
    this.roleDisplay = '', this.isTenantAdmin = false, this.isActive = true,
    this.isOnline = false, this.profilePhotoUrl, this.lastActiveAt, this.createdAt,
    this.timezone = 'Asia/Kolkata', this.totalLoginCount = 0, this.callTracking = false,
  });

  factory Agent.fromJson(Map<String, dynamic> j) => Agent(
    id: j['id'] as int,
    email: j['email'] as String? ?? '',
    name: j['name'] as String? ?? '',
    phone: j['phone'] as String? ?? '',
    employeeId: j['employee_id'] as String? ?? '',
    role: j['role'] as String? ?? 'agent',
    roleDisplay: j['role_display'] as String? ?? '',
    isTenantAdmin: j['is_tenant_admin'] as bool? ?? false,
    isActive: j['is_active'] as bool? ?? true,
    isOnline: j['is_online'] as bool? ?? false,
    profilePhotoUrl: j['profile_photo_url'] as String?,
    lastActiveAt: j['last_active_at'] as String?,
    createdAt: j['created_at'] as String?,
    timezone: j['timezone'] as String? ?? 'Asia/Kolkata',
    totalLoginCount: j['total_login_count'] as int? ?? 0,
    callTracking: j['call_tracking'] as bool? ?? false,
  );

  String get initials => name.split(' ').map((n) => n.isNotEmpty ? n[0] : '').take(2).join().toUpperCase();
}

/// One custom field's value on a lead, as LeadDetailSerializer sends it:
/// {"field": 1, "field_key": "property_type", "field_name": "Property Type",
///  "value": "Villa"}
class LeadCustomField {
  final int fieldId;
  final String key, name, value;

  const LeadCustomField({
    required this.fieldId, required this.key, required this.name, required this.value,
  });

  factory LeadCustomField.fromJson(Map<String, dynamic> j) => LeadCustomField(
    fieldId: (j['field'] as num?)?.toInt() ?? 0,
    key: j['field_key'] as String? ?? '',
    name: j['field_name'] as String? ?? '',
    value: (j['value'] ?? '').toString(),
  );
}

/// A custom field a client's lead form asks for (set in the platform panel).
class LeadFormField {
  final String key, name, type, placeholder;
  final bool required;
  final List<String> options;

  const LeadFormField({
    required this.key, required this.name, this.type = 'text',
    this.placeholder = '', this.required = false, this.options = const [],
  });

  factory LeadFormField.fromJson(Map<String, dynamic> j) => LeadFormField(
    key: j['field_key'] as String? ?? '',
    name: j['name'] as String? ?? '',
    type: j['field_type'] as String? ?? 'text',
    placeholder: j['placeholder'] as String? ?? '',
    required: j['is_required'] as bool? ?? false,
    options: [for (final o in (j['options'] as List? ?? const [])) o.toString()],
  );
}

/// One standard field's per-client setting: shown or not, and its label.
class StandardFieldSetting {
  final bool show;
  final String label;
  const StandardFieldSetting({required this.show, required this.label});

  factory StandardFieldSetting.fromJson(Map<String, dynamic>? j, String fallback) =>
      StandardFieldSetting(
        show: j?['show'] as bool? ?? true,
        label: (j?['label'] as String?)?.isNotEmpty == true ? j!['label'] as String : fallback,
      );
}

/// What this client's Add Lead form shows.
class LeadFormConfig {
  final StandardFieldSetting budget, dealValue;
  final List<LeadFormField> customFields;

  const LeadFormConfig({
    this.budget = const StandardFieldSetting(show: true, label: 'Budget (₹)'),
    this.dealValue = const StandardFieldSetting(show: true, label: 'Deal Value (₹)'),
    this.customFields = const [],
  });

  factory LeadFormConfig.fromJson(Map<String, dynamic> j) {
    final standard = (j['standard'] as Map?)?.cast<String, dynamic>() ?? const {};
    return LeadFormConfig(
      budget: StandardFieldSetting.fromJson(
          (standard['budget'] as Map?)?.cast<String, dynamic>(), 'Budget (₹)'),
      dealValue: StandardFieldSetting.fromJson(
          (standard['deal_value'] as Map?)?.cast<String, dynamic>(), 'Deal Value (₹)'),
      customFields: [
        for (final f in (j['custom_fields'] as List? ?? const []))
          if (f is Map) LeadFormField.fromJson(f.cast<String, dynamic>()),
      ],
    );
  }
}

class Lead {
  final int id;
  final String name, phone, alternatePhone, email, city, state;
  final String source, sourceDisplay;
  final String status, statusDisplay;
  final String priority, priorityDisplay;
  final int score;
  final int? assignedTo;
  final String? assignedToName, budget, dealValue, nextFollowupAt, lastContactedAt;
  final String requirement;
  final bool followupOverdue, isDnd;
  /// Answered calls (the server counts only those now).
  final int contactCount;
  final List<String> tags;
  final String createdAt;

  // ---- What the lead's calls came to (kept up to date by the server) ----
  /// Outcome of the most recent call that has one.
  final String? lastDispositionName;
  /// 'connected' / 'not_connected' — which group that outcome is in.
  final String? lastDispositionCategory;
  /// Whether the most recent call was answered (null: never called).
  final bool? lastCallConnected;
  final String? lastDialedAt;
  /// Calls made to the lead, and how many of them were answered.
  final int dialAttempts, connectedCalls;

  /// Custom field values. The app never parsed these, so every tenant's
  /// custom fields — imported from CSV, set on the web, the fields a sales
  /// team actually qualifies on — were sent by the server and dropped here,
  /// before any screen had a chance to show them.
  final List<LeadCustomField> customFields;

  /// Whether the response this lead came from carried custom fields at all.
  ///
  /// Not the same as "has none". The list endpoint omits the key to stay
  /// light, so a lead taken from the list reads as having no custom fields
  /// when it simply was not told. The dialer queue started from the leads
  /// list is exactly that case, and uses this to fetch the full lead before
  /// showing the agent an empty panel as if it were the truth.
  final bool customFieldsLoaded;

  const Lead({
    required this.id, required this.name, required this.phone,
    this.alternatePhone = '', this.email = '', this.city = '', this.state = '',
    this.source = 'manual', this.sourceDisplay = 'Manual',
    required this.status, this.statusDisplay = '',
    this.priority = 'warm', this.priorityDisplay = 'Warm',
    this.score = 0, this.assignedTo, this.assignedToName,
    this.budget, this.dealValue, this.nextFollowupAt, this.lastContactedAt,
    this.requirement = '', this.followupOverdue = false, this.isDnd = false,
    this.contactCount = 0, this.tags = const [], required this.createdAt,
    this.customFields = const [], this.customFieldsLoaded = false,
    this.lastDispositionName, this.lastDispositionCategory, this.lastCallConnected,
    this.lastDialedAt, this.dialAttempts = 0, this.connectedCalls = 0,
  });

  factory Lead.fromJson(Map<String, dynamic> j) => Lead(
    // Every other field here tolerates a missing key; `id` did not, so one
    // absent field in a response turned into a TypeError the UI reported as
    // "An unexpected error occurred" — which is exactly how a create that had
    // actually succeeded looked like a failure.
    id: (j['id'] as num?)?.toInt() ?? 0,
    name: j['name'] as String? ?? '',
    phone: j['phone'] as String? ?? '',
    alternatePhone: j['alternate_phone'] as String? ?? '',
    email: j['email'] as String? ?? '',
    city: j['city'] as String? ?? '',
    state: j['state'] as String? ?? '',
    source: j['source'] as String? ?? 'manual',
    sourceDisplay: j['source_display'] as String? ?? '',
    status: j['status'] as String? ?? 'new',
    statusDisplay: j['status_display'] as String? ?? '',
    priority: j['priority'] as String? ?? 'warm',
    priorityDisplay: j['priority_display'] as String? ?? '',
    score: j['score'] as int? ?? 0,
    assignedTo: j['assigned_to'] as int?,
    assignedToName: j['assigned_to_name'] as String?,
    budget: j['budget']?.toString(),
    dealValue: j['deal_value']?.toString(),
    nextFollowupAt: j['next_followup_at'] as String?,
    lastContactedAt: j['last_contacted_at'] as String?,
    requirement: j['requirement'] as String? ?? '',
    followupOverdue: j['followup_overdue'] as bool? ?? false,
    isDnd: j['is_dnd'] as bool? ?? false,
    contactCount: j['contact_count'] as int? ?? 0,
    tags: (j['tags'] as List?)?.cast<String>() ?? [],
    customFields: [
      for (final v in (j['custom_field_values'] as List? ?? const []))
        if (v is Map) LeadCustomField.fromJson(v.cast<String, dynamic>()),
    ],
    customFieldsLoaded: j.containsKey('custom_field_values'),
    createdAt: j['created_at'] as String? ?? '',
    lastDispositionName: j['last_disposition_name'] as String?,
    lastDispositionCategory: j['last_disposition_category'] as String?,
    lastCallConnected: j['last_call_connected'] as bool?,
    lastDialedAt: j['last_dialed_at'] as String?,
    // An older server has no counters: fall back to the contact count.
    dialAttempts: (j['dial_attempts'] as num?)?.toInt() ?? (j['contact_count'] as num?)?.toInt() ?? 0,
    connectedCalls: (j['connected_calls'] as num?)?.toInt() ?? 0,
  );

  String get initials => name.split(' ').map((n) => n.isNotEmpty ? n[0] : '').take(2).join().toUpperCase();
}

class FollowUp {
  final int id, lead, assignedTo;
  final String assignedToName, followupType, followupTypeDisplay;
  final String scheduledAt, notes, createdAt;
  final bool isCompleted, isOverdue;
  final String? completedAt;
  /// Who the follow-up is with. A lock-screen reminder saying "follow up with
  /// lead 54" is useless, and resolving it needed a request per follow-up
  /// until the serializer started sending it.
  final String? leadName;
  final String? leadPhone;

  const FollowUp({
    required this.id, required this.lead, required this.assignedTo,
    this.assignedToName = '', required this.followupType, this.followupTypeDisplay = '',
    required this.scheduledAt, this.notes = '', required this.createdAt,
    this.isCompleted = false, this.isOverdue = false, this.completedAt,
    this.leadName, this.leadPhone,
  });

  /// Alias so callers reading a reminder do not have to remember that the
  /// foreign key is called `lead`.
  int get leadId => lead;

  /// Parsed local time, or the epoch when the server sent nothing usable —
  /// scheduling code checks that the time is in the future anyway, so an
  /// unparseable value is simply skipped rather than throwing.
  DateTime get scheduledAtLocal =>
      DateTime.tryParse(scheduledAt)?.toLocal() ??
      DateTime.fromMillisecondsSinceEpoch(0);

  factory FollowUp.fromJson(Map<String, dynamic> j) => FollowUp(
    id: j['id'] as int,
    lead: j['lead'] as int,
    assignedTo: j['assigned_to'] as int? ?? 0,
    assignedToName: j['assigned_to_name'] as String? ?? '',
    followupType: j['followup_type'] as String? ?? 'call',
    followupTypeDisplay: j['followup_type_display'] as String? ?? '',
    scheduledAt: j['scheduled_at'] as String? ?? '',
    notes: j['notes'] as String? ?? '',
    createdAt: j['created_at'] as String? ?? '',
    isCompleted: j['is_completed'] as bool? ?? false,
    isOverdue: j['is_overdue'] as bool? ?? false,
    completedAt: j['completed_at'] as String?,
    leadName: j['lead_name'] as String?,
    leadPhone: j['lead_phone'] as String?,
  );
}

/// One notification, matching apps/authentication/serializers_notifications.py.
class AppNotification {
  final int id;
  final String kind, title, body, url;
  final int? leadId, followupId;
  final bool isRead;
  final String createdAt;

  const AppNotification({
    required this.id, required this.kind, required this.title,
    this.body = '', this.url = '',
    this.leadId, this.followupId,
    this.isRead = false, this.createdAt = '',
  });

  DateTime? get createdAtLocal => DateTime.tryParse(createdAt)?.toLocal();

  factory AppNotification.fromJson(Map<String, dynamic> j) => AppNotification(
    id: j['id'] as int,
    kind: j['kind'] as String? ?? 'system',
    title: j['title'] as String? ?? '',
    body: j['body'] as String? ?? '',
    url: j['url'] as String? ?? '',
    leadId: j['lead_id'] as int?,
    followupId: j['followup_id'] as int?,
    isRead: j['is_read'] as bool? ?? false,
    createdAt: j['created_at'] as String? ?? '',
  );
}

class LeadNote {
  final int id, lead;
  final int? agent;
  final String? agentName, attachment;
  final String content, createdAt;
  final bool isPinned;

  const LeadNote({
    required this.id, required this.lead, this.agent, this.agentName,
    required this.content, this.isPinned = false, this.attachment,
    required this.createdAt,
  });

  factory LeadNote.fromJson(Map<String, dynamic> j) => LeadNote(
    id: j['id'] as int,
    lead: j['lead'] as int,
    agent: j['agent'] as int?,
    agentName: j['agent_name'] as String?,
    content: j['content'] as String? ?? '',
    isPinned: j['is_pinned'] as bool? ?? false,
    attachment: j['attachment'] as String?,
    createdAt: j['created_at'] as String? ?? '',
  );
}

class CallLog {
  final String id;
  final int? agent, lead;
  final String? agentName, leadName, endedAt, dispositionName, recordingUrl;
  final String direction, phoneNumber, startedAt, notes, provider, durationDisplay;
  final int durationSeconds;
  final bool isConnected;
  final int? disposition;
  /// 'connected' / 'not_connected' — the group of the call's outcome.
  final String? dispositionCategory;

  /// Saved without an outcome (a click-to-call, a provider call): the agent
  /// still has to say how it went.
  bool get needsOutcome => disposition == null;

  const CallLog({
    required this.id, this.agent, this.agentName, this.lead, this.leadName,
    required this.direction, required this.phoneNumber, required this.startedAt,
    this.endedAt, this.durationSeconds = 0, this.durationDisplay = '—',
    this.isConnected = false, this.disposition, this.dispositionName,
    this.notes = '', this.provider = '', this.recordingUrl, this.dispositionCategory,
  });

  factory CallLog.fromJson(Map<String, dynamic> j) => CallLog(
    id: j['id'] as String? ?? '',
    agent: j['agent'] as int?,
    agentName: j['agent_name'] as String?,
    lead: j['lead'] as int?,
    leadName: j['lead_name'] as String?,
    direction: j['direction'] as String? ?? 'outbound',
    phoneNumber: j['phone_number'] as String? ?? '',
    startedAt: j['started_at'] as String? ?? '',
    endedAt: j['ended_at'] as String?,
    durationSeconds: j['duration_seconds'] as int? ?? 0,
    durationDisplay: j['duration_display'] as String? ?? '—',
    isConnected: j['is_connected'] as bool? ?? false,
    disposition: j['disposition'] as int?,
    dispositionName: j['disposition_name'] as String?,
    dispositionCategory: j['disposition_category'] as String?,
    notes: j['notes'] as String? ?? '',
    provider: j['provider'] as String? ?? '',
    recordingUrl: _extractRecordingUrl(j),
  );
}

String? _extractRecordingUrl(Map<String, dynamic> j) {
  final rec = j['recording'];
  if (rec is Map) {
    final url = rec['playback_url'];
    return url is String ? url : null;
  }
  return j['recording_url'] as String?;
}

final _notConnectedWords = RegExp(
    r'not reachable|unreachable|busy|switched off|switch off|voicemail|voice mail|no answer|'
    r'not answered|not connected|ringing|rnr|out of service|invalid number|rejected|ivr');

class CallDisposition {
  final int id;
  final String name, slug;
  final bool isPositive;
  final int? autoFollowupHours;
  /// 'connected' or 'not_connected' — which kind of call this outcome is for.
  final String category;
  /// The lead status a call with this outcome moves the lead to ('' = only
  /// the minimum: Contacted if answered, Attempted if not).
  final String leadStatus;
  final bool setsDnd;

  const CallDisposition({
    required this.id, required this.name, required this.slug,
    this.isPositive = false, this.autoFollowupHours,
    this.category = 'connected', this.leadStatus = '', this.setsDnd = false,
  });

  bool get isConnectedOutcome => category == 'connected';

  /// "Lead → Interested · follow-up in 24 h", or null when it does neither.
  String? get effectLine {
    final parts = <String>[
      if (leadStatus.isNotEmpty) 'Lead → ${Fmt.leadStatusLabels[leadStatus] ?? leadStatus}',
      if ((autoFollowupHours ?? 0) > 0) 'follow-up in $autoFollowupHours h',
      if (setsDnd) 'marks the lead Do Not Disturb',
    ];
    return parts.isEmpty ? null : parts.join(' · ');
  }

  factory CallDisposition.fromJson(Map<String, dynamic> j) {
    // An older server (or a list cached before this version) has no
    // category: use marks_connected, else read the name.
    final marks = j['marks_connected'];
    final category = j['category'] as String? ??
        (marks == true ? 'connected'
        : marks == false ? 'not_connected'
        : _notConnectedWords.hasMatch('${j['slug'] ?? ''} ${j['name'] ?? ''}'.toLowerCase().replaceAll('_', ' '))
            ? 'not_connected' : 'connected');
    return CallDisposition(
      id: j['id'] as int,
      name: j['name'] as String? ?? '',
      slug: j['slug'] as String? ?? '',
      isPositive: j['is_positive'] as bool? ?? false,
      autoFollowupHours: j['auto_followup_hours'] as int?,
      category: category,
      leadStatus: j['lead_status'] as String? ?? '',
      setsDnd: j['sets_dnd'] as bool? ?? false,
    );
  }
}

class WhatsAppTemplate {
  final int id;
  final String name, category, language, bodyText, headerText, status, provider;
  final int usageCount;
  /// The WhatsApp number it was approved on; null = any number.
  final int? accountId;
  final String accountLabel;

  const WhatsAppTemplate({
    required this.id, required this.name, this.category = 'utility',
    this.language = 'en', required this.bodyText, this.headerText = '',
    this.status = 'pending', this.provider = 'interakt', this.usageCount = 0,
    this.accountId, this.accountLabel = '',
  });

  factory WhatsAppTemplate.fromJson(Map<String, dynamic> j) => WhatsAppTemplate(
    id: j['id'] as int,
    name: j['name'] as String? ?? '',
    category: j['category'] as String? ?? 'utility',
    language: j['language'] as String? ?? 'en',
    bodyText: j['body_text'] as String? ?? '',
    headerText: j['header_text'] as String? ?? '',
    status: j['status'] as String? ?? 'pending',
    provider: j['provider'] as String? ?? 'interakt',
    usageCount: j['usage_count'] as int? ?? 0,
    accountId: j['account'] as int?,
    accountLabel: j['account_label'] as String? ?? '',
  );
}

/// One of the company's WhatsApp numbers an agent can send from
/// (GET /comms/whatsapp/senders/ — names only, never credentials).
class WhatsAppSender {
  final int id;
  final String label, displayPhone, provider;
  final bool isDefault, isActive;

  /// The number this agent's sends start on: the one an admin assigned them,
  /// else the company default. An agent with assigned numbers is only ever
  /// sent those numbers.
  final bool preferred;

  const WhatsAppSender({
    required this.id, required this.label, this.displayPhone = '',
    this.provider = '', this.isDefault = false, this.isActive = false,
    this.preferred = false,
  });

  /// " · yours" for the agent's own number, " · default" for the company's.
  String get suffix => preferred && !isDefault ? ' · yours' : (isDefault ? ' · default' : '');

  /// "Sales (+91 98765 43210)"
  String get title => displayPhone.isEmpty ? label : '$label ($displayPhone)';

  factory WhatsAppSender.fromJson(Map<String, dynamic> j) => WhatsAppSender(
    id: j['id'] as int,
    label: j['label'] as String? ?? '',
    displayPhone: j['display_phone'] as String? ?? '',
    provider: j['provider'] as String? ?? '',
    isDefault: j['is_default'] as bool? ?? false,
    isActive: j['is_active'] as bool? ?? false,
    preferred: j['preferred'] as bool? ?? false,
  );
}

class LeadStats {
  final int newLeadsToday, followupsDue, overdueFollowups;
  final int totalLeads, activeLeads, won, lost;
  final double conversionRate, pipelineValue;
  final Map<String, int> byStatus;

  const LeadStats({
    this.newLeadsToday = 0, this.followupsDue = 0, this.overdueFollowups = 0,
    this.totalLeads = 0, this.activeLeads = 0, this.won = 0, this.lost = 0,
    this.conversionRate = 0, this.pipelineValue = 0, this.byStatus = const {},
  });

  factory LeadStats.fromJson(Map<String, dynamic> j) {
    final today = j['today'] as Map<String, dynamic>? ?? {};
    final total = j['total'] as Map<String, dynamic>? ?? {};
    return LeadStats(
      newLeadsToday: today['new_leads'] as int? ?? 0,
      followupsDue: today['followups_due'] as int? ?? 0,
      overdueFollowups: today['overdue_followups'] as int? ?? 0,
      totalLeads: total['total_leads'] as int? ?? 0,
      activeLeads: total['active_leads'] as int? ?? 0,
      won: total['won'] as int? ?? 0,
      lost: total['lost'] as int? ?? 0,
      conversionRate: (total['conversion_rate'] as num?)?.toDouble() ?? 0,
      pipelineValue: (total['pipeline_value'] as num?)?.toDouble() ?? 0,
      byStatus: (j['by_status'] as Map<String, dynamic>?)?.map((k, v) => MapEntry(k, v as int)) ?? {},
    );
  }
}

class PaginatedResponse<T> {
  final int count, totalPages, currentPage;
  final List<T> results;

  const PaginatedResponse({
    required this.count, required this.totalPages,
    required this.currentPage, required this.results,
  });

  factory PaginatedResponse.fromJson(
    Map<String, dynamic> j, T Function(Map<String, dynamic>) fromJson,
  ) => PaginatedResponse<T>(
    count: j['count'] as int? ?? 0,
    totalPages: j['total_pages'] as int? ?? 1,
    currentPage: j['current_page'] as int? ?? 1,
    results: (j['results'] as List?)?.map((e) => fromJson(e as Map<String, dynamic>)).toList() ?? [],
  );
}

class LoginResponse {
  final String access, refresh;
  final Agent agent;
  final bool mustChangePassword;

  const LoginResponse({
    required this.access, required this.refresh,
    required this.agent, this.mustChangePassword = false,
  });

  factory LoginResponse.fromJson(Map<String, dynamic> j) => LoginResponse(
    access: j['access'] as String,
    refresh: j['refresh'] as String,
    agent: Agent.fromJson(j['agent'] as Map<String, dynamic>),
    mustChangePassword: j['must_change_password'] as bool? ?? false,
  );
}

// ─── WhatsApp inbox ─────────────────────────────────────────
/// Whether free text can still be sent: WhatsApp allows it for 24 hours after
/// the customer's last message, after that only an approved template.
class ReplyWindow {
  final bool open;
  final DateTime? closesAt;

  const ReplyWindow({this.open = false, this.closesAt});

  factory ReplyWindow.fromJson(Map<String, dynamic>? j) => ReplyWindow(
    open: j?['open'] as bool? ?? false,
    closesAt: DateTime.tryParse(j?['closes_at'] as String? ?? '')?.toLocal(),
  );

  /// "23h left", "40 min left", or '' once closed.
  String leftLabel(DateTime now) {
    final at = closesAt;
    if (!open || at == null) return '';
    final left = at.difference(now);
    if (left.isNegative) return '';
    if (left.inHours >= 1) return '${left.inHours}h left';
    return '${left.inMinutes < 1 ? 1 : left.inMinutes} min left';
  }
}

/// One customer who has written in: the newest message and what is unread.
class InboxConversation {
  final int leadId;
  final String leadName, phone, status;
  final String? ownerName;
  final int unread;
  final String lastText, lastDirection, lastStatus;
  final String? lastAccountLabel;
  final DateTime? lastAt;
  final ReplyWindow window;

  const InboxConversation({
    required this.leadId, required this.leadName, this.phone = '', this.status = '',
    this.ownerName, this.unread = 0, this.lastText = '', this.lastDirection = 'inbound',
    this.lastStatus = '', this.lastAccountLabel, this.lastAt, this.window = const ReplyWindow(),
  });

  bool get lastIsMine => lastDirection == 'outbound';

  factory InboxConversation.fromJson(Map<String, dynamic> j) {
    final last = Map<String, dynamic>.from(j['last_message'] as Map? ?? const {});
    return InboxConversation(
      leadId: j['lead_id'] as int,
      leadName: j['lead_name'] as String? ?? '',
      phone: j['phone'] as String? ?? '',
      status: j['status'] as String? ?? '',
      ownerName: j['owner_name'] as String?,
      unread: j['unread'] as int? ?? 0,
      lastText: last['text'] as String? ?? '',
      lastDirection: last['direction'] as String? ?? 'inbound',
      lastStatus: last['status'] as String? ?? '',
      lastAccountLabel: last['account_label'] as String?,
      lastAt: DateTime.tryParse(last['at'] as String? ?? '')?.toLocal(),
      window: ReplyWindow.fromJson(j['window'] as Map<String, dynamic>?),
    );
  }
}

class InboxMessage {
  final String id, direction, type, content, status, errorMessage;
  final String? templateName, sentByName, accountLabel;
  final DateTime at;

  const InboxMessage({
    required this.id, required this.direction, this.type = 'text', this.content = '',
    this.status = '', this.errorMessage = '', this.templateName, this.sentByName,
    this.accountLabel, required this.at,
  });

  bool get isMine => direction == 'outbound';

  /// What to show in the bubble: the text, else the template, else the kind.
  String get display {
    if (content.isNotEmpty) return content;
    if ((templateName ?? '').isNotEmpty) return 'Template: $templateName';
    return '[$type]';
  }

  factory InboxMessage.fromJson(Map<String, dynamic> j) => InboxMessage(
    id: '${j['id']}',
    direction: j['direction'] as String? ?? 'inbound',
    type: j['message_type'] as String? ?? 'text',
    content: j['content'] as String? ?? '',
    status: j['status'] as String? ?? '',
    errorMessage: j['error_message'] as String? ?? '',
    templateName: j['template_name'] as String?,
    sentByName: j['sent_by_name'] as String?,
    accountLabel: j['account_label'] as String?,
    at: (DateTime.tryParse(j['sent_at'] as String? ?? '') ??
            DateTime.tryParse(j['created_at'] as String? ?? '') ??
            DateTime.now())
        .toLocal(),
  );
}

class InboxThread {
  final int leadId;
  final String leadName, phone, status;
  final String? ownerName, lastAccountLabel;
  final int? lastAccountId;
  final int unread;
  final ReplyWindow window;
  final List<InboxMessage> messages;

  const InboxThread({
    required this.leadId, required this.leadName, this.phone = '', this.status = '',
    this.ownerName, this.lastAccountId, this.lastAccountLabel, this.unread = 0,
    this.window = const ReplyWindow(), this.messages = const [],
  });

  factory InboxThread.fromJson(Map<String, dynamic> j) {
    final lead = Map<String, dynamic>.from(j['lead'] as Map? ?? const {});
    return InboxThread(
      leadId: lead['id'] as int,
      leadName: lead['name'] as String? ?? '',
      phone: lead['phone'] as String? ?? '',
      status: lead['status'] as String? ?? '',
      ownerName: lead['owner_name'] as String?,
      lastAccountId: j['last_account_id'] as int?,
      lastAccountLabel: j['last_account_label'] as String?,
      unread: j['unread'] as int? ?? 0,
      window: ReplyWindow.fromJson(j['window'] as Map<String, dynamic>?),
      messages: [
        for (final m in (j['messages'] as List? ?? const []))
          InboxMessage.fromJson(Map<String, dynamic>.from(m as Map)),
      ],
    );
  }
}
