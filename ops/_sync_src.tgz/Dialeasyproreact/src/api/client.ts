// ============================================================
// DialSathi — API Client
// Axios instance with JWT auth + automatic token refresh
// Base URL: /api/v1/ (proxied to Django backend in dev)
// ============================================================
import axios, { type AxiosError, type InternalAxiosRequestConfig } from 'axios';
import { resolveTenantOrigin, buildTenantWsUrl } from '../utils/domain';

export const apiClient = axios.create({
  baseURL: `${resolveTenantOrigin(localStorage.getItem('tenant_workspace'))}/api/v1`,
  headers: { 'Content-Type': 'application/json' },
  timeout: 30_000,
});

// ---- Request interceptor: attach Bearer token and dynamic tenant URL ----
apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const workspace = localStorage.getItem('tenant_workspace');
  if (workspace) {
    config.baseURL = `${resolveTenantOrigin(workspace)}/api/v1`;

    // Always send the tenant schema as a header.
    // TenantSchemaFromTokenMiddleware on the backend uses this as a fallback
    // for requests that arrive before a JWT is available (e.g. the login call
    // and the token-refresh call), ensuring the DB is always on the right schema.
    config.headers['X-Tenant-Schema'] = workspace;
  }

  // Identifies the web app (vs the mobile app, which sends nothing) so login
  // can apply the tenant's "agents may sign in on the web" policy.
  config.headers['X-Client'] = 'web';

  const token = localStorage.getItem('access_token');
  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`;
  }
  return config;
});

// ---- Response interceptor: handle 401 + refresh ----
let isRefreshing = false;
let failedQueue: Array<{ resolve: (v: string) => void; reject: (e: unknown) => void }> = [];

const processQueue = (error: unknown, token: string | null) => {
  failedQueue.forEach((p) => (error ? p.reject(error) : p.resolve(token!)));
  failedQueue = [];
};

// Fires when the backend rejects a call because the tenant's plan doesn't
// include the feature. The app subscribes to this to show an upgrade prompt.
export interface UpgradeRequired {
  feature_key: string;
  feature_label: string;
  available_in: string[];
  module: string | null;
  upgrade_url: string;
  /** HTTP method of the refused request (added client-side): a GET is a
   *  screen loading, anything else is something the user just tried to do. */
  request_method?: string;
}
export const onUpgradeRequired = new EventTarget();

/** The company's plan has expired or it was suspended by the platform owner:
 *  every call is refused until it is renewed. */
export interface AccountBlocked {
  error: 'plan_expired' | 'account_suspended';
  message: string;
}
export const onAccountBlocked = new EventTarget();
const BLOCKED_CODES = ['plan_expired', 'account_suspended'];

apiClient.interceptors.response.use(
  (res) => res,
  async (error: AxiosError) => {
    const original = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

    // 402 = plan gate. Broadcast the structured upsell payload so the UI can
    // prompt an upgrade rather than surfacing a generic error.
    if (error.response?.status === 402) {
      // A download (Export) asked for a blob, so the JSON refusal arrives as
      // one too and was never recognised. Read it back into JSON — for this
      // prompt and for every error message shown from it.
      if (typeof Blob !== 'undefined' && error.response.data instanceof Blob) {
        try {
          error.response.data = JSON.parse(await error.response.data.text());
        } catch { /* not JSON: leave it as it was */ }
      }
      const data = error.response.data as Partial<UpgradeRequired> & { error?: string };
      if (data?.error === 'upgrade_required') {
        // A download is something the user clicked, like any non-GET.
        const isDownload = original?.responseType === 'blob';
        const method = (original?.method ?? 'get').toLowerCase();
        onUpgradeRequired.dispatchEvent(
          new CustomEvent<UpgradeRequired>('upgrade', {
            detail: { ...(data as UpgradeRequired), request_method: isDownload ? 'download' : method },
          })
        );
      }
      return Promise.reject(error);
    }

    // 403 plan_expired / account_suspended = the whole company is locked out.
    // The login page shows the message itself; everywhere else the app is
    // replaced by the "Plan expired" screen (PlanExpiredGate).
    if (error.response?.status === 403) {
      const data = error.response.data as { error?: string; message?: string } | undefined;
      if (data?.error && BLOCKED_CODES.includes(data.error) && window.location.pathname !== '/login') {
        onAccountBlocked.dispatchEvent(
          new CustomEvent<AccountBlocked>('blocked', {
            detail: { error: data.error as AccountBlocked['error'], message: data.message ?? '' },
          })
        );
      }
      return Promise.reject(error);
    }

    if (error.response?.status === 401 && !original._retry) {
      if (isRefreshing) {
        return new Promise<string>((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then((token) => {
          original.headers['Authorization'] = `Bearer ${token}`;
          return apiClient(original);
        });
      }

      original._retry = true;
      isRefreshing = true;

      const refresh = localStorage.getItem('refresh_token');
      if (!refresh) {
        isRefreshing = false;
        clearAuth();
        redirectToLogin();
        return Promise.reject(error);
      }

      try {
        // BASE_URL was never defined. When original.baseURL is missing this
        // threw a ReferenceError inside the 401 handler, so the refresh never
        // ran and the agent was bounced to /login on a recoverable expiry.
        // resolveTenantOrigin is the same resolver the client is built from.
        const fallbackBase =
          `${resolveTenantOrigin(localStorage.getItem('tenant_workspace'))}/api/v1`;
        const refreshUrl = `${original.baseURL || fallbackBase}/auth/refresh/`;
        const { data } = await axios.post(refreshUrl, { refresh });
        localStorage.setItem('access_token', data.access);
        localStorage.setItem('refresh_token', data.refresh);
        apiClient.defaults.headers['Authorization'] = `Bearer ${data.access}`;
        processQueue(null, data.access);
        original.headers['Authorization'] = `Bearer ${data.access}`;
        return apiClient(original);
      } catch (refreshError) {
        processQueue(refreshError, null);
        clearAuth();
        redirectToLogin();
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  }
);

// Redirect to login at most once, and never when already there — prevents the
// full-page-reload loop where a failing request on /login would reload forever.
let redirecting = false;
const redirectToLogin = () => {
  if (redirecting) return;
  if (window.location.pathname === '/login') return;
  redirecting = true;
  window.location.href = '/login';
};

export const clearAuth = () => {
  localStorage.removeItem('access_token');
  localStorage.removeItem('refresh_token');
  localStorage.removeItem('agent');
  // Critical: also clear the persisted zustand auth state. Without this the
  // store rehydrates isAuthenticated=true on reload and the route guard bounces
  // /login → /dashboard → 401 → /login forever.
  localStorage.removeItem('dialeasypro-auth');
};

export const setAuth = (access: string, refresh: string) => {
  localStorage.setItem('access_token', access);
  localStorage.setItem('refresh_token', refresh);
};

// Build a tenant-scoped WebSocket URL (wss://{workspace}.{domain}{path}).
// Uses the centralized domain resolver to ensure WebSocket routing exactly matches REST.
export const tenantWsUrl = (path: string): string => {
  return buildTenantWsUrl(path);
};

// Open a tenant WebSocket. Browsers can't set an Authorization header on a
// socket, so the token goes as the "bearer" subprotocol — a header, which
// servers don't log, unlike the ?token= URL this used to build.
export const openTenantSocket = (path: string): WebSocket => {
  const token = localStorage.getItem('access_token') ?? '';
  return new WebSocket(tenantWsUrl(path), ['bearer', token]);
};

export default apiClient;
