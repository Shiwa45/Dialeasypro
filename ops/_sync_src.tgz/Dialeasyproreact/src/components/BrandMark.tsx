/** Placeholder DialSathi mark — a handset with signal arcs, drawn for dark
 *  green grounds (the rail and the login panel). Swap for the real logo file
 *  when there is one. */
export default function BrandMark({ size }: { size?: number }) {
  return (
    <svg className="brand-mark" viewBox="0 0 44 44" aria-hidden="true"
         style={size ? { width: size, height: size } : undefined}>
      <path d="M9 12c0-1.7 1.3-3 3-3h5l2.6 6.5-3.2 2a13 13 0 0 0 6.1 6.1l2-3.2L31 23v5c0 1.7-1.3 3-3 3h-1C16.5 31 9 23.5 9 13z" fill="#7de8b3" />
      <path d="M25 8a11 11 0 0 1 11 11M25 13.5a5.5 5.5 0 0 1 5.5 5.5" fill="none" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" />
      <path d="M7 30c4 7 13 10 21 7" fill="none" stroke="#7de8b3" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}
