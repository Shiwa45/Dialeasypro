// ============================================================
// Log a call / set a call's outcome
//
// Call status and call outcome are two different things, asked in that
// order: was the call answered? Then only the outcomes for that answer are
// offered. The old form had an "answered" tick box next to one flat list of
// every outcome; the two could contradict each other and the outcome
// silently won. An empty duration also made the save fail with no message.
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { callsApi } from '../api';
import { Input, Modal, Select, Textarea, useToast } from './ui';
import { getErrorMessage } from '../utils/errors';
import { LEAD_STATUSES } from '../utils/fmt';
import type { CallDisposition, CallLog, DispositionCategory } from '../types';

type Props =
  | { mode: 'log'; leadId: number; phone: string; onClose: () => void; onSaved?: (call: CallLog) => void }
  | { mode: 'set'; call: Pick<CallLog, 'id' | 'lead' | 'lead_name' | 'phone_number' | 'is_connected' | 'duration_seconds'>;
      onClose: () => void; onSaved?: (call: CallLog) => void };

const newClientId = () =>
  (typeof crypto !== 'undefined' && 'randomUUID' in crypto)
    ? crypto.randomUUID()
    : `web-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;

/** What an outcome does, in a line: "Lead → Interested · follow-up in 24 h". */
export function outcomeEffect(d: CallDisposition): string {
  const parts: string[] = [];
  if (d.lead_status) parts.push(`Lead → ${LEAD_STATUSES.find(s => s.value === d.lead_status)?.label ?? d.lead_status}`);
  if (d.auto_followup_hours) parts.push(`follow-up in ${d.auto_followup_hours} h`);
  if (d.sets_dnd) parts.push('marks the lead Do Not Disturb');
  return parts.join(' · ');
}

export default function CallOutcomeModal(props: Props) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const isSet = props.mode === 'set';

  const [answered, setAnswered] = useState<boolean | null>(
    isSet && props.call.duration_seconds > 0 ? true : null,
  );
  const [disposition, setDisposition] = useState('');
  const [direction, setDirection] = useState('outbound');
  const [duration, setDuration] = useState(isSet && props.call.duration_seconds ? String(props.call.duration_seconds) : '');
  const [notes, setNotes] = useState('');
  // Only Busy, Call back later and Voicemail book a follow-up on their own;
  // for anything else the agent can set one here (it also replaces the
  // automatic one with an exact time).
  const [followupAt, setFollowupAt] = useState('');
  // One id per form: pressing Save again after a lost response returns the
  // call already saved instead of saving it twice.
  const [clientCallId] = useState(newClientId);

  const { data: dispositions } = useQuery({
    queryKey: ['dispositions'],
    queryFn: () => callsApi.dispositions().then(r => r.data),
  });

  const category: DispositionCategory | null = answered === null ? null : answered ? 'connected' : 'not_connected';
  const options = useMemo(
    () => (dispositions ?? []).filter(d => d.category === category),
    [dispositions, category],
  );
  const chosen = options.find(d => String(d.id) === disposition);

  const seconds = Number(duration || 0);
  const followupIso = followupAt ? new Date(followupAt).toISOString() : undefined;
  const followupPast = !!followupAt && new Date(followupAt).getTime() < Date.now() - 60_000;
  const durationMissing = answered === true && !(seconds > 0);
  const canSave = answered !== null && !!chosen && !durationMissing && !followupPast;

  const save = useMutation({
    mutationFn: async () => {
      if (props.mode === 'log') {
        return callsApi.create({
          lead: props.leadId,
          phone_number: props.phone,
          direction,
          is_connected: answered,
          disposition: Number(disposition),
          duration_seconds: answered ? seconds : 0,
          notes,
          client_call_id: clientCallId,
          ...(followupIso ? { followup_at: followupIso } : {}),
        });
      }
      return callsApi.setOutcome(props.call.id, {
        disposition: Number(disposition),
        is_connected: !!answered,
        ...(answered ? { duration_seconds: seconds } : {}),
        ...(followupIso ? { followup_at: followupIso } : {}),
        notes,
      });
    },
    onSuccess: (r) => {
      const leadId = props.mode === 'log' ? props.leadId : props.call.lead;
      if (leadId) {
        const id = String(leadId);
        // The call may have moved the lead and booked a follow-up: refresh
        // everything the lead page shows, not just its call list.
        for (const key of ['lead', 'lead-calls', 'lead-followups', 'lead-activities']) {
          qc.invalidateQueries({ queryKey: [key, id] });
        }
      }
      qc.invalidateQueries({ queryKey: ['calls'] });
      qc.invalidateQueries({ queryKey: ['call-stats'] });
      qc.invalidateQueries({ queryKey: ['leads'] });
      showToast('success', isSet ? 'Outcome saved' : 'Call logged', chosen?.name ?? '');
      props.onSaved?.(r.data as CallLog);
      props.onClose();
    },
    onError: (e: unknown) => showToast('error', 'Could not save the call', getErrorMessage(e, 'Please try again.')),
  });

  const pick = (value: boolean) => { setAnswered(value); setDisposition(''); };

  return (
    <Modal title={isSet ? 'Set call outcome' : 'Log a call'}
           subtitle={isSet ? `${props.call.lead_name ?? ''} ${props.call.phone_number}`.trim() : undefined}
           onClose={props.onClose}>
      <div className="flex flex-col gap-3">
        {!isSet && (
          <Select label="Direction" value={direction} onChange={e => setDirection(e.target.value)}>
            <option value="outbound">Outbound (I called)</option>
            <option value="inbound">Inbound (they called)</option>
          </Select>
        )}

        <div>
          <div className="field-label">Was the call answered? <span style={{ color: 'var(--hot)' }}>*</span></div>
          <div className="flex gap-2">
            {[{ v: true, l: '✓ Answered' }, { v: false, l: '✕ Not answered' }].map(o => (
              <button key={String(o.v)} type="button" onClick={() => pick(o.v)}
                      className={`btn ${answered === o.v ? 'btn-p' : 'btn-g'} flex-1`}
                      aria-pressed={answered === o.v}>
                {o.l}
              </button>
            ))}
          </div>
        </div>

        {answered !== null && (
          <>
            <Select label={answered ? 'Outcome (answered calls)' : 'Outcome (unanswered calls)'} required
                    value={disposition} onChange={e => setDisposition(e.target.value)}
                    hint={chosen ? outcomeEffect(chosen) || undefined : undefined}>
              <option value="">Choose the outcome…</option>
              {options.map(d => <option key={d.id} value={String(d.id)}>{d.name}</option>)}
            </Select>
            {answered && (
              <Input label="Talk time (seconds)" required type="number" min="1" value={duration}
                     onChange={e => setDuration(e.target.value)} placeholder="e.g. 120"
                     error={duration !== '' && durationMissing ? 'Enter how long you spoke' : undefined} />
            )}
            {chosen && !chosen.lead_status.match(/^(not_interested|lost|invalid|converted)$/) && (
              <Input label="Follow-up (optional)" type="datetime-local" value={followupAt}
                     onChange={e => setFollowupAt(e.target.value)}
                     error={followupPast ? 'Pick a time in the future' : undefined}
                     hint={chosen.auto_followup_hours
                       ? `Booked automatically in ${chosen.auto_followup_hours} h — pick a time to set it exactly.`
                       : 'This outcome books no follow-up on its own. Set one here if the lead needs another call.'} />
            )}
          </>
        )}

        <Textarea label="Notes" value={notes} onChange={e => setNotes(e.target.value)} />
      </div>
      <div className="flex gap-3 mt-4">
        <button onClick={props.onClose} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">Cancel</button>
        <button onClick={() => save.mutate()} disabled={!canSave || save.isPending}
                className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black">
          {save.isPending ? 'Saving…' : isSet ? 'Save outcome →' : 'Log call →'}
        </button>
      </div>
    </Modal>
  );
}
