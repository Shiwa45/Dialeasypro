// ============================================================
// DialSathi — DataTable / StatusPill / FilterBar
//
// The same table markup was hand-rolled in HRMSPage, ERPPage and HRMSSettings,
// three times, with three slightly different paddings and none of them
// sortable or paginated. Every module screen now renders through this, so a
// new tab is consistent by construction rather than by copy-paste.
//
// Deliberately NOT generic over a row type parameter beyond `T`: columns carry
// their own render function, which is where the type safety actually matters.
// ============================================================
import { useMemo, useState } from 'react';
import { EmptyState, Pagination, Spinner } from './ui';

/* ---- StatusPill ----------------------------------------------
   One palette for every status string in the app. A status the map
   doesn't know renders neutral rather than throwing or going invisible. */
const TONES: Record<string, string> = {
  // approvals
  pending: 'var(--warm-50)', approved: 'var(--won-50)', rejected: 'var(--lost-50)',
  cancelled: 'var(--surface-2)', reimbursed: 'var(--visit-50)',
  // attendance
  present: 'var(--won-50)', absent: 'var(--lost-50)', half_day: 'var(--warm-50)',
  on_leave: 'var(--visit-50)', leave: 'var(--visit-50)',
  holiday: 'var(--surface-2)', week_off: 'var(--surface-2)',
  // documents
  draft: 'var(--surface-2)', sent: 'var(--visit-50)', accepted: 'var(--won-50)',
  expired: 'var(--warm-50)', converted: 'var(--visit-50)', issued: 'var(--visit-50)',
  partially_paid: 'var(--warm-50)', paid: 'var(--won-50)',
  confirmed: 'var(--won-50)', invoiced: 'var(--visit-50)', finalized: 'var(--visit-50)',
  // recruitment
  open: 'var(--won-50)', on_hold: 'var(--warm-50)', closed: 'var(--surface-2)',
  applied: 'var(--surface-2)', screening: 'var(--warm-50)',
  interview: 'var(--visit-50)', offer: 'var(--brass-50)', hired: 'var(--won-50)',
  scheduled: 'var(--visit-50)', completed: 'var(--won-50)', no_show: 'var(--lost-50)',
  declined: 'var(--lost-50)', revoked: 'var(--lost-50)',
  // generic
  active: 'var(--won-50)', inactive: 'var(--surface-2)',
};

export function StatusPill({ value, label }: { value: string; label?: string }) {
  if (!value) return <span style={{ color: 'var(--text-3)' }}>—</span>;
  return (
    <span className="font-heading font-bold"
          style={{
            background: TONES[value] ?? 'var(--surface-2)',
            border: '1px solid var(--line)',
            padding: '2px 8px', fontSize: '0.68rem', whiteSpace: 'nowrap',
            display: 'inline-block',
          }}>
      {(label ?? value.replace(/_/g, ' ')).toUpperCase()}
    </span>
  );
}

/* ---- Column definition -------------------------------------- */
export interface Column<T> {
  /** Stable key; also the sort key when `sortable` and no `sortValue` given. */
  key: string;
  header: string;
  render: (row: T) => React.ReactNode;
  /** Right-aligns and uses a monospace face — for money and counts. */
  numeric?: boolean;
  sortable?: boolean;
  /** Value to sort on when the rendered cell isn't sortable (JSX, formatted money…). */
  sortValue?: (row: T) => string | number;
  width?: string;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  rows: T[];
  rowKey: (row: T) => string | number;
  isLoading?: boolean;
  onRowClick?: (row: T) => void;
  /** Row-level actions rendered in a trailing column. */
  actions?: (row: T) => React.ReactNode;
  empty?: { icon?: string; title: string; message?: string; action?: { label: string; onClick: () => void } };
  minWidth?: string;
  /** Client-side pagination. Omit for server-paginated lists. */
  pageSize?: number;
  /** Footer row, e.g. column totals. */
  footer?: React.ReactNode;
}

// Matches `.table-brutal thead th` so a DataTable and a hand-rolled table on
// the next screen do not disagree about what a column header looks like.
const HEAD: React.CSSProperties = {
  textAlign: 'left', padding: '10px 12px',
  fontFamily: 'var(--mono)', fontSize: '12px', fontWeight: 700,
  letterSpacing: '0.07em', textTransform: 'uppercase',
  color: 'var(--text-2)', background: 'var(--surface-2)', whiteSpace: 'nowrap',
};
const CELL: React.CSSProperties = { padding: '10px 12px', fontSize: '0.82rem' };
const NUM: React.CSSProperties = { ...CELL, fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', textAlign: 'right' };

export function DataTable<T>({
  columns, rows, rowKey, isLoading, onRowClick, actions, empty,
  minWidth = '680px', pageSize, footer,
}: DataTableProps<T>) {
  const [sort, setSort] = useState<{ key: string; dir: 'asc' | 'desc' } | null>(null);
  const [page, setPage] = useState(1);

  const sorted = useMemo(() => {
    if (!sort) return rows;
    const col = columns.find(c => c.key === sort.key);
    if (!col) return rows;
    const get = col.sortValue ?? ((r: T) => String((r as Record<string, unknown>)[col.key] ?? ''));
    // Copy before sorting — sorting the prop array in place makes React Query's
    // cached data mutate under us, which shows up as a list that reorders
    // itself on unrelated refetches.
    return [...rows].sort((a, b) => {
      const av = get(a), bv = get(b);
      const cmp = typeof av === 'number' && typeof bv === 'number'
        ? av - bv
        : String(av).localeCompare(String(bv), undefined, { numeric: true });
      return sort.dir === 'asc' ? cmp : -cmp;
    });
  }, [rows, sort, columns]);

  const totalPages = pageSize ? Math.max(1, Math.ceil(sorted.length / pageSize)) : 1;
  const visible = pageSize ? sorted.slice((page - 1) * pageSize, page * pageSize) : sorted;

  if (isLoading) return <div className="flex justify-center py-16"><Spinner /></div>;

  if (!rows.length) {
    return empty
      ? <EmptyState icon={empty.icon} title={empty.title} message={empty.message} action={empty.action} />
      : <EmptyState title="Nothing here yet" />;
  }

  const toggleSort = (col: Column<T>) => {
    if (!col.sortable) return;
    setSort(s =>
      s?.key === col.key
        ? { key: col.key, dir: s.dir === 'asc' ? 'desc' : 'asc' }
        : { key: col.key, dir: 'asc' },
    );
    setPage(1);
  };

  return (
    <>
      <div className="card-brutal" style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--line)' }}>
              {columns.map(col => (
                <th key={col.key}
                    onClick={() => toggleSort(col)}
                    style={{
                      ...HEAD,
                      width: col.width,
                      textAlign: col.numeric ? 'right' : 'left',
                      cursor: col.sortable ? 'pointer' : undefined,
                      userSelect: 'none',
                    }}>
                  {col.header.toUpperCase()}
                  {col.sortable && (
                    <span style={{ opacity: sort?.key === col.key ? 1 : 0.25, marginLeft: 4 }}>
                      {sort?.key === col.key && sort.dir === 'desc' ? '▼' : '▲'}
                    </span>
                  )}
                </th>
              ))}
              {actions && <th style={{ ...HEAD, textAlign: 'right' }} />}
            </tr>
          </thead>
          <tbody>
            {visible.map(row => (
              <tr key={rowKey(row)}
                  onClick={onRowClick ? () => onRowClick(row) : undefined}
                  style={{
                    borderBottom: '1px solid var(--line)',
                    cursor: onRowClick ? 'pointer' : undefined,
                  }}>
                {columns.map(col => (
                  <td key={col.key} style={col.numeric ? NUM : CELL}>{col.render(row)}</td>
                ))}
                {actions && (
                  // Actions must not also trigger the row's own click target —
                  // "Delete" that first opens the detail drawer behind the
                  // confirm dialog is a genuinely confusing thing to ship.
                  <td style={{ ...CELL, textAlign: 'right', whiteSpace: 'nowrap' }}
                      onClick={e => e.stopPropagation()}>
                    {actions(row)}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
          {footer && <tfoot>{footer}</tfoot>}
        </table>
      </div>
      {pageSize && <Pagination page={page} totalPages={totalPages} onPageChange={setPage} />}
    </>
  );
}

/* ---- FilterBar ----------------------------------------------
   A single row of controls above a table. Children are whatever the screen
   needs (Select, Input, date range); the bar only owns layout and the
   search box, because every screen wants search in the same place. */
export function FilterBar({
  search, onSearch, searchPlaceholder = 'Search…', children, right,
}: {
  search?: string;
  onSearch?: (v: string) => void;
  searchPlaceholder?: string;
  children?: React.ReactNode;
  right?: React.ReactNode;
}) {
  return (
    <div className="card-brutal flex gap-2 items-end mb-3"
         style={{ padding: '10px 12px', flexWrap: 'wrap' }}>
      {onSearch && (
        <div style={{ flex: 1, minWidth: '180px' }}>
          <input className="input-brutal" value={search ?? ''} placeholder={searchPlaceholder}
                 onChange={e => onSearch(e.target.value)} />
        </div>
      )}
      {children}
      {right && <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>{right}</div>}
    </div>
  );
}

/** Small action button used inside DataTable `actions`. */
export function RowAction({
  label, onClick, danger, positive, disabled,
}: {
  label: string; onClick: () => void;
  /** Destructive — reject, delete, cancel. */
  danger?: boolean;
  /** Confirming — approve, issue, accept. */
  positive?: boolean;
  disabled?: boolean;
}) {
  // A confirming action sat on the same plain white as every neutral one, so
  // Approve and Reject read as a red button next to a blank one. Each of the
  // three intents now carries its own colour.
  const tone = danger
    ? { background: 'var(--lost-50)', color: 'var(--lost)', border: '1px solid var(--lost-50)' }
    : positive
      ? { background: 'var(--won-50)', color: 'var(--won)', border: '1px solid var(--won-50)' }
      : { background: 'var(--surface)', color: 'var(--text-2)', border: '1px solid var(--line-2)' };

  return (
    <button onClick={onClick} disabled={disabled}
            style={{
              ...tone,
              fontFamily: 'var(--sans)', fontSize: '11.5px', fontWeight: 600,
              padding: '4px 10px', borderRadius: 6, marginLeft: 6,
              cursor: disabled ? 'not-allowed' : 'pointer',
              opacity: disabled ? 0.5 : 1,
              transition: 'filter .13s',
            }}
            onMouseEnter={e => { e.currentTarget.style.filter = 'brightness(0.96)'; }}
            onMouseLeave={e => { e.currentTarget.style.filter = 'none'; }}>
      {label}
    </button>
  );
}

/** Primary "+ Add …" button, right-aligned above a table. */
export function AddButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <div className="flex justify-end mb-3">
      <button className="btn-brutal btn-primary px-3 py-2 font-heading font-black"
              style={{ fontSize: '0.8rem' }} onClick={onClick}>
        + {label}
      </button>
    </div>
  );
}
