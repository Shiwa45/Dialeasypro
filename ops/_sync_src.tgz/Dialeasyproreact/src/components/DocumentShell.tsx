// ============================================================
// DialSathi — Printable document shell
//
// Invoices, quotations and payslips are the only things in the product that
// leave it: a customer keeps the invoice, an employee keeps the payslip. All
// three were rendering as ordinary app panels — no letterhead, nothing
// identifying the company, and a Print button that put the sidebar, the modal
// chrome and the toolbar on the paper.
//
// This gives the three a shared letterhead, a shared paper block, and a print
// path that emits the document alone. Company details come from the tenant's
// own record, so a workspace prints as itself rather than as "DialSathi".
// ============================================================
import { useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { authApi } from '../api';

export type CompanyProfile = {
  company_name: string;
  gstin: string;
  billing_address: string;
  city: string;
  state: string;
  pincode: string;
  email: string;
  phone: string;
  logo: string;
  primary_color: string;
};

/** The tenant's billing identity. Cached hard — it changes about as often as
 *  the company moves office, and every document on screen wants it. */
export function useCompany() {
  return useQuery<CompanyProfile>({
    queryKey: ['company-profile'],
    queryFn: () => authApi.company().then(r => r.data as CompanyProfile),
    staleTime: 60 * 60 * 1000,
    retry: false,
  });
}

function initials(name?: string) {
  if (!name) return '—';
  return name.split(' ').filter(Boolean).map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

/* ---- Amount in words ----------------------------------------
   Expected on an Indian tax invoice, and in the Indian system — crore, lakh,
   thousand — not the western one, so Intl cannot do it. */
const ONES = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
  'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
const TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

function under100(n: number): string {
  if (n < 20) return ONES[n];
  return (TENS[Math.floor(n / 10)] + (n % 10 ? ' ' + ONES[n % 10] : '')).trim();
}

function under1000(n: number): string {
  const h = Math.floor(n / 100);
  const rest = n % 100;
  return [h ? ONES[h] + ' Hundred' : '', rest ? under100(rest) : ''].filter(Boolean).join(' ');
}

export function amountInWords(value: string | number): string {
  const amount = Number(value);
  if (!isFinite(amount)) return '';
  const negative = amount < 0;
  const abs = Math.abs(amount);
  const rupees = Math.floor(abs);
  const paise = Math.round((abs - rupees) * 100);

  const groups: Array<[number, string]> = [
    [10000000, 'Crore'], [100000, 'Lakh'], [1000, 'Thousand'],
  ];
  const parts: string[] = [];
  let left = rupees;
  for (const [size, name] of groups) {
    const count = Math.floor(left / size);
    if (count) { parts.push(under1000(count) + ' ' + name); left %= size; }
  }
  if (left) parts.push(under1000(left));

  const whole = parts.length ? parts.join(' ') : 'Zero';
  const unit = rupees === 1 ? 'Rupee' : 'Rupees';
  const words = paise
    ? whole + ' ' + unit + ' and ' + under100(paise) + (paise === 1 ? ' Paisa Only' : ' Paise Only')
    : whole + ' ' + unit + ' Only';
  return negative ? 'Minus ' + words : words;
}

/* ---- Printing -----------------------------------------------
   window.print() prints the whole application: sidebar, modal overlay,
   toolbars and all. Rather than fight that with a wall of @media print
   overrides across every screen, the document node is cloned into an
   off-screen frame carrying the app's own stylesheets, and that frame is
   printed. What lands on the paper is exactly the .doc-paper block. */
export function printDocument(node: HTMLElement | null, title: string) {
  if (!node) return;

  const frame = document.createElement('iframe');
  frame.setAttribute('aria-hidden', 'true');
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;';
  document.body.appendChild(frame);

  const doc = frame.contentDocument;
  if (!doc) { frame.remove(); return; }

  // Carry the app's stylesheets across so the clone keeps the theme — its
  // fonts, its palette, and the .doc-* rules that make it a document.
  const styles = Array.from(
    document.head.querySelectorAll('style, link[rel="stylesheet"]'),
  ).map(n => n.outerHTML).join('\n');

  const escapes: Record<string, string> = { '<': '&lt;', '>': '&gt;', '&': '&amp;' };
  const safeTitle = title.replace(/[<>&]/g, c => escapes[c]);

  // Flattened for paper: the border, radius and padding belong to the
  // on-screen card, not to a page that already has print margins.
  const pageCss = [
    '@page { size: A4; margin: 14mm; }',
    'html,body { background:#fff; margin:0; padding:0; }',
    '.doc-paper { border:0 !important; border-radius:0 !important; box-shadow:none !important;',
    ' padding:0 !important; margin:0 !important; max-width:none !important; }',
    '.doc-noprint { display:none !important; }',
    'tr, .doc-totals, .doc-words, .doc-foot { break-inside: avoid; }',
    'thead { display: table-header-group; }',
  ].join('\n');

  doc.open();
  doc.write(
    '<!doctype html><html><head><meta charset="utf-8">'
    // The frame starts on about:blank, so a relative URL — a tenant logo
    // served from /media, a font the stylesheet reaches for — would resolve
    // against nothing and silently fail to load.
    + '<base href="' + document.baseURI + '">'
    + '<title>' + safeTitle + '</title>'
    + styles
    + '<style>' + pageCss + '</style>'
    + '</head><body>' + node.outerHTML + '</body></html>',
  );
  doc.close();

  const go = () => {
    const win = frame.contentWindow;
    if (!win) { frame.remove(); return; }
    const fire = () => {
      win.focus();
      win.print();
      // Some browsers print asynchronously, so the frame has to outlive the call.
      setTimeout(() => frame.remove(), 1500);
    };
    // Wait for the webfonts the copied stylesheets pull in; printing before
    // they land produces a fallback-serif document.
    if (doc.fonts && doc.fonts.ready) doc.fonts.ready.then(fire).catch(fire);
    else setTimeout(fire, 300);
  };

  if (doc.readyState === 'complete') setTimeout(go, 60);
  else frame.addEventListener('load', () => setTimeout(go, 60), { once: true });
}

/** Ref plus handler for a document that has a Print button. */
export function useDocumentPrint(title: string) {
  const ref = useRef<HTMLDivElement>(null);
  return { ref, print: () => printDocument(ref.current, title) };
}

/* ---- Pieces -------------------------------------------------- */

/** Company letterhead: mark, name, address block, GSTIN, document number. */
export function DocumentLetterhead({
  company, docLabel, docNumber, meta,
}: {
  company?: CompanyProfile;
  /** "Tax Invoice", "Quotation", "Payslip" */
  docLabel: string;
  docNumber?: string;
  /** Right-hand key/value rows — dates, period, status. */
  meta?: Array<[string, string]>;
}) {
  const cityLine = [company?.city, company?.state, company?.pincode]
    .filter(Boolean).join(', ');
  const contact = [company?.phone, company?.email].filter(Boolean).join('  ·  ');

  return (
    <div className="doc-head">
      <div style={{ display: 'flex', gap: 12, minWidth: 0 }}>
        {company?.logo
          ? <img src={company.logo} alt="" className="doc-logo" />
          : <div className="doc-logo doc-logo-fallback">{initials(company?.company_name)}</div>}
        <div style={{ minWidth: 0 }}>
          <div className="doc-company">{company?.company_name || 'Your company'}</div>
          {company?.billing_address && <div className="doc-addr">{company.billing_address}</div>}
          {cityLine && <div className="doc-addr">{cityLine}</div>}
          {contact && <div className="doc-addr">{contact}</div>}
          {company?.gstin && <div className="doc-gstin">GSTIN&nbsp;&nbsp;{company.gstin}</div>}
        </div>
      </div>

      <div style={{ textAlign: 'right', flex: 'none' }}>
        <div className="doc-label">{docLabel}</div>
        {docNumber && <div className="doc-number">{docNumber}</div>}
        {!!meta?.length && (
          <div className="doc-meta">
            {meta.map(([k, v]) => (
              <div key={k}>
                <span className="doc-meta-k">{k}</span>
                <span className="doc-meta-v">{v}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/** A named block of the document — "Bill to", "Employee", "Notes". */
export function DocumentBlock({
  title, children, style,
}: { title: string; children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{ minWidth: 0, ...style }}>
      <div className="doc-block-t">{title}</div>
      {children}
    </div>
  );
}

/** One row of the totals stack. `grand` is the highlighted final figure. */
export function DocumentTotal({
  label, value, variant,
}: { label: string; value: string; variant?: 'grand' | 'due' }) {
  return (
    <div className={variant ? 'doc-total-row ' + variant : 'doc-total-row'}>
      <span>{label}</span><span>{value}</span>
    </div>
  );
}

/** Amount-in-words strip. Skipped when the amount cannot be read. */
export function DocumentWords({ amount }: { amount: string | number }) {
  const words = amountInWords(amount);
  if (!words) return null;
  return (
    <div className="doc-words">
      <b>Amount in words:</b> {words}
    </div>
  );
}

/**
 * The printable area. Give it the ref from useDocumentPrint — the Print
 * button clones exactly this node.
 */
export function DocumentPaper({
  children, innerRef,
}: { children: React.ReactNode; innerRef?: React.Ref<HTMLDivElement> }) {
  return <div className="doc-paper" ref={innerRef}>{children}</div>;
}
