// ============================================================
// DialSathi — Layout (rail + topbar + main)
//
// TeleCRM shell: forest-green rail with grouped navigation and a mint pill on
// the active row, a white topbar carrying search, date, theme switch and the
// notification bell, and the page on a cool-grey ground. Below 900px the rail
// becomes a drawer opened from the topbar.
// ============================================================
import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { authApi, commsApi } from '../api';
import { useInboxLiveRefresh } from '../pages/InboxPage';
import { useFeatures } from '../hooks/useFeatures';
import { AREAS, LockMark, type AreaKey } from './UpgradeGate';
import { useCapabilities } from '../hooks/useCapabilities';
import { useWorkspace } from '../hooks/useWorkspace';
import { MODULE_GROUPS } from '../pages/moduleSections';
import NotificationBell from './NotificationBell';
import BrandMark from './BrandMark';
import { useToast } from './ui';

/* ---- Icons ---------------------------------------------------
   One stroke weight, one 24-box, so the rail reads as a set. */
const I = {
  dashboard: <><rect x="3" y="3" width="7" height="9" rx="1.5" /><rect x="14" y="3" width="7" height="5" rx="1.5" /><rect x="14" y="12" width="7" height="9" rx="1.5" /><rect x="3" y="16" width="7" height="5" rx="1.5" /></>,
  leads: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /></>,
  batches: <><rect x="3" y="4" width="18" height="5" rx="1" /><rect x="3" y="12" width="18" height="5" rx="1" /><path d="M7 20h10" /></>,
  upload: <><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><path d="M17 8l-5-5-5 5" /><path d="M12 3v12" /></>,
  phone: <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z" />,
  queue: <><path d="M3 6h18M3 12h18M3 18h11" /></>,
  agents: <><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></>,
  live: <><circle cx="12" cy="12" r="3" /><path d="M5.6 5.6a9 9 0 0 0 0 12.8M18.4 18.4a9 9 0 0 0 0-12.8" /></>,
  chat: <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2Z" />,
  inbox: <><path d="M22 12h-6l-2 3h-4l-2-3H2" /><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11Z" /></>,
  megaphone: <><path d="m3 11 18-5v12L3 14v-3Z" /><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6" /></>,
  flow: <><rect x="3" y="3" width="6" height="6" rx="1" /><rect x="15" y="15" width="6" height="6" rx="1" /><path d="M6 9v3a3 3 0 0 0 3 3h6" /></>,
  spark: <><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1" /></>,
  people: <><path d="M12 2 2 7l10 5 10-5-10-5Z" /><path d="m2 17 10 5 10-5M2 12l10 5 10-5" /></>,
  hire: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M19 8v6M22 11h-6" /></>,
  rupee: <><path d="M6 3h12M6 8h12M6 13h5a5 5 0 0 0 0-10" /><path d="m6 13 8 8" /></>,
  chart: <><path d="M3 3v18h18" /><path d="m19 9-5 5-4-4-3 3" /></>,
  plug: <><path d="M12 2v6M8 8h8v4a4 4 0 0 1-8 0V8Z" /><path d="M12 16v6" /></>,
  cog: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6h.09A1.65 1.65 0 0 0 10 3.09V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z" /></>,
  power: <><path d="M18.36 6.64a9 9 0 1 1-12.73 0" /><path d="M12 2v10" /></>,
  chevron: <path d="m15 18-6-6 6-6" />,
  caret: <path d="m6 9 6 6 6-6" />,
  bell: <><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.73 21a2 2 0 0 1-3.46 0" /></>,
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></>,
  calendar: <><rect x="3.5" y="5" width="17" height="15" rx="2.5" /><path d="M3.5 10h17M8 3v4M16 3v4" /></>,
  sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>,
  moon: <path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z" />,
  right: <path d="m9 6 6 6-6 6" />,
};

function Ico({ d }: { d: React.ReactNode }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"
         strokeLinecap="round" strokeLinejoin="round">{d}</svg>
  );
}

// Every item is shown whatever the plan. `area` names the paid feature or
// add-on behind it: when the plan does not include it the item carries a lock
// and opens the upgrade screen (see UpgradeGate) instead of disappearing —
// a customer cannot buy what they never see.
type NavChild = { path: string; label: string; cap?: string };

type NavItem = {
  path: string; icon: React.ReactNode; label: string;
  area?: AreaKey;
  /** Capability needed to see this item at all (used by flattened sections). */
  cap?: string;
  /** Sub-sections. Present → the item expands instead of navigating. */
  children?: NavChild[];
  /** A live count shown beside the label. */
  badge?: 'inbox';
};

/** Sections of a module, as sidebar children. Sourced from the same registry
 *  the router reads, so a link here always resolves to a real route. */
function sectionsOf(base: string): NavChild[] {
  const group = MODULE_GROUPS.find(g => g.base === base);
  return (group?.sections ?? []).map(s => ({
    path: `${base}/${s.path}`, label: s.label, cap: s.cap,
  }));
}

const NAV_GROUPS: Array<{ group: string; items: NavItem[] }> = [
  {
    group: 'Main',
    items: [
      { path: '/dashboard',    icon: I.dashboard, label: 'Dashboard' },
      { path: '/leads',        icon: I.leads,     label: 'Leads' },
      { path: '/leads/import', icon: I.upload,    label: 'Import Leads', area: 'leadImport' },
      { path: '/leads/batches', icon: I.batches,  label: 'Lead Batches' },
      { path: '/calls',        icon: I.phone,     label: 'Calls' },
      { path: '/queues',       icon: I.queue,     label: 'Call Queues' },
    ],
  },
  {
    group: 'Team',
    items: [
      { path: '/agents',      icon: I.agents, label: 'Agents' },
      { path: '/live-agents', icon: I.live,   label: 'Live Agents', area: 'liveAgents' },
      // Each agent's logged-in day, live for today.
      { path: '/login-report', icon: I.calendar, label: 'Login Report', area: 'loginReport' },
      // Reports sits under Live Agents: the floor and the numbers behind it
      // are read one after the other.
      { path: '/reports',     icon: I.chart,  label: 'Reports' },
    ],
  },
  {
    group: 'Outreach',
    items: [
      { path: '/inbox',          icon: I.inbox,     label: 'WhatsApp Inbox', badge: 'inbox' },
      { path: '/communications', icon: I.chat,      label: 'Communications' },
      { path: '/campaigns',      icon: I.megaphone, label: 'Campaigns', area: 'campaigns' },
      { path: '/workflows',      icon: I.flow,      label: 'Workflows', area: 'workflows' },
    ],
  },
  {
    group: 'Modules',
    items: [
      { path: '/insights', icon: I.spark,  label: 'AI Call Summary', area: 'insights' },
      { path: '/hrms',     icon: I.people, label: 'HRMS',            area: 'hrms',
        children: sectionsOf('/hrms') },
      { path: '/erp',      icon: I.rupee,  label: 'Sales & Billing', area: 'erp',
        children: sectionsOf('/erp') },
      { path: '/recruitment', icon: I.hire, label: 'Recruitment',   area: 'recruitment',
        children: sectionsOf('/recruitment') },
    ],
  },
  {
    group: 'Setup',
    items: [
      { path: '/integrations', icon: I.plug,  label: 'Integrations' },
      { path: '/settings',     icon: I.cog,   label: 'Settings' },
    ],
  },
];

/* ---- Workspace navs -----------------------------------------
   An agent's sidebar is their own day and nothing else; a recruiter's is
   Recruitment and nothing else. The SERVER decides which workspace someone
   gets (see useWorkspace) — these only describe what each one looks like. */
const AGENT_NAV_GROUPS: Array<{ group: string; items: NavItem[] }> = [
  {
    group: 'My work',
    items: [
      { path: '/dashboard', icon: I.dashboard, label: 'My Performance' },
      { path: '/leads',     icon: I.leads,     label: 'My Leads' },
      { path: '/calls',     icon: I.phone,     label: 'Call History' },
    ],
  },
  {
    group: 'Account',
    items: [
      { path: '/profile', icon: I.agents, label: 'My Profile' },
    ],
  },
];

/** Section path → icon, so a recruiter's flat sidebar is scannable. */
const ATS_ICONS: Record<string, React.ReactNode> = {
  dashboard: I.dashboard, openings: I.hire, pipeline: I.queue,
  candidates: I.leads, interviews: I.calendar, offers: I.chat, settings: I.cog,
};

function recruiterNavGroups(): Array<{ group: string; items: NavItem[] }> {
  // Recruitment is the whole workspace, so its sections sit at the top level
  // rather than under one expandable parent. `cap` travels through as an area
  // check below; `area` keeps the upgrade lock if the module isn't bought.
  return [
    {
      group: 'Recruitment',
      items: sectionsOf('/recruitment').map(c => ({
        path: c.path,
        label: c.label,
        icon: ATS_ICONS[c.path.split('/').pop() ?? ''] ?? I.hire,
        area: 'recruitment' as AreaKey,
        cap: c.cap,
      })),
    },
    {
      group: 'Account',
      items: [{ path: '/profile', icon: I.agents, label: 'My Profile' }],
    },
  ];
}

function initials(name?: string) {
  if (!name) return 'A';
  return name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
}

/* ---- Theme ---------------------------------------------------
   index.html stamps data-theme on <html> before first paint; this keeps the
   toggle and that attribute in step and remembers the choice. */
function useTheme() {
  const [theme, setTheme] = useState<'light' | 'dark'>(() =>
    document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light');
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    try { localStorage.setItem('de-theme', theme); } catch {}
  }, [theme]);
  return { theme, toggle: () => setTheme(t => (t === 'dark' ? 'light' : 'dark')) };
}

/** Soft light-green curves behind the rail. Decorative placeholder art. */
function RailArt() {
  return (
    <svg className="rail-art" viewBox="0 0 290 900" preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <linearGradient id="railWv1" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#3fd08f" stopOpacity="0" />
          <stop offset="1" stopColor="#3fd08f" stopOpacity=".26" />
        </linearGradient>
        <linearGradient id="railWv2" x1="1" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7de8b3" stopOpacity=".2" />
          <stop offset="1" stopColor="#7de8b3" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d="M0 40 C90 10 190 60 290 0 L290 0 L0 0Z" fill="url(#railWv2)" />
      <path d="M-20 380 C80 300 200 320 310 230" fill="none" stroke="#7de8b3" strokeOpacity=".16" strokeWidth="2" />
      <path d="M-20 420 C90 340 210 350 310 270 L310 330 C210 400 100 400 -20 470Z" fill="url(#railWv1)" />
      <path d="M-20 720 C80 640 200 660 310 560 L310 900 L-20 900Z" fill="url(#railWv1)" />
      <path d="M-20 760 C90 690 200 700 310 610" fill="none" stroke="#7de8b3" strokeOpacity=".2" strokeWidth="2" />
    </svg>
  );
}

function Rail({ collapsed, onToggle, onNavigate }: {
  collapsed: boolean; onToggle: () => void; onNavigate: () => void;
}) {
  const location = useLocation();
  const { agent, logout } = useAuthStore();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { isLocked } = useFeatures();
  const { can } = useCapabilities();
  const { workspace, home } = useWorkspace();

  const groups = workspace === 'agent'
    ? AGENT_NAV_GROUPS
    : workspace === 'recruiter'
      ? recruiterNavGroups()
      : NAV_GROUPS;

  // Which module submenus are open. Seeded from the current URL so a deep link
  // to /hrms/payslips arrives with HRMS already expanded and the row visible;
  // otherwise the user lands on a page whose nav entry appears unselected.
  const [open, setOpen] = useState<string[]>([]);
  useEffect(() => {
    const current = MODULE_GROUPS.find(g => location.pathname.startsWith(g.base));
    if (current) setOpen(prev => prev.includes(current.base) ? prev : [...prev, current.base]);
  }, [location.pathname]);

  const toggle = (base: string) =>
    setOpen(prev => prev.includes(base) ? prev.filter(b => b !== base) : [...prev, base]);

  // Conversations waiting for a reply, for the WhatsApp Inbox badge. Only the
  // admin console has the inbox; agents reply from the mobile app.
  useInboxLiveRefresh();
  const inboxSummary = useQuery({
    queryKey: ['wa-inbox-summary'],
    queryFn: () => commsApi.inboxSummary().then(r => r.data),
    enabled: workspace === 'full',
    // The socket refreshes it the moment a message arrives; this is the
    // fallback for when the socket is down.
    refetchInterval: 60_000,
    retry: false,
  });
  const inboxUnread = inboxSummary.data?.unread_conversations ?? 0;


  const handleLogout = async () => {
    try {
      const refresh = localStorage.getItem('refresh_token');
      if (refresh) await authApi.logout(refresh);
    } catch {}
    logout();
    navigate('/login');
    showToast('info', 'Signed out', 'See you next time!');
  };

  return (
    <aside className="rail" style={{
      width: collapsed ? 76 : 270,
      minWidth: collapsed ? 76 : 270,
      transition: 'width .18s ease, min-width .18s ease',
    }}>
      <RailArt />

      <div className="brand" style={collapsed ? { flexDirection: 'column', padding: '16px 0 10px', gap: 6 } : undefined}>
        <Link to={home} className="brand-link" onClick={onNavigate} aria-label="DialSathi TeleCRM home">
          <BrandMark />
          {!collapsed && (
            <div>
              <div className="brand-name">Dial<b>Sathi</b></div>
              <div className="brand-sub">TeleCRM</div>
            </div>
          )}
        </Link>
        <button type="button" className="rail-toggle" onClick={onToggle}
                aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}>
          <Ico d={I.menu} />
        </button>
      </div>

      <nav className="nav" style={collapsed ? { padding: '4px 10px 20px' } : undefined}>
        {groups.map(({ group, items }) => (
          <div key={group}>
            {!collapsed && <div className="nav-group">{group}</div>}
            {collapsed && <div style={{ height: 10 }} />}
            {items.filter(item => !item.cap || can(item.cap)).map(item => {
              // Exact match for /leads so /leads/import does not light both.
              const active = item.path === '/leads'
                ? location.pathname === '/leads' || /^\/leads\/\d+/.test(location.pathname)
                : location.pathname.startsWith(item.path);

              // Not in the plan: shown with a lock, and it opens the upgrade
              // screen rather than a submenu of sections nobody can use.
              const locked = item.area ? isLocked(AREAS[item.area].gate) : false;

              // Sections the user may actually open. A module whose every
              // section is gated away still shows its own row, which links to
              // the redirect that sorts out where they should land.
              const children = locked ? [] : (item.children ?? []).filter(c => !c.cap || can(c.cap));

              // Collapsed rail has no room for a tree; the parent behaves as a
              // plain link and the redirect picks the section.
              if (!children.length || collapsed) {
                const hint = locked ? `${item.label} — upgrade to unlock` : item.label;
                return (
                  <Link key={item.path} to={item.path} onClick={onNavigate}>
                    <div className={`nav-item ${active ? 'on' : ''} ${locked ? 'locked' : ''} ${collapsed ? 'nav-collapsed' : ''}`}
                         style={{ justifyContent: collapsed ? 'center' : undefined, padding: collapsed ? 0 : undefined }}
                         title={collapsed || locked ? hint : undefined}>
                      <Ico d={item.icon} />
                      {!collapsed && <span>{item.label}</span>}
                      {item.badge === 'inbox' && inboxUnread > 0 && (
                        <span className="nav-badge" aria-label={`${inboxUnread} unread conversations`}>
                          {inboxUnread > 99 ? '99+' : inboxUnread}
                        </span>
                      )}
                      {locked && <LockMark title={hint} />}
                    </div>
                  </Link>
                );
              }

              const expanded = open.includes(item.path);
              return (
                <div key={item.path}>
                  <button
                    type="button"
                    onClick={() => toggle(item.path)}
                    aria-expanded={expanded}
                    className={`nav-item nav-parent ${active ? 'on' : ''}`}
                  >
                    <Ico d={item.icon} />
                    <span>{item.label}</span>
                    <span className={`nav-caret ${expanded ? 'open' : ''}`}>
                      <Ico d={I.caret} />
                    </span>
                  </button>

                  {expanded && (
                    <div className="nav-sub">
                      {children.map(child => (
                        <Link key={child.path} to={child.path} onClick={onNavigate}>
                          <div className={`nav-subitem ${location.pathname === child.path ? 'on' : ''}`}>
                            {child.label}
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="rail-foot">
        {agent && (
          <button type="button" className="me"
                  style={{ justifyContent: collapsed ? 'center' : undefined, padding: collapsed ? 8 : undefined, color: 'inherit', textAlign: 'left' }}
                  onClick={() => { navigate('/profile'); onNavigate(); }}
                  title={collapsed ? agent.name : undefined}>
            <div className="av">{initials(agent.name)}</div>
            {!collapsed && (
              <>
                <div style={{ minWidth: 0 }}>
                  <div className="me-n" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{agent.name}</div>
                  <div className="me-r">{agent.role}</div>
                </div>
                <span className="me-chev"><Ico d={I.right} /></span>
              </>
            )}
          </button>
        )}
        <button type="button" onClick={handleLogout} className="signout" title="Sign out">
          <Ico d={I.power} />
          {!collapsed && <span>Sign out</span>}
        </button>
      </div>
    </aside>
  );
}

function Topbar({ onMenu, theme, onTheme }: {
  onMenu: () => void; theme: 'light' | 'dark'; onTheme: () => void;
}) {
  const { agent } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [q, setQ] = useState('');
  const { workspace } = useWorkspace();

  // The box mirrors the Leads list's own ?search=. It kept whatever was last
  // typed — after "Clear filters", and on every other page — so it showed a
  // search that was no longer applied anywhere.
  useEffect(() => {
    const onLeads = location.pathname === '/leads';
    setQ(onLeads ? new URLSearchParams(location.search).get('search') ?? '' : '');
  }, [location.pathname, location.search]);

  // Search hands off to the Leads list, which already filters on ?search=
  // across name, phone and email.
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const term = q.trim();
    navigate(term ? `/leads?search=${encodeURIComponent(term)}` : '/leads');
  };

  const today = new Date().toLocaleDateString('en-IN', {
    weekday: 'short', day: 'numeric', month: 'long', year: 'numeric',
  });

  return (
    <header className="top">
      <button type="button" className="icon-btn top-menu" onClick={onMenu} aria-label="Open navigation">
        <Ico d={I.menu} />
      </button>
      {/* Lead search. A recruiter has no leads, so the box would only ever
          bounce them off the route guard — it is not offered. An agent's
          search runs against their own leads (the API scopes it). */}
      {workspace !== 'recruiter' ? (
        <form className="top-search" onSubmit={submit} role="search">
          <Ico d={I.search} />
          <input id="global-search" type="search" value={q} onChange={e => setQ(e.target.value)}
                 placeholder={workspace === 'agent'
                   ? 'Search my leads by name or phone…'
                   : 'Search leads, phone, name, source…'}
                 aria-label="Search leads" />
        </form>
      ) : <div style={{ flex: 1 }} />}
      <div className="top-r">
        <div className="top-date"><Ico d={I.calendar} /><span>{today}</span></div>
        <button type="button" className="icon-btn" onClick={onTheme}
                aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
                title={theme === 'dark' ? 'Light mode' : 'Dark mode'}>
          <Ico d={theme === 'dark' ? I.sun : I.moon} />
        </button>
        <NotificationBell />
        <button type="button" className="top-user" onClick={() => navigate('/profile')} title={agent?.name}
                aria-label="My profile">
          <span className="av">{initials(agent?.name)}</span>
          <Ico d={I.caret} />
        </button>
      </div>
    </header>
  );
}

// Section titles for the module sub-routes, so the browser tab names the
// screen rather than the module. Built from the same registry as the routes.
const SECTION_TITLES: Record<string, string> = Object.fromEntries(
  MODULE_GROUPS.flatMap(g =>
    g.sections.map(s => [`${g.base}/${s.path}`, `${g.label} · ${s.label}`]),
  ),
);

const PAGE_TITLES: Record<string, string> = {
  ...SECTION_TITLES,
  '/dashboard': 'Dashboard', '/leads/import': 'Import Leads',
  '/leads/batches': 'Lead Batches', '/leads': 'Leads',
  '/calls': 'Calls', '/queues': 'Call Queues',
  '/agents': 'Agents', '/live-agents': 'Live Agents', '/login-report': 'Login Report',
  '/communications': 'Communications', '/campaigns': 'Campaigns', '/workflows': 'Workflows',
  '/insights': 'AI Call Summary', '/hrms': 'HRMS', '/erp': 'Sales & Billing',
  '/recruitment': 'Recruitment',
  '/reports': 'Reports', '/integrations': 'Integrations', '/settings': 'Settings',
  '/profile': 'My Profile',
};

const AGENT_PAGE_TITLES: Record<string, string> = {
  '/dashboard': 'My Performance', '/leads': 'My Leads',
  '/calls': 'Call History', '/profile': 'My Profile',
};

export function Layout({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { theme, toggle } = useTheme();
  const location = useLocation();
  const { workspace } = useWorkspace();
  // Longest prefix wins, so /leads/import is not reported as "Leads". An
  // agent's tab names match their sidebar ("My Leads", not "Leads").
  const titles = workspace === 'agent' ? { ...PAGE_TITLES, ...AGENT_PAGE_TITLES } : PAGE_TITLES;
  const title = Object.entries(titles)
    .filter(([p]) => location.pathname.startsWith(p))
    .sort((a, b) => b[0].length - a[0].length)[0]?.[1] ?? 'DialSathi';

  useEffect(() => { document.title = `${title} · DialSathi TeleCRM`; }, [title]);

  return (
    <div className={`shell ${mobileOpen ? 'nav-open' : ''}`}>
      <Rail collapsed={collapsed} onToggle={() => setCollapsed(c => !c)}
            onNavigate={() => setMobileOpen(false)} />
      <div className="shell-scrim" onClick={() => setMobileOpen(false)} />
      <div className="shell-main">
        <Topbar onMenu={() => setMobileOpen(true)} theme={theme} onTheme={toggle} />
        <main className="shell-page">
          {children}
        </main>
      </div>
    </div>
  );
}
