// ============================================================
// DialSathi — Module section page shell
//
// Wraps one section of HRMS / Sales & Billing / Recruitment with its own page
// header, and enforces the section's capability at the ROUTE rather than only
// hiding it in the nav. Hiding a nav item is a courtesy; a typed or bookmarked
// URL has to be refused too, or the gate is decorative.
//
// A refused section redirects to the first one the user can actually open,
// rather than showing "no access" — someone who lands on /hrms/payslips without
// payroll rights still has attendance and leave to do.
// ============================================================
import { Navigate } from 'react-router-dom';
import { SectionHeader } from './ui';
import { useCapabilities } from '../hooks/useCapabilities';
import type { ModuleSection } from '../pages/moduleSections';

export function firstAllowed(sections: ModuleSection[], can: (c: string) => boolean) {
  return sections.find(s => !s.cap || can(s.cap));
}

export default function ModuleSectionPage({
  section, siblings, base,
}: {
  section: ModuleSection;
  siblings: ModuleSection[];
  base: string;
}) {
  const { can } = useCapabilities();

  if (section.cap && !can(section.cap)) {
    const fallback = firstAllowed(siblings, can);
    // Every section gated away means the module is effectively off for this
    // user; the dashboard is the safe landing rather than a redirect loop.
    return <Navigate to={fallback ? `${base}/${fallback.path}` : '/dashboard'} replace />;
  }

  return (
    <div style={{ padding: 20 }}>
      <SectionHeader title={section.title} sub={section.sub} />
      {section.element}
    </div>
  );
}

/** Redirects a bare module root (/hrms) to the first section the user may open. */
export function ModuleIndexRedirect({ sections, base }: { sections: ModuleSection[]; base: string }) {
  const { can } = useCapabilities();
  const target = firstAllowed(sections, can);
  return <Navigate to={target ? `${base}/${target.path}` : '/dashboard'} replace />;
}
