// ============================================================
// DialSathi — Plan expired / account suspended
//
// When the platform owner suspends a company (or its plan or trial runs out)
// every API call answers 403 { error: "plan_expired" | "account_suspended" }.
// Before this, the web app kept running on whatever it had cached and showed
// scattered "Request failed" toasts. Now the first such answer replaces the
// whole app with one clear screen and a way to sign out.
// ============================================================
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { onAccountBlocked, type AccountBlocked } from '../api/client';
import { useAuthStore } from '../store/authStore';

export default function PlanExpiredGate() {
  const [blocked, setBlocked] = useState<AccountBlocked | null>(null);
  const logout = useAuthStore((s) => s.logout);
  const navigate = useNavigate();

  useEffect(() => {
    const handler = (e: Event) => setBlocked((prev) => prev ?? (e as CustomEvent<AccountBlocked>).detail);
    onAccountBlocked.addEventListener('blocked', handler);
    return () => onAccountBlocked.removeEventListener('blocked', handler);
  }, []);

  if (!blocked) return null;

  const signOut = () => {
    logout();
    setBlocked(null);
    navigate('/login', { replace: true });
  };

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="plan-expired-title"
      style={{
        position: 'fixed', inset: 0, zIndex: 10000, background: 'var(--paper)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16, overflowY: 'auto',
      }}
    >
      <div className="upgrade-card">
        <div className="upgrade-badge" aria-hidden="true">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="11" width="18" height="11" rx="2" />
            <path d="M7 11V7a5 5 0 0 1 10 0v4" />
          </svg>
        </div>
        <div className="upgrade-eyebrow">
          {blocked.error === 'account_suspended' ? 'Account suspended' : 'Plan expired'}
        </div>
        <h1 id="plan-expired-title" className="upgrade-title">Your plan has expired</h1>
        <p className="upgrade-lead">
          {blocked.message || 'Your plan has expired. Please contact support to renew your account.'}
        </p>
        <p className="upgrade-lead" style={{ fontSize: 13 }}>
          Your data is kept safe. Everything comes back as soon as the account is renewed.
        </p>
        <button className="btn btn-p" onClick={signOut}>Sign out</button>
      </div>
    </div>
  );
}
