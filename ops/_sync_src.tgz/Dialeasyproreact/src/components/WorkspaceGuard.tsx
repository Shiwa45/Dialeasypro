// ============================================================
// WorkspaceGuard — keeps each person inside their workspace.
//
// An agent who types /settings, or follows an old bookmark to /reports, lands
// back on their own dashboard instead of a screen whose every request the API
// would refuse. Same for a recruiter outside /recruitment.
//
// Also signs out a session that was ALREADY open when access went away — an
// admin turned agent web sign-in off, the plan no longer includes it, or the
// Recruitment module was removed under a recruiter. Login refuses new ones;
// this catches the open ones on their next boot, with the server's reason.
// ============================================================
import { useEffect } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useWorkspace } from '../hooks/useWorkspace';
import { useAuthStore } from '../store/authStore';
import { useToast } from './ui';

export function WorkspaceGuard({ children }: { children: React.ReactNode }) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { logout } = useAuthStore();
  const { isPathAllowed, home, webAccessAllowed, webAccessMessage } = useWorkspace();

  useEffect(() => {
    if (webAccessAllowed) return;
    logout(); // also clears every cached query — see authStore
    showToast('info', 'Signed out',
      webAccessMessage || 'Web access is not available for your account. Please use the mobile app.');
    navigate('/login', { replace: true });
  }, [webAccessAllowed, webAccessMessage, logout, navigate, showToast]);

  if (!webAccessAllowed) return null;
  if (!isPathAllowed(pathname)) return <Navigate to={home} replace />;
  return <>{children}</>;
}
