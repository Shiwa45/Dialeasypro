// ============================================================
// DialSathi — Shared UI Components
// ============================================================
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { localISODate } from '../utils/fmt';

// ---- Modal ------------------------------------------------
//
// Rendered into <body> through a portal, not where it is written. The overlay
// is `position: fixed`, but fixed is relative to the nearest ancestor with a
// transform, filter or animation — and the dashboard has those. The New Lead
// form opened there sat inside the content column, below the header, scrolling
// with the page: it looked like a form on the page, not a dialog over it.
function OnTop({ children }: { children: React.ReactNode }) {
  return typeof document === 'undefined' ? <>{children}</> : createPortal(children, document.body);
}

interface ModalProps {
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: React.ReactNode;
  maxWidth?: string;
}
export function Modal({ title, subtitle, onClose, children, maxWidth = '540px' }: ModalProps) {
  useEffect(() => {
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', esc);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', esc); document.body.style.overflow = ''; };
  }, [onClose]);

  return (
    <OnTop>
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal-box" style={{ maxWidth, width: '100%' }}>
        {/* Was a dark ink slab with brass text — the one surface in the app
            that still looked like the old theme, and it fronts every form. */}
        <div style={{
          display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
          gap: 14, padding: '16px 20px 14px', borderBottom: '1px solid var(--line)',
        }}>
          <div style={{ minWidth: 0 }}>
            <h3 style={{
              fontFamily: 'var(--disp)', fontWeight: 800, fontSize: '1.15rem',
              letterSpacing: '-0.3px', color: 'var(--text)', margin: 0,
            }}>{title}</h3>
            {subtitle && (
              <p style={{ color: 'var(--text-2)', fontSize: '0.8rem', marginTop: 4 }}>{subtitle}</p>
            )}
          </div>
          <button onClick={onClose} aria-label="Close" className="icon-btn"
                  style={{ flex: 'none', width: 30, height: 30 }}>
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
                 strokeWidth="2" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>
        <div style={{ padding: 20 }}>{children}</div>
      </div>
    </div>
    </OnTop>
  );
}

// ---- Toast System -----------------------------------------
export type ToastType = 'success' | 'error' | 'warning' | 'info';

interface ToastItem {
  id: string;
  type: ToastType;
  title: string;
  message: string;
}

interface ToastCtx {
  showToast: (type: ToastType, title: string, message: string) => void;
}

export const ToastContext = React.createContext<ToastCtx>({ showToast: () => {} });

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const showToast = useCallback((type: ToastType, title: string, message: string) => {
    const id = `t_${Date.now()}_${Math.random()}`;
    setToasts((p) => [...p, { id, type, title, message }]);
    setTimeout(() => setToasts((p) => p.filter((t) => t.id !== id)), 4000);
  }, []);

  const colors: Record<ToastType, { bar: string; icon: string }> = {
    success: { bar: 'var(--won)', icon: '✓' },
    error:   { bar: 'var(--hot)', icon: '✕' },
    warning: { bar: 'var(--warm)', icon: '⚠' },
    info:    { bar: 'var(--visit)', icon: 'ℹ' },
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="toast-container">
        {toasts.map((t) => (
          <div key={t.id} className="toast">
            <div style={{ height: '4px', background: colors[t.type].bar }} />
            <div className="flex items-start gap-3 p-3">
              <span className="font-heading font-black text-sm" style={{ color: colors[t.type].bar }}>
                {colors[t.type].icon}
              </span>
              <div className="flex-1 min-w-0">
                <div className="font-heading font-black" style={{ fontSize: '0.82rem' }}>{t.title}</div>
                <div className="font-medium" style={{ fontSize: '0.75rem', color: 'var(--text-2)', marginTop: '2px' }}>{t.message}</div>
              </div>
              <button onClick={() => setToasts((p) => p.filter((x) => x.id !== t.id))}
                      style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-3)', fontSize: '0.85rem' }}>✕</button>
            </div>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  return React.useContext(ToastContext);
}

// ---- Status Badge -----------------------------------------
// Chip class per status. Each colour in the theme means one thing, so a
// status maps to the colour of its outcome rather than to a decorative hue.
const STATUS_COLORS: Record<string, string> = {
  new: 'c-brand', attempted: 'c-brand', contacted: 'c-brand',
  interested: 'c-won', follow_up: 'c-visit',
  negotiation: 'c-warm',
  converted: 'c-won', active: 'c-won',
  lost: 'c-lost', not_interested: 'c-lost', duplicate: 'c-mute', invalid: 'c-mute',
  inactive: 'c-mute', trial: 'c-brass',
  pending: 'c-warm', approved: 'c-won',
  rejected: 'c-lost',
  scheduled: 'c-brass', running: 'c-won', paused: 'c-warm',
  completed: 'c-won', failed: 'c-lost', cancelled: 'c-mute', draft: 'c-mute',
};

export function StatusBadge({ status, label }: { status: string; label?: string }) {
  const cls = STATUS_COLORS[status] ?? 'c-mute';
  return (
    <span className={`chip ${cls}`}>
      <i className="pip" />
      {label ?? status.replace(/_/g, ' ')}
    </span>
  );
}

// ---- Priority Badge ----------------------------------------
// The API's LeadPriority is hot / warm / cold and nothing else. This map used
// to read hot/high/medium/low — a scale that exists nowhere in the backend —
// so a real 'warm' or 'cold' lead fell through to an unstyled badge. The old
// keys are kept as aliases only so historic rows still render.
const PRIORITY_CLASS: Record<string, string> = {
  hot: 'c-hot',
  warm: 'c-warm',
  cold: 'c-cold',
  high: 'c-hot',    // legacy
  medium: 'c-warm', // legacy
  low: 'c-cold',    // legacy
};
export function PriorityBadge({ priority }: { priority: string }) {
  const key = (priority || '').toLowerCase();
  return (
    <span className={`chip ${PRIORITY_CLASS[key] ?? 'c-mute'}`}>
      <i className="pip" />
      {key.toUpperCase()}
    </span>
  );
}

// ---- Pagination --------------------------------------------
interface PaginationProps {
  page: number;
  totalPages: number;
  onPageChange: (p: number) => void;
}
export function Pagination({ page, totalPages, onPageChange }: PaginationProps) {
  if (totalPages <= 1) return null;
  const pages = Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
    if (totalPages <= 7) return i + 1;
    if (page <= 4) return i + 1 <= 5 ? i + 1 : i === 5 ? -1 : totalPages;
    if (page >= totalPages - 3) return i === 0 ? 1 : i === 1 ? -1 : totalPages - 5 + i;
    return i === 0 ? 1 : i === 1 ? -1 : i === 5 ? -2 : i === 6 ? totalPages : page - 3 + i;
  });
  return (
    <div className="flex items-center gap-1 justify-end mt-4">
      <button onClick={() => onPageChange(page - 1)} disabled={page === 1}
              className="btn-brutal btn-secondary px-3 py-1.5 font-heading font-bold text-xs" style={{ fontSize: '0.75rem' }}>← Prev</button>
      {pages.map((p, i) =>
        p < 0 ? <span key={`e${i}`} className="px-2 font-heading font-bold text-xs">…</span> :
        <button key={p} onClick={() => onPageChange(p)}
                className="btn-brutal px-3 py-1.5 font-heading font-bold"
                style={{ fontSize: '0.75rem', background: p === page ? 'var(--brass-50)' : 'var(--surface)', boxShadow: p === page ? '3px 3px 0 var(--text)' : '2px 2px 0 var(--text)' }}>
          {p}
        </button>
      )}
      <button onClick={() => onPageChange(page + 1)} disabled={page === totalPages}
              className="btn-brutal btn-secondary px-3 py-1.5 font-heading font-bold text-xs" style={{ fontSize: '0.75rem' }}>Next →</button>
    </div>
  );
}

// ---- Loading Spinner ---------------------------------------
export function Spinner({ size = 40 }: { size?: number }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px' }}>
      <div style={{
        width: size, height: size,
        border: '1px solid var(--line)',
        borderTop: '3px solid var(--brass-50)',
        borderRadius: '50%',
        animation: 'spin 0.7s linear infinite',
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

// ---- Empty State -------------------------------------------
export function EmptyState({ icon = '○', title, message, action }: {
  icon?: string; title: string; message?: string;
  action?: { label: string; onClick: () => void };
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="font-heading font-black" style={{ fontSize: '3rem', marginBottom: '16px', opacity: 0.3 }}>{icon}</div>
      <div className="font-heading font-black" style={{ fontSize: '1.1rem', marginBottom: '6px' }}>{title}</div>
      {message && <p className="font-medium" style={{ fontSize: '0.82rem', color: 'var(--text-2)', maxWidth: '300px', marginBottom: '20px' }}>{message}</p>}
      {action && (
        <button onClick={action.onClick}
                className="btn-brutal btn-primary px-5 py-2.5 font-heading font-black"
                style={{ fontSize: '0.85rem' }}>
          {action.label}
        </button>
      )}
    </div>
  );
}

// ---- Confirm Dialog ----------------------------------------
export function ConfirmDialog({ title, message, confirmLabel = 'Confirm', danger = false, onConfirm, onCancel }: {
  title: string; message: string; confirmLabel?: string;
  danger?: boolean; onConfirm: () => void; onCancel: () => void;
}) {
  return (
    <OnTop>
    <div className="modal-overlay">
      <div className="modal-box" style={{ maxWidth: '400px' }}>
        <div style={{ padding: '18px 20px 14px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 10 }}>
          {danger && <span style={{ width: 10, height: 10, borderRadius: '50%', background: 'var(--hot)', flex: 'none' }} />}
          <h3 style={{ color: 'var(--text)', fontSize: '1.05rem', fontWeight: 800, letterSpacing: '-0.01em' }}>{title}</h3>
        </div>
        <div className="p-5">
          <p className="font-medium" style={{ fontSize: '0.875rem', lineHeight: 1.6, marginBottom: '20px' }}>{message}</p>
          <div className="flex gap-3">
            <button onClick={onCancel} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black" style={{ fontSize: '0.85rem' }}>Cancel</button>
            <button onClick={onConfirm}
                    className={`btn-brutal flex-1 py-2.5 font-heading font-black ${danger ? 'btn-danger' : 'btn-primary'}`}
                    style={{ fontSize: '0.85rem' }}>
              {confirmLabel}
            </button>
          </div>
        </div>
      </div>
    </div>
    </OnTop>
  );
}

// ---- Input -----------------------------------------------
// ---- Form fields --------------------------------------------
//
// One label treatment for every field in the app. The previous version set a
// heavy uppercase Archivo bold label and left the control at the browser's
// default width, so a field in a modal rendered as a short stub floating in a
// wide dialog — the main reason forms looked unfinished.
//
// The label is now the theme's mono caption (same as .plate-s and the login
// labels), the control fills its column, and `required` is a red mark rather
// than an asterisk glued to the text. `hint` and `error` are supported because
// nearly every form was hand-rolling those underneath the field anyway.

type FieldShellProps = {
  label?: string;
  required?: boolean;
  hint?: string;
  error?: string;
  htmlFor?: string;
  children: React.ReactNode;
};

function FieldShell({ label, required, hint, error, htmlFor, children }: FieldShellProps) {
  return (
    <div style={{ minWidth: 0 }}>
      {label && (
        <label htmlFor={htmlFor} className="field-label">
          {label}
          {required && <span style={{ color: 'var(--hot)', marginLeft: 3 }}>*</span>}
        </label>
      )}
      {children}
      {(error || hint) && (
        <div style={{
          fontSize: 11.5, marginTop: 5,
          color: error ? 'var(--hot)' : 'var(--text-3)',
        }}>
          {error || hint}
        </div>
      )}
    </div>
  );
}

export function Input({
  label, required, hint, error, ...props
}: React.InputHTMLAttributes<HTMLInputElement> & {
  label?: string; required?: boolean; hint?: string; error?: string;
}) {
  return (
    <FieldShell label={label} required={required} hint={hint} error={error} htmlFor={props.id}>
      <input
        className="input-brutal"
        {...props}
        style={{ width: '100%', ...(error ? { borderColor: 'var(--hot)' } : null), ...props.style }}
      />
    </FieldShell>
  );
}

export function Select({
  label, required, hint, error, children, ...props
}: React.SelectHTMLAttributes<HTMLSelectElement> & {
  label?: string; required?: boolean; hint?: string; error?: string; children: React.ReactNode;
}) {
  return (
    <FieldShell label={label} required={required} hint={hint} error={error} htmlFor={props.id}>
      {/* The native arrow is replaced by a caret drawn in CSS, so a select
          matches the inputs beside it instead of showing the OS widget. */}
      <div style={{ position: 'relative' }}>
        <select
          className="input-brutal select-field"
          {...props}
          style={{ width: '100%', cursor: 'pointer', ...(error ? { borderColor: 'var(--hot)' } : null), ...props.style }}
        >
          {children}
        </select>
        <span className="select-caret" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
               strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6" /></svg>
        </span>
      </div>
    </FieldShell>
  );
}

export function Textarea({
  label, required, hint, error, ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & {
  label?: string; required?: boolean; hint?: string; error?: string;
}) {
  return (
    <FieldShell label={label} required={required} hint={hint} error={error} htmlFor={props.id}>
      <textarea
        className="input-brutal"
        rows={props.rows ?? 3}
        style={{ width: '100%', resize: 'vertical', ...(error ? { borderColor: 'var(--hot)' } : null), ...props.style }}
        {...props}
      />
    </FieldShell>
  );
}





// ---- Stat Card ---------------------------------------------
type StatTone = 'yellow' | 'green' | 'blue' | 'red' | 'purple' | 'teal';

/*
 * On-palette tones.
 *
 * These were Tailwind defaults — a violet #ede9fe, a teal #ccfbf1, a navy
 * #1e3a8a — dropped straight onto a page whose palette is drafting paper,
 * survey-ink green and brass. Five of these tiles in a row read as stickers
 * from another product, and every dashboard in the app uses them.
 *
 * The tint is now the theme's own -50 step for each hue, the figure stays in
 * the normal ink so the number is legible rather than coloured, and the label
 * and icon carry the hue. `blue`, `purple` and `teal` are kept as names
 * because screens across HRMS and ERP ask for them; they now resolve to the
 * theme's visit, brass and cold.
 */
const STAT_TONES: Record<StatTone, {
  background: string;
  value: string;
  label: string;
  sub: string;
  icon: string;
}> = {
  yellow: { background: 'var(--brass-50)', value: 'var(--text)', label: 'var(--brass-ink)', sub: 'var(--text-2)', icon: 'var(--brass)' },
  green:  { background: 'var(--won-50)',   value: 'var(--text)', label: 'var(--won)', sub: 'var(--text-2)', icon: 'var(--won)' },
  blue:   { background: 'var(--visit-50)', value: 'var(--text)', label: 'var(--visit)', sub: 'var(--text-2)', icon: 'var(--visit)' },
  red:    { background: 'var(--hot-50)',   value: 'var(--text)', label: 'var(--hot)', sub: 'var(--text-2)', icon: 'var(--hot)' },
  purple: { background: 'var(--brass-50)', value: 'var(--text)', label: 'var(--brass-ink)', sub: 'var(--text-2)', icon: 'var(--brass)' },
  teal:   { background: 'var(--cold-50)',  value: 'var(--text)', label: 'var(--cold)', sub: 'var(--text-2)', icon: 'var(--cold)' },
};

export function StatCard({ label, value, sub, accent = false, icon, tone }: {
  label: string; value: string | number; sub?: string; accent?: boolean; icon?: string; tone?: StatTone;
}) {
  const colors = tone ? STAT_TONES[tone] : undefined;

  return (
    <div className="stat-card" style={{ background: colors?.background }}>
      <div className="flex items-start justify-between mb-2">
        <div className="font-heading font-bold" style={{ fontSize: '0.7rem', color: colors?.label ?? 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</div>
        {icon && <span style={{ fontSize: '1.1rem', color: colors?.icon, opacity: tone ? 0.9 : 0.5 }}>{icon}</span>}
      </div>
      <div className="num" style={{ fontSize: '1.7rem', fontWeight: 600, letterSpacing: '-1px', lineHeight: 1, color: colors?.value, background: accent && !tone ? 'var(--brass-50)' : 'transparent', display: 'inline-block', padding: accent && !tone ? '2px 6px' : '0', borderRadius: accent && !tone ? 'var(--r-sm)' : undefined }}>
        {value}
      </div>
      {sub && <div className="font-medium mt-1" style={{ fontSize: '0.75rem', color: colors?.sub ?? 'var(--text-3)' }}>{sub}</div>}
    </div>
  );
}

/* ---- KPI tile ------------------------------------------------
   The BrokerStack KPI: a tinted icon square beside a mono caption, the figure
   in mono underneath, and a footer that carries a movement and a note.

   StatCard above is the older tile — a heavy Archivo number, an emoji glyph
   and a flat wash of colour behind the whole card. The theme ships .kpi/.kpi-ic
   /.kpi-v styling for this shape and nothing was using it. New screens should
   reach for this; StatCard stays for the ones already built on it. */

export type KpiTone = 'brand' | 'brass' | 'won' | 'warm' | 'hot' | 'visit' | 'cold' | 'mute';

const KPI_TONES: Record<KpiTone, { fg: string; bg: string }> = {
  brand: { fg: 'var(--brand)', bg: 'var(--brand-50)' },
  brass: { fg: 'var(--brass-ink)',      bg: 'var(--brass-50)' },
  won:   { fg: 'var(--won)',   bg: 'var(--won-50)' },
  warm:  { fg: 'var(--warm-ink)',      bg: 'var(--warm-50)' },
  hot:   { fg: 'var(--hot)',   bg: 'var(--hot-50)' },
  visit: { fg: 'var(--visit)', bg: 'var(--visit-50)' },
  cold:  { fg: 'var(--cold)',  bg: 'var(--cold-50)' },
  mute:  { fg: 'var(--text-2)', bg: 'var(--sunken)' },
};

export function Kpi({
  label, value, unit, note, icon, tone = 'brand', delta, onClick,
}: {
  label: string;
  value: string | number;
  /** Trails the figure at a smaller size — "days", "%", "of 12". */
  unit?: string;
  note?: string;
  icon?: React.ReactNode;
  tone?: KpiTone;
  /** Signed movement, rendered green when positive and red when negative. */
  delta?: { value: string; up: boolean };
  onClick?: () => void;
}) {
  const t = KPI_TONES[tone];
  return (
    <div
      className="plate kpi no-ticks"
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? e => { if (e.key === 'Enter') onClick(); } : undefined}
      style={onClick ? { cursor: 'pointer' } : undefined}
    >
      <div className="kpi-top">
        {icon && (
          <span className="kpi-ic" style={{ background: t.bg, color: t.fg }}>{icon}</span>
        )}
        <span className="kpi-l">{label}</span>
      </div>
      <div className="kpi-v">
        {/* "12 days" wants the space, "12 %" does not. */}
        {value}{unit && <small>{/^[a-z]/i.test(unit) ? ' ' : ''}{unit}</small>}
      </div>
      {(note || delta) && (
        <div className="kpi-f">
          {delta
            ? <span className={`delta ${delta.up ? 'up' : 'dn'}`}>{delta.up ? '▲' : '▼'} {delta.value}</span>
            : <span />}
          {note && <span className="kpi-note">{note}</span>}
        </div>
      )}
    </div>
  );
}

// ---- Section Header ----------------------------------------
export function SectionHeader({ title, sub, children }: { title: string; sub?: string; children?: React.ReactNode }) {
  return (
    // .phead/.ptitle is the theme's page head: Fraunces at 29px over a muted
    // sub. This one component titles every page, so it is where the display
    // serif earns its keep — buttons and labels stay on the sans.
    <div className="phead">
      <div>
        <h2 className="ptitle">{title}</h2>
        {sub && <p className="psub">{sub}</p>}
      </div>
      {children && <div className="flex gap-2 flex-wrap">{children}</div>}
    </div>
  );
}

// ---- Score Bar ---------------------------------------------
export function ScoreBar({ score }: { score: number }) {
  const color = score >= 70 ? 'var(--won)' : score >= 40 ? 'var(--warm)' : 'var(--hot)';
  return (
    <div className="flex items-center gap-2">
      <div className="progress-bar" style={{ width: '60px' }}>
        <div className="progress-fill" style={{ width: `${score}%`, background: color }} />
      </div>
      <span className="font-mono font-bold" style={{ fontSize: '0.72rem' }}>{score}</span>
    </div>
  );
}

// ---- Date filter bar ---
export function DateFilter({ dateFrom, dateTo, onDateFrom, onDateTo }: {
  dateFrom: string; dateTo: string;
  onDateFrom: (v: string) => void; onDateTo: (v: string) => void;
}) {
  return (
    // Grouped into one control with a hairline divider, so the pair reads as a
    // range rather than two unrelated browser date pickers floating in the
    // header. The drop shadow is dropped: an input is not an elevated surface.
    <div style={{
      display: 'inline-flex', alignItems: 'center',
      border: '1px solid var(--line-2)', borderRadius: 8,
      background: 'var(--surface)', overflow: 'hidden',
    }}>
      <input type="date" value={dateFrom} onChange={e => onDateFrom(e.target.value)}
             aria-label="From date"
             style={{ border: 0, outline: 0, background: 'none', padding: '7px 10px',
                      fontFamily: 'var(--mono)', fontSize: '12px', color: 'var(--text)' }} />
      <span style={{
        fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '.1em',
        textTransform: 'uppercase', color: 'var(--text-3)',
        borderLeft: '1px solid var(--line)', borderRight: '1px solid var(--line)',
        padding: '7px 9px', alignSelf: 'stretch', display: 'flex', alignItems: 'center',
      }}>to</span>
      <input type="date" value={dateTo} onChange={e => onDateTo(e.target.value)}
             aria-label="To date"
             style={{ border: 0, outline: 0, background: 'none', padding: '7px 10px',
                      fontFamily: 'var(--mono)', fontSize: '12px', color: 'var(--text)' }} />
    </div>
  );
}

// ---- Date range presets -------------------------------------------
// Today / 7 days / 30 days / a pair of dates, in one control. Written once
// because three screens ask the same question, and a preset that means
// "last 7 days" on one page and "this week" on another is a support ticket.
export const RANGE_PRESETS = [
  { key: 'today', days: 1, label: 'Today' },
  { key: '7', days: 7, label: 'Last 7 days' },
  { key: '30', days: 30, label: 'Last 30 days' },
  { key: 'custom', days: 0, label: 'Select dates…' },
] as const;

export type RangePresetKey = typeof RANGE_PRESETS[number]['key'];

/** ISO date, n days back from today, in the browser's own day. */
export const isoDaysBack = (n: number) => {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return localISODate(d);
};

export function useDateRange(initial: RangePresetKey = 'today') {
  const [preset, setPreset] = useState<RangePresetKey>(initial);
  const [from, setFrom] = useState(isoDaysBack(6));
  const [to, setTo] = useState(isoDaysBack(0));

  const presetRange = (k: RangePresetKey) => ({
    date_from: isoDaysBack((RANGE_PRESETS.find(r => r.key === k)?.days ?? 1) - 1),
    date_to: isoDaysBack(0),
  });
  const resolved = preset === 'custom' ? { date_from: from, date_to: to } : presetRange(preset);

  // Switching to "Select dates…" starts from the range already on screen —
  // it used to open on a fixed last-7-days whatever had been chosen.
  const choose = (k: RangePresetKey) => {
    if (k === 'custom' && preset !== 'custom') {
      const cur = presetRange(preset);
      setFrom(cur.date_from);
      setTo(cur.date_to);
    }
    setPreset(k);
  };

  return { preset, setPreset: choose, from, setFrom, to, setTo, ...resolved };
}

export function RangePicker({ preset, onPreset, from, to, onFrom, onTo, note }: {
  preset: RangePresetKey; onPreset: (k: RangePresetKey) => void;
  from: string; to: string; onFrom: (v: string) => void; onTo: (v: string) => void;
  note?: string;
}) {
  return (
    <div className="flex items-center gap-2 flex-wrap">
      <div className="seg">
        {RANGE_PRESETS.map(r => (
          <button key={r.key} className={`seg-btn ${preset === r.key ? 'on' : ''}`}
                  onClick={() => onPreset(r.key)}>{r.label}</button>
        ))}
      </div>
      {preset === 'custom' && (
        <DateFilter dateFrom={from} dateTo={to} onDateFrom={onFrom} onDateTo={onTo} />
      )}
      {note && <span style={{ fontSize: 12.5, color: 'var(--text-3)' }}>{note}</span>}
    </div>
  );
}
