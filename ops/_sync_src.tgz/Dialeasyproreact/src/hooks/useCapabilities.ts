// ============================================================
// Role capabilities — what the signed-in agent is allowed to DO.
//
// This is the second of two independent gates. `useFeatures()` answers "did
// this tenant buy the module?"; this answers "may this user perform the
// action?". A screen usually needs both: the nav item is hidden without the
// module, and the Approve button is hidden without the capability.
//
// The map is served by the backend from apps/core/capabilities.py, so the UI
// never re-derives the rule. That matters: every previous check in this app
// was a hand-written `agent?.role === 'admin'`, which is how an Approve button
// ends up visible to someone the API then refuses.
// ============================================================
import { useQuery } from '@tanstack/react-query';
import { authApi, type TenantFeatures } from '../api';

/** Capability keys. Mirrors apps/core/capabilities.py :: Cap. */
export const Cap = {
  CRM_VIEW: 'crm.view',
  CRM_MANAGE_AGENTS: 'crm.manage_agents',
  CRM_SETTINGS: 'crm.settings',

  HRMS_VIEW: 'hrms.view',
  HRMS_VIEW_ALL: 'hrms.view_all',
  HRMS_MANAGE: 'hrms.manage',
  HRMS_APPROVE: 'hrms.approve',
  HRMS_PAYROLL: 'hrms.payroll',
  HRMS_INCENTIVES: 'hrms.incentives',

  ERP_VIEW: 'erp.view',
  ERP_MANAGE: 'erp.manage',
  ERP_INVOICE_ISSUE: 'erp.invoice_issue',
  ERP_INVOICE_CANCEL: 'erp.invoice_cancel',
  ERP_PAYMENTS: 'erp.payments',
  ERP_EXPORT: 'erp.export',

  ATS_VIEW: 'ats.view',
  ATS_MANAGE: 'ats.manage',
  ATS_INTERVIEW: 'ats.interview',
  ATS_OFFER: 'ats.offer',
  /** Convert an accepted offer into an HRMS employee — HR/Admin only. */
  ATS_ONBOARD: 'ats.onboard',
} as const;

export type CapKey = typeof Cap[keyof typeof Cap];

/**
 * Reads the capability map that rides along with /auth/features/, so this
 * shares one cache entry with useFeatures() rather than issuing a second
 * request on every screen.
 */
export function useCapabilities() {
  const { data, isLoading } = useQuery<TenantFeatures>({
    queryKey: ['tenant-features'],
    queryFn: () => authApi.features().then(r => r.data),
    staleTime: 5 * 60_000,
    retry: 1,
  });

  return {
    isLoading,
    role: data?.role ?? null,
    /** True when the signed-in agent's role allows this action. */
    can: (capability: string) => Boolean(data?.capabilities?.[capability]),
    /** True when the role allows at least one of these. */
    canAny: (...caps: string[]) => caps.some(c => Boolean(data?.capabilities?.[c])),
  };
}
