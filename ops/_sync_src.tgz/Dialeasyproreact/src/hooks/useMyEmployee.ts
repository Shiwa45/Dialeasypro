import { useQuery } from '@tanstack/react-query';
import { hrmsApi } from '../api';

/**
 * Whether the signed-in person has an HRMS employee record.
 *
 * Check-in/out, leave and expense claims are things an EMPLOYEE does. An
 * admin or HR user who isn't on the roster was offered them anyway, and each
 * one ended in an error.
 */
export function useMyEmployee() {
  const { data, isLoading } = useQuery({
    queryKey: ['hrms-me'],
    queryFn: () => hrmsApi.me().then(r => r.data as unknown as { enrolled?: boolean }),
    staleTime: 60_000,
  });
  return { isLoading, enrolled: data?.enrolled !== false && !!data };
}
