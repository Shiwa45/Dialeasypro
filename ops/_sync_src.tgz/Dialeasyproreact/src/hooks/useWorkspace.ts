// ============================================================
// Workspace — which web experience the signed-in person gets.
//
//   full       the admin console (admin, manager, senior agent, HR, accounts)
//   agent      own dashboard, own leads, own calls (agent, read-only)
//   recruiter  recruitment only
//
// The SERVER decides (apps/core/capabilities.py :: workspace_for) and sends
// the answer with /auth/features/, so the sidebar, the route guard and the
// landing page all read one value — the same one the API is built around.
//
// A workspace is presentation, not security. Hiding a screen stops nobody who
// types its URL or calls its endpoint; the API's role checks and row scoping
// are the boundary, and they hold whatever this hook says.
// ============================================================
import { useQuery } from '@tanstack/react-query';
import { authApi, type TenantFeatures, type Workspace } from '../api';
import { useAuthStore } from '../store/authStore';

/**
 * The same mapping the server applies. Used ONLY until /auth/features/ has
 * answered, so an agent's first paint never flashes the admin sidebar. Once
 * the server's answer arrives it always wins.
 */
export function workspaceForRole(role?: string | null): Workspace {
  if (role === 'agent' || role === 'readonly') return 'agent';
  if (role === 'recruiter') return 'recruiter';
  return 'full';
}

/** Where each workspace lands after sign-in, and where a refused URL bounces to. */
export const WORKSPACE_HOME: Record<Workspace, string> = {
  full: '/dashboard',
  agent: '/dashboard',
  recruiter: '/recruitment/dashboard',
};

/**
 * Route allowlists. A path outside the list redirects to the workspace home
 * rather than rendering a screen whose every request would be refused.
 * `full` has no list: the admin console keeps every route it had.
 */
const ALLOWED: Record<Exclude<Workspace, 'full'>, RegExp[]> = {
  agent: [
    /^\/dashboard\/?$/,
    /^\/leads\/?$/,
    /^\/leads\/\d+\/?$/,      // a lead's detail — never /leads/import or /leads/batches
    /^\/calls\/?$/,
    /^\/profile\/?$/,
  ],
  recruiter: [
    /^\/recruitment(\/.*)?$/,
    /^\/profile\/?$/,
  ],
};

export function isPathAllowed(workspace: Workspace, pathname: string): boolean {
  if (workspace === 'full') return true;
  return ALLOWED[workspace].some(rx => rx.test(pathname));
}

export function useWorkspace() {
  const { agent } = useAuthStore();
  const { data, isLoading } = useQuery<TenantFeatures>({
    queryKey: ['tenant-features'],
    queryFn: () => authApi.features().then(r => r.data),
    staleTime: 5 * 60_000,
    retry: 1,
  });

  const workspace: Workspace = data?.workspace ?? workspaceForRole(agent?.role);
  const role = data?.role ?? agent?.role ?? null;

  return {
    isLoading,
    workspace,
    home: WORKSPACE_HOME[workspace],
    isAgentWorkspace: workspace === 'agent',
    isRecruiterWorkspace: workspace === 'recruiter',
    isFullWorkspace: workspace === 'full',
    /** Read-only: same agent screens, every write control removed. */
    isReadOnly: role === 'readonly',
    /** False once the server says this person may not use the web app. */
    webAccessAllowed: data?.web_access_allowed ?? true,
    webAccessMessage: data?.web_access_message ?? '',
    isPathAllowed: (pathname: string) => isPathAllowed(workspace, pathname),
  };
}
