// ============================================================
// DialSathi — Agent Login Report
//
// Every agent's working day: when they came online, when they were last
// seen, how long they were logged in, and how that time split between idle
// (available), calls, wrap-up and breaks — with their calls alongside. Built
// from the same presence intervals as Live Agents, so today is live and
// refreshes on its own. Any range up to 31 days; downloads as CSV.
// ============================================================
import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { reportsApi, type AgentLoginRow } from '../api';
import { EmptyState, RangePicker, SectionHeader, Spinner, useDateRange, useToast } from '../components/ui';
import { getErrorMessage } from '../utils/errors';
import { localISODate } from '../utils/fmt';

/** 5400 → "1h 30m"; 0 → "—". */
function span(secs: number): string {
  if (!secs) return '—';
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  return h ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}m`;
}

function clock(iso: string | null): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}

const STATUS_LABEL: Record<string, string> = {
  available: 'Available', on_call: 'On call', wrap_up: 'Wrap-up', break: 'On break', offline: 'Offline',
};

export default function AgentLoginReport() {
  const { showToast } = useToast();
  const range = useDateRange('today');
  const [query, setQuery] = useState('');
  const [downloading, setDownloading] = useState(false);
  const includesToday = range.date_to >= localISODate();

  const { data, isLoading, error, dataUpdatedAt } = useQuery({
    queryKey: ['agent-login-report', range.date_from, range.date_to],
    queryFn: () => reportsApi.agentLogin({ date_from: range.date_from, date_to: range.date_to }).then(r => r.data),
    // Today is live: agents are still logging time.
    refetchInterval: includesToday ? 30_000 : false,
  });

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return (data?.rows ?? []).filter(r => !q || r.name.toLowerCase().includes(q));
  }, [data, query]);

  const totals = useMemo(() => rows.reduce((t, r) => ({
    online: t.online + r.online_seconds,
    available: t.available + r.available_seconds,
    onCall: t.onCall + r.on_call_seconds,
    wrap: t.wrap + r.wrap_up_seconds,
    brk: t.brk + r.break_seconds,
    breaks: t.breaks + r.break_count,
    calls: t.calls + r.calls,
    connected: t.connected + r.connected_calls,
    talk: t.talk + (r.talk_seconds ?? 0),
    present: t.present + (r.first_online ? 1 : 0),
  }), { online: 0, available: 0, onCall: 0, wrap: 0, brk: 0, breaks: 0, calls: 0, connected: 0, talk: 0, present: 0 }), [rows]);

  const multiDay = range.date_from !== range.date_to;

  const download = async () => {
    setDownloading(true);
    try {
      const res = await reportsApi.agentLoginCsv({ date_from: range.date_from, date_to: range.date_to });
      const url = URL.createObjectURL(new Blob([res.data as BlobPart], { type: 'text/csv;charset=utf-8' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = `agent_login_${range.date_from}_${range.date_to}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (e) {
      showToast('error', 'Download failed', getErrorMessage(e));
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="p-6" style={{ minHeight: '100%' }}>
      <SectionHeader
        title="Login Report"
        sub={includesToday
          ? `Live — refreshes every 30 seconds${dataUpdatedAt ? ` · updated ${new Date(dataUpdatedAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}` : ''}`
          : 'Each agent’s logged-in time, day by day'}
      >
        <button className="btn-brutal btn-secondary px-3 py-2 font-heading font-bold"
                style={{ fontSize: '0.78rem' }} disabled={downloading || !data} onClick={download}>
          {downloading ? 'Preparing…' : 'Download CSV'}
        </button>
      </SectionHeader>

      <div className="flex gap-3 items-center flex-wrap mb-4">
        <RangePicker preset={range.preset} onPreset={range.setPreset}
                     from={range.from} to={range.to} onFrom={range.setFrom} onTo={range.setTo}
                     note="Up to 31 days" />
        <input className="input-brutal" placeholder="Search an agent…" value={query}
               onChange={e => setQuery(e.target.value)} style={{ width: 220 }} />
      </div>

      {/* The day at a glance. */}
      <div className="lr-kpis">
        <Kpi label={multiDay ? 'Agent-days present' : 'Agents present'} value={String(totals.present)} />
        <Kpi label="Logged in" value={span(totals.online)} />
        <Kpi label="Idle / available" value={span(totals.available)} />
        <Kpi label="On call (dialer)" value={span(totals.onCall)} />
        <Kpi label="Break" value={span(totals.brk)} sub={`${totals.breaks} break${totals.breaks === 1 ? '' : 's'}`} />
        <Kpi label="Calls" value={String(totals.calls)} sub={`${totals.connected} connected · ${span(totals.talk)} talk`} />
      </div>

      {isLoading ? <Spinner /> : error ? (
        <EmptyState icon="!" title="Could not load the report" message={getErrorMessage(error)} />
      ) : !rows.length ? (
        <EmptyState icon="○" title="No agents" message="No agent matches this search." />
      ) : (
        <div className="plate no-ticks" style={{ padding: 0, overflowX: 'auto' }}>
          <table className="lr-table">
            <thead>
              <tr>
                {multiDay && <th>Date</th>}
                <th>Agent</th>
                <th>First online</th>
                <th>Last seen</th>
                <th className="num-col">Logged in</th>
                <th className="num-col">Idle</th>
                <th className="num-col" title="Time in the dialer's On call status, dialling and ringing included">On call (dialer)</th>
                <th className="num-col">Wrap-up</th>
                <th className="num-col">Break</th>
                <th className="num-col">Calls</th>
                <th className="num-col" title="Connected calls' durations, as on the Calls page">Talk time</th>
                <th className="num-col">Occupancy</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r: AgentLoginRow) => (
                <tr key={`${r.date}-${r.agent_id}`} className={r.first_online ? '' : 'lr-absent'}>
                  {multiDay && <td className="lr-date">{new Date(`${r.date}T00:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', weekday: 'short' })}</td>}
                  <td>
                    <div className="lr-name">{r.name}</div>
                    <div className="lr-sub">
                      {r.role.replace(/_/g, ' ')}
                      {r.is_active === false && <span className="lr-muted"> · deactivated</span>}
                      {r.status_now && r.online_now && <span className="lr-now"> · {STATUS_LABEL[r.status_now] ?? r.status_now}</span>}
                    </div>
                  </td>
                  <td>{r.first_online ? clock(r.first_online)
                    : r.first_sign_in
                      ? <span className="lr-muted" title="Signed in, but never went online on the dialer app">Signed in {clock(r.first_sign_in)} · not on dialer</span>
                      : <span className="lr-muted">Not logged in</span>}</td>
                  <td>{r.online_now ? <span className="lr-now">Online now</span> : clock(r.last_seen)}</td>
                  <td className="num-col"><b>{span(r.online_seconds)}</b></td>
                  <td className="num-col">{span(r.available_seconds)}</td>
                  <td className="num-col">{span(r.on_call_seconds)}</td>
                  <td className="num-col">{span(r.wrap_up_seconds)}</td>
                  <td className="num-col" title={r.break_reasons || undefined}>
                    {span(r.break_seconds)}
                    {r.break_count > 0 && <div className="lr-note lr-reasons">{r.break_reasons}</div>}
                  </td>
                  <td className="num-col">{r.calls}{r.calls > 0 && <div className="lr-note">{r.connected_calls} connected</div>}</td>
                  <td className="num-col">{span(r.talk_seconds ?? 0)}</td>
                  <td className="num-col">{r.online_seconds ? `${r.occupancy}%` : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function Kpi({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="plate no-ticks lr-kpi">
      <div className="lr-kpi-l">{label}</div>
      <div className="lr-kpi-v num">{value}</div>
      {sub && <div className="lr-note">{sub}</div>}
    </div>
  );
}
