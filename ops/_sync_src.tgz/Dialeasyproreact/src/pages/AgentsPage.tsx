import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { authApi, leadsApi } from '../api';
import {
  SectionHeader, Modal, Input, Select, ConfirmDialog,
  Pagination, Spinner, EmptyState, useToast, StatusBadge,
} from '../components/ui';
import { fmtRelative } from '../utils/fmt';
import { getErrorMessage } from '../utils/errors';
import { Module, useFeatures } from '../hooks/useFeatures';

// Must match apps/core/constants.py :: AgentRole.CHOICES exactly — the
// serializer validates against it, so an extra entry here is a form that
// always fails. ('trainee' was exactly that, until it was removed.)
const ROLES = [
  { value: 'admin',        label: 'Admin',        hint: 'Full access to everything' },
  { value: 'manager',      label: 'Manager',      hint: 'Team, reports, approvals' },
  { value: 'hr',           label: 'HR',           hint: 'HRMS + Recruitment, no CRM admin' },
  { value: 'accounts',     label: 'Accounts',     hint: 'Sales & Billing, no CRM admin' },
  { value: 'recruiter',    label: 'Recruiter',    hint: 'Recruitment only — no CRM, no HRMS' },
  { value: 'senior_agent', label: 'Senior Agent', hint: "Own leads + juniors' leads" },
  { value: 'agent',        label: 'Agent',        hint: 'Own leads only' },
  { value: 'readonly',     label: 'Read Only',    hint: 'View only, cannot edit' },
];

export default function Agents() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [statusTab, setStatusTab] = useState<'active' | 'deactivated'>('active');
  const [page, setPage] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [editAgent, setEditAgent] = useState<Record<string, unknown>>({});
  const [confirmDeactivate, setConfirmDeactivate] = useState<number | null>(null);
  const [search, setSearch] = useState('');
  const [pwdAgent, setPwdAgent] = useState<{ id: number; name: string } | null>(null);
  const [pwdForm, setPwdForm] = useState({ new_password: '', confirm_password: '', require_change_on_login: false });
  // The Recruiter role exists only with the Recruitment module (the API
  // refuses it otherwise). Still listed for someone who already holds it, so
  // editing their name doesn't silently change their role.
  const { hasModule } = useFeatures();
  const roleOptions = ROLES.filter(r =>
    r.value !== 'recruiter' || hasModule(Module.RECRUITMENT) || editAgent.role === 'recruiter');

  const { data, isLoading } = useQuery({
    queryKey: ['agents', statusTab, page, search],
    queryFn: () => authApi.listAgents({
      page, page_size: 20,
      is_active: statusTab === 'active' ? 'true' : 'false',
      ...(search ? { search } : {}),
    }).then(r => r.data),
    placeholderData: prev => prev,
  });

  const reactivateMut = useMutation({
    mutationFn: (id: number) => authApi.reactivateAgent(id),
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ['agents'] });
      showToast('success', 'Agent reactivated', `${r.data.name} can now log in again.`);
    },
    onError: (e: unknown) => showToast('error', 'Could not reactivate', getErrorMessage(e, 'This may exceed your plan\'s agent limit — deactivate another agent or upgrade your plan.')),
  });

  // Only the fields the form edits. The whole list row used to be sent back —
  // teams, login stats, is_active — and anything stale in it was written too.
  const EDITABLE = ['name', 'email', 'phone', 'employee_id', 'role', 'shift_start', 'shift_end', 'working_days'] as const;
  const formPayload = () => {
    const out: Record<string, unknown> = {};
    for (const k of EDITABLE) if (k in editAgent) out[k] = editAgent[k] === '' && (k === 'shift_start' || k === 'shift_end') ? null : editAgent[k];
    if (!editAgent.id) { out.password = editAgent.password; out.confirm_password = editAgent.confirm_password; }
    return out;
  };
  const saveMut = useMutation({
    mutationFn: () =>
      editAgent.id
        ? authApi.updateAgent(Number(editAgent.id), formPayload() as unknown as import('../types').Agent)
        : authApi.createAgent(formPayload()),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['agents'] });
      setShowModal(false);
      setEditAgent({});
      showToast('success', 'Agent saved', '');
    },
    onError: (e: unknown) => showToast('error', 'Error', getErrorMessage(e, 'Failed')),
  });

  const deactivateMut = useMutation({
    mutationFn: (id: number) => authApi.updateAgent(id, { is_active: false } as unknown as import('../types').Agent),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['agents'] });
      setConfirmDeactivate(null);
      showToast('info', 'Agent deactivated', '');
    },
    onError: (e: unknown) => {
      setConfirmDeactivate(null);
      showToast('error', 'Could not deactivate', getErrorMessage(e, 'Failed'));
    },
  });

  const closePwdModal = () => {
    setPwdAgent(null);
    setPwdForm({ new_password: '', confirm_password: '', require_change_on_login: false });
  };

  const setPasswordMut = useMutation({
    mutationFn: () =>
      authApi.setAgentPassword(
        pwdAgent!.id,
        pwdForm.new_password,
        pwdForm.confirm_password,
        pwdForm.require_change_on_login,
      ),
    onSuccess: () => {
      showToast('success', 'Password updated', `New password set for ${pwdAgent?.name}.`);
      closePwdModal();
    },
    onError: (e: unknown) => showToast('error', 'Error', getErrorMessage(e, 'Failed to set password')),
  });

  const f = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setEditAgent(p => ({ ...p, [k]: e.target.value }));
  const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const workingDays: number[] = Array.isArray(editAgent.working_days) && (editAgent.working_days as number[]).length
    ? (editAgent.working_days as number[]) : [0, 1, 2, 3, 4, 5];
  const toggleDay = (d: number) => setEditAgent(p => {
    const cur = new Set(workingDays);
    if (cur.has(d)) cur.delete(d); else cur.add(d);
    return { ...p, working_days: [...cur].sort((a, b) => a - b) };
  });

  // What deactivating leaves behind, so the admin can hand it over first.
  const deactivating = agentsForConfirm(confirmDeactivate);
  const { data: openLeads } = useQuery({
    queryKey: ['agent-open-leads', confirmDeactivate],
    queryFn: () => leadsApi.list({ assigned_to: confirmDeactivate!, page_size: 1 }).then(r => r.data.count),
    enabled: confirmDeactivate !== null,
  });
  function agentsForConfirm(id: number | null) {
    return id === null ? null : (data?.results ?? []).find(a => a.id === id) ?? null;
  }

  const agents = data?.results ?? [];

  return (
    <div className="p-6 flex flex-col gap-4" style={{ background: 'var(--paper)', minHeight: '100%' }}>
      <SectionHeader title="Agents" sub={`${data?.count ?? 0} agents`}>
        <button
          onClick={() => { setEditAgent({}); setShowModal(true); }}
          className="btn-brutal btn-primary px-4 py-2.5 font-heading font-black"
          style={{ fontSize: '0.85rem', boxShadow: 'var(--shadow)' }}
        >
          + New Agent
        </button>
      </SectionHeader>

      {/* Active / Deactivated tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid var(--line)' }}>
        {([['active', 'Active'], ['deactivated', 'Deactivated']] as const).map(([k, l]) => (
          <button key={k} onClick={() => { setStatusTab(k); setPage(1); }} className="font-heading font-bold px-4 py-2.5"
                  style={{ background: statusTab === k ? 'var(--brass-50)' : 'var(--surface)', border: 'none', borderRight: '1px solid var(--line)', cursor: 'pointer', fontSize: '0.8rem' }}>
            {l}
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="card card-sm p-3 flex gap-2">
        <input
          placeholder="Search agents by name or email…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="input-brutal flex-1"
          style={{ boxShadow: 'var(--shadow)' }}
        />
      </div>

      {isLoading ? (
        <Spinner />
      ) : agents.length === 0 ? (
        <EmptyState
          icon="◉"
          title="No agents found"
          action={{ label: '+ Add Agent', onClick: () => setShowModal(true) }}
        />
      ) : (
        <div className="card" style={{ overflowX: 'auto' }}>
          <table className="table-brutal">
            <thead>
              <tr>
                {['Agent', 'Role', 'Phone', 'Status', 'Online', 'Logins', 'Last Active', 'Actions'].map(h => (
                  <th key={h}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {agents.map(agent => (
                <tr key={agent.id}>
                  <td>
                    <div className="flex items-center gap-2">
                      <div className="avt">
                        {agent.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-heading font-bold" style={{ fontSize: '0.83rem' }}>{agent.name}</div>
                        <div style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>{agent.email}</div>
                      </div>
                    </div>
                  </td>
                  <td><span className="tag">{agent.role_display}</span></td>
                  <td className="font-mono" style={{ fontSize: '0.78rem' }}>{agent.phone || '—'}</td>
                  <td><StatusBadge status={agent.is_active ? 'active' : 'inactive'} /></td>
                  <td>
                    <span style={{
                      width: '10px', height: '10px', borderRadius: '50%',
                      background: agent.is_online ? 'var(--won)' : '#d1d5db',
                      display: 'inline-block', border: '1px solid var(--line)',
                    }} />
                  </td>
                  <td style={{ fontSize: '0.82rem' }}>{agent.total_login_count}</td>
                  <td style={{ fontSize: '0.75rem', color: 'var(--text-3)' }}>{fmtRelative(agent.last_active_at)}</td>
                  <td>
                    <div className="flex gap-1">
                      <button
                        onClick={() => { setEditAgent(agent as unknown as Record<string, unknown>); setShowModal(true); }}
                        className="btn-brutal btn-yellow px-2 py-1 font-heading font-bold"
                        style={{ fontSize: '0.68rem' }}
                      >
                        Edit
                      </button>
                      {!agent.is_tenant_admin && (
                        <button
                          onClick={() => setPwdAgent({ id: agent.id, name: agent.name })}
                          className="btn-brutal btn-secondary px-2 py-1 font-heading font-bold"
                          style={{ fontSize: '0.68rem' }}
                        >
                          Password
                        </button>
                      )}
                      {agent.is_active && !agent.is_tenant_admin && (
                        <button
                          onClick={() => setConfirmDeactivate(agent.id)}
                          className="btn-brutal btn-danger px-2 py-1 font-heading font-bold"
                          style={{ fontSize: '0.68rem' }}
                        >
                          Deactivate
                        </button>
                      )}
                      {!agent.is_active && (
                        <button
                          onClick={() => reactivateMut.mutate(agent.id)}
                          disabled={reactivateMut.isPending}
                          className="btn-brutal btn-primary px-2 py-1 font-heading font-bold"
                          style={{ fontSize: '0.68rem' }}
                        >
                          Reactivate
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="px-4 pb-4">
            <Pagination page={page} totalPages={data?.total_pages ?? 1} onPageChange={setPage} />
          </div>
        </div>
      )}

      {/* Agent Form Modal */}
      {showModal && (
        <Modal
          title={editAgent.id ? `Edit: ${editAgent.name}` : 'New Agent'}
          onClose={() => { setShowModal(false); setEditAgent({}); }}
          maxWidth="580px"
        >
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <Input label="Full Name *" value={String(editAgent.name ?? '')} onChange={f('name')} placeholder="Rahul Sharma" />
            </div>
            {/* autoComplete off / new-password: the browser used to autofill
                the ADMIN's own saved login into these — their email ended up as
                agents' Employee IDs, and their password could become an agent's. */}
            <Input label="Email *" type="email" value={String(editAgent.email ?? '')} onChange={f('email')}
                   autoComplete="off" name="agent-email"
                   hint={editAgent.id ? 'This is what they sign in with.' : undefined} />
            <Input label="Phone" value={String(editAgent.phone ?? '')} onChange={f('phone')} placeholder="+919876543210" autoComplete="off" />
            <Input label="Employee ID" value={String(editAgent.employee_id ?? '')} onChange={f('employee_id')} autoComplete="off" name="agent-employee-id" />
            <Select label="Role *" value={String(editAgent.role ?? 'agent')} onChange={f('role')}>
              {roleOptions.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
            </Select>
            {!editAgent.id && (
              <>
                <Input label="Password *" type="password" value={String(editAgent.password ?? '')} onChange={f('password')} autoComplete="new-password" />
                <Input label="Confirm Password *" type="password" value={String(editAgent.confirm_password ?? '')} onChange={f('confirm_password')} autoComplete="new-password" />
              </>
            )}
            <Input label="Shift starts" type="time" value={String(editAgent.shift_start ?? '').slice(0, 5)} onChange={f('shift_start')} />
            <Input label="Shift ends" type="time" value={String(editAgent.shift_end ?? '').slice(0, 5)} onChange={f('shift_end')} />
            <div className="col-span-2">
              <div className="font-heading font-bold" style={{ fontSize: '0.72rem', textTransform: 'uppercase', marginBottom: 6 }}>Working days</div>
              <div className="flex gap-2 flex-wrap">
                {WEEKDAYS.map((d, i) => (
                  <label key={d} className="flex items-center gap-1" style={{ fontSize: '0.8rem', cursor: 'pointer' }}>
                    <input type="checkbox" checked={workingDays.includes(i)} onChange={() => toggleDay(i)} /> {d}
                  </label>
                ))}
              </div>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginTop: 4 }}>
                Other days count as a week off in HRMS attendance and payroll.
              </div>
            </div>
          </div>
          {saveMut.isError && (
            <div style={{ background: 'var(--lost-50)', border: '1px solid var(--hot)', padding: '8px 12px', fontSize: '0.8rem', marginTop: '12px' }}>
              {getErrorMessage(saveMut.error, 'An error occurred.')}
            </div>
          )}
          <div className="flex gap-3 mt-5 pt-4" style={{ borderTop: '2px solid var(--line)' }}>
            <button onClick={() => { setShowModal(false); setEditAgent({}); }} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">Cancel</button>
            <button
              onClick={() => saveMut.mutate()}
              disabled={saveMut.isPending}
              className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black"
              style={{ boxShadow: 'var(--shadow)' }}
            >
              {saveMut.isPending ? '◌ Saving…' : editAgent.id ? 'Save Changes →' : 'Create Agent →'}
            </button>
          </div>
        </Modal>
      )}

      {confirmDeactivate !== null && (
        <ConfirmDialog
          title={`Deactivate ${deactivating?.name ?? 'agent'}?`}
          message={[
            'They lose all access to the CRM and the app immediately.',
            openLeads ? `${openLeads} lead${openLeads === 1 ? ' is' : 's are'} still assigned to them — hand ${openLeads === 1 ? 'it' : 'them'} over afterwards with Leads → Assign Lead or Settings → Unassign Leads.` : '',
            'Call queues they are on keep them listed until you edit the queue. If they have left the company, also exit them in HRMS → Employees so payroll stops.',
          ].filter(Boolean).join(' ')}
          confirmLabel="Deactivate"
          danger
          onConfirm={() => deactivateMut.mutate(confirmDeactivate)}
          onCancel={() => setConfirmDeactivate(null)}
        />
      )}

      {/* Set Password Modal */}
      {pwdAgent && (
        <Modal
          title={`Set Password: ${pwdAgent.name}`}
          onClose={closePwdModal}
          maxWidth="440px"
        >
          <div className="flex flex-col gap-3">
            <Input
              label="New Password *"
              type="password"
              value={pwdForm.new_password}
              onChange={e => setPwdForm(p => ({ ...p, new_password: e.target.value }))}
              placeholder="At least 8 characters"
            />
            <Input
              label="Confirm Password *"
              type="password"
              value={pwdForm.confirm_password}
              onChange={e => setPwdForm(p => ({ ...p, confirm_password: e.target.value }))}
            />
            <label className="flex items-center gap-2 cursor-pointer" style={{ fontSize: '0.8rem' }}>
              <input
                type="checkbox"
                checked={pwdForm.require_change_on_login}
                onChange={e => setPwdForm(p => ({ ...p, require_change_on_login: e.target.checked }))}
                style={{ width: '16px', height: '16px', accentColor: 'var(--brass-50)' }}
              />
              <span className="font-medium">Require agent to change password on next login</span>
            </label>
            {pwdForm.new_password.length > 0 && pwdForm.new_password.length < 8 && (
              <div style={{ fontSize: '0.72rem', color: 'var(--hot)' }}>Password must be at least 8 characters.</div>
            )}
            {pwdForm.confirm_password.length > 0 && pwdForm.new_password !== pwdForm.confirm_password && (
              <div style={{ fontSize: '0.72rem', color: 'var(--hot)' }}>Passwords do not match.</div>
            )}
          </div>
          <div className="flex gap-3 mt-5 pt-4" style={{ borderTop: '2px solid var(--line)' }}>
            <button onClick={closePwdModal} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">Cancel</button>
            <button
              onClick={() => setPasswordMut.mutate()}
              disabled={
                setPasswordMut.isPending ||
                pwdForm.new_password.length < 8 ||
                pwdForm.new_password !== pwdForm.confirm_password
              }
              className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black"
              style={{ boxShadow: 'var(--shadow)' }}
            >
              {setPasswordMut.isPending ? '◌ Setting…' : 'Set Password →'}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
