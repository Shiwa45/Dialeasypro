// ============================================================
// DialSathi — Billing & Plan (tenant side)
//
// This tab used to be a notice telling the paying customer to "visit the
// Super Admin panel at /superadmin/" — the platform operator's console, which
// no tenant can sign into — beside placeholder phone numbers reading
// +91-1800-XXX-XXXX. A customer could not see which plan they were on, what
// it allows, how much of it they had used, or when it renews.
//
// Everything here comes from GET /api/v1/billing/ (admin only). Nothing is
// hardcoded: support contacts come from the platform's own settings, and a
// contact that has not been configured is left out rather than invented.
// ============================================================
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';

import { billingApi } from '../api';
import { EmptyState, Spinner } from '../components/ui';
import { fmtDate, formatINRExact } from '../utils/fmt';
import type { BillingOverview, UsageMetric } from '../types';

const STATUS_TONE: Record<string, string> = {
  active: 'status-active',
  trial: 'status-trial',
  // The ones that cost the customer service are the ones that must not look
  // like a neutral grey chip.
  past_due: 'status-lost',
  suspended: 'status-lost',
  expired: 'status-lost',
  cancelled: 'status-inactive',
};

const STATUS_LABEL: Record<string, string> = {
  active: 'Active',
  trial: 'Trial',
  past_due: 'Payment overdue',
  suspended: 'Suspended',
  cancelled: 'Cancelled',
  expired: 'Expired',
};

const USAGE_ROWS: { key: keyof BillingOverview['usage']; label: string; unit?: string }[] = [
  { key: 'agents', label: 'Agents' },
  { key: 'leads', label: 'Leads' },
  { key: 'leads_per_day', label: 'Leads added today' },
  { key: 'custom_fields', label: 'Custom fields' },
];

export default function BillingPanel() {
  const [showFeatures, setShowFeatures] = useState(false);

  const q = useQuery({
    queryKey: ['billing'],
    queryFn: () => billingApi.overview().then(r => r.data),
  });

  if (q.isLoading) return <Spinner />;

  if (q.isError) {
    return (
      <EmptyState
        icon="₹"
        title="Billing is not available"
        message="Only a workspace admin can view the plan and invoices. If you are an admin and still see this, your session may have expired — sign in again."
      />
    );
  }

  const data = q.data as BillingOverview;
  const { plan, subscription, usage, features, invoices, support } = data;
  const enabled = features.filter(f => f.enabled);

  return (
    <div className="flex flex-col gap-4">
      {/* ---- The plan ------------------------------------ */}
      <div className="card p-5">
        <div className="flex items-start justify-between gap-4" style={{ flexWrap: 'wrap' }}>
          <div>
            <div style={{ fontSize: '0.72rem', letterSpacing: '0.08em', color: 'var(--text-3)', fontWeight: 700 }}>
              YOUR PLAN
            </div>
            <div className="font-heading font-black" style={{ fontSize: '1.5rem', lineHeight: 1.2 }}>
              {plan?.name ?? 'No plan assigned'}
            </div>
            {plan?.description && (
              <div style={{ fontSize: '0.85rem', color: 'var(--text-2)', marginTop: '2px' }}>
                {plan.description}
              </div>
            )}
          </div>
          <span className={`badge ${STATUS_TONE[subscription.status] ?? 'status-inactive'}`}>
            {STATUS_LABEL[subscription.status] ?? subscription.status}
          </span>
        </div>

        <div className="flex gap-6 mt-4" style={{ flexWrap: 'wrap' }}>
          {plan && (
            <Fact
              label={subscription.billing_cycle === 'yearly' ? 'Billed yearly' : 'Billed monthly'}
              value={formatINRExact(
                subscription.billing_cycle === 'yearly' ? plan.price_yearly : plan.price_monthly,
              )}
            />
          )}
          {subscription.status === 'trial' && subscription.trial_end && (
            <Fact label="Trial ends" value={fmtDate(subscription.trial_end)} />
          )}
          {subscription.current_period_end && (
            <Fact
              label={subscription.cancel_at_period_end ? 'Access ends' : 'Renews on'}
              value={fmtDate(subscription.current_period_end)}
              hint={
                subscription.days_until_renewal != null
                  ? `in ${subscription.days_until_renewal} day${subscription.days_until_renewal === 1 ? '' : 's'}`
                  : undefined
              }
            />
          )}
        </div>

        {subscription.cancel_at_period_end && (
          <div className="mt-4" style={{ background: 'var(--hot-50)', border: '1px solid var(--hot)', padding: '10px 12px', fontSize: '0.82rem' }}>
            This subscription is set to end at the close of the current period and will not renew.
          </div>
        )}
      </div>

      {/* ---- What you are using -------------------------- */}
      <div className="card p-5">
        <div className="font-heading font-black mb-3" style={{ fontSize: '0.95rem' }}>Usage</div>
        <div className="flex flex-col gap-3">
          {USAGE_ROWS.map(row => (
            <UsageBar key={row.key} label={row.label} metric={usage[row.key]} />
          ))}
        </div>
        <div style={{ fontSize: '0.75rem', color: 'var(--text-3)', marginTop: '12px' }}>
          The agent limit is the one enforced for this workspace, which may differ from the plan's
          standard allowance if your seats were adjusted.
        </div>
      </div>

      {/* ---- What the plan includes ---------------------- */}
      {enabled.length > 0 && (
        <div className="card p-5">
          <button
            onClick={() => setShowFeatures(v => !v)}
            className="flex items-center justify-between w-full"
            style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', textAlign: 'left' }}
          >
            <span className="font-heading font-black" style={{ fontSize: '0.95rem' }}>
              Included in your plan
              <span style={{ color: 'var(--text-3)', fontWeight: 500 }}> · {enabled.length} features</span>
            </span>
            <span style={{ color: 'var(--text-3)', fontSize: '0.8rem' }}>{showFeatures ? 'Hide' : 'Show all'}</span>
          </button>
          {showFeatures && (
            <div
              className="mt-3"
              style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(220px,1fr))', gap: '6px' }}
            >
              {enabled.map(f => (
                <div key={f.key} style={{ fontSize: '0.82rem', color: 'var(--text-2)' }}>
                  <span style={{ color: 'var(--won)', marginRight: '6px' }}>✓</span>
                  {f.label}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ---- Invoices ------------------------------------ */}
      <div className="card" style={{ overflowX: 'auto' }}>
        <div className="px-5 pt-5 pb-3 font-heading font-black" style={{ fontSize: '0.95rem' }}>
          Invoices
        </div>
        {invoices.length === 0 ? (
          <div style={{ padding: '0 20px 20px', fontSize: '0.83rem', color: 'var(--text-3)' }}>
            No invoices yet. They appear here once a billing period has been charged.
          </div>
        ) : (
          <table className="table-brutal">
            <thead>
              <tr>{['Invoice', 'Date', 'Period', 'Amount', 'Status'].map(h => <th key={h}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {invoices.map(inv => (
                <tr key={inv.id}>
                  <td className="font-mono" style={{ fontSize: '0.78rem' }}>{inv.invoice_number}</td>
                  <td style={{ fontSize: '0.82rem' }}>{fmtDate(inv.invoice_date)}</td>
                  <td style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>
                    {inv.billing_period_start && inv.billing_period_end
                      ? `${fmtDate(inv.billing_period_start)} – ${fmtDate(inv.billing_period_end)}`
                      : '—'}
                  </td>
                  <td className="font-heading font-bold" style={{ fontSize: '0.83rem' }}>
                    {formatINRExact(inv.total_amount)}
                  </td>
                  <td>
                    <span className={`badge ${inv.payment_status === 'paid' ? 'status-active' : 'status-inactive'}`}>
                      {inv.payment_status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* ---- Getting help -------------------------------- */}
      <div className="card p-5">
        <div className="font-heading font-black mb-2" style={{ fontSize: '0.95rem' }}>
          Changing your plan
        </div>
        <div style={{ fontSize: '0.84rem', color: 'var(--text-2)', lineHeight: 1.6 }}>
          To upgrade, add seats or ask about an invoice, contact {support.platform_name}.
        </div>
        <div className="mt-3" style={{ fontSize: '0.84rem', display: 'flex', flexDirection: 'column', gap: '6px' }}>
          {support.email && (
            <div>
              Email <a href={`mailto:${support.email}`} style={{ color: 'var(--text)', fontWeight: 700 }}>{support.email}</a>
            </div>
          )}
          {support.phone && (
            <div>
              Phone <a href={`tel:${support.phone}`} style={{ color: 'var(--text)', fontWeight: 700 }}>{support.phone}</a>
            </div>
          )}
          {support.whatsapp && (
            <div>
              WhatsApp{' '}
              <a
                href={`https://wa.me/${support.whatsapp.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noreferrer"
                style={{ color: 'var(--text)', fontWeight: 700 }}
              >
                {support.whatsapp}
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Fact({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div>
      <div style={{ fontSize: '0.72rem', color: 'var(--text-3)', fontWeight: 600 }}>{label}</div>
      <div className="font-heading font-bold" style={{ fontSize: '1rem' }}>{value}</div>
      {hint && <div style={{ fontSize: '0.75rem', color: 'var(--text-3)' }}>{hint}</div>}
    </div>
  );
}

function UsageBar({ label, metric }: { label: string; metric: UsageMetric | undefined }) {
  const used = metric?.used ?? null;
  const limit = metric?.limit ?? null;

  // No limit is not the same as a full bar, and an unmetered resource is not
  // the same as zero used. Both say so rather than drawing a misleading bar.
  const unlimited = limit == null;
  const pct = unlimited || used == null || limit === 0 ? 0 : Math.min(100, (used / limit) * 100);
  const tight = pct >= 90;

  return (
    <div>
      <div className="flex justify-between" style={{ fontSize: '0.82rem', marginBottom: '4px' }}>
        <span style={{ color: 'var(--text-2)' }}>{label}</span>
        <span className="font-heading font-bold">
          {used == null ? 'Not measured' : used.toLocaleString('en-IN')}
          {!unlimited && <span style={{ color: 'var(--text-3)', fontWeight: 500 }}> / {limit!.toLocaleString('en-IN')}</span>}
          {unlimited && used != null && <span style={{ color: 'var(--text-3)', fontWeight: 500 }}> · no limit</span>}
        </span>
      </div>
      <div style={{ height: '6px', background: 'var(--line)', borderRadius: '999px', overflow: 'hidden' }}>
        <div
          style={{
            width: `${pct}%`,
            height: '100%',
            background: tight ? 'var(--hot)' : 'var(--brass)',
            transition: 'width 200ms',
          }}
        />
      </div>
    </div>
  );
}
