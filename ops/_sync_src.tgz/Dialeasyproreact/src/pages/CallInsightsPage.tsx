// ============================================================
// DialSathi — AI Call Summary  (add-on module: ai_suite; route /insights)
//
// A manager's review queue. The old screen listed an analysis timestamp, a
// sentiment chip and a single truncated line of summary — and never said
// whose call it was or who was on the other end, so there was no way to
// decide which row to open. The list view had already joined the agent and
// the lead; the serializer was throwing both away.
//
// Rebuilt around triage: negatives first if you want them, every row naming
// the agent, the lead and how long the call ran, and the summary given the
// two lines it needs to be worth reading in the list.
// ============================================================
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { aiApi, authApi } from '../api';
import { useAuthStore } from '../store/authStore';
import {
  EmptyState, Kpi, Modal, Pagination, SectionHeader, Select, Spinner, useToast,
} from '../components/ui';
import { fmtDateTime, formatDuration } from '../utils/fmt';
import type { CallInsight, Sentiment } from '../types';
import { isAdmin as isAdminRole } from '../utils/roles';
import { getErrorMessage } from '../utils/errors';
import { fetchAllPages } from '../utils/fetchAll';

// ---- Icons ---------------------------------------------------
const Ico = ({ d, size = 15 }: { d: React.ReactNode; size?: number }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor"
       strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{d}</svg>
);
const I = {
  spark: <><path d="M12 3v4M12 17v4M3 12h4M17 12h4" /><circle cx="12" cy="12" r="3.5" /></>,
  text: <><path d="M4 6h16M4 12h16M4 18h10" /></>,
  wave: <><path d="M3 12h2l2-7 3 14 3-11 2 6 2-3h4" /></>,
  bolt: <><path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z" /></>,
  warn: <><path d="M12 9v4M12 17h.01" /><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1" /></>,
  phoneIn: <><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  target: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="4" /></>,
  book: <><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" /></>,
  refresh: <><path d="M21 12a9 9 0 1 1-3-6.7" /><path d="M21 3v6h-6" /></>,
};

// ---- Sentiment -----------------------------------------------
// Each theme colour means one thing, so sentiment borrows the outcome
// colours: won for a good call, lost for a bad one.
const SENTIMENT: Record<Sentiment, { label: string; chip: string; rail: string }> = {
  positive: { label: 'Positive', chip: 'c-won',  rail: 'var(--won)' },
  neutral:  { label: 'Neutral',  chip: 'c-mute', rail: 'var(--line-3)' },
  negative: { label: 'Negative', chip: 'c-lost', rail: 'var(--lost)' },
};

const FILTERS: Array<{ key: string; label: string; sentiment?: Sentiment; status?: string }> = [
  { key: 'all',      label: 'All calls' },
  { key: 'negative', label: 'Negative',  sentiment: 'negative' },
  { key: 'neutral',  label: 'Neutral',   sentiment: 'neutral' },
  { key: 'positive', label: 'Positive',  sentiment: 'positive' },
  { key: 'failed',   label: 'Failed',    status: 'failed' },
];

function SentimentChip({ sentiment, score }: { sentiment: Sentiment | ''; score: number | null }) {
  if (!sentiment) return <span className="chip c-mute">Not scored</span>;
  const s = SENTIMENT[sentiment];
  return (
    <span className={`chip ${s.chip}`}>
      <i className="pip" />
      {s.label}
      {score !== null && <span className="num" style={{ opacity: 0.75 }}>{score.toFixed(1)}</span>}
    </span>
  );
}

/** Who, to whom, when, how long. Shared by the row and the detail header. */
function CallMeta({ insight }: { insight: CallInsight }) {
  const who = insight.lead_name || insight.phone_number || 'Unknown number';
  return (
    <div className="ci-meta">
      <span><Ico d={I.user} size={12} />{insight.agent_name || 'Unassigned'}</span>
      <span><Ico d={I.phoneIn} size={12} />{who}</span>
      {insight.call_started_at && (
        <span><Ico d={I.clock} size={12} />{fmtDateTime(insight.call_started_at)}</span>
      )}
      {insight.duration_seconds > 0 && (
        <span className="num">{formatDuration(insight.duration_seconds)}</span>
      )}
    </div>
  );
}

// ---- Detail --------------------------------------------------
function Points({ title, items, icon, tone }: {
  title: string; items: string[]; icon: React.ReactNode; tone: string;
}) {
  if (!items.length) return null;
  return (
    <div className="ci-block">
      <div className="ci-block-h" style={{ color: tone }}>{icon}{title}</div>
      <ul className="ci-list">
        {items.map((item, i) => <li key={i}>{item}</li>)}
      </ul>
    </div>
  );
}

function Callout({ title, body, icon, tone, bg }: {
  title: string; body: string; icon: React.ReactNode; tone: string; bg: string;
}) {
  return (
    <div className="ci-callout" style={{ background: bg, borderColor: tone }}>
      <div className="ci-block-h" style={{ color: tone, marginBottom: 5 }}>{icon}{title}</div>
      <div style={{ fontSize: 13, lineHeight: 1.6 }}>{body}</div>
    </div>
  );
}

function InsightDetail({ insight, onClose }: { insight: CallInsight; onClose: () => void }) {
  const qc = useQueryClient();
  const nav = useNavigate();
  const { showToast } = useToast();

  const reanalyse = useMutation({
    mutationFn: () => aiApi.analyse(insight.call),
    onSuccess: (res) => {
      showToast('info', 'Queued', res?.data?.transcribing
        ? 'Transcribing the recording first, then the summary. Refresh in a minute.'
        : 'Re-analysis started. Refresh in a moment.');
      qc.invalidateQueries({ queryKey: ['ai-insights'] });
      onClose();
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not queue re-analysis.')),
  });

  const unfinished = insight.status !== 'done';

  return (
    <Modal title={insight.lead_name || insight.phone_number || 'Call insight'}
           subtitle={insight.agent_name ? `Handled by ${insight.agent_name}` : undefined}
           onClose={onClose} maxWidth="720px">
      <div className="flex items-center justify-between gap-3 flex-wrap mb-3">
        <SentimentChip sentiment={insight.sentiment} score={insight.sentiment_score} />
        {insight.suggested_disposition_name && (
          <span className="chip c-brand">
            <Ico d={I.target} size={12} />
            Suggested: {insight.suggested_disposition_name}
          </span>
        )}
      </div>

      <CallMeta insight={insight} />

      {/* An analysis that never completed used to render as a blank body with
          a status word buried in the list. Say what happened instead. */}
      {unfinished ? (
        <div className="ci-callout" style={{ background: 'var(--warm-50)', borderColor: 'var(--warm)', marginTop: 14 }}>
          <div className="ci-block-h" style={{ color: 'var(--warm-ink)', marginBottom: 5 }}>
            <Ico d={I.warn} size={13} />
            {insight.status === 'failed' ? 'Analysis failed'
              : insight.status === 'skipped' ? 'Analysis skipped'
              : 'Not analysed yet'}
          </div>
          <div style={{ fontSize: 13, lineHeight: 1.6 }}>
            {insight.error || 'Re-analyse below to try again once a transcript exists.'}
          </div>
        </div>
      ) : (
        <>
          <p style={{ fontSize: 14, lineHeight: 1.7, marginTop: 14 }}>{insight.summary}</p>

          <div style={{ display: 'grid', gap: 18, gridTemplateColumns: '1fr 1fr', marginTop: 4 }}>
            <Points title="Key points" items={insight.key_points}
                    icon={<Ico d={I.text} size={13} />} tone="var(--brand)" />
            <Points title="Objections" items={insight.objections}
                    icon={<Ico d={I.warn} size={13} />} tone="var(--lost)" />
          </div>

          {insight.next_action && (
            <Callout title="Next action" body={insight.next_action}
                     icon={<Ico d={I.target} size={13} />}
                     tone="var(--brand)" bg="var(--brand-50)" />
          )}
          {insight.coaching_notes && (
            <Callout title="Coaching" body={insight.coaching_notes}
                     icon={<Ico d={I.book} size={13} />}
                     tone="var(--brass)" bg="var(--brass-50)" />
          )}
        </>
      )}

      <div className="flex items-center justify-between gap-3 flex-wrap mt-4 pt-3"
           style={{ borderTop: '1px solid var(--line)' }}>
        <span className="num" style={{ fontSize: 10.5, color: 'var(--text-3)' }}>
          {insight.model || 'no model'} · {(insight.input_tokens + insight.output_tokens).toLocaleString('en-IN')} tokens
          {insight.generated_at && ` · analysed ${fmtDateTime(insight.generated_at)}`}
        </span>
        <div className="flex gap-2">
          {insight.lead && (
            <button className="btn btn-g" onClick={() => nav(`/leads/${insight.lead}`)}>
              Open lead
            </button>
          )}
          <button className="btn btn-p" disabled={reanalyse.isPending}
                  onClick={() => reanalyse.mutate()}>
            <Ico d={I.refresh} size={14} />
            {reanalyse.isPending ? 'Queueing…' : 'Re-analyse'}
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ---- Page ----------------------------------------------------
export default function CallInsightsPage() {
  const { agent } = useAuthStore();
  const { showToast } = useToast();
  const qc = useQueryClient();
  const [filter, setFilter] = useState('all');
  const [agentId, setAgentId] = useState('');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<CallInsight | null>(null);

  const isAdmin = isAdminRole(agent);
  const active = FILTERS.find(f => f.key === filter) ?? FILTERS[0];

  const { data, isLoading } = useQuery({
    queryKey: ['ai-insights', filter, agentId, page],
    queryFn: () => aiApi.insights({
      sentiment: active.sentiment,
      status: active.status,
      agent: agentId || undefined,
      page,
    }).then(r => r.data),
  });

  // Usage and the agent roster are both admin-only on the backend; don't
  // even ask otherwise, or every non-admin load fires two 403s.
  const { data: usage } = useQuery({
    queryKey: ['ai-usage'],
    queryFn: () => aiApi.usage().then(r => r.data),
    enabled: isAdmin,
  });
  const { data: agents } = useQuery({
    queryKey: ['agents-for-insights'],
    queryFn: () => fetchAllPages(page => authApi.listAgents({ page_size: 100, page })),
    enabled: isAdmin,
  });

  const backfill = useMutation({
    mutationFn: () => aiApi.backfill(50),
    onSuccess: () => {
      showToast('info', 'Queued', 'Up to 50 recordings are being transcribed. Summaries appear here in a minute or two.');
      qc.invalidateQueries({ queryKey: ['ai-usage'] });
      qc.invalidateQueries({ queryKey: ['ai-insights'] });
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not start the backfill.')),
  });

  const insights = data?.results ?? [];
  const totalPages = Math.ceil((data?.count ?? 0) / 25);
  const reset = (fn: () => void) => { fn(); setPage(1); };

  return (
    <div style={{ padding: 20 }}>
      <SectionHeader title="AI Call Summary" sub="What the AI heard on every recorded call">
        {isAdmin && (
          <button className="btn btn-g" disabled={backfill.isPending}
                  onClick={() => backfill.mutate()}>
            {backfill.isPending ? 'Queueing…'
              : usage?.recordings_waiting ? `Summarise ${usage.recordings_waiting} waiting call${usage.recordings_waiting === 1 ? '' : 's'}`
              : 'Backfill older calls'}
          </button>
        )}
      </SectionHeader>

      {/* Without the server's Gemini key nothing is ever transcribed, and
          the page used to just stay empty with no reason given. */}
      {usage && usage.gemini_configured === false && (
        <div className="plate mb-4" style={{ padding: '12px 14px', borderColor: 'var(--hot)' }}>
          <b>AI summaries are switched off on the server.</b>{' '}
          <span style={{ color: 'var(--text-2)' }}>
            Add <code>GEMINI_API_KEY</code> to the backend <code>.env</code> and restart the web and
            worker containers. {usage.recordings_waiting
              ? `${usage.recordings_waiting} recorded call${usage.recordings_waiting === 1 ? ' is' : 's are'} waiting; `
              : ''}
            then press “Summarise waiting calls”.
          </span>
        </div>
      )}

      {usage && (
        <div className="grid gap-4 mb-5" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
          <Kpi label="Calls analysed" value={usage.calls_analysed} tone="brand"
               icon={<Ico d={I.spark} />} note="Summarised and scored" />
          <Kpi label="Transcribed" value={usage.calls_transcribed} tone="visit"
               icon={<Ico d={I.text} />} note="Recordings turned into text" />
          <Kpi label="Audio processed" value={formatDuration(usage.audio_seconds)} tone="cold"
               icon={<Ico d={I.wave} />} note="Total recording length" />
          {usage.failed_insights > 0 ? (
            <Kpi label="Failed" value={usage.failed_insights} tone="hot"
                 icon={<Ico d={I.warn} />} note="Tap to review and re-run"
                 onClick={() => reset(() => setFilter('failed'))} />
          ) : (
            <Kpi label="Tokens used"
                 value={(usage.input_tokens + usage.output_tokens).toLocaleString('en-IN')}
                 tone="brass" icon={<Ico d={I.bolt} />} note="Input plus output, to date" />
          )}
        </div>
      )}

      {/* ---- Filters ---- */}
      <div className="flex gap-3 items-end flex-wrap mb-4">
        <div className="seg">
          {FILTERS.map(f => (
            <button key={f.key} onClick={() => reset(() => setFilter(f.key))}
                    className={`seg-btn ${filter === f.key ? 'on' : ''}`}>
              {f.label}
            </button>
          ))}
        </div>
        {isAdmin && !!agents?.results?.length && (
          <div style={{ minWidth: 200 }}>
            <Select label="Agent" value={agentId}
                    onChange={e => reset(() => setAgentId(e.target.value))}>
              <option value="">Everyone</option>
              {agents.results.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
            </Select>
          </div>
        )}
        {!!data?.count && (
          <span className="num" style={{ fontSize: 11.5, color: 'var(--text-3)', paddingBottom: 9 }}>
            {data.count} call{data.count === 1 ? '' : 's'}
          </span>
        )}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16"><Spinner /></div>
      ) : !insights.length ? (
        <EmptyState
          icon="◈"
          title={filter === 'all' && !agentId ? 'No insights yet' : 'Nothing matches'}
          message={
            filter === 'all' && !agentId
              ? 'Call summaries appear here once agents upload call recordings. Older recordings can be backfilled.'
              : 'No calls match this filter. Clear it to see the whole queue.'
          }
          action={filter === 'all' && !agentId ? undefined : {
            label: 'Clear filters',
            onClick: () => reset(() => { setFilter('all'); setAgentId(''); }),
          }}
        />
      ) : (
        <>
          <div className="plate" style={{ overflow: 'hidden' }}>
            {insights.map(i => {
              const rail = i.sentiment ? SENTIMENT[i.sentiment].rail : 'var(--line-2)';
              const unfinished = i.status !== 'done';
              return (
                <button key={i.id} className="ci-row" onClick={() => setSelected(i)}>
                  <span className="ci-rail" style={{ background: rail }} />
                  <span className="ci-body">
                    <span className="ci-top">
                      <SentimentChip sentiment={i.sentiment} score={i.sentiment_score} />
                      {unfinished && (
                        <span className={`chip ${i.status === 'failed' ? 'c-lost' : 'c-warm'}`}>
                          {i.status}
                        </span>
                      )}
                      {i.objections.length > 0 && (
                        <span className="chip c-warm">
                          {i.objections.length} objection{i.objections.length === 1 ? '' : 's'}
                        </span>
                      )}
                      {i.suggested_disposition_name && (
                        <span className="chip c-brand">{i.suggested_disposition_name}</span>
                      )}
                    </span>

                    <span className="ci-summary">
                      {i.summary || (
                        <em style={{ color: 'var(--text-3)' }}>
                          {i.error || 'No summary was produced for this call.'}
                        </em>
                      )}
                    </span>

                    <CallMeta insight={i} />
                  </span>
                </button>
              );
            })}
          </div>
          <Pagination page={page} totalPages={totalPages} onPageChange={setPage} />
        </>
      )}

      {selected && <InsightDetail insight={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
