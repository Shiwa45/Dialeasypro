// ============================================================
// DialSathi — Call log
//
// A supervisor's record of every dial. The old screen had six dingbat stat
// cards, a filter strip of unlabelled selects, no search of any kind, and an
// <audio> element inlined into all 25 rows. Two header buttons were wired to
// the wrong places: "Call Stats" opened the CSV lead importer.
//
// Rebuilt around finding a call and listening to it. Search over number,
// lead and agent; one player, opened on the row you asked for; and a detail
// view for everything else the log holds. The outcome mix that used to sit
// above the filters was removed at the client's request — the same numbers
// are on the Reports screen.
//
// Transcripts and AI analysis are not here on purpose — they belong to the AI
// Suite and live at /insights.
// ============================================================
import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { callsApi } from '../api';
import {
  EmptyState, Kpi, Modal, Pagination, SectionHeader, Select, Spinner, useToast,
} from '../components/ui';
import { fmtDateTime, fmtRelative, formatDuration, localISODate } from '../utils/fmt';
import CallOutcomeModal from '../components/CallOutcomeModal';
import { getErrorMessage } from '../utils/errors';
import { useWorkspace } from '../hooks/useWorkspace';
import type { CallDirection, CallLog } from '../types';

// ---- Icons ---------------------------------------------------
const Ico = ({ d, size = 15 }: { d: React.ReactNode; size?: number }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor"
       strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{d}</svg>
);
const I = {
  phone: <><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z" /></>,
  check: <><path d="M20 6 9 17l-5-5" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  gauge: <><path d="M12 14 20 6" /><path d="M3.5 18a9 9 0 1 1 17 0" /></>,
  rupee: <><path d="M7 4h10M7 9h10M15 4c0 5-3.5 5-8 5l8 10" /></>,
  play: <><path d="m7 4 13 8-13 8V4Z" /></>,
  out: <><path d="M7 17 17 7M9 7h8v8" /></>,
  in: <><path d="M17 7 7 17M15 17H7V9" /></>,
  missed: <><path d="M18 6 6 18M6 6l12 12" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></>,
  note: <><path d="M4 6h16M4 12h16M4 18h10" /></>,
  open: <><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M21 14v7H3V3h7" /></>,
};

// Direction is three values, not two. `missed` is a real one and the old
// screen rendered it with the inbound arrow, quietly filing every missed call
// as a received one.
const DIRECTION: Record<CallDirection, { label: string; chip: string; icon: React.ReactNode }> = {
  outbound: { label: 'Out',    chip: 'c-visit', icon: <Ico d={I.out} size={12} /> },
  inbound:  { label: 'In',     chip: 'c-won',   icon: <Ico d={I.in} size={12} /> },
  missed:   { label: 'Missed', chip: 'c-lost',  icon: <Ico d={I.missed} size={12} /> },
};

const BLANK = {
  q: '', direction: '', connected: '', disposition: '',
  has_recording: '', date_from: '', date_to: '',
};

export default function Calls() {
  const nav = useNavigate();
  // Agent workspace: these are always the caller's own calls (the API scopes
  // them), so the Agent column and the link to team reports go. Read-only
  // additionally can't call anyone back.
  const { isAgentWorkspace, isReadOnly } = useWorkspace();
  const { showToast } = useToast();
  const [page, setPage] = useState(1);
  const [filters, setFilters] = useState(BLANK);
  const [playing, setPlaying] = useState<string | null>(null);
  const [detail, setDetail] = useState<CallLog | null>(null);
  // A call waiting for its outcome (no outcome yet, or just placed).
  const [outcomeFor, setOutcomeFor] = useState<Pick<CallLog, 'id' | 'lead' | 'lead_name' | 'phone_number' | 'is_connected' | 'duration_seconds'> | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['calls', page, filters],
    queryFn: () => callsApi.list({
      page, page_size: 25,
      q: filters.q || undefined,
      direction: filters.direction || undefined,
      connected: filters.connected || undefined,
      disposition: filters.disposition || undefined,
      has_recording: filters.has_recording || undefined,
      date_from: filters.date_from || undefined,
      date_to: filters.date_to || undefined,
    }).then(r => r.data),
    placeholderData: prev => prev,
  });

  // The boxes describe the same calls as the list: the From/To filter when
  // one is set, today otherwise. They used to mix today's counts with an
  // all-time connection rate and average, and ignored the date filter.
  const today = localISODate();
  const statsFrom = filters.date_from || (filters.date_to ? '' : today);
  const statsTo = filters.date_to || (filters.date_from ? '' : today);
  const rangeLabel = !filters.date_from && !filters.date_to ? 'today' : 'in this range';
  // …and the list's other filters: searching an agent used to filter the
  // list but leave the boxes on everyone's calls.
  const { data: stats } = useQuery({
    queryKey: ['call-stats', statsFrom, statsTo, filters.q, filters.direction, filters.connected,
               filters.disposition, filters.has_recording],
    queryFn: () => callsApi.stats({
      date_from: statsFrom || undefined, date_to: statsTo || undefined,
      q: filters.q || undefined,
      direction: filters.direction || undefined,
      connected: filters.connected || undefined,
      disposition: filters.disposition || undefined,
      has_recording: filters.has_recording || undefined,
    }).then(r => r.data),
    refetchInterval: 30000,
  });

  const { data: dispositions } = useQuery({
    queryKey: ['call-dispositions'],
    queryFn: () => callsApi.dispositions().then(r => r.data),
  });

  const clickToCall = useMutation({
    mutationFn: ({ lead_id }: { lead_id: number }) => callsApi.clickToCall(lead_id),
    // The API says whether anything was dialled: in manual mode it only logs
    // the call, so promising a ring was wrong.
    onSuccess: (res: { data?: { dialed?: boolean; message?: string; call_id?: string } }, vars) => {
      showToast('success', res.data?.dialed ? 'Call initiated' : 'Call logged', res.data?.message ?? '');
      // Ask for the outcome; it can also be set later from the row.
      if (res.data?.call_id) {
        const from = calls.find(c => c.lead === vars.lead_id);
        setOutcomeFor({ id: res.data.call_id, lead: vars.lead_id, lead_name: from?.lead_name ?? null,
                        phone_number: from?.phone_number ?? '', is_connected: false, duration_seconds: 0 });
      }
    },
    onError: (e: unknown) => showToast('error', 'Call failed', getErrorMessage(e, 'Check your calling integration settings.')),
  });

  const calls = data?.results ?? [];
  const dirty = Object.values(filters).some(Boolean);

  const set = (k: keyof typeof BLANK) =>
    (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
      setFilters(p => ({ ...p, [k]: e.target.value }));
      setPage(1);
    };

  return (
    <div style={{ padding: 20 }}>
      <SectionHeader title={isAgentWorkspace ? 'My call history' : 'Call log'}
                     sub={`${data?.count ?? 0} calls${dirty ? ' matching' : ''}`}>
        {/* Both buttons here used to go somewhere else entirely: "Go to Lead"
            to the lead list, and "Call Stats" to the CSV importer. */}
        {!isAgentWorkspace && (
          <button className="btn btn-g" onClick={() => nav('/reports')}>Call reports</button>
        )}
        {!isReadOnly && (
          <button className="btn btn-p" onClick={() => nav('/leads')}>
            <Ico d={I.phone} size={14} />
            {isAgentWorkspace ? 'Go to my leads' : 'Start dialling'}
          </button>
        )}
      </SectionHeader>

      {/* ---- Today and period ---- */}
      <div className="grid gap-4 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))' }}>
        <Kpi label={`Calls ${rangeLabel}`} value={stats?.period.total_calls ?? 0} tone="brand"
             icon={<Ico d={I.phone} />}
             note={`${stats?.period.connected_calls ?? 0} connected`} />
        <Kpi label={`Talk time ${rangeLabel}`}
             value={formatDuration(stats?.period.total_duration_seconds ?? 0)}
             tone="visit" icon={<Ico d={I.clock} />} note="Connected time" />
        <Kpi label="Connection rate" value={`${stats?.period.connection_rate ?? 0}%`}
             tone="won" icon={<Ico d={I.check} />}
             note={`${stats?.period.connected_calls ?? 0} of ${stats?.period.total_calls ?? 0} answered`} />
        <Kpi label="Average call duration"
             value={formatDuration(stats?.period.avg_duration_seconds ?? 0)}
             tone="cold" icon={<Ico d={I.gauge} />} note={`Connected calls ${rangeLabel}`} />
      </div>

      {/* ---- Filters ---- */}
      <div className="plate no-ticks mb-4" style={{ padding: 14 }}>
        <div className="flex gap-3 items-end flex-wrap">
          <div style={{ position: 'relative', minWidth: 240, flex: 1, maxWidth: 340 }}>
            <label className="field-label" htmlFor="call-q">Search</label>
            <span style={{
              position: 'absolute', left: 11, top: 30, color: 'var(--text-3)',
              pointerEvents: 'none', display: 'flex',
            }}>
              <Ico d={I.search} size={14} />
            </span>
            <input id="call-q" className="input-brutal" value={filters.q}
                   onChange={set('q')} placeholder="Number, lead or agent…"
                   style={{ width: '100%', paddingLeft: 32 }} />
          </div>

          <div style={{ minWidth: 150 }}>
            <Select label="Direction" value={filters.direction} onChange={set('direction')}>
              <option value="">Any direction</option>
              <option value="outbound">Outbound</option>
              <option value="inbound">Inbound</option>
              <option value="missed">Missed</option>
            </Select>
          </div>

          <div style={{ minWidth: 150 }}>
            <Select label="Call status" value={filters.connected} onChange={set('connected')}>
              <option value="">Answered or not</option>
              <option value="true">Answered</option>
              <option value="false">Not answered</option>
            </Select>
          </div>

          <div style={{ minWidth: 170 }}>
            <Select label="Outcome" value={filters.disposition} onChange={set('disposition')}>
              <option value="">Any outcome</option>
              <option value="none">Needs an outcome</option>
              <optgroup label="Answered calls">
                {(dispositions ?? []).filter(d => d.category === 'connected').map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </optgroup>
              <optgroup label="Unanswered calls">
                {(dispositions ?? []).filter(d => d.category === 'not_connected').map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </optgroup>
            </Select>
          </div>

          <div style={{ minWidth: 150 }}>
            <Select label="Recording" value={filters.has_recording} onChange={set('has_recording')}>
              <option value="">Any</option>
              <option value="true">Has a recording</option>
              <option value="false">No recording</option>
            </Select>
          </div>

          <div style={{ minWidth: 145 }}>
            <label className="field-label" htmlFor="call-from">From</label>
            <input id="call-from" type="date" className="input-brutal" style={{ width: '100%' }}
                   value={filters.date_from} onChange={set('date_from')} />
          </div>
          <div style={{ minWidth: 145 }}>
            <label className="field-label" htmlFor="call-to">To</label>
            <input id="call-to" type="date" className="input-brutal" style={{ width: '100%' }}
                   value={filters.date_to} onChange={set('date_to')} />
          </div>

          {dirty && (
            <button className="btn btn-g" onClick={() => { setFilters(BLANK); setPage(1); }}>
              Clear
            </button>
          )}
        </div>
      </div>

      {/* ---- The log ---- */}
      {isLoading ? (
        <div className="flex justify-center py-16"><Spinner /></div>
      ) : !calls.length ? (
        <EmptyState
          icon="☎"
          title={dirty ? 'No calls match' : 'No calls yet'}
          message={dirty
            ? 'Nothing in the log matches these filters.'
            : 'Calls appear here as agents dial, and when recordings are uploaded from the mobile app.'}
          action={dirty ? { label: 'Clear filters', onClick: () => { setFilters(BLANK); setPage(1); } } : undefined}
        />
      ) : (
        <div className="plate" style={{ overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table className="table-brutal" style={{ minWidth: 940 }}>
              <thead>
                <tr>
                  <th>Direction</th>
                  <th>Lead</th>
                  <th>Number</th>
                  {!isAgentWorkspace && <th>Agent</th>}
                  <th>Outcome</th>
                  <th>Recording</th>
                  <th>When</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {calls.map(c => {
                  const dir = DIRECTION[c.direction as CallDirection] ?? DIRECTION.outbound;
                  const open = playing === c.id;
                  return (
                    <tr key={c.id} style={{ cursor: 'pointer' }}
                        onClick={() => setDetail(c)}>
                      <td>
                        <span className={`chip ${dir.chip}`}>{dir.icon}{dir.label}</span>
                      </td>
                      <td>
                        {c.lead ? (
                          <button className="link-cell"
                                  onClick={e => { e.stopPropagation(); nav(`/leads/${c.lead}`); }}>
                            {c.lead_name}
                          </button>
                        ) : <span style={{ color: 'var(--text-3)' }} title="The lead was deleted">{c.lead_name ?? 'Unknown'}</span>}
                        <div style={{ marginTop: 3 }}>
                          {c.disposition_name ? (
                            <span className="chip c-mute">{c.disposition_name}</span>
                          ) : !isReadOnly ? (
                            <button className="chip c-warm" style={{ cursor: 'pointer' }}
                                    onClick={e => { e.stopPropagation(); setOutcomeFor(c); }}>
                              Set outcome
                            </button>
                          ) : <span className="chip c-warm">No outcome</span>}
                        </div>
                      </td>
                      <td className="num" style={{ fontSize: 12.5 }}>{c.phone_number}</td>
                      {!isAgentWorkspace && <td>{c.agent_name ?? '—'}</td>}
                      <td>
                        <span className={`chip ${c.is_connected ? 'c-won' : 'c-mute'}`}>
                          <i className="pip" />
                          {c.is_connected ? 'Answered' : 'Not answered'}
                        </span>
                      </td>
                      <td style={{ minWidth: 190 }}>
                        {/* One player, on the row you asked for. Inlining an
                            <audio> into all 25 rows made the browser build 25
                            media elements for a page where at most one gets
                            played. */}
                        {c.recording?.playback_url ? (
                          open ? (
                            <audio controls autoPlay preload="none"
                                   src={c.recording.playback_url}
                                   onClick={e => e.stopPropagation()}
                                   style={{ height: 32, maxWidth: 190 }} />
                          ) : (
                            <button className="btn btn-g btn-sm"
                                    onClick={e => { e.stopPropagation(); setPlaying(c.id); }}>
                              <Ico d={I.play} size={12} />
                              {c.recording.duration_seconds
                                ? formatDuration(c.recording.duration_seconds)
                                : 'Play'}
                            </button>
                          )
                        ) : c.recording ? (
                          // A recording row exists but carries no playable URL —
                          // upload failed, or the file was never attached. A
                          // bare dash here would contradict the "has a
                          // recording" filter, which counts this row.
                          <span className="chip c-warm" title="A recording is logged but no audio file is available">
                            No audio
                          </span>
                        ) : (
                          <span style={{ color: 'var(--text-3)', fontSize: 12 }}>—</span>
                        )}
                      </td>
                      <td style={{ fontSize: 12, color: 'var(--text-3)', whiteSpace: 'nowrap' }}>
                        {fmtRelative(c.started_at)}
                      </td>
                      <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                        <div className="flex gap-2" style={{ justifyContent: 'flex-end' }}>
                          <button className="btn btn-g btn-sm" onClick={() => setDetail(c)}>
                            Details
                          </button>
                          {c.lead && !isReadOnly && (
                            <button className="btn btn-g btn-sm"
                                    disabled={clickToCall.isPending}
                                    onClick={e => { e.stopPropagation(); clickToCall.mutate({ lead_id: c.lead! }); }}>
                              <Ico d={I.phone} size={12} />
                              Call back
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div style={{ padding: '4px 16px 14px' }}>
            <Pagination page={page} totalPages={data?.total_pages ?? 1} onPageChange={setPage} />
          </div>
        </div>
      )}

      {detail && (
        <CallDetail call={detail} onClose={() => setDetail(null)}
                    onCallBack={isReadOnly ? undefined : (id => clickToCall.mutate({ lead_id: id }))} />
      )}
      {outcomeFor && <CallOutcomeModal mode="set" call={outcomeFor} onClose={() => setOutcomeFor(null)} />}
    </div>
  );
}

/* ---- Call detail --------------------------------------------
   The table row is a summary; this is everything the log holds about one
   call. There was no way to reach any of it before — the notes an agent
   typed, the provider's call id and the cost were all fetched with the list
   and shown nowhere.

   Deliberately no transcript and no AI analysis. Those belong to the AI Suite
   and have their own screen at /insights; duplicating them here made the call
   log a second, worse version of it. This screen answers what the call was
   and lets you listen to it.

   The row object carries everything shown here, so it opens with no request
   of its own. */
function CallDetail({ call, onClose, onCallBack }: {
  call: CallLog;
  onClose: () => void;
  /** Absent → no call-back button (read-only users). */
  onCallBack?: (leadId: number) => void;
}) {
  const nav = useNavigate();

  const dir = DIRECTION[call.direction as CallDirection] ?? DIRECTION.outbound;
  const rec = call.recording;
  const cost = (call.call_cost_paise ?? 0) / 100;

  return (
    <Modal title={call.lead_name || call.phone_number || 'Call'}
           subtitle={call.agent_name ? `Handled by ${call.agent_name}` : undefined}
           onClose={onClose} maxWidth="760px">
      <div className="flex gap-2 flex-wrap mb-4">
        <span className={`chip ${dir.chip}`}>{dir.icon}{dir.label}</span>
        <span className={`chip ${call.is_connected ? 'c-won' : 'c-mute'}`}>
          <i className="pip" />{call.is_connected ? 'Connected' : 'No answer'}
        </span>
        {call.disposition_name && <span className="chip c-brand">{call.disposition_name}</span>}
      </div>

      <div className="grid gap-4 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))' }}>
        <Fact label="Number" value={call.phone_number} mono />
        <Fact label="Started" value={call.started_at ? fmtDateTime(call.started_at) : '—'} />
        <Fact label="Ended" value={call.ended_at ? fmtDateTime(call.ended_at) : 'Not recorded'} />
        <Fact label="Duration" value={call.duration_display || '—'} mono />
      </div>

      {call.notes && (
        <Block title="Agent notes" icon={<Ico d={I.note} size={13} />} tone="var(--text-2)">
          <div style={{ fontSize: 13, lineHeight: 1.65, whiteSpace: 'pre-line' }}>{call.notes}</div>
        </Block>
      )}

      {/* ---- Recording ---- */}
      <Block title="Call recording" icon={<Ico d={I.play} size={13} />} tone="var(--brand)">
        {!rec ? (
          <Muted>No recording was captured for this call.</Muted>
        ) : rec.playback_url ? (
          <>
            <audio controls preload="none" src={rec.playback_url} style={{ width: '100%', height: 36 }} />
            <Muted style={{ marginTop: 8 }}>
              {[
                rec.duration_seconds ? formatDuration(rec.duration_seconds) : null,
                rec.format ? rec.format.toUpperCase() : null,
              ].filter(Boolean).join(' · ')}
            </Muted>
          </>
        ) : (
          <Muted>
            A recording is logged{rec.duration_seconds ? ` (${formatDuration(rec.duration_seconds)})` : ''},
            but no audio file is available to play.
          </Muted>
        )}
      </Block>

      {/* ---- Provenance ---- */}
      <div className="flex items-center justify-between gap-3 flex-wrap mt-4 pt-3"
           style={{ borderTop: '1px solid var(--line)' }}>
        <span className="num" style={{ fontSize: 10.5, color: 'var(--text-3)' }}>
          {[
            call.provider || 'no provider',
            call.provider_call_id || null,
            cost > 0 ? `₹${cost.toFixed(2)}` : null,
          ].filter(Boolean).join(' · ')}
        </span>
        <div className="flex gap-2">
          {call.lead && (
            <button className="btn btn-g" onClick={() => nav(`/leads/${call.lead}`)}>
              <Ico d={I.open} size={13} />
              Open lead
            </button>
          )}
          {call.lead && onCallBack && (
            <button className="btn btn-p" onClick={() => onCallBack(call.lead!)}>
              <Ico d={I.phone} size={13} />
              Call back
            </button>
          )}
        </div>
      </div>
    </Modal>
  );
}

function Fact({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div style={{ minWidth: 0 }}>
      <div className="kpi-l">{label}</div>
      <div className={mono ? 'num' : undefined}
           style={{ fontSize: 13, marginTop: 5, wordBreak: 'break-word' }}>{value}</div>
    </div>
  );
}

function Block({ title, icon, tone, children }: {
  title: string; icon: React.ReactNode; tone: string; children: React.ReactNode;
}) {
  return (
    <div style={{ marginTop: 18 }}>
      <div className="ci-block-h" style={{ color: tone, marginBottom: 8 }}>{icon}{title}</div>
      {children}
    </div>
  );
}

function Muted({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return <div style={{ fontSize: 12.5, color: 'var(--text-3)', ...style }}>{children}</div>;
}
