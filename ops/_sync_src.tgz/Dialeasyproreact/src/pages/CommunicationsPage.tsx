import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { commsApi, leadsApi, senderLabel } from '../api';
import type { WhatsAppTemplate } from '../types';
import { LEAD_VARIABLE_FIELDS, placeholdersIn } from './communications/templateVariables';
import {
  ConfirmDialog, SectionHeader, Modal, Input, Select, Textarea, Spinner,
  EmptyState, StatusBadge, useToast,
} from '../components/ui';
import { getErrorMessage } from '../utils/errors';
import { useAuthStore } from '../store/authStore';
import { isAdmin as isAdminRole } from '../utils/roles';

export default function Communications() {
  const { showToast } = useToast();
  const qc = useQueryClient();
  const [tab, setTab] = useState<'templates' | 'send'>('templates');
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [confirmRemove, setConfirmRemove] = useState<number | null>(null);
  // Approving is a claim about what Meta permits, so it is an admin action —
  // the API enforces the same.
  const isAdmin = isAdminRole(useAuthStore(st => st.agent));
  const EMPTY_TPL = {
    name: '', category: 'marketing', body_text: '', language: 'en', provider: 'interakt',
    provider_template_id: '', variable_mapping: {} as Record<string, string>,
    // The WhatsApp number it was approved on ('' = any number).
    account: '' as string,
  };
  const [tplForm, setTplForm] = useState(EMPTY_TPL);
  // null → creating; a template → editing it (wording, provider name, variables).
  const [editingTpl, setEditingTpl] = useState<WhatsAppTemplate | null>(null);
  const [sendForm, setSendForm] = useState({ lead_id: '', channel: 'whatsapp', message: '', template_id: '', sender_id: '', wa_from: '' });
  const [leadQuery, setLeadQuery] = useState('');
  const [pickedLead, setPickedLead] = useState<{ id: number; name: string; phone: string } | null>(null);

  const { data: customFields } = useQuery({
    queryKey: ['custom-fields'],
    queryFn: () => leadsApi.listCustomFields().then(r => r.data),
    staleTime: 300_000,
  });
  const variableChoices = [
    ...LEAD_VARIABLE_FIELDS,
    ...((customFields ?? []).filter(f => f.is_active).map(f => ({ value: `custom:${f.field_key}`, label: f.name }))),
  ];

  // The lead picker for a one-off message — typing a raw lead id was the
  // only way before, and nobody knows a lead's id.
  const { data: leadMatches } = useQuery({
    queryKey: ['comms-lead-search', leadQuery],
    queryFn: () => leadsApi.list({ search: leadQuery, page_size: 8 }).then(r => r.data.results),
    enabled: leadQuery.trim().length >= 2 && !pickedLead,
  });

  // The workspace's WhatsApp numbers. Templates belong to one (Meta approves
  // a template per WhatsApp Business Account), and a send picks one.
  const { data: senders } = useQuery({
    queryKey: ['wa-senders'],
    queryFn: () => commsApi.listWhatsAppSenders().then(r => r.data),
  });
  const multiNumber = (senders?.length ?? 0) > 1;
  // With a "send from" number picked, what that number can send: its own
  // templates, its WhatsApp Business Account's, and shared ones.
  const { data: fromTemplates } = useQuery({
    queryKey: ['wa-templates', sendForm.wa_from],
    queryFn: () => commsApi.listTemplates(true, Number(sendForm.wa_from)).then(r => r.data),
    enabled: !!sendForm.wa_from,
  });
  const activeSenders = (senders ?? []).filter(x => x.is_active);

  const openNewTemplate = () => {
    const def = senders?.find(x => x.is_default);
    setEditingTpl(null);
    setTplForm({ ...EMPTY_TPL, account: def ? String(def.id) : '', provider: def?.provider ?? EMPTY_TPL.provider });
    setShowTemplateModal(true);
  };
  const openEditTemplate = (t: WhatsAppTemplate) => {
    setEditingTpl(t);
    setTplForm({
      name: t.name, category: t.category, body_text: t.body_text, language: t.language,
      provider: t.provider, provider_template_id: t.provider_template_id ?? '',
      variable_mapping: { ...(t.variable_mapping ?? {}) },
      account: t.account ? String(t.account) : '',
    });
    setShowTemplateModal(true);
  };
  const formPlaceholders = placeholdersIn(tplForm.body_text);
  const formUnmapped = formPlaceholders.filter(n => !tplForm.variable_mapping[String(n)]);

  const { data: templates, isLoading } = useQuery({
    queryKey: ['wa-templates'],
    queryFn: () => commsApi.listTemplates().then(r => r.data),
  });

  const saveTplMut = useMutation({
    mutationFn: () => {
      // Only the placeholders the body still uses are sent — a mapping for a
      // {{3}} that was deleted from the wording would otherwise linger.
      const mapping: Record<string, string> = {};
      for (const n of formPlaceholders) {
        const v = tplForm.variable_mapping[String(n)];
        if (v) mapping[String(n)] = v;
      }
      const payload = {
        ...tplForm, variable_mapping: mapping,
        account: tplForm.account ? Number(tplForm.account) : null,
      };
      return editingTpl
        ? commsApi.updateTemplate(editingTpl.id, payload)
        : commsApi.createTemplate(payload);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['wa-templates'] });
      setShowTemplateModal(false);
      showToast('success', editingTpl ? 'Template saved' : 'Template created',
        editingTpl ? '' : 'Submit it to Meta for approval to use in bulk campaigns.');
      setEditingTpl(null);
      setTplForm(EMPTY_TPL);
    },
    onError: (e) => showToast('error', 'Could not save template', getErrorMessage(e)),
  });

  // A template is created "pending" and nothing could ever move it on, so
  // every template a tenant wrote stayed unusable and the bulk-campaign
  // template list was permanently empty. Meta decides approval; this records
  // the decision.
  const setStatusMut = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) =>
      commsApi.updateTemplate(id, { status } as Partial<import('../types').WhatsAppTemplate>),
    onSuccess: (_r, v) => {
      qc.invalidateQueries({ queryKey: ['wa-templates'] });
      showToast(
        'success',
        v.status === 'approved' ? 'Marked approved' : 'Status updated',
        v.status === 'approved' ? 'It can now be used in bulk campaigns.' : '',
      );
    },
    onError: (e) => showToast('error', 'Could not update', getErrorMessage(e)),
  });

  const removeTplMut = useMutation({
    mutationFn: (id: number) => commsApi.deleteTemplate(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['wa-templates'] });
      showToast('success', 'Template removed', 'Messages already sent with it keep their record.');
    },
    onError: (e) => showToast('error', 'Could not remove', getErrorMessage(e)),
  });

  const sendMut = useMutation({
    // Awaited and discarded: the two branches return differently-shaped
    // AxiosResponse generics, and inferring a union of them made the
    // MutationFunction type unassignable. Neither result is used.
    mutationFn: async (): Promise<void> => {
      if (sendForm.channel === 'whatsapp') {
        await commsApi.sendWhatsApp(
          Number(sendForm.lead_id),
          sendForm.message,
          sendForm.template_id ? Number(sendForm.template_id) : undefined,
          sendForm.wa_from ? Number(sendForm.wa_from) : null,
        );
      } else {
        await commsApi.sendSMS(
          Number(sendForm.lead_id), sendForm.message, sendForm.sender_id,
        );
      }
    },
    onSuccess: () => {
      setSendForm(p => ({ ...p, message: '', lead_id: '' }));
      setPickedLead(null); setLeadQuery('');
      showToast('success', 'Message queued', 'It will be delivered shortly.');
    },
    onError: (e: unknown) => showToast('error', 'Send failed', getErrorMessage(e, 'Check the WhatsApp connection in Settings.')),
  });

  const tf = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setTplForm(p => ({ ...p, [k]: e.target.value }));
  const sf = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setSendForm(p => ({ ...p, [k]: e.target.value }));

  const STATUS_COLORS: Record<string, string> = {
    approved: 'var(--won-50)', pending: 'var(--warm-50)', rejected: 'var(--lost-50)', paused: 'var(--surface-2)',
  };

  return (
    <div className="p-6 flex flex-col gap-4" style={{ background: 'var(--paper)', minHeight: '100%' }}>
      <SectionHeader title="Communications" sub="WhatsApp templates and one-off WhatsApp or SMS messages">
        {tab === 'templates' && (
          <button onClick={openNewTemplate}
                  className="btn-brutal btn-primary px-4 py-2.5 font-heading font-black"
                  style={{ fontSize: '0.85rem', boxShadow: 'var(--shadow)' }}>
            + New Template
          </button>
        )}
      </SectionHeader>

      <div style={{ display: 'flex', borderBottom: '1px solid var(--line)' }}>
        {(['templates', 'send'] as const).map((t, i) => (
          <button key={t} onClick={() => setTab(t)} className="font-heading font-bold px-5 py-2.5"
                  style={{ background: tab === t ? 'var(--brass-50)' : 'var(--surface)', border: 'none', borderRight: '1px solid var(--line)', cursor: 'pointer', fontSize: '0.82rem' }}>
            {t === 'templates' ? '▦ Message Templates' : '✉ Send Single Message'}
          </button>
        ))}
      </div>

      {tab === 'templates' && (
        isLoading ? <Spinner /> : (templates ?? []).length === 0 ? (
          <EmptyState icon="✉" title="No templates yet"
                      message="Create WhatsApp templates. They need Meta approval before use in bulk campaigns."
                      action={{ label: '+ New Template', onClick: openNewTemplate }} />
        ) : (
          <div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))' }}>
            {(templates ?? []).map(t => (
              <div key={t.id} className="card p-4" style={{ background: STATUS_COLORS[t.status] ?? 'var(--surface)' }}>
                <div className="flex items-start justify-between mb-2">
                  <div className="font-heading font-black" style={{ fontSize: '0.95rem' }}>{t.name}</div>
                  <StatusBadge status={t.status} />
                </div>
                <div className="flex gap-1 flex-wrap mb-2">
                  <span className="tag">{t.category}</span>
                  <span className="tag">{t.language.toUpperCase()}</span>
                  <span className="tag">{t.provider}</span>
                  {multiNumber && (
                    <span className="tag" title="The WhatsApp number it was approved on">
                      {t.account_label ?? 'Any number'}
                    </span>
                  )}
                </div>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-2)', lineHeight: 1.5, background: 'rgba(255,255,255,0.6)', padding: '8px', border: '1px solid var(--line)' }}>
                  {t.body_text}
                </p>
                {t.header_text && (
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginTop: '6px' }}>Header: {t.header_text}</div>
                )}
                {(t.unmapped ?? []).length > 0 && (
                  <div style={{ fontSize: '0.72rem', color: 'var(--hot)', marginTop: '6px', fontWeight: 700 }}>
                    ⚠ {(t.unmapped ?? []).map(n => `{{${n}}}`).join(', ')} not mapped to a lead field — it can't be sent until you map {(t.unmapped ?? []).length === 1 ? 'it' : 'them'}.
                  </div>
                )}
                {(t.placeholders ?? []).length > 0 && (t.unmapped ?? []).length === 0 && (
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginTop: '6px' }}>
                    {(t.placeholders ?? []).map(n => {
                      const f = t.variable_mapping?.[String(n)] ?? '';
                      return `{{${n}}} → ${variableChoices.find(c => c.value === f)?.label ?? f}`;
                    }).join(' · ')}
                  </div>
                )}
                <div style={{ fontSize: '0.7rem', color: 'var(--text-3)', marginTop: '6px' }}>
                  Used {t.usage_count} {t.usage_count === 1 ? 'time' : 'times'}
                </div>

                {isAdmin && (
                  <div className="flex gap-2 mt-3" style={{ flexWrap: 'wrap' }}>
                    <button className="btn btn-g" style={{ fontSize: '0.75rem' }}
                            onClick={() => openEditTemplate(t)}>
                      {(t.unmapped ?? []).length > 0 ? 'Map variables' : 'Edit'}
                    </button>
                    {t.status !== 'approved' && (
                      <button className="btn btn-g" style={{ fontSize: '0.75rem' }}
                              disabled={setStatusMut.isPending}
                              onClick={() => setStatusMut.mutate({ id: t.id, status: 'approved' })}>
                        Mark approved
                      </button>
                    )}
                    {t.status !== 'rejected' && (
                      <button className="btn btn-g" style={{ fontSize: '0.75rem' }}
                              disabled={setStatusMut.isPending}
                              onClick={() => setStatusMut.mutate({ id: t.id, status: 'rejected' })}>
                        Mark rejected
                      </button>
                    )}
                    <button className="btn btn-g" style={{ fontSize: '0.75rem', color: 'var(--hot)' }}
                            disabled={removeTplMut.isPending}
                            onClick={() => setConfirmRemove(t.id)}>
                      Remove
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )
      )}

      {tab === 'send' && (
        <div className="card p-5" style={{ maxWidth: '520px' }}>
          <div className="font-heading font-black mb-4" style={{ fontSize: '0.95rem' }}>Send Single Message</div>
          <div className="flex flex-col gap-3">
            {pickedLead ? (
              <div className="flex items-center justify-between" style={{ border: '1px solid var(--line)', padding: '8px 10px', borderRadius: 8 }}>
                <div>
                  <div className="font-heading font-bold" style={{ fontSize: '0.86rem' }}>{pickedLead.name}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-3)' }}>{pickedLead.phone}</div>
                </div>
                <button className="btn btn-g" style={{ fontSize: '0.75rem' }}
                        onClick={() => { setPickedLead(null); setSendForm(p => ({ ...p, lead_id: '' })); }}>
                  Change
                </button>
              </div>
            ) : (
              <div style={{ position: 'relative' }}>
                <Input label="Lead *" value={leadQuery} onChange={e => setLeadQuery(e.target.value)}
                       placeholder="Search by name or phone…" autoComplete="off" />
                {leadQuery.trim().length >= 2 && (leadMatches ?? []).length > 0 && (
                  <div className="card" style={{ position: 'absolute', zIndex: 20, left: 0, right: 0, top: '100%', marginTop: 4, padding: 4 }}>
                    {(leadMatches ?? []).map(l => (
                      <button key={l.id} type="button"
                              onClick={() => { setPickedLead({ id: l.id, name: l.name, phone: l.phone }); setSendForm(p => ({ ...p, lead_id: String(l.id) })); }}
                              style={{ display: 'block', width: '100%', textAlign: 'left', padding: '6px 8px', background: 'none', border: 'none', cursor: 'pointer', fontSize: '0.82rem' }}>
                        <b>{l.name}</b> <span style={{ color: 'var(--text-3)' }}>{l.phone}</span>
                      </button>
                    ))}
                  </div>
                )}
                {leadQuery.trim().length >= 2 && leadMatches && leadMatches.length === 0 && (
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-3)', marginTop: 4 }}>No lead matches “{leadQuery}”.</div>
                )}
              </div>
            )}
            <Select label="Channel" value={sendForm.channel} onChange={sf('channel')}>
              <option value="whatsapp">✉ WhatsApp</option>
              <option value="sms">📱 SMS</option>
            </Select>
            {sendForm.channel === 'whatsapp' && activeSenders.length > 1 && (
              <Select label="Send from" value={sendForm.wa_from}
                      onChange={e => setSendForm(p => ({ ...p, wa_from: e.target.value, template_id: '' }))}>
                <option value="">Automatic — the number the lead last wrote to</option>
                {activeSenders.map(x => (
                  <option key={x.id} value={x.id}>{senderLabel(x)}{x.is_default ? ' (default)' : ''}</option>
                ))}
              </Select>
            )}
            {sendForm.channel === 'whatsapp' && (
              <Select label="Template (optional)" value={sendForm.template_id} onChange={sf('template_id')}>
                <option value="">No template — type custom message</option>
                {(sendForm.wa_from ? (fromTemplates ?? []) : (templates ?? []))
                  .filter(t => t.status === 'approved')
                  .map(t => (
                  <option key={t.id} value={t.id} disabled={(t.unmapped ?? []).length > 0}>
                    {t.name}{multiNumber && t.account_label ? ` · ${t.account_label}` : ''}{(t.unmapped ?? []).length > 0 ? ' — map its variables first' : ''}
                  </option>
                ))}
              </Select>
            )}
            {sendForm.channel === 'sms' && (
              <Input label="Sender ID" value={sendForm.sender_id} onChange={sf('sender_id')} placeholder="TELCRM (max 6 chars, TRAI approved)" />
            )}
            {!(sendForm.channel === 'whatsapp' && sendForm.template_id) && (
              <Textarea label="Message *" value={sendForm.message} onChange={sf('message')} placeholder="Type your message here…" />
            )}
            {sendForm.channel === 'sms' && sendForm.message.length > 0 && (
              <div style={{ fontSize: '0.72rem', color: sendForm.message.length > 160 ? 'var(--hot)' : 'var(--text-3)' }}>
                {sendForm.message.length}/160 chars ({Math.ceil(sendForm.message.length / 160)} SMS)
              </div>
            )}
            <button
              onClick={() => sendMut.mutate()}
              disabled={!sendForm.lead_id || (!sendForm.message && !sendForm.template_id) || sendMut.isPending}
              className="btn-brutal btn-primary py-2.5 font-heading font-black"
              style={{ fontSize: '0.88rem', boxShadow: 'var(--shadow)' }}
            >
              {sendMut.isPending ? '◌ Sending…' : 'Send Message →'}
            </button>
          </div>
        </div>
      )}

      {confirmRemove != null && (
        <ConfirmDialog
          title="Remove this template?"
          message="It stops being offered for new messages and campaigns. Messages already sent with it keep their record, and you can recreate it later."
          confirmLabel={removeTplMut.isPending ? 'Removing…' : 'Remove'}
          danger
          onConfirm={() => { removeTplMut.mutate(confirmRemove); setConfirmRemove(null); }}
          onCancel={() => setConfirmRemove(null)}
        />
      )}

      {showTemplateModal && (
        <Modal title={editingTpl ? `Edit template: ${editingTpl.name}` : 'New WhatsApp Template'} onClose={() => setShowTemplateModal(false)}>
          <div className="flex flex-col gap-3">
            <Input label="Template Name *" value={tplForm.name} onChange={tf('name')} placeholder="e.g. welcome_followup" />
            {(senders?.length ?? 0) > 0 && (
              <Select label="WhatsApp number" value={tplForm.account}
                      hint="The number it was approved on. Meta approves templates per WhatsApp Business Account, so it is only sent from this number."
                      onChange={e => {
                        const picked = senders?.find(x => String(x.id) === e.target.value);
                        setTplForm(p => ({ ...p, account: e.target.value, provider: picked?.provider ?? p.provider }));
                      }}>
                {(senders ?? []).map(x => (
                  <option key={x.id} value={x.id}>{senderLabel(x)}{x.is_default ? ' (default)' : ''}</option>
                ))}
                <option value="">Any number (shared)</option>
              </Select>
            )}
            <Select label="Category" value={tplForm.category} onChange={tf('category')}>
              <option value="marketing">Marketing</option>
              <option value="utility">Utility / Transactional</option>
              <option value="authentication">Authentication (OTP)</option>
            </Select>
            <Select label="Provider" value={tplForm.provider} onChange={tf('provider')}>
              <option value="meta_cloud">Meta Cloud API (direct)</option>
              <option value="interakt">Interakt</option>
              <option value="aisensy">AiSensy</option>
              <option value="wati">Wati</option>
              <option value="gupshup">Gupshup</option>
            </Select>
            <Select label="Language" value={tplForm.language} onChange={tf('language')}>
              <option value="en">English</option>
              <option value="hi">Hindi (हिन्दी)</option>
              <option value="mr">Marathi (मराठी)</option>
              <option value="gu">Gujarati (ગુજરાતી)</option>
              <option value="ta">Tamil (தமிழ்)</option>
            </Select>
            <Textarea
              label="Body Text *"
              value={tplForm.body_text}
              onChange={tf('body_text')}
              placeholder="Hi {{1}}, your property enquiry has been received. Our agent will call you within {{2}} hours."
            />
            <Input label="Name at the provider (optional)" value={tplForm.provider_template_id}
                   onChange={tf('provider_template_id')}
                   hint="Leave blank if the template was approved under the same name. Fill it in only if your provider gave it a different name or id." />

            {formPlaceholders.length > 0 && (
              <div className="flex flex-col gap-2" style={{ border: '1px solid var(--line)', padding: 10, borderRadius: 8 }}>
                <div className="font-heading font-bold" style={{ fontSize: '0.8rem' }}>
                  Fill the variables from
                </div>
                {formPlaceholders.map(n => (
                  <div key={n} className="flex items-center gap-2">
                    <span className="font-mono" style={{ fontSize: '0.8rem', minWidth: 44 }}>{`{{${n}}}`}</span>
                    <select className="input-brutal" style={{ flex: 1 }}
                            value={tplForm.variable_mapping[String(n)] ?? ''}
                            onChange={e => setTplForm(p => ({ ...p, variable_mapping: { ...p.variable_mapping, [String(n)]: e.target.value } }))}>
                      <option value="">— choose a lead field —</option>
                      {variableChoices.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                    </select>
                  </div>
                ))}
                {formUnmapped.length > 0 && (
                  <div style={{ fontSize: '0.72rem', color: 'var(--hot)' }}>
                    Until every variable is mapped this template can't be used — customers would get the literal “{`{{${formUnmapped[0]}}}`}”.
                  </div>
                )}
              </div>
            )}

            <div style={{ fontSize: '0.75rem', color: 'var(--text-2)', background: 'var(--brass-50)', border: '1px solid var(--brass-600)', padding: '10px' }}>
              <strong>Variables:</strong> write {'{{1}}'}, {'{{2}}'}… in the body, then pick which lead field fills each one.<br />
              WhatsApp formatting uses single asterisks: *bold*, _italic_.<br />
              A template needs Meta's approval (1–3 business days) before bulk use.
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={() => setShowTemplateModal(false)} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">Cancel</button>
            <button onClick={() => saveTplMut.mutate()} disabled={saveTplMut.isPending || !tplForm.name || !tplForm.body_text}
                    className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black" style={{ boxShadow: 'var(--shadow)' }}>
              {editingTpl ? 'Save template →' : 'Create Template →'}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
