// ============================================================
// Settings — Company profile
//
// The tenant's billing identity: the name, GSTIN, state and address printed
// on every quotation, invoice and payslip. There was no screen for it, so
// documents printed the workspace slug ("crm") as the company name and a tax
// invoice could go out with no supplier GSTIN.
// ============================================================
import { useEffect, useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { authApi } from '../api';
import { Input, Spinner, Textarea, useToast } from '../components/ui';
import { useCompany } from '../components/DocumentShell';
import { getErrorMessage } from '../utils/errors';
import { INDIAN_STATES, stateFromGstin, stateName } from './erp/erpShared';

export default function CompanyProfilePanel() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { data: company, isLoading } = useCompany();

  const [form, setForm] = useState({
    company_name: '', gstin: '', state: '', billing_address: '', city: '', pincode: '',
  });

  useEffect(() => {
    if (company) {
      setForm({
        company_name: company.company_name ?? '',
        gstin: company.gstin ?? '',
        state: company.state ?? '',
        billing_address: company.billing_address ?? '',
        city: company.city ?? '',
        pincode: company.pincode ?? '',
      });
    }
  }, [company]);

  const set = (k: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm(f => ({ ...f, [k]: e.target.value }));

  const onGstin = (e: React.ChangeEvent<HTMLInputElement>) => {
    const gstin = e.target.value.toUpperCase().replace(/\s/g, '');
    const derived = gstin.length >= 2 ? stateFromGstin(gstin) : '';
    setForm(f => ({ ...f, gstin, state: derived || f.state }));
  };

  const gstinState = form.gstin.length >= 2 ? stateFromGstin(form.gstin) : '';
  const mismatch = !!gstinState && !!form.state && gstinState !== form.state;
  const badPin = !!form.pincode && !/^\d{6}$/.test(form.pincode);

  const save = useMutation({
    mutationFn: () => authApi.updateCompany(form),
    onSuccess: () => {
      showToast('success', 'Saved', 'Company profile updated — new documents will use it.');
      qc.invalidateQueries({ queryKey: ['company-profile'] });
    },
    onError: e => showToast('error', 'Could not save', getErrorMessage(e)),
  });

  if (isLoading) return <Spinner />;

  return (
    <div className="card-brutal" style={{ padding: 20, maxWidth: 640 }}>
      <h3 className="font-heading font-black" style={{ fontSize: '1rem', marginBottom: 4 }}>Company profile</h3>
      <p style={{ fontSize: '0.78rem', color: 'var(--text-2)', marginBottom: 16 }}>
        Printed on every quotation, invoice and payslip. A tax invoice can't be issued until the
        GSTIN is set, and your state decides whether a sale is charged IGST or CGST + SGST.
      </p>
      <div className="flex flex-col gap-3">
        <Input label="Legal / trade name" required value={form.company_name} onChange={set('company_name')}
               placeholder="Acme Solutions Pvt Ltd" />
        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
          <Input label="GSTIN" value={form.gstin} onChange={onGstin} maxLength={15}
                 placeholder="09ABCDE1234F1Z5" style={{ fontFamily: 'monospace', letterSpacing: '0.04em' }} />
          <div>
            <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
              State
            </label>
            <select className="input-brutal" style={{ cursor: 'pointer', width: '100%' }}
                    value={form.state} onChange={set('state')}>
              <option value="">—</option>
              {INDIAN_STATES.map(([c, n]) => <option key={c} value={c}>{n} ({c})</option>)}
            </select>
          </div>
        </div>
        {mismatch && (
          <p style={{ fontSize: '0.72rem', color: 'var(--hot)', marginTop: -6 }}>
            This GSTIN is registered in {stateName(gstinState)}, not {stateName(form.state)}.
          </p>
        )}
        <Textarea label="Registered address" value={form.billing_address} onChange={set('billing_address')} />
        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
          <Input label="City" value={form.city} onChange={set('city')} />
          <Input label="PIN code" value={form.pincode} onChange={set('pincode')} maxLength={6} inputMode="numeric"
                 error={badPin ? '6 digits' : undefined} />
        </div>
        <div>
          <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                  style={{ fontSize: '0.85rem' }}
                  disabled={!form.company_name.trim() || mismatch || badPin || save.isPending}
                  onClick={() => save.mutate()}>
            {save.isPending ? 'Saving…' : 'Save company profile'}
          </button>
        </div>
      </div>
    </div>
  );
}
