import { useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid,
} from 'recharts';
import { leadsApi, reportsApi } from '../api';
import { Spinner, StatusBadge, ScoreBar, useToast } from '../components/ui';
import LeadFormModal from './LeadFormModal';
import { fmtDate, localISODate } from '../utils/fmt';

// ---- Icons ---------------------------------------------------
// Solid glyphs inside the round KPI badges, line glyphs everywhere else.
const Solid = ({ d }: { d: React.ReactNode }) => (
  <svg viewBox="0 0 24 24" width="100%" height="100%" fill="currentColor" aria-hidden="true">{d}</svg>
);
const Line = ({ d, w = 1.8 }: { d: React.ReactNode; w?: number }) => (
  <svg viewBox="0 0 24 24" width="100%" height="100%" fill="none" stroke="currentColor" strokeWidth={w}
       strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{d}</svg>
);
const I = {
  users: <path d="M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm7.5-1a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM2 19.5C2 16 5.1 13.5 9 13.5s7 2.5 7 6V21H2zm15.5-4.8c2.6.3 4.5 2 4.5 4.8V21h-4v-1.5c0-1.9-.2-3.4-.5-4.8z" />,
  layers: <path d="M12 2.5 22 8l-10 5.5L2 8zm-7.6 8.3L12 15l7.6-4.2L22 12l-10 5.5L2 12zm0 4L12 19l7.6-4.2L22 16l-10 5.5L2 16z" />,
  phone: <path d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1z" />,
  bell: <path d="M12 2a6.5 6.5 0 0 0-6.5 6.5c0 5.2-2 7-2.4 7.4A.9.9 0 0 0 3.7 17.5h16.6a.9.9 0 0 0 .6-1.6c-.4-.4-2.4-2.2-2.4-7.4A6.5 6.5 0 0 0 12 2zm-2.3 17a2.3 2.3 0 0 0 4.6 0z" />,
  bars: <path d="M4 10h4v10H4zm6-6h4v16h-4zm6 9h4v7h-4z" />,
  funnel: <path d="M3 4h18l-7 8.5V20l-4-2v-5.5z" />,
  plus: <path d="M12 5v14M5 12h14" />,
  arrow: <path d="M5 12h14M13 6l6 6-6 6" />,
  cal: <><rect x="3.5" y="5" width="17" height="15" rx="2.5" /><path d="M3.5 10h17M8 3v4M16 3v4" /></>,
  caret: <path d="m6 9 6 6 6-6" />,
  dots: <><circle cx="12" cy="5" r="1.2" /><circle cx="12" cy="12" r="1.2" /><circle cx="12" cy="19" r="1.2" /></>,
};

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const dayLabel = (iso: string, withYear = false) => {
  const [y, m, d] = iso.split('-');
  return `${Number(d)} ${MONTHS[Number(m) - 1] ?? ''}${withYear ? ` ${y}` : ''}`;
};
const isoDaysAgo = (n: number) => {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return localISODate(d);
};

// ---- Hero illustration ---------------------------------------
// Placeholder artwork: a support agent at a laptop with floating chat, call
// and chart icons. Replace with the real illustration file when there is one.
function HeroArt() {
  return (
    <svg className="dash-art" viewBox="0 0 470 150" aria-hidden="true">
      <ellipse cx="300" cy="146" rx="170" ry="6" fill="#8fd9b6" opacity=".35" />
      <path d="M40 146h40l-5-30H45z" fill="#fff" stroke="#cbd5e1" />
      <path d="M60 116c-2-22-14-36-28-44 12 16 16 30 18 44zM60 116c3-26 14-44 30-54-10 18-16 36-18 54zM60 116c-8-14-22-20-36-20 12 6 22 12 30 22zM60 116c6-12 18-18 32-16-12 4-22 10-28 18z" fill="#1f9c67" />
      <path d="M60 116c0-30 4-48 10-62-2 18-4 38-4 62z" fill="#2fbf86" />
      <circle cx="130" cy="36" r="20" fill="#0f8a5f" />
      <path d="M122 29h4l2 4-2 1.3a7 7 0 0 0 3.2 3.2l1.3-2 4 2v4a1.6 1.6 0 0 1-1.6 1.6A13 13 0 0 1 120.6 30.6 1.6 1.6 0 0 1 122 29z" fill="#fff" />
      <rect x="176" y="0" width="44" height="34" rx="8" fill="#16a06f" />
      <path d="M190 34l6 8 6-8z" fill="#16a06f" />
      <path d="M186 11h24M186 17h24M186 23h14" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" />
      <rect x="160" y="60" width="44" height="34" rx="8" fill="#1f9c67" />
      <path d="M170 94l6 8 6-8z" fill="#1f9c67" />
      <rect x="170" y="70" width="24" height="15" rx="3" fill="none" stroke="#fff" strokeWidth="2.4" />
      <circle cx="177" cy="77" r="1.6" fill="#fff" /><circle cx="182" cy="77" r="1.6" fill="#fff" /><circle cx="187" cy="77" r="1.6" fill="#fff" />
      <rect x="420" y="40" width="42" height="42" rx="9" fill="#16a06f" />
      <path d="M431 72V62M441 72V54M451 72V48" stroke="#fff" strokeWidth="4.5" strokeLinecap="round" />
      <path d="M222 92h80l10 46h-80z" fill="#1c2733" /><circle cx="268" cy="115" r="4" fill="#3a4a5c" />
      <path d="M214 138h120v6H214z" fill="#2a3a4a" />
      <path d="M322 146c0-30 16-50 44-50s44 20 44 50z" fill="#0f8a5f" />
      <path d="M356 98l10 14 10-14z" fill="#fff" />
      <path d="M296 128c14-10 28-16 40-16l6 12c-14 4-28 10-40 16z" fill="#0f8a5f" />
      <rect x="358" y="80" width="16" height="18" rx="6" fill="#f1c6a4" />
      <ellipse cx="366" cy="60" rx="24" ry="27" fill="#f6d0b1" />
      <path d="M340 64c-4-30 12-44 30-44 20 0 32 14 28 40-4-12-14-22-30-24-10 8-20 14-28 28z" fill="#2b1d1a" />
      <path d="M388 50c10 14 12 40 2 64-2-20-4-40-10-56z" fill="#2b1d1a" />
      <circle cx="357" cy="62" r="2.2" fill="#2b1d1a" /><circle cx="375" cy="62" r="2.2" fill="#2b1d1a" />
      <path d="M360 74c4 3 8 3 12 0" fill="none" stroke="#c9735a" strokeWidth="2" strokeLinecap="round" />
      <path d="M340 60a26 26 0 0 1 52 0" fill="none" stroke="#1c2733" strokeWidth="4" />
      <rect x="335" y="56" width="9" height="16" rx="4" fill="#1c2733" />
      <path d="M340 72c2 8 8 12 16 12" fill="none" stroke="#1c2733" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

// ---- Sparkline -----------------------------------------------
// Drawn only from a real series. A KPI with no history behind it gets no line
// rather than a decorative one that would read as a trend.
function Spark({ values, id }: { values: number[]; id: string }) {
  if (values.length < 2) return null;
  const max = Math.max(...values, 1);
  const pts = values.map((v, i) => [2 + (i * 80) / (values.length - 1), 32 - (v / max) * 28]);
  const line = pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`).join(' ');
  return (
    <svg className="kcard-spark" viewBox="0 0 84 34" aria-hidden="true">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="var(--c)" stopOpacity=".35" />
          <stop offset="1" stopColor="var(--c)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={`${line} L82 34 L2 34Z`} fill={`url(#${id})`} />
      <path d={line} fill="none" stroke="var(--c)" strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

type Tone = 'green' | 'blue' | 'violet' | 'orange' | 'red' | 'teal';

function KpiCard({ tone, icon, label, value, note, noteHl, spark, onClick }: {
  tone: Tone; icon: React.ReactNode; label: string; value: React.ReactNode;
  note: string; noteHl?: boolean; spark?: number[]; onClick: () => void;
}) {
  return (
    <button type="button" className={`kcard-t t-${tone}`} onClick={onClick}>
      <div className="kcard-top">
        <span className="kcard-ic"><Solid d={icon} /></span>
        <span className={`kcard-l ${tone === 'orange' || tone === 'red' ? 'hl' : ''}`}>{label}</span>
      </div>
      <div className="kcard-mid">
        <div>
          <div className="kcard-v">{value}</div>
          <div className={`kcard-s ${noteHl ? 'hl' : ''}`}>{note}</div>
        </div>
        {spark && <Spark values={spark} id={`sp-${tone}`} />}
      </div>
    </button>
  );
}

// ---- Pipeline donut ------------------------------------------
// One ring segment per pipeline stage, the total in the middle, and a legend
// carrying the numbers. SVG arcs by hand: five wedges and a hole is less
// configuration than Recharts' Pie and styles better against the theme.
const STAGE_COLOUR: Record<string, string> = {
  new: 'var(--brand)',
  attempted: 'var(--brass)',
  contacted: 'var(--yellow)',
  interested: 'var(--teal)',
  follow_up: 'var(--warm)',
  negotiation: 'var(--visit)',
  converted: 'var(--hot)',
  not_interested: 'var(--lost)',
  lost: 'var(--lost)',
  duplicate: 'var(--text-3)',
  invalid: 'var(--text-3)',
};

function PipelineDonut({ stages, loading }: {
  stages: Array<{ status: string; label: string; count: number; pct_of_total: number }>;
  loading?: boolean;
}) {
  const shown = stages.filter(s => s.count > 0);
  const total = shown.reduce((sum, s) => sum + s.count, 0);
  if (loading) {
    return (
      <div className="flex items-center justify-center" style={{ height: 240, color: 'var(--text-3)', fontSize: '0.85rem' }}>
        Loading…
      </div>
    );
  }
  if (!total) {
    return (
      <div className="flex items-center justify-center" style={{ height: 240, color: 'var(--text-3)', fontSize: '0.85rem' }}>
        No pipeline data yet
      </div>
    );
  }

  const cx = 80, cy = 80, r = 76, w = 22;
  const point = (radius: number, angle: number) =>
    [cx + radius * Math.cos(angle), cy + radius * Math.sin(angle)] as const;

  let angle = -Math.PI / 2;   // start at 12 o'clock
  const wedges = shown.map(stage => {
    const sweep = (stage.count / total) * Math.PI * 2;
    const end = angle + sweep;
    const large = sweep > Math.PI ? 1 : 0;
    const [x1, y1] = point(r, angle);
    const [x2, y2] = point(r, end);
    const [x3, y3] = point(r - w, end);
    const [x4, y4] = point(r - w, angle);
    angle = end;
    return {
      status: stage.status,
      colour: STAGE_COLOUR[stage.status] ?? 'var(--text-3)',
      d: `M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2} `
       + `L ${x3} ${y3} A ${r - w} ${r - w} 0 ${large} 0 ${x4} ${y4} Z`,
    };
  });
  // A single stage holding every lead sweeps a full turn, where start and end
  // land on the same point and the arc collapses to nothing. Draw a ring.
  const isFullCircle = shown.length === 1;

  // Legend lists every stage the API reports, zeros included, so a stage the
  // team has not reached yet is visibly empty rather than missing.
  // Every open stage, plus closed ones only when they hold leads.
  const OPEN = ['new', 'attempted', 'contacted', 'interested', 'follow_up', 'negotiation', 'converted'];
  const legend = stages.filter(s => s.count > 0 || OPEN.includes(s.status));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18 }}>
      <svg viewBox="0 0 160 160" style={{ width: 200, height: 200, display: 'block' }}>
        {isFullCircle ? (
          <circle cx={cx} cy={cy} r={r - w / 2} fill="none" stroke={wedges[0].colour} strokeWidth={w} />
        ) : (
          wedges.map(seg => (
            <path key={seg.status} d={seg.d} fill={seg.colour} stroke="var(--surface)" strokeWidth={2} />
          ))
        )}
        <text x={cx} y={cy + 4} textAnchor="middle" fill="var(--text)"
              fontSize={30} fontWeight={800} letterSpacing={-1}>{total}</text>
        <text x={cx} y={cy + 24} textAnchor="middle" fill="var(--text-2)"
              fontSize={10} fontWeight={700} letterSpacing={1.6}>LEADS</text>
      </svg>

      <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 7 }}>
        {legend.map(stage => (
          <div key={stage.status}
               style={{ display: 'grid', gridTemplateColumns: '12px 1fr auto 44px', alignItems: 'center', gap: 10, fontSize: 13.5, fontWeight: 500 }}>
            <i style={{ width: 11, height: 11, borderRadius: '50%', background: STAGE_COLOUR[stage.status] ?? 'var(--text-3)' }} />
            <span>{stage.label}</span>
            <b className="num" style={{ fontWeight: 700 }}>{stage.count}</b>
            <span className="num" style={{ color: 'var(--text-2)', textAlign: 'right' }}>
              {Math.round((stage.count / total) * 100)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---- Chart tooltip -------------------------------------------
function ChartTip({ active, payload, label }: {
  active?: boolean; label?: string;
  payload?: Array<{ dataKey: string; value: number }>;
}) {
  if (!active || !payload?.length || !label) return null;
  const v = (k: string) => payload.find(p => p.dataKey === k)?.value ?? 0;
  return (
    <div className="chart-tip">
      <div className="chart-tip-d">{dayLabel(label, true)}</div>
      <div className="chart-tip-r"><i style={{ background: 'var(--brand)' }} /><span>Total</span><b>{v('total')}</b></div>
      <div className="chart-tip-r"><i style={{ background: 'var(--brass)' }} /><span>Connected</span><b>{v('connected')}</b></div>
    </div>
  );
}

// One range drives both the call chart and the pipeline. They sit side by
// side and are read together, so two independent pickers meant comparing a
// week of calls against all-time leads without noticing.
const RANGES = [
  { key: 'today', days: 1,  label: 'Today' },
  { key: '7',     days: 7,  label: 'Last 7 days' },
  { key: '30',    days: 30, label: 'Last 30 days' },
  { key: 'custom', days: 0, label: 'Select dates…' },
] as const;
type RangeKey = typeof RANGES[number]['key'];
const AVATAR_TINTS = [
  { bg: 'var(--brand-50)', fg: 'var(--brand-ink)' },
  { bg: 'var(--visit-50)', fg: 'var(--visit)' },
  { bg: 'var(--brass-50)', fg: 'var(--brass-ink)' },
  { bg: 'var(--warm-50)',  fg: 'var(--warm-ink)' },
  { bg: 'var(--teal-50)',  fg: 'var(--teal)' },
];
const initials = (name: string) =>
  name.split(' ').filter(Boolean).map(n => n[0]).join('').slice(0, 2).toUpperCase() || '?';

export default function Dashboard() {
  const nav = useNavigate();
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [showCreate, setShowCreate] = useState(false);
  const [rangeKey, setRangeKey] = useState<RangeKey>('today');
  const [customFrom, setCustomFrom] = useState(isoDaysAgo(6));
  const [customTo, setCustomTo] = useState(isoDaysAgo(0));

  // The window every panel on this page reads.
  const { from, to, days, label } = useMemo(() => {
    if (rangeKey === 'custom') {
      const ms = new Date(customTo).getTime() - new Date(customFrom).getTime();
      return {
        from: customFrom, to: customTo,
        days: Math.max(1, Math.round(ms / 86_400_000) + 1),
        label: `${dayLabel(customFrom)} – ${dayLabel(customTo)}`,
      };
    }
    const r = RANGES.find(x => x.key === rangeKey)!;
    return {
      from: isoDaysAgo(r.days - 1), to: isoDaysAgo(0), days: r.days, label: r.label,
    };
  }, [rangeKey, customFrom, customTo]);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['lead-stats'],
    queryFn: () => leadsApi.stats().then(r => r.data),
    refetchInterval: 60_000,
  });
  const { data: daily } = useQuery({
    queryKey: ['daily-activity'],
    queryFn: () => reportsApi.dailyActivity().then(r => r.data),
    refetchInterval: 30_000,
  });
  const { data: callAnalytics } = useQuery({
    queryKey: ['call-analytics-dashboard', from, to],
    queryFn: () => reportsApi.callAnalytics({ date_from: from, date_to: to }).then(r => r.data),
  });
  const { data: recentLeads } = useQuery({
    queryKey: ['leads-recent'],
    queryFn: () => leadsApi.list({ page: 1, page_size: 6, order_by: '-created_at' }).then(r => r.data),
  });
  // The pipeline is where leads stand now, whenever they came in — not only
  // leads created inside the chosen range (which showed an empty pipeline to
  // a tenant whose leads all arrived last month).
  const { data: funnel, isLoading: funnelLoading } = useQuery({
    queryKey: ['funnel-dashboard-current'],
    queryFn: () => reportsApi.conversionFunnel({ current: true }).then(r => r.data),
  });

  const trendData = useMemo(() => (callAnalytics?.daily_trend ?? []).slice(-days), [callAnalytics, days]);

  if (statsLoading) return <Spinner />;

  const overdue = daily?.leads.overdue_followups ?? 0;
  const period = callAnalytics?.period;

  return (
    <div className="dash">
      <div className="dash-hero" aria-hidden="true" />
      <HeroArt />

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <div className="crumb"><span>DialSathi</span><span>/</span><b>Dashboard</b></div>
          <h1 className="dash-title">Dashboard</h1>
          <p className="dash-sub">Here's what's happening with your TeleCRM today.</p>
        </div>
        {/* Opens the form here rather than sending the admin to the leads
            list to find the button again. */}
        <button onClick={() => setShowCreate(true)} className="btn btn-primary"
                style={{ height: 44, padding: '0 20px', fontSize: 15, marginTop: 24 }}>
          <Line d={I.plus} w={2.4} /> New Lead
        </button>
      </div>

      {showCreate && (
        <LeadFormModal
          onClose={() => setShowCreate(false)}
          onSuccess={() => {
            setShowCreate(false);
            qc.invalidateQueries({ queryKey: ['lead-stats'] });
            qc.invalidateQueries({ queryKey: ['leads-recent'] });
            qc.invalidateQueries({ queryKey: ['daily-activity'] });
            showToast('success', 'Lead created', '');
          }} />
      )}

      {/* KPI cards */}
      <div className="kpis">
        {/* The number of leads sitting in New — the same figure the Leads
            list shows for that filter. It used to show only what arrived
            since midnight, which read as a wrong count beside a list of 14. */}
        <KpiCard tone="green" icon={I.users} label="New leads"
                 value={stats?.by_status?.new ?? 0}
                 note={`${daily?.leads.new_today ?? 0} added today`}
                 onClick={() => nav('/leads?status=new')} />
        <KpiCard tone="blue" icon={I.layers} label="Active leads"
                 value={stats?.total.active_leads ?? 0} note={`${stats?.total.total_leads ?? 0} in total`} noteHl
                 onClick={() => nav('/leads')} />
        <KpiCard tone="violet" icon={I.phone} label="Calls today"
                 value={daily?.calls.total ?? 0} note={`${daily?.calls.connected ?? 0} connected`}
                 spark={trendData.map(d => d.total)}
                 onClick={() => nav('/calls')} />
        {/* Overdue is the number that changes what you do next, so the card
            turns from orange to red when there is any. */}
        <KpiCard tone={overdue > 0 ? 'red' : 'orange'} icon={I.bell} label="Follow-ups due"
                 value={daily?.followups.due_today ?? 0}
                 note={overdue > 0 ? `${overdue} overdue` : 'Nothing overdue'} noteHl={overdue > 0}
                 onClick={() => nav('/leads')} />
        <KpiCard tone="teal" icon={I.bars} label="Conversion rate"
                 value={`${stats?.total.conversion_rate ?? 0}%`} note={`${stats?.total.won ?? 0} won`}
                 onClick={() => nav('/reports')} />
      </div>

      {/* The window both panels below are drawn for. Sitting directly above
          them, rather than in the page header over the illustration, so it
          reads as belonging to them. */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="seg">
          {RANGES.map(r => (
            <button key={r.key} className={`seg-btn ${rangeKey === r.key ? 'on' : ''}`}
                    onClick={() => setRangeKey(r.key)}>{r.label}</button>
          ))}
        </div>
        {rangeKey === 'custom' && (
          <div className="flex items-center gap-1">
            <input type="date" className="field" style={{ width: 150 }} value={customFrom}
                   max={customTo} onChange={e => setCustomFrom(e.target.value)} aria-label="From" />
            <span style={{ color: 'var(--text-3)' }}>–</span>
            <input type="date" className="field" style={{ width: 150 }} value={customTo}
                   min={customFrom} max={isoDaysAgo(0)}
                   onChange={e => setCustomTo(e.target.value)} aria-label="To" />
          </div>
        )}
        <span style={{ fontSize: 12.5, color: 'var(--text-3)' }}>
          Applies to call activity
        </span>
      </div>

      <div className="grid gap-4 dash-row">
        {/* Call activity */}
        <div className="plate">
          <div className="plate-h" style={{ borderBottom: 0, alignItems: 'flex-start' }}>
            <div className="flex gap-3">
              <span className="panel-ic"><Solid d={I.bars} /></span>
              <div>
                <div className="plate-t" style={{ fontSize: 18 }}>Call activity</div>
                <div className="plate-s">{label}</div>
              </div>
            </div>
            <div className="flex flex-col items-end gap-3">
              <span className="pill-select" style={{ paddingRight: 12 }}>
                <Line d={I.cal} />
                <span>{period ? `${dayLabel(period.date_from, true)} - ${dayLabel(period.date_to, true)}` : label}</span>
              </span>
              {trendData.length > 0 && (
                <div className="legend">
                  <span><i style={{ background: 'var(--brand)' }} />Total</span>
                  <span><i style={{ background: 'var(--brass)' }} />Connected</span>
                </div>
              )}
            </div>
          </div>
          <div className="plate-b" style={{ paddingTop: 0 }}>
            {trendData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={trendData} margin={{ top: 10, right: 10, bottom: 0, left: -14 }}>
                  <defs>
                    <linearGradient id="gTotal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--brand)" stopOpacity={0.32} />
                      <stop offset="100%" stopColor="var(--brand)" stopOpacity={0.03} />
                    </linearGradient>
                    <linearGradient id="gConn" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--brass)" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="var(--brass)" stopOpacity={0.03} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid vertical={false} strokeDasharray="3 4" stroke="var(--line)" />
                  <XAxis
                    dataKey="date"
                    tickFormatter={(v: string) => dayLabel(v)}
                    tick={{ fontSize: 12, fontWeight: 600, fill: 'var(--text-2)' }}
                    tickLine={false}
                    axisLine={{ stroke: 'var(--line)' }}
                    minTickGap={24}
                    dy={6}
                  />
                  <YAxis
                    tick={{ fontSize: 12, fontWeight: 600, fill: 'var(--text-2)' }}
                    tickLine={false}
                    axisLine={false}
                    width={44}
                    allowDecimals={false}
                  />
                  <Tooltip content={<ChartTip />} cursor={{ stroke: 'var(--line-2)', strokeDasharray: '4 4' }} />
                  <Area type="monotone" dataKey="total" name="Total"
                        stroke="var(--brand)" strokeWidth={2.5} fill="url(#gTotal)"
                        dot={false} activeDot={{ r: 6, strokeWidth: 2.5, stroke: 'var(--surface)', fill: 'var(--brand)' }} />
                  <Area type="monotone" dataKey="connected" name="Connected"
                        stroke="var(--brass)" strokeWidth={2.5} fill="url(#gConn)"
                        dot={false} activeDot={{ r: 6, strokeWidth: 2.5, stroke: 'var(--surface)', fill: 'var(--brass)' }} />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center" style={{ height: 250, color: 'var(--text-3)', fontSize: '0.85rem' }}>
                No call data for this period
              </div>
            )}
          </div>
        </div>

        {/* Pipeline */}
        <div className="plate">
          <div className="plate-h" style={{ borderBottom: 0, alignItems: 'flex-start' }}>
            <div className="flex gap-3">
              <span className="panel-ic"><Solid d={I.funnel} /></span>
              <div>
                <div className="plate-t" style={{ fontSize: 18 }}>Pipeline</div>
                <div className="plate-s">By stage · all leads now</div>
              </div>
            </div>

          </div>
          <div className="plate-b" style={{ paddingTop: 4 }}>
            {/* Every lead, open and closed — Not interested and Follow-up
                used to be missing, so the total didn't match the lead count. */}
            <PipelineDonut stages={funnel?.pipeline ?? funnel?.funnel ?? []} loading={funnelLoading} />
          </div>
        </div>
      </div>

      {/* Recent leads */}
      <div className="plate" style={{ overflow: 'hidden' }}>
        <div className="plate-h" style={{ borderBottom: 0 }}>
          <div className="flex gap-3">
            <span className="panel-ic"><Solid d={I.users} /></span>
            <div>
              <div className="plate-t" style={{ fontSize: 18 }}>Recent leads</div>
              <div className="plate-s">Newest first</div>
            </div>
          </div>
          <button className="btn btn-g" onClick={() => nav('/leads')} style={{ color: 'var(--brand-ink)' }}>
            View all <Line d={I.arrow} w={2.2} />
          </button>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="table-brutal" style={{ minWidth: 900 }}>
            <thead>
              <tr>
                {['Lead', 'Phone', 'Source', 'Status', 'Score', 'Assigned to', 'Created'].map(h => (
                  <th key={h}>{h}</th>
                ))}
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {(recentLeads?.results ?? []).map((lead, i) => {
                const tint = AVATAR_TINTS[i % AVATAR_TINTS.length];
                return (
                  <tr key={lead.id} style={{ cursor: 'pointer' }} onClick={() => nav(`/leads/${lead.id}`)}>
                    <td>
                      <div className="cell-p">
                        <span className="avt" style={{ background: tint.bg, color: tint.fg }}>{initials(lead.name)}</span>
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 13 }}>{lead.name}</div>
                          <div className="cell-m">{lead.city || '—'}</div>
                        </div>
                      </div>
                    </td>
                    <td className="num" style={{ fontWeight: 500 }}>{lead.phone}</td>
                    <td><span className="tag">{lead.source_display}</span></td>
                    <td><StatusBadge status={lead.status} label={lead.status_display} /></td>
                    <td><ScoreBar score={lead.score} /></td>
                    <td style={{ fontWeight: 500 }}>{lead.assigned_to_name ?? '—'}</td>
                    <td style={{ color: 'var(--text-2)' }}>{fmtDate(lead.created_at)}</td>
                    <td style={{ textAlign: 'right' }}>
                      <button className="mini" style={{ marginLeft: 'auto', border: 0 }}
                              aria-label={`Open ${lead.name}`}
                              onClick={e => { e.stopPropagation(); nav(`/leads/${lead.id}`); }}>
                        <span style={{ width: 18, height: 18, display: 'block' }}><Line d={I.dots} w={2.4} /></span>
                      </button>
                    </td>
                  </tr>
                );
              })}
              {!recentLeads?.results?.length && (
                <tr><td colSpan={8} style={{ textAlign: 'center', color: 'var(--text-3)', padding: 28 }}>No leads yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
