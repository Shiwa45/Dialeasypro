// ============================================================
// Outreach → WhatsApp Inbox
//
// Every lead who has written to one of the workspace's WhatsApp numbers,
// newest conversation first, with what is still unread — and the chat itself,
// with a reply box. Before this a customer's reply was visible only to
// somebody who happened to open that lead's WhatsApp tab.
//
// Read state is the team's: opening a conversation clears it for everyone.
// Free text can be sent for 24 hours after the customer last wrote (Meta's
// rule); after that only an approved template restarts the conversation.
//
// Live: the notification socket announces new messages (NotificationBell
// re-emits them as a window event); a poll covers everything else.
// ============================================================
import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  authApi, commsApi, senderLabel,
  type InboxConversation, type InboxFilters, type InboxMessage, type InboxThread,
} from '../api';
import { EmptyState, SectionHeader, Spinner, useToast } from '../components/ui';
import { useWorkspace } from '../hooks/useWorkspace';
import { getErrorMessage } from '../utils/errors';
import { LEAD_STATUSES } from '../utils/fmt';

/** Fired by NotificationBell when the socket says a customer wrote in. */
export const INBOX_EVENT = 'wa-inbox';

/** Refresh the inbox and its badge whenever the socket says so. */
export function useInboxLiveRefresh() {
  const qc = useQueryClient();
  useEffect(() => {
    const refresh = () => {
      qc.invalidateQueries({ queryKey: ['wa-inbox'] });
      qc.invalidateQueries({ queryKey: ['wa-inbox-summary'] });
      qc.invalidateQueries({ queryKey: ['wa-inbox-thread'] });
    };
    window.addEventListener(INBOX_EVENT, refresh);
    return () => window.removeEventListener(INBOX_EVENT, refresh);
  }, [qc]);
}

type Tab = 'all' | 'unread' | 'mine' | 'unassigned';
const TABS: Array<{ key: Tab; label: string }> = [
  { key: 'all', label: 'All' },
  { key: 'unread', label: 'Unread' },
  { key: 'mine', label: 'Mine' },
  { key: 'unassigned', label: 'Unassigned' },
];

const statusLabel = (s: string) => LEAD_STATUSES.find(x => x.value === s)?.label ?? s;

/** 10:42 today, "Yesterday", or 21 Nov. */
function listTime(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) {
    return d.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' });
  }
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}

function dayLabel(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Today';
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}

function hoursLeft(closesAt: string | null): string {
  if (!closesAt) return '';
  const ms = new Date(closesAt).getTime() - Date.now();
  if (ms <= 0) return '';
  const h = Math.floor(ms / 3_600_000);
  return h >= 1 ? `${h}h left` : `${Math.max(1, Math.round(ms / 60_000))} min left`;
}

function initials(name: string): string {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]?.toUpperCase()).join('') || '?';
}

const TICK: Record<string, string> = { queued: '◷', sent: '✓', delivered: '✓✓', read: '✓✓', failed: '!' };

// ------------------------------------------------------------

export default function InboxPage() {
  useInboxLiveRefresh();
  const { leadId } = useParams();
  const selected = leadId ? Number(leadId) : null;
  const nav = useNavigate();
  const { isReadOnly } = useWorkspace();

  const [tab, setTab] = useState<Tab>('all');
  const [search, setSearch] = useState('');
  const [q, setQ] = useState('');
  const [agent, setAgent] = useState('');
  const [account, setAccount] = useState('');

  // Search as you type, without a request per keystroke.
  useEffect(() => {
    const t = setTimeout(() => setQ(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  const filters: InboxFilters = {
    ...(tab === 'unread' ? { unread: true } : {}),
    ...(tab === 'mine' ? { mine: true } : {}),
    ...(tab === 'unassigned' ? { unassigned: true } : {}),
    ...(agent ? { agent: Number(agent) } : {}),
    ...(account ? { account: Number(account) } : {}),
    ...(q ? { q } : {}),
  };

  const list = useQuery({
    queryKey: ['wa-inbox', filters],
    queryFn: () => commsApi.inbox(filters).then(r => r.data),
    // Live updates come over the socket; polls are the fallback, kept slow
    // because every request counts against the user's rate limit.
    refetchInterval: 45_000,
  });
  const summary = useQuery({
    queryKey: ['wa-inbox-summary'],
    queryFn: () => commsApi.inboxSummary().then(r => r.data),
    refetchInterval: 60_000,
  });
  const senders = useQuery({
    queryKey: ['wa-senders'],
    queryFn: () => commsApi.listWhatsAppSenders().then(r => r.data),
  });
  // Admins and managers can filter by agent; for anyone else the list call
  // is refused and the filter simply does not appear.
  const agents = useQuery({
    queryKey: ['agents-min'],
    queryFn: () => authApi.listAgents({ page_size: 200 }).then(r => r.data.results),
    staleTime: 5 * 60_000,
    retry: false,
  });

  const rows = list.data?.results ?? [];
  const unread = summary.data?.unread_conversations ?? 0;

  return (
    <div className="inbox-page">
      <SectionHeader
        title="WhatsApp Inbox"
        sub={unread
          ? `${unread} conversation${unread === 1 ? '' : 's'} waiting for a reply`
          : 'Customers who have written to your WhatsApp numbers'}
      />

      <div className={`inbox-grid ${selected ? 'has-thread' : ''}`}>
        {/* ---------- Conversation list ---------- */}
        <aside className="inbox-list card-brutal">
          <div className="inbox-filters">
            <input
              className="input-brutal"
              placeholder="Search name or phone"
              value={search}
              onChange={e => setSearch(e.target.value)}
              aria-label="Search conversations"
            />
            <div className="inbox-tabs" role="tablist">
              {TABS.map(t => (
                <button key={t.key} role="tab" aria-selected={tab === t.key}
                        className={tab === t.key ? 'on' : ''} onClick={() => setTab(t.key)}>
                  {t.label}
                  {t.key === 'unread' && unread > 0 && <span className="inbox-count">{unread}</span>}
                </button>
              ))}
            </div>
            <div className="inbox-selects">
              {(agents.data?.length ?? 0) > 1 && (
                <select className="input-brutal" value={agent} onChange={e => setAgent(e.target.value)}
                        aria-label="Filter by agent">
                  <option value="">Every agent</option>
                  {agents.data!.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                </select>
              )}
              {(senders.data?.length ?? 0) > 1 && (
                <select className="input-brutal" value={account} onChange={e => setAccount(e.target.value)}
                        aria-label="Filter by WhatsApp number">
                  <option value="">Every number</option>
                  {senders.data!.map(s => <option key={s.id} value={s.id}>{senderLabel(s)}</option>)}
                </select>
              )}
            </div>
          </div>

          <div className="inbox-rows">
            {list.isLoading && <div className="flex justify-center py-8"><Spinner size={28} /></div>}
            {list.isError && (
              <div className="inbox-note">{getErrorMessage(list.error, 'Could not load the inbox.')}</div>
            )}
            {!list.isLoading && !list.isError && rows.length === 0 && (
              <div className="inbox-note">
                {tab === 'unread' ? 'Nothing unread. You’re all caught up.'
                  : q || agent || account || tab !== 'all' ? 'No conversations match.'
                  : 'No customer has written in yet. Replies to your WhatsApp messages appear here.'}
              </div>
            )}
            {rows.map(c => (
              <ConversationRow key={c.lead_id} c={c} active={c.lead_id === selected}
                               showNumber={(senders.data?.length ?? 0) > 1}
                               onOpen={() => nav(`/inbox/${c.lead_id}`)} />
            ))}
          </div>
        </aside>

        {/* ---------- The chat ---------- */}
        <section className="inbox-thread card-brutal">
          {selected
            ? <Thread key={selected} leadId={selected} canReply={!isReadOnly} onBack={() => nav('/inbox')} />
            : (
              <EmptyState icon="✉" title="Pick a conversation"
                          message="Choose a customer on the left to read and reply." />
            )}
        </section>
      </div>
    </div>
  );
}

function ConversationRow({ c, active, showNumber, onOpen }: {
  c: InboxConversation; active: boolean; showNumber: boolean; onOpen: () => void;
}) {
  const m = c.last_message;
  return (
    <button className={`inbox-row ${active ? 'on' : ''} ${c.unread ? 'unread' : ''}`} onClick={onOpen}>
      <span className="inbox-avatar" aria-hidden="true">{initials(c.lead_name)}</span>
      <span className="inbox-row-main">
        <span className="inbox-row-top">
          <span className="inbox-name">{c.lead_name}</span>
          <span className="inbox-time">{listTime(m.at)}</span>
        </span>
        <span className="inbox-row-bottom">
          <span className="inbox-preview">
            {m.direction === 'outbound' && <span className="inbox-you">{TICK[m.status] ?? ''} </span>}
            {m.text || '…'}
          </span>
          {c.unread > 0 && <span className="inbox-count" aria-label={`${c.unread} unread`}>{c.unread}</span>}
        </span>
        <span className="inbox-row-meta">
          {c.owner_name ?? 'Unassigned'}
          {showNumber && m.account_label && <> · {m.account_label}</>}
          {!c.window.open && <> · window closed</>}
        </span>
      </span>
    </button>
  );
}

// ------------------------------------------------------------

function Thread({ leadId, canReply, onBack }: { leadId: number; canReply: boolean; onBack: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const scroller = useRef<HTMLDivElement>(null);

  const thread = useQuery({
    queryKey: ['wa-inbox-thread', leadId],
    queryFn: () => commsApi.inboxThread(leadId).then(r => r.data),
    refetchInterval: 20_000,
  });
  const data: InboxThread | undefined = thread.data;

  // On screen = read. Again whenever something new arrives while it is open.
  const markRead = useMutation({
    mutationFn: () => commsApi.inboxMarkRead(leadId),
    onSuccess: r => {
      qc.setQueryData(['wa-inbox-summary'], {
        unread_conversations: r.data.unread_conversations, unread_messages: r.data.unread_messages,
      });
      qc.invalidateQueries({ queryKey: ['wa-inbox'] });
      qc.invalidateQueries({ queryKey: ['notifications'] });
    },
  });
  useEffect(() => {
    if (data && data.unread > 0 && !markRead.isPending) markRead.mutate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data?.unread, leadId]);

  // Keep the newest message in view.
  const lastId = data?.messages[data.messages.length - 1]?.id;
  useEffect(() => {
    const el = scroller.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [lastId]);

  if (thread.isLoading) return <div className="flex justify-center py-16"><Spinner /></div>;
  if (thread.isError || !data) {
    return <div className="inbox-note">{getErrorMessage(thread.error, 'Could not open this conversation.')}</div>;
  }

  const sent = () => {
    // Sending is queued on the server; look again once it has gone out.
    [1500, 5000].forEach(ms => setTimeout(() => {
      qc.invalidateQueries({ queryKey: ['wa-inbox-thread', leadId] });
      qc.invalidateQueries({ queryKey: ['wa-inbox'] });
    }, ms));
  };

  return (
    <>
      <header className="inbox-head">
        <button className="inbox-back btn-brutal btn-secondary" onClick={onBack} aria-label="Back to conversations">←</button>
        <span className="inbox-avatar" aria-hidden="true">{initials(data.lead.name)}</span>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div className="font-heading font-bold inbox-head-name">{data.lead.name}</div>
          <div className="inbox-head-sub">
            {data.lead.phone} · {statusLabel(data.lead.status)} · {data.lead.owner_name ?? 'Unassigned'}
          </div>
        </div>
        <Link to={`/leads/${data.lead.id}`} className="btn-brutal btn-secondary px-3 py-1 font-heading font-bold"
              style={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
          Open lead
        </Link>
      </header>

      <div className="inbox-messages" ref={scroller}>
        {data.messages.map((m, i) => {
          const prev = data.messages[i - 1];
          const newDay = !prev || new Date(prev.created_at).toDateString() !== new Date(m.created_at).toDateString();
          return (
            <div key={m.id} style={{ display: 'contents' }}>
              {newDay && <div className="inbox-day"><span>{dayLabel(m.created_at)}</span></div>}
              <Bubble m={m} />
            </div>
          );
        })}
      </div>

      {canReply && (
        <Composer
          thread={data}
          onSent={label => { showToast('success', 'Sent', label ? `From ${label}` : ''); sent(); }}
          onError={e => showToast('error', 'Not sent', getErrorMessage(e, 'Try again.'))}
        />
      )}
    </>
  );
}

function Bubble({ m }: { m: InboxMessage }) {
  const out = m.direction === 'outbound';
  const text = m.content || (m.template_name ? `Template: ${m.template_name}` : `[${m.message_type}]`);
  const time = new Date(m.sent_at ?? m.created_at).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' });
  return (
    <div className={`inbox-bubble ${out ? 'out' : 'in'} ${m.status === 'failed' ? 'failed' : ''}`}>
      {m.template_name && m.content && <div className="inbox-bubble-tag">Template · {m.template_name}</div>}
      <div className="inbox-bubble-text">{text}</div>
      {m.media_url && <a href={m.media_url} target="_blank" rel="noreferrer" className="inbox-bubble-media">Open attachment</a>}
      <div className="inbox-bubble-meta">
        {out && (m.sent_by_name ?? 'System')}
        {out && ' · '}
        {time}
        {m.account_label && <> · {out ? 'from' : 'to'} {m.account_label}</>}
        {out && <> · <span title={m.status}>{m.status === 'failed' ? 'failed' : TICK[m.status] ?? m.status}</span></>}
      </div>
      {m.status === 'failed' && m.error_message && <div className="inbox-bubble-error">{m.error_message}</div>}
    </div>
  );
}

function Composer({ thread, onSent, onError }: {
  thread: InboxThread; onSent: (fromLabel: string | null) => void; onError: (e: unknown) => void;
}) {
  const leadId = thread.lead.id;
  const windowOpen = thread.window.open;
  const [mode, setMode] = useState<'text' | 'template'>(windowOpen ? 'text' : 'template');
  const [text, setText] = useState('');
  const [templateId, setTemplateId] = useState('');
  const [from, setFrom] = useState<string>('');

  useEffect(() => { if (!windowOpen) setMode('template'); }, [windowOpen]);

  const senders = useQuery({
    queryKey: ['wa-senders'],
    queryFn: () => commsApi.listWhatsAppSenders().then(r => r.data),
  });
  const active = (senders.data ?? []).filter(s => s.is_active);
  // Templates the chosen number (or, on automatic, the number this
  // conversation is on) can send.
  const templateAccount = from ? Number(from) : thread.last_account_id;
  const templates = useQuery({
    queryKey: ['wa-templates-approved', templateAccount ?? 'any'],
    queryFn: () => commsApi.listTemplates(true, templateAccount).then(r => r.data),
    enabled: mode === 'template',
  });
  const usable = useMemo(
    () => (templates.data ?? []).filter(t => t.is_active !== false && !(t.unmapped?.length)),
    [templates.data],
  );

  const send = useMutation({
    mutationFn: () => mode === 'text'
      ? commsApi.sendWhatsApp(leadId, text.trim(), undefined, from ? Number(from) : null)
      : commsApi.sendWhatsApp(leadId, '', Number(templateId), from ? Number(from) : null),
    onSuccess: r => { setText(''); setTemplateId(''); onSent(r.data.sent_from); },
    onError,
  });

  const canSend = mode === 'text' ? !!text.trim() && windowOpen : !!templateId;
  const left = hoursLeft(thread.window.closes_at);

  return (
    <footer className="inbox-composer">
      {!windowOpen && (
        <div className="inbox-window-note">
          The customer last wrote more than 24 hours ago, so WhatsApp only allows an approved template now.
          Once they reply you can type freely again.
        </div>
      )}
      <div className="inbox-composer-bar">
        {windowOpen && (
          <div className="inbox-mode" role="tablist" aria-label="Message type">
            <button role="tab" aria-selected={mode === 'text'} className={mode === 'text' ? 'on' : ''}
                    onClick={() => setMode('text')}>Message</button>
            <button role="tab" aria-selected={mode === 'template'} className={mode === 'template' ? 'on' : ''}
                    onClick={() => setMode('template')}>Template</button>
          </div>
        )}
        {windowOpen && left && <span className="inbox-left" title="Free text can be sent until 24 hours after the customer’s last message">Reply window: {left}</span>}
        {active.length > 1 && (
          <select className="input-brutal inbox-from" value={from} onChange={e => setFrom(e.target.value)}
                  aria-label="Send from">
            <option value="">
              From: {thread.last_account_label ? `${thread.last_account_label} (this chat)` : 'automatic'}
            </option>
            {active.map(s => (
              <option key={s.id} value={s.id}>From: {senderLabel(s)}{s.is_default ? ' (default)' : ''}</option>
            ))}
          </select>
        )}
      </div>

      <div className="inbox-composer-row">
        {mode === 'text' ? (
          <textarea
            className="input-brutal"
            rows={2}
            placeholder="Type a reply…  (Enter to send, Shift+Enter for a new line)"
            value={text}
            maxLength={4096}
            onChange={e => setText(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                if (canSend && !send.isPending) send.mutate();
              }
            }}
          />
        ) : (
          <select className="input-brutal" value={templateId} onChange={e => setTemplateId(e.target.value)}
                  aria-label="Template">
            <option value="">
              {templates.isLoading ? 'Loading templates…'
                : usable.length ? 'Choose an approved template…' : 'No approved template for this number'}
            </option>
            {usable.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        )}
        <button className="btn-brutal btn-primary px-5 font-heading font-black" disabled={!canSend || send.isPending}
                onClick={() => send.mutate()}>
          {send.isPending ? 'Sending…' : 'Send'}
        </button>
      </div>
      {mode === 'template' && templateId && (
        <div className="inbox-template-preview">
          {usable.find(t => String(t.id) === templateId)?.body_text}
        </div>
      )}
    </footer>
  );
}
