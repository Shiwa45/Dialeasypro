import { useState, type ReactNode } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { integrationsApi, leadsApi } from '../api';
import {
  SectionHeader, Modal, Select, Spinner, EmptyState,
  ConfirmDialog, useToast, Input,
} from '../components/ui';
import { fmtRelative } from '../utils/fmt';
import { LEAD_SOURCES } from '../utils/fmt';
import { getErrorMessage } from '../utils/errors';
import type { IntegrationConfig } from '../types';
import ClickToWhatsAppCard from './integrations/ClickToWhatsAppCard';

// Sources that are NOT LeadSourceConfig rows. Click-to-WhatsApp and organic
// WhatsApp inbound are configured on the tenant's WhatsApp connection and land
// on their own signed webhook, so adding them here would create an inert row
// with a generic token URL nothing reads. They still belong in the webhook-log
// filter below — that lists what arrived, not how it was set up.
const NOT_LEAD_SOURCE_CONFIGS = ['meta_ctwa', 'whatsapp'];

const INTEGRATION_META: Record<string, { icon: string; color: string; description: string }> = {
  indiamart:     { icon: '🏭', color: '#ff6b00', description: "India's largest B2B marketplace. Buyer enquiries auto-captured." },
  meta_facebook: { icon: '📘', color: '#1877f2', description: 'Facebook & Instagram Lead Ads. Real-time lead form submissions.' },
  meta_instagram:{ icon: '📷', color: '#e1306c', description: 'Instagram Lead Ads. Real-time lead form submissions.' },
  meta_ctwa:     { icon: '💬', color: '#25d366', description: 'Click-to-WhatsApp ads. Leads from the WhatsApp chat itself — no lead form.' },
  google_ads:    { icon: '🔍', color: '#4285f4', description: 'Google Ads Lead Form extensions. Capture Google leads directly.' },
  website:       { icon: '🌐', color: 'var(--won)', description: 'Website contact forms via generic webhook integration.' },
  webhook:       { icon: '🔗', color: '#7c3aed', description: 'Generic webhook endpoint. Connect any external platform.' },
  referral:      { icon: '👥', color: 'var(--warm)', description: 'Referral tracking for word-of-mouth leads.' },
};

export default function Integrations() {
  const { showToast } = useToast();
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);
  const [newSource, setNewSource] = useState('indiamart');
  const [logSource, setLogSource] = useState('');
  const [configTarget, setConfigTarget] = useState<IntegrationConfig | null>(null);
  // Only what the backend reads. There used to be an `api_key` here, shown on
  // every non-Meta integration — no source uses one, so it asked website and
  // webhook users for a key that does not exist and saved it nowhere useful.
  const [creds, setCreds] = useState<{ verify_token: string; app_secret: string; access_token: string; google_key: string; page_id: string }>(
    { verify_token: '', app_secret: '', access_token: '', google_key: '', page_id: '' }
  );
  const [copied, setCopied] = useState('');
  const [mapRows, setMapRows] = useState<Array<{ metaField: string; target: string }>>([]);
  const [metaFieldOptions, setMetaFieldOptions] = useState<string[]>([]);

  // Tenant's custom fields, to offer as mapping targets.
  const { data: customFields } = useQuery({
    queryKey: ['custom-fields'],
    queryFn: () => leadsApi.listCustomFields().then(r => r.data),
  });

  const openConfigure = (cfg: IntegrationConfig) => {
    setConfigTarget(cfg);
    setCreds({
      verify_token: cfg.credentials_status?.verify_token || '',
      app_secret: '', access_token: '', google_key: '',
      page_id: (cfg.options?.page_id as string) || '',
    });
    // Seed mapping rows from saved options.field_mapping.
    const fm = (cfg.options?.field_mapping as Record<string, string>) || {};
    const rows = Object.entries(fm).map(([metaField, target]) => ({ metaField, target }));
    setMapRows(rows.length ? rows : [{ metaField: '', target: '' }]);
    setMetaFieldOptions([]);
  };

  const fetchMetaFields = async () => {
    if (!configTarget) {
      showToast('error', 'Could not fetch', 'Open the Meta integration configuration first.');
      return;
    }
    try {
      const { data } = await integrationsApi.metaForms(configTarget.id);
      const labels = new Set<string>();
      data.forms.forEach(f => f.fields.forEach(q => labels.add(q.label || q.key)));
      setMetaFieldOptions([...labels]);
      showToast('success', 'Fetched form fields', `${labels.size} fields from ${data.forms.length} form(s).`);
    } catch (e) {
      showToast('error', 'Could not fetch', getErrorMessage(e, 'Save Page Access Token + Page ID first.'));
    }
  };

  // Mapping targets: standard CRM fields + the tenant's custom fields.
  const STANDARD_TARGETS = [
    { value: 'name', label: 'Name' },
    { value: 'phone', label: 'Phone' },
    { value: 'alternate_phone', label: 'Alternate / WhatsApp phone' },
    { value: 'email', label: 'Email' },
    { value: 'city', label: 'City' },
    { value: 'state', label: 'State' },
    { value: 'pincode', label: 'Pincode' },
    { value: 'requirement', label: 'Requirement / Message' },
    { value: 'budget', label: 'Budget' },
    { value: 'campaign_name', label: 'Campaign Name' },
    { value: 'ad_name', label: 'Ad / Ad Set Name' },
    { value: 'ignore', label: '— Ignore —' },
  ];


  /** Incoming field name → CRM field rows, shared by every integration. */
  const renderMapping = (placeholder: string) => (
    <>
      {metaFieldOptions.length > 0 && (
        <datalist id="meta-field-options">
          {metaFieldOptions.map(f => <option key={f} value={f} />)}
        </datalist>
      )}
      <div className="flex flex-col gap-2">
        {mapRows.map((row, i) => (
          <div key={i} className="flex items-center gap-2">
            <input
              list={metaFieldOptions.length ? 'meta-field-options' : undefined}
              value={row.metaField}
              onChange={e => setMapRows(rows => rows.map((r, j) => j === i ? { ...r, metaField: e.target.value } : r))}
              placeholder={placeholder}
              className="input-brutal" style={{ flex: 1, fontSize: '0.75rem', boxShadow: 'var(--shadow)' }}
            />
            <span style={{ fontSize: '0.9rem' }}>→</span>
            <select
              value={row.target}
              onChange={e => setMapRows(rows => rows.map((r, j) => j === i ? { ...r, target: e.target.value } : r))}
              className="input-brutal" style={{ flex: 1, fontSize: '0.75rem', boxShadow: 'var(--shadow)' }}
            >
              <option value="">— Select CRM field —</option>
              <optgroup label="Standard">
                {STANDARD_TARGETS.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
              </optgroup>
              {(customFields ?? []).length > 0 && (
                <optgroup label="Custom fields">
                  {(customFields ?? []).map(cf => (
                    <option key={cf.id} value={`custom:${cf.field_key}`}>{cf.name}</option>
                  ))}
                </optgroup>
              )}
            </select>
            <button onClick={() => setMapRows(rows => rows.filter((_, j) => j !== i))}
                    style={{ border: '1px solid var(--line)', background: 'var(--lost-50)', cursor: 'pointer', fontWeight: 900, padding: '4px 9px' }}>×</button>
          </div>
        ))}
        <button onClick={() => setMapRows(rows => [...rows, { metaField: '', target: '' }])}
                className="btn-brutal btn-yellow px-3 py-1.5 font-heading font-bold" style={{ fontSize: '0.72rem', alignSelf: 'flex-start' }}>
          + Add field mapping
        </button>
      </div>
    </>
  );

  const copy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(''), 1500);
  };

  const { data: configs, isLoading } = useQuery({
    queryKey: ['integrations'],
    queryFn: () => integrationsApi.listConfigs().then(r => r.data),
  });

  const { data: logs } = useQuery({
    queryKey: ['webhook-logs', logSource],
    queryFn: () => integrationsApi.listLogs(logSource || undefined).then(r => r.data),
    refetchInterval: 10000,
  });

  const createMut = useMutation({
    mutationFn: () => integrationsApi.createConfig({ source: newSource, is_active: true, options: {} } as unknown as import('../types').IntegrationConfig),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['integrations'] });
      setShowCreate(false);
      showToast('success', 'Integration added', 'Configure the webhook URL in the source platform.');
    },
    onError: (e: unknown) => showToast('error', 'Error', getErrorMessage(e, 'Could not add integration.')),
  });

  const toggleMut = useMutation({
    mutationFn: ({ id, is_active }: { id: number; is_active: boolean }) =>
      integrationsApi.updateConfig(id, { is_active } as unknown as import('../types').IntegrationConfig),
    onSuccess: (_r, vars) => {
      qc.invalidateQueries({ queryKey: ['integrations'] });
      showToast(
        'success',
        vars.is_active ? 'Integration switched on' : 'Integration switched off',
        vars.is_active
          ? 'Incoming leads from this source will be accepted again.'
          : 'Incoming leads from this source will be rejected until you switch it back on. Nothing is deleted.',
      );
    },
    // Switching ON is gated on the plan, so this can legitimately refuse —
    // without a message the button simply snapped back and looked broken.
    onError: (e: unknown) =>
      showToast('error', 'Could not change this integration', getErrorMessage(e, 'Please try again.')),
  });

  const configureMut = useMutation({
    mutationFn: () => {
      // Only send credentials the user actually typed (blank = keep existing).
      const credPayload: Record<string, string> = {};
      if (creds.verify_token) credPayload.verify_token = creds.verify_token;
      if (creds.app_secret) credPayload.app_secret = creds.app_secret;
      if (creds.access_token) credPayload.access_token = creds.access_token;
      if (creds.google_key) credPayload.google_key = creds.google_key;
      if (creds.page_id) credPayload.page_id = creds.page_id;

      // Build field_mapping from the rows (skip empty).
      const field_mapping: Record<string, string> = {};
      mapRows.forEach(r => {
        if (r.metaField.trim() && r.target) field_mapping[r.metaField.trim()] = r.target;
      });
      const options = {
        ...(configTarget!.options || {}),
        field_mapping,
        ...(creds.page_id ? { page_id: creds.page_id } : {}),
      };

      return integrationsApi.updateConfig(
        configTarget!.id,
        { credentials: credPayload, options } as unknown as IntegrationConfig,
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['integrations'] });
      showToast('success', 'Settings saved', 'Your integration is configured.');
      setConfigTarget(null);
    },
    onError: (e: unknown) => showToast('error', 'Could not save', getErrorMessage(e, 'Please try again.')),
  });

  const deleteMut = useMutation({
    mutationFn: (id: number) => integrationsApi.deleteConfig(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['integrations'] });
      setConfirmDelete(null);
      showToast('info', 'Integration removed', '');
    },
  });

  const [syncingId, setSyncingId] = useState<number | null>(null);
  const syncMetaMut = useMutation({
    mutationFn: () => integrationsApi.syncMeta().then(r => r.data),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['integrations'] });
      qc.invalidateQueries({ queryKey: ['webhook-logs'] });
      showToast(
        data.created > 0 ? 'success' : 'info',
        'Sync complete',
        data.message || `${data.created} new lead(s) imported`,
      );
    },
    onError: (e) => showToast('error', 'Sync failed', getErrorMessage(e, 'Could not fetch leads from Meta.')),
    onSettled: () => setSyncingId(null),
  });

  return (
    <div className="p-6 flex flex-col gap-5" style={{ background: 'var(--paper)', minHeight: '100%' }}>
      <SectionHeader title="Lead Source Integrations" sub="Connect platforms that automatically send leads to your CRM">
        <button onClick={() => setShowCreate(true)}
                className="btn-brutal btn-primary px-4 py-2.5 font-heading font-black"
                style={{ fontSize: '0.85rem', boxShadow: 'var(--shadow)' }}>
          + Add Integration
        </button>
      </SectionHeader>

      {isLoading ? <Spinner /> : (
        <div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(320px,1fr))' }}>
          {/* Click-to-WhatsApp is configured on the tenant's WhatsApp connection,
              not as a LeadSourceConfig row, so it renders outside the map. */}
          <ClickToWhatsAppCard />

          {(configs ?? []).map(cfg => {
            const meta = INTEGRATION_META[cfg.source];

            // A row created before this source was blocked. It does nothing —
            // say so plainly and offer to remove it, rather than rendering a
            // credentials form and a webhook URL that will never fire.
            if (NOT_LEAD_SOURCE_CONFIGS.includes(cfg.source)) {
              return (
                <div key={cfg.id} className="card p-5" style={{ background: 'var(--brass-50)' }}>
                  <div className="font-heading font-black" style={{ fontSize: '0.9rem', marginBottom: 6 }}>
                    ⚠ {cfg.source_display} — not configured here
                  </div>
                  <p style={{ fontSize: '0.78rem', color: 'var(--text-2)', lineHeight: 1.5, marginBottom: 10 }}>
                    This entry does nothing. Click-to-WhatsApp is set up on the
                    <strong> Meta — Click to WhatsApp </strong> card above, which holds the
                    real credentials and callback URL. The webhook URL on a row like this is
                    never called.
                  </p>
                  <button onClick={() => setConfirmDelete(cfg.id)}
                          className="btn-brutal btn-danger px-3 py-1 font-heading font-bold w-full"
                          style={{ fontSize: '0.72rem' }}>
                    Remove this entry
                  </button>
                </div>
              );
            }

            return (
              <div key={cfg.id} className="card p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div style={{ fontSize: '2rem', width: '48px', height: '48px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: meta?.color ?? 'var(--line)', border: '1px solid var(--line)', boxShadow: 'var(--shadow)' }}>
                      {meta?.icon ?? '○'}
                    </div>
                    <div>
                      <div className="font-heading font-black" style={{ fontSize: '0.95rem' }}>{cfg.source_display}</div>
                      <div style={{ fontSize: '0.7rem', color: cfg.status === 'error' ? 'var(--hot)' : cfg.is_active ? 'var(--won)' : 'var(--text-3)', fontWeight: 700 }}>
                        ● {cfg.status === 'error' ? 'Error — check config' : cfg.is_active ? 'Active' : 'Inactive'}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleMut.mutate({ id: cfg.id, is_active: !cfg.is_active })}
                    className="btn-brutal px-3 py-1 font-heading font-bold"
                    style={{ fontSize: '0.72rem', background: cfg.is_active ? 'var(--won-50)' : 'var(--surface-2)', boxShadow: 'var(--shadow)' }}
                  >
                    {cfg.is_active ? 'Active ✓' : 'Inactive'}
                  </button>
                </div>

                {meta?.description && (
                  <p style={{ fontSize: '0.78rem', color: 'var(--text-2)', marginBottom: '12px', lineHeight: 1.4 }}>{meta.description}</p>
                )}

                <div style={{ fontSize: '0.78rem', color: 'var(--text-2)', marginBottom: '10px' }}>
                  <div>Leads received: <strong>{cfg.total_leads_received}</strong></div>
                  <div>Last lead: {cfg.last_received_at ? fmtRelative(cfg.last_received_at) : 'Never'}</div>
                  {cfg.error_message && (
                    <div style={{ color: 'var(--hot)', marginTop: '4px' }}>⚠ {cfg.error_message}</div>
                  )}
                </div>

                <div style={{ background: 'var(--surface-2)', border: '1px solid var(--line)', padding: '8px 10px', marginBottom: '12px' }}>
                  <div className="flex items-center justify-between" style={{ marginBottom: '4px' }}>
                    <div style={{ fontSize: '0.65rem', color: 'var(--text-3)', fontWeight: 700, textTransform: 'uppercase' }}>
                      Webhook / Callback URL
                    </div>
                    <button onClick={() => copy(cfg.webhook_url, `url-${cfg.id}`)}
                            style={{ fontSize: '0.6rem', border: '1px solid var(--line)', background: copied === `url-${cfg.id}` ? 'var(--won-50)' : 'var(--surface)', cursor: 'pointer', padding: '2px 6px', fontWeight: 700 }}>
                      {copied === `url-${cfg.id}` ? 'Copied ✓' : 'Copy'}
                    </button>
                  </div>
                  <div className="font-mono" style={{ fontSize: '0.68rem', wordBreak: 'break-all', color: 'var(--text)' }}>
                    {cfg.webhook_url}
                  </div>
                </div>

                {(cfg.source === 'meta_facebook' || cfg.source === 'meta_instagram') && (
                  <button
                    onClick={() => { setSyncingId(cfg.id); syncMetaMut.mutate(); }}
                    disabled={syncMetaMut.isPending}
                    className="btn-brutal btn-yellow px-3 py-1.5 font-heading font-bold w-full mb-2"
                    style={{ fontSize: '0.72rem', boxShadow: 'var(--shadow)' }}
                    title="Manually pull the latest leads from Meta if the webhook hasn't delivered them"
                  >
                    {syncMetaMut.isPending && syncingId === cfg.id ? '◌ Fetching leads…' : '⟳ Sync leads now'}
                  </button>
                )}

                <div className="flex gap-2">
                  <button onClick={() => openConfigure(cfg)}
                          className="btn-brutal btn-primary px-3 py-1 font-heading font-bold flex-1" style={{ fontSize: '0.72rem', boxShadow: 'var(--shadow)' }}>
                    ⚙ Configure
                  </button>
                  <button onClick={() => setConfirmDelete(cfg.id)}
                          className="btn-brutal btn-danger px-3 py-1 font-heading font-bold" style={{ fontSize: '0.72rem' }}>
                    Remove
                  </button>
                </div>
              </div>
            );
          })}

          {(configs ?? []).length === 0 && (
            <div className="col-span-full">
              <EmptyState
                icon="⊕"
                title="No lead-source integrations yet"
                message="Connect IndiaMART, Meta Lead Ads, Google Ads, or any platform using our generic webhook. Click-to-WhatsApp is set up on its own card above."
                action={{ label: '+ Add Integration', onClick: () => setShowCreate(true) }}
              />
            </div>
          )}
        </div>
      )}

      {/* Webhook Logs */}
      <div className="card">
        <div className="px-4 py-3 border-b-2 border-black flex items-center justify-between"
             style={{ background: 'var(--surface-2)' }}>
          <span className="font-heading font-black" style={{ color: 'var(--text)', fontSize: '0.95rem' }}>
            ▸ Webhook Logs (live, auto-refreshes every 10s)
          </span>
          <select value={logSource} onChange={e => setLogSource(e.target.value)}
                  className="input-brutal" style={{ fontSize: '0.8rem', padding: '5px 10px' }}>
            <option value="">All Sources</option>
            {LEAD_SOURCES.filter(s => !['manual', 'csv_import', 'api'].includes(s.value)).map(s => (
              <option key={s.value} value={s.value}>{s.label}</option>
            ))}
          </select>
        </div>
        {(logs ?? []).length === 0 ? (
          <div style={{ padding: '28px', textAlign: 'center', color: 'var(--text-3)', fontSize: '0.82rem' }}>
            No webhook logs yet. Logs appear here when leads arrive via integrations.
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table className="table-brutal">
              <thead>
                <tr>{['Source', 'Status', 'Leads Created', 'Leads Updated', 'Error', 'Received'].map(h => <th key={h}>{h}</th>)}</tr>
              </thead>
              <tbody>
                {(logs ?? []).slice(0, 50).map(log => (
                  <tr key={log.id}>
                    <td><span className="tag">{log.source_display}</span></td>
                    <td>
                      {log.processed
                        ? <span className="badge status-active">Processed</span>
                        : log.error
                          ? <span className="badge status-lost">Error</span>
                          : <span className="badge status-new">Pending</span>}
                    </td>
                    <td className="font-heading font-black" style={{ fontSize: '0.82rem', color: 'var(--won)' }}>{log.leads_created}</td>
                    <td style={{ fontSize: '0.82rem' }}>{log.leads_updated}</td>
                    <td style={{ fontSize: '0.72rem', color: 'var(--hot)', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {log.error || '—'}
                    </td>
                    <td style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>{fmtRelative(log.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add integration modal */}
      {showCreate && (
        <Modal title="Add Lead Source Integration" onClose={() => setShowCreate(false)}>
          <Select label="Lead Source *" value={newSource} onChange={e => setNewSource(e.target.value)}>
            {LEAD_SOURCES
              .filter(s => !['manual', 'csv_import', 'api'].includes(s.value))
              .filter(s => !NOT_LEAD_SOURCE_CONFIGS.includes(s.value))
              .map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
          </Select>
          {INTEGRATION_META[newSource] && (
            <div style={{ marginTop: '10px', padding: '10px', background: 'var(--brass-50)', border: '1px solid var(--brass-600)', fontSize: '0.78rem' }}>
              {INTEGRATION_META[newSource].description}
            </div>
          )}
          <div style={{ marginTop: '10px', fontSize: '0.75rem', color: 'var(--text-2)' }}>
            After adding, click <strong>⚙ Configure</strong> on the integration card to get the
            webhook URL to paste into the source platform. Only Meta asks for app credentials.
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={() => setShowCreate(false)} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">Cancel</button>
            <button onClick={() => createMut.mutate()}
                    className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black" style={{ boxShadow: 'var(--shadow)' }}>
              Add Integration →
            </button>
          </div>
        </Modal>
      )}

      {confirmDelete !== null && (
        <ConfirmDialog
          title="Remove Integration?"
          message="The webhook token will be invalidated and all configuration removed. Existing leads will remain."
          confirmLabel="Remove"
          danger
          onConfirm={() => deleteMut.mutate(confirmDelete)}
          onCancel={() => setConfirmDelete(null)}
        />
      )}

      {/* Configure credentials modal */}
      {configTarget && (() => {
        const isMeta = configTarget.source === 'meta_facebook' || configTarget.source === 'meta_instagram';
        const cs = configTarget.credentials_status;
        return (
          <Modal title={`Configure: ${configTarget.source_display}`} onClose={() => setConfigTarget(null)} maxWidth="620px">
            <div className="flex flex-col gap-4">
              {isMeta ? (
                <>
                  {/* Callback URL + verify token to paste into Meta */}
                  <div style={{ background: '#eff6ff', border: '1px solid var(--visit)', padding: '12px' }}>
                    <div className="font-heading font-black mb-2" style={{ fontSize: '0.82rem' }}>① Paste these into Meta</div>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-2)', marginBottom: '3px', fontWeight: 700 }}>Callback URL</div>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="font-mono flex-1" style={{ fontSize: '0.7rem', wordBreak: 'break-all', background: 'var(--surface)', border: '1px solid var(--line-2)', padding: '5px 7px' }}>{configTarget.webhook_url}</div>
                      <button onClick={() => copy(configTarget.webhook_url, 'm-url')}
                              style={{ fontSize: '0.62rem', border: '1px solid var(--line)', background: copied === 'm-url' ? 'var(--won-50)' : 'var(--surface)', cursor: 'pointer', padding: '4px 7px', fontWeight: 700, whiteSpace: 'nowrap' }}>
                        {copied === 'm-url' ? '✓' : 'Copy'}
                      </button>
                    </div>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-2)', marginBottom: '3px', fontWeight: 700 }}>Verify Token</div>
                    <div className="flex items-center gap-2">
                      <div className="font-mono flex-1" style={{ fontSize: '0.7rem', wordBreak: 'break-all', background: 'var(--surface)', border: '1px solid var(--line-2)', padding: '5px 7px' }}>{creds.verify_token || '(set a verify token below)'}</div>
                      <button onClick={() => copy(creds.verify_token, 'm-vt')} disabled={!creds.verify_token}
                              style={{ fontSize: '0.62rem', border: '1px solid var(--line)', background: copied === 'm-vt' ? 'var(--won-50)' : 'var(--surface)', cursor: 'pointer', padding: '4px 7px', fontWeight: 700 }}>
                        {copied === 'm-vt' ? '✓' : 'Copy'}
                      </button>
                    </div>
                  </div>

                  {/* Credential fields */}
                  <div className="font-heading font-black" style={{ fontSize: '0.82rem' }}>② Enter your Meta app credentials</div>
                  <div>
                    <Input label="Verify Token (you choose any string)" value={creds.verify_token}
                           onChange={e => setCreds(p => ({ ...p, verify_token: e.target.value }))}
                           placeholder="e.g. my_secret_verify_123" />
                    <button onClick={() => setCreds(p => ({ ...p, verify_token: `dlp_${Math.random().toString(36).slice(2, 14)}` }))}
                            style={{ fontSize: '0.66rem', border: 'none', background: 'none', color: '#1877f2', cursor: 'pointer', textDecoration: 'underline', marginTop: '4px' }}>
                      Generate one for me
                    </button>
                  </div>
                  <Input label={`App Secret ${cs?.has_app_secret ? '(saved — leave blank to keep)' : ''}`} type="password"
                         value={creds.app_secret} onChange={e => setCreds(p => ({ ...p, app_secret: e.target.value }))}
                         placeholder={cs?.has_app_secret ? '•••••••• (unchanged)' : 'From Meta App → Settings → Basic'} />
                  <Input label={`Page Access Token ${cs?.has_access_token ? '(saved — leave blank to keep)' : ''}`} type="password"
                         value={creds.access_token} onChange={e => setCreds(p => ({ ...p, access_token: e.target.value }))}
                         placeholder={cs?.has_access_token ? '•••••••• (unchanged)' : 'Long-lived Page access token'} />
                  <Input label="Facebook Page ID (for auto-fetching form fields)" value={creds.page_id}
                         onChange={e => setCreds(p => ({ ...p, page_id: e.target.value }))}
                         placeholder="e.g. 102938475610293" />

                  {/* ③ FIELD MAPPING */}
                  <div className="font-heading font-black flex items-center justify-between" style={{ fontSize: '0.82rem' }}>
                    <span>③ Map form fields → CRM fields</span>
                    <button onClick={fetchMetaFields}
                            className="btn-brutal btn-secondary px-2 py-1 font-heading font-bold"
                            style={{ fontSize: '0.66rem' }}>
                      ⟳ Fetch fields from Meta
                    </button>
                  </div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-2)' }}>
                    Your Meta form questions may have any name. Map each to a CRM field so leads
                    sync correctly. Unmapped fields are still saved on the lead's raw data.
                  </div>
                  {renderMapping('Meta field name')}

                  <div style={{ background: 'var(--brass-50)', border: '1px solid var(--brass-600)', padding: '10px 12px', fontSize: '0.72rem', lineHeight: 1.5 }}>
                    <strong>Setup steps in Meta:</strong><br />
                    1. developers.facebook.com → your App → <strong>Webhooks</strong> → subscribe to <strong>Page → leadgen</strong>.<br />
                    2. Paste the <strong>Callback URL</strong> and <strong>Verify Token</strong> above, click Verify &amp; Save.<br />
                    3. Connect your Facebook Page and generate a <strong>long-lived Page access token</strong>; paste it above.<br />
                    4. Add <strong>App Secret</strong> (App → Settings → Basic) so we can verify signatures.<br />
                    New Lead Ads form submissions will then appear in <strong>Leads</strong> automatically.
                  </div>
                </>
              ) : (
                <WebhookSetup
                  cfg={configTarget}
                  copied={copied}
                  copy={copy}
                  googleKey={creds.google_key}
                  hasGoogleKey={Boolean(cs?.has_google_key)}
                  onGoogleKey={v => setCreds(p => ({ ...p, google_key: v }))}
                  mapping={renderMapping('Field name your form sends')}
                />
              )}
            </div>

            <div className="flex gap-3 mt-5 pt-4" style={{ borderTop: '2px solid var(--line)' }}>
              <button onClick={() => setConfigTarget(null)} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">Cancel</button>
              <button onClick={() => configureMut.mutate()} disabled={configureMut.isPending}
                      className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black" style={{ boxShadow: 'var(--shadow)' }}>
                {configureMut.isPending ? '◌ Saving…' : isMeta ? 'Save Credentials →' : 'Save Settings →'}
              </button>
            </div>
          </Modal>
        );
      })()}
    </div>
  );
}

/* ---- Non-Meta integrations -------------------------------------
   Website, generic webhook, referral, IndiaMART and Google Ads all
   authenticate by the secret token in their webhook URL; none takes an API
   key. What each needs is the URL, where to paste it, and (Google only) the
   optional key Google's form asks for. */
const SETUP_STEPS: Record<string, ReactNode> = {
  indiamart: <>IndiaMART Seller Panel → <strong>Lead Manager</strong> → <strong>CRM Integration (Push API)</strong> → paste the URL and save. New enquiries then arrive as leads.</>,
  google_ads: <>Google Ads → your <strong>lead form asset</strong> → <strong>Lead delivery</strong> → <strong>Webhook integration</strong>: paste the URL. Google also asks for a <strong>Key</strong>: type the key below in both places (optional here, but it adds a second check). Use <strong>Send test data</strong> to try it.</>,
};

function WebhookSetup({ cfg, copied, copy, googleKey, hasGoogleKey, onGoogleKey, mapping }: {
  cfg: IntegrationConfig;
  copied: string;
  copy: (text: string, label: string) => void;
  googleKey: string;
  hasGoogleKey: boolean;
  onGoogleKey: (v: string) => void;
  mapping: ReactNode;
}) {
  const generic = !SETUP_STEPS[cfg.source];
  const example = `curl -X POST "${cfg.webhook_url}" \\
  -H "Content-Type: application/json" \\
  -d '{"name":"Rahul Sharma","phone":"9876543210","email":"rahul@example.com","city":"Delhi","message":"Interested"}'`;
  const box = { background: 'var(--surface-2)', border: '1px solid var(--line)', padding: '10px 12px' } as const;
  const label = { fontSize: '0.66rem', color: 'var(--text-3)', fontWeight: 700, textTransform: 'uppercase', marginBottom: '4px' } as const;
  const copyBtn = (key: string) => ({
    fontSize: '0.62rem', border: '1px solid var(--line)', cursor: 'pointer', padding: '4px 8px', fontWeight: 700,
    background: copied === key ? 'var(--won-50)' : 'var(--surface)', whiteSpace: 'nowrap',
  } as const);

  return (
    <>
      <div style={{ fontSize: '0.8rem', color: 'var(--text-2)', lineHeight: 1.5 }}>
        No API key is needed. The secret token in this URL identifies your workspace, so keep it
        private. Removing the integration invalidates it.
      </div>

      <div style={box}>
        <div style={label}>① Webhook URL</div>
        <div className="flex items-center gap-2">
          <div className="font-mono flex-1" style={{ fontSize: '0.7rem', wordBreak: 'break-all' }}>{cfg.webhook_url}</div>
          <button onClick={() => copy(cfg.webhook_url, 'g-url')} style={copyBtn('g-url')}>
            {copied === 'g-url' ? '✓ Copied' : 'Copy'}
          </button>
        </div>
      </div>

      {generic ? (
        <div style={box}>
          <div style={label}>② Send leads to it</div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-2)', lineHeight: 1.55, marginBottom: 8 }}>
            POST a JSON body from your website's server, form plugin or Zapier/Make. Recognised
            fields: <code>name</code>, <code>phone</code>, <code>email</code>, <code>city</code>,{' '}
            <code>message</code>, <code>budget</code>, <code>utm_campaign</code>. Anything else is kept
            on the lead, or map it below.
          </div>
          <div className="flex items-start gap-2">
            <pre className="font-mono flex-1" style={{ fontSize: '0.66rem', margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-all',
              background: 'var(--surface)', border: '1px solid var(--line-2)', padding: '7px 8px' }}>{example}</pre>
            <button onClick={() => copy(example, 'g-ex')} style={copyBtn('g-ex')}>
              {copied === 'g-ex' ? '✓ Copied' : 'Copy'}
            </button>
          </div>
        </div>
      ) : (
        <div style={{ ...box, fontSize: '0.75rem', lineHeight: 1.55 }}>
          <div style={label}>② Where to paste it</div>
          {SETUP_STEPS[cfg.source]}
        </div>
      )}

      {cfg.source === 'google_ads' && (
        <div>
          <Input label={`Webhook key ${hasGoogleKey ? '(saved — leave blank to keep)' : '(optional)'}`} type="password"
                 value={googleKey} onChange={e => onGoogleKey(e.target.value)}
                 placeholder={hasGoogleKey ? '•••••••• (unchanged)' : 'The same Key you enter in Google Ads'} />
          <button onClick={() => onGoogleKey(`gk_${Math.random().toString(36).slice(2, 14)}`)}
                  style={{ fontSize: '0.66rem', border: 'none', background: 'none', color: 'var(--brass)', cursor: 'pointer', textDecoration: 'underline', marginTop: '4px' }}>
            Generate one for me
          </button>
        </div>
      )}

      <div className="font-heading font-black" style={{ fontSize: '0.82rem' }}>
        ③ Map fields (optional)
      </div>
      <div style={{ fontSize: '0.72rem', color: 'var(--text-2)', marginTop: -8 }}>
        Common names are matched automatically. Map anything else — e.g. a form field called
        <code> mobile_no</code> → Phone, or a question → one of your custom fields.
      </div>
      {mapping}
    </>
  );
}
