// ============================================================
// DialSathi — Lead batches
//
// A batch is one consignment of leads: a CSV import, or one day's intake from
// a webhook source. It is the unit an admin assigns by — tick batch 1 and
// batch 3, pick four agents, and only those leads move.
//
// Webhook batches are created automatically (one per source per day) so leads
// arriving from Meta at 3am are already grouped when somebody opens this in
// the morning.
//
// Laid out as cards rather than a table. The question this screen answers is
// "which consignments still need handing out", which is a shape — a meter of
// assigned against unassigned — not a column of numbers to read one by one.
// Each card is tinted by where its leads came from, so file imports, automatic
// intake and hand-typed batches separate at a glance.
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import {
  authApi, leadsApi, DISTRIBUTION_METHODS, type DistributionMethod,
} from '../api';
import {
  ConfirmDialog, EmptyState, Input, Modal, SectionHeader, Spinner, StatCard, useToast,
} from '../components/ui';
import { getErrorMessage } from '../utils/errors';
import { fmtDate } from '../utils/fmt';
import { isAdmin as isAdminRole } from '../utils/roles';
import { useAuthStore } from '../store/authStore';
import type { LeadBatch } from '../types';

// ---- Icons ---------------------------------------------------
const Solid = ({ d }: { d: React.ReactNode }) => (
  <svg viewBox="0 0 24 24" width="100%" height="100%" fill="currentColor" aria-hidden="true">{d}</svg>
);
const I = {
  layers: <path d="M12 2.5 22 8l-10 5.5L2 8zm-7.6 8.3L12 15l7.6-4.2L22 12l-10 5.5L2 12zm0 4L12 19l7.6-4.2L22 16l-10 5.5L2 16z" />,
  users: <path d="M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm7.5-1a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM2 19.5C2 16 5.1 13.5 9 13.5s7 2.5 7 6V21H2zm15.5-4.8c2.6.3 4.5 2 4.5 4.8V21h-4v-1.5c0-1.9-.2-3.4-.5-4.8z" />,
  split: <path d="M4 5h4.2l3 4.2-1.7 2.4L6.9 8H4zm16 0v5l-2-2-3.6 5.1 1.6 2.3L20 10.9V16h-5l2-2-3.4-4.9L11 5zM4 16h2.9l4.3-6 1.7 2.4L8.2 19H4z" />,
  check: <path d="M9.6 17.3 4.3 12l1.8-1.8 3.5 3.5 8.3-8.3L19.7 7z" />,
  file: <path d="M13 2H6.5A2.5 2.5 0 0 0 4 4.5v15A2.5 2.5 0 0 0 6.5 22h11a2.5 2.5 0 0 0 2.5-2.5V9zm0 2.6L17.4 9H13z" />,
  bolt: <path d="M13 2 4.5 13.5H11L10 22l8.5-11.5H12z" />,
  hand: <path d="M12 2a2 2 0 0 1 2 2v6h1V5.5a2 2 0 0 1 4 0V14a7 7 0 0 1-7 7h-1a6 6 0 0 1-6-6V9a2 2 0 0 1 4 0v2h1V4a2 2 0 0 1 2-2z" />,
  search: <path d="M10.5 3a7.5 7.5 0 1 0 4.55 13.46l4.24 4.25 1.42-1.42-4.25-4.24A7.5 7.5 0 0 0 10.5 3zm0 2a5.5 5.5 0 1 1 0 11 5.5 5.5 0 0 1 0-11z" />,
  up: <path d="M11 20V8.8l-4.6 4.6L5 12l7-7 7 7-1.4 1.4L13 8.8V20z" />,
  pencil: <path d="M3 17.25V21h3.75L17.8 9.94l-3.75-3.75zm17.7-10.2a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75z" />,
  lock: <path d="M12 2a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-1V7a5 5 0 0 0-5-5zm0 2a3 3 0 0 1 3 3v3H9V7a3 3 0 0 1 3-3z" />,
  unlock: <path d="M12 2a5 5 0 0 1 5 5h-2a3 3 0 0 0-6 0v3h9a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h1V7a5 5 0 0 1 5-5z" />,
  trash: <path d="M9 3h6l1 2h4v2H4V5h4zm-3 6h12l-1 12H7zm3 2v8h2v-8zm4 0v8h2v-8z" />,
  undo: <path d="M12.5 8c-2.65 0-5.05 1-6.9 2.6L2 7v9h9l-3.62-3.62A7.48 7.48 0 0 1 12.5 10c3.54 0 6.55 2.31 7.6 5.5l2.37-.78A10.02 10.02 0 0 0 12.5 8z" />,
};

// What each origin looks like: class for the tint, icon, and the word used
// for it. `import` and `webhook` are the server's kinds, not ours to rename.
const ORIGIN = {
  import:  { cls: 'o-import',  icon: I.file, label: 'File import' },
  webhook: { cls: 'o-webhook', icon: I.bolt, label: 'Automatic' },
  manual:  { cls: 'o-manual',  icon: I.hand, label: 'Added by hand' },
} as const;

const originOf = (kind: string) => ORIGIN[kind as keyof typeof ORIGIN] ?? ORIGIN.manual;

const SORTS = [
  { key: 'newest', label: 'Newest' },
  { key: 'unassigned', label: 'Most unassigned' },
  { key: 'largest', label: 'Largest' },
] as const;
type SortKey = typeof SORTS[number]['key'];

const n = (v: number) => v.toLocaleString('en-IN');

export default function LeadBatchesPage() {
  const qc = useQueryClient();
  const nav = useNavigate();
  const { showToast } = useToast();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [kindFilter, setKindFilter] = useState('');
  const [sort, setSort] = useState<SortKey>('newest');
  const [selected, setSelected] = useState<Set<number>>(new Set());
  // Null when closed; otherwise the batches being assigned — which is either
  // the ticked ones or a single card's own button.
  const [assigning, setAssigning] = useState<LeadBatch[] | null>(null);
  const [renaming, setRenaming] = useState<LeadBatch | null>(null);
  const [viewing, setViewing] = useState<LeadBatch | null>(null);
  const [deleting, setDeleting] = useState<LeadBatch | null>(null);
  const [unassigning, setUnassigning] = useState<LeadBatch | null>(null);
  const { agent: me } = useAuthStore();
  const isAdmin = isAdminRole(me);

  const { data, isLoading } = useQuery({
    queryKey: ['lead-batches', statusFilter, kindFilter],
    queryFn: () => leadsApi.batches({
      status: statusFilter || undefined,
      kind: kindFilter || undefined,
      page_size: 200,
    }).then(r => r.data),
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['lead-batches'] });
    qc.invalidateQueries({ queryKey: ['leads'] });
  };

  const setStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: 'open' | 'closed' }) =>
      leadsApi.setBatchStatus(id, status),
    onSuccess: (_r, v) => {
      showToast('success', v.status === 'closed' ? 'Batch closed' : 'Batch reopened', '');
      invalidate();
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const remove = useMutation({
    mutationFn: (id: number) => leadsApi.deleteBatch(id),
    onSuccess: () => {
      showToast('success', 'Batch removed', 'The leads themselves were kept.');
      setSelected(new Set());
      invalidate();
      setDeleting(null);
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const all = data?.results ?? [];

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    const matched = !q ? all : all.filter(b =>
      b.label.toLowerCase().includes(q) ||
      String(b.number).includes(q) ||
      b.source_display?.toLowerCase().includes(q));

    const sorted = [...matched];
    if (sort === 'unassigned') sorted.sort((a, b) => b.unassigned_count - a.unassigned_count);
    else if (sort === 'largest') sorted.sort((a, b) => b.total_leads - a.total_leads);
    else sorted.sort((a, b) => b.number - a.number);
    return sorted;
  }, [all, search, sort]);

  const toggle = (id: number) => setSelected(s => {
    const next = new Set(s);
    if (next.has(id)) next.delete(id); else next.add(id);
    return next;
  });

  const selectedBatches = all.filter(b => selected.has(b.id));
  const selectedUnassigned = selectedBatches.reduce((sum, b) => sum + b.unassigned_count, 0);

  // Counted from assigned + unassigned, which are read from the leads
  // themselves. `total_leads` is a stored counter that is bumped on arrival
  // and drifts when leads are deleted, so mixing the two produced a card
  // reading "0 assigned" beside a total of 2.
  const totals = all.reduce(
    (acc, b) => ({
      leads: acc.leads + b.assigned_count + b.unassigned_count,
      unassigned: acc.unassigned + b.unassigned_count,
      open: acc.open + (b.status === 'open' ? 1 : 0),
    }),
    { leads: 0, unassigned: 0, open: 0 },
  );
  const assigned = totals.leads - totals.unassigned;
  const assignedPct = totals.leads ? Math.round((assigned / totals.leads) * 100) : 0;

  // Everything ticked that still has something to hand out.
  const waiting = rows.filter(b => b.unassigned_count > 0);

  return (
    <div style={{ padding: '20px' }}>
      <SectionHeader title="Lead Batches"
                     sub="Every import and every day's automatic intake, as one unit you can hand out">
        <button className="btn btn-g" onClick={() => nav('/leads')}>
          <Solid d={I.users} /> All leads
        </button>
        <button className="btn btn-p" onClick={() => nav('/leads/import')}>
          <Solid d={I.up} /> Import CSV
        </button>
      </SectionHeader>

      {/* ---- The four numbers worth knowing before acting ---- */}
      <div className="kpis mt-4 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))' }}>
        <div className="kcard-t t-blue">
          <div className="kcard-top">
            <span className="kcard-ic"><Solid d={I.layers} /></span>
            <span className="kcard-l">Batches</span>
          </div>
          <div className="kcard-mid">
            <div>
              <div className="kcard-v">{all.length}</div>
              <div className="kcard-s">{totals.open} still open</div>
            </div>
          </div>
        </div>

        <div className="kcard-t t-green">
          <div className="kcard-top">
            <span className="kcard-ic"><Solid d={I.users} /></span>
            <span className="kcard-l">Leads batched</span>
          </div>
          <div className="kcard-mid">
            <div>
              <div className="kcard-v">{n(totals.leads)}</div>
              <div className="kcard-s">across every batch</div>
            </div>
          </div>
        </div>

        {/* Orange until it is zero: this is the number that says there is
            work to do on this screen, so it should not look settled. */}
        <div className={`kcard-t ${totals.unassigned ? 't-orange' : 't-teal'}`}>
          <div className="kcard-top">
            <span className="kcard-ic"><Solid d={totals.unassigned ? I.split : I.check} /></span>
            <span className={`kcard-l ${totals.unassigned ? 'hl' : ''}`}>Waiting to be assigned</span>
          </div>
          <div className="kcard-mid">
            <div>
              <div className="kcard-v">{n(totals.unassigned)}</div>
              <div className={`kcard-s ${totals.unassigned ? 'hl' : ''}`}>
                {totals.unassigned
                  ? `in ${waiting.length} batch${waiting.length === 1 ? '' : 'es'}`
                  : 'everything has an owner'}
              </div>
            </div>
          </div>
        </div>

        <div className="kcard-t t-violet">
          <div className="kcard-top">
            <span className="kcard-ic"><Solid d={I.check} /></span>
            <span className="kcard-l">Assigned</span>
          </div>
          <div className="kcard-mid">
            <div>
              <div className="kcard-v">{n(assigned)}</div>
              <div className="kcard-s">{assignedPct}% of everything batched</div>
            </div>
          </div>
        </div>
      </div>

      {/* ---- Ticked batches act here ------------------------- */}
      {selected.size > 0 && (
        <div className="bbar mb-4">
          <b>{selected.size}</b>
          <span className="sp">
            batch{selected.size === 1 ? '' : 'es'} ticked ·{' '}
            <b>{n(selectedUnassigned)}</b> lead{selectedUnassigned === 1 ? '' : 's'} still unassigned
          </span>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            <button className="btn btn-w"
                    disabled={selectedUnassigned === 0}
                    title={selectedUnassigned === 0
                      ? 'Every lead in these batches already has an owner'
                      : undefined}
                    onClick={() => setAssigning(selectedBatches)}>
              <Solid d={I.split} /> Assign these leads
            </button>
            <button className="btn btn-t" onClick={() => setSelected(new Set())}>Clear</button>
          </div>
        </div>
      )}

      {/* ---- Filters ----------------------------------------- */}
      <div className="card p-3 mb-4 flex items-center gap-3" style={{ flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: '1 1 300px', minWidth: 240 }}>
          <span style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)',
                         width: 15, height: 15, color: 'var(--text-3)' }}>
            <Solid d={I.search} />
          </span>
          <input className="field" style={{ paddingLeft: 34 }}
                 placeholder="Search batches…"
                 value={search} onChange={e => setSearch(e.target.value)} />
        </div>

        <div className="seg">
          {[['', 'All'], ['open', 'Open'], ['closed', 'Closed']].map(([v, l]) => (
            <button key={v} className={`seg-btn ${statusFilter === v ? 'on' : ''}`}
                    onClick={() => setStatusFilter(v)}>{l}</button>
          ))}
        </div>

        <div className="seg">
          {[['', 'Any origin'], ['import', 'File'], ['webhook', 'Automatic'], ['manual', 'By hand']].map(([v, l]) => (
            <button key={v} className={`seg-btn ${kindFilter === v ? 'on' : ''}`}
                    onClick={() => setKindFilter(v)}>{l}</button>
          ))}
        </div>

        <div className="seg" style={{ marginLeft: 'auto' }}>
          {SORTS.map(s => (
            <button key={s.key} className={`seg-btn ${sort === s.key ? 'on' : ''}`}
                    onClick={() => setSort(s.key)}>{s.label}</button>
          ))}
        </div>
      </div>

      {/* ---- The batches ------------------------------------- */}
      {isLoading ? <Spinner /> : rows.length === 0 ? (
        <EmptyState icon="▤"
                    title={all.length ? 'No batch matches those filters' : 'No batches yet'}
                    message={all.length
                      ? 'Clear the filters, or search for a different name or number.'
                      : 'Import a CSV, or wait for leads to arrive from a connected source — both create a batch on their own.'}
                    action={all.length
                      ? { label: 'Clear filters', onClick: () => { setSearch(''); setStatusFilter(''); setKindFilter(''); } }
                      : { label: '↑ Import CSV', onClick: () => nav('/leads/import') }} />
      ) : (
        <div className="bgrid">
          {rows.map(b => (
            <BatchCard key={b.id} batch={b}
                       picked={selected.has(b.id)}
                       onPick={() => toggle(b.id)}
                       onOpen={() => setViewing(b)}
                       onAssign={() => setAssigning([b])}
                       onRename={() => setRenaming(b)}
                       onToggleStatus={() => setStatus.mutate({
                         id: b.id, status: b.status === 'open' ? 'closed' : 'open',
                       })}
                       onUnassign={isAdmin ? () => setUnassigning(b) : undefined}
                       onDelete={() => setDeleting(b)} />
          ))}
        </div>
      )}

      {assigning && (
        <DistributeModal batches={assigning}
                         onDone={() => { setAssigning(null); setSelected(new Set()); invalidate(); }}
                         onClose={() => setAssigning(null)} />
      )}
      {renaming && <RenameModal batch={renaming}
                                onDone={() => { setRenaming(null); invalidate(); }}
                                onClose={() => setRenaming(null)} />}
      {viewing && <BatchBreakdown batch={viewing} onClose={() => setViewing(null)} />}
      {unassigning && (
        <UnassignModal batch={unassigning}
                       onDone={() => { setUnassigning(null); invalidate(); }}
                       onClose={() => setUnassigning(null)} />
      )}

      {deleting && (
        <ConfirmDialog
          title={`Delete "${deleting.label}"?`}
          message={`This removes the batch record only. All ${deleting.total_leads} lead(s) are kept and stay assigned exactly as they are — they simply stop belonging to a batch. This cannot be undone.`}
          confirmLabel="Delete batch"
          danger
          onConfirm={() => remove.mutate(deleting.id)}
          onCancel={() => setDeleting(null)}
        />
      )}
    </div>
  );
}

/* ---- One batch ---------------------------------------------- */
function BatchCard({ batch, picked, onPick, onOpen, onAssign, onRename, onToggleStatus, onUnassign, onDelete }: {
  batch: LeadBatch; picked: boolean;
  onPick: () => void; onOpen: () => void; onAssign: () => void;
  onRename: () => void; onToggleStatus: () => void; onDelete: () => void;
  /** Admin only: take the batch back from every agent. */
  onUnassign?: () => void;
}) {
  const origin = originOf(batch.kind);
  const assigned = batch.assigned_count;
  const unassigned = batch.unassigned_count;
  // The leads that actually exist. `total_leads` is a stored counter bumped
  // as leads arrive; deleting leads leaves it behind, and taking the meter
  // from it drew a full "unassigned" bar under the words "all handed out".
  const total = assigned + unassigned;
  const empty = total === 0;
  const pct = empty ? 0 : (assigned / total) * 100;

  return (
    <div className={`bcard ${origin.cls} ${picked ? 'on' : ''} ${batch.status === 'closed' ? 'closed' : ''}`}>
      <input className="bcard-pick" type="checkbox" checked={picked} onChange={onPick}
             aria-label={`Select ${batch.label}`} />

      <div className="bcard-top">
        <span className="bcard-ic"><Solid d={origin.icon} /></span>
        <div style={{ minWidth: 0, paddingRight: 24 }}>
          <div className="bcard-no">BATCH #{batch.number}</div>
          <div className="bcard-name" title={batch.label}>{batch.label}</div>
          {/* A webhook batch is named after its source and day, so repeating
              them underneath would say the same thing twice. */}
          {batch.kind !== 'webhook' && (
            <div className="bcard-meta">
              {batch.source_display}
              {batch.collection_date && ` · ${fmtDate(batch.collection_date)}`}
            </div>
          )}
        </div>
      </div>

      <div>
        <div className="bmeter" title={empty ? 'No leads in this batch' : `${assigned} assigned, ${unassigned} unassigned`}>
          {!empty && <>
            <i className="as" style={{ width: `${pct}%` }} />
            <i className="un" style={{ width: `${100 - pct}%` }} />
          </>}
        </div>
        <div className="bnums">
          {empty ? (
            <span style={{ color: 'var(--text-3)' }}>No leads in this batch</span>
          ) : (
            <>
              <span className="as"><b>{n(assigned)}</b> assigned</span>
              {unassigned > 0
                ? <span className="un"><b>{n(unassigned)}</b> waiting</span>
                : <span style={{ color: 'var(--text-3)' }}>all handed out</span>}
            </>
          )}
        </div>
      </div>

      <div className="flex gap-1.5 flex-wrap" style={{ fontSize: 0 }}>
        <span className={`chip ${batch.status === 'open' ? 'c-brand' : 'c-mute'}`}>
          <i className="pip" />{batch.status === 'open' ? 'Open' : 'Closed'}
        </span>
        <span className="chip c-mute">{origin.label}</span>
        <span className="chip c-mute">{n(total)} lead{total === 1 ? '' : 's'}</span>
        {/* The stored counter, when it no longer matches the leads that are
            actually here — deleted leads leave it behind. Said plainly
            rather than silently shown as the truth. */}
        {batch.total_leads !== total && (
          <span className="chip c-warm" title="The batch counter has not been repaired since leads were deleted">
            counter says {n(batch.total_leads)}
          </span>
        )}
        {batch.created_by_name && <span className="chip c-mute">by {batch.created_by_name}</span>}
      </div>

      <div className="bcard-foot">
        <button className="btn btn-p" disabled={unassigned === 0}
                title={unassigned === 0 ? 'Every lead here already has an owner' : undefined}
                onClick={onAssign}>
          <Solid d={I.split} /> Assign
        </button>
        <button className="btn btn-g" onClick={onOpen}>Breakdown</button>
        {/* The icon actions as one group: on a narrow card it wraps to its
            own line instead of pushing the last buttons out of the card. */}
        <div className="bcard-icons">
        {onUnassign && (
          <button className="btn btn-q btn-sm" disabled={assigned === 0} onClick={onUnassign}
                  title={assigned === 0 ? 'No lead in this batch is assigned' : 'Take these leads back from every agent'}>
            <Solid d={I.undo} />
          </button>
        )}
        <button className="btn btn-q btn-sm" onClick={onRename} title="Rename this batch">
          <Solid d={I.pencil} />
        </button>
        <button className="btn btn-q btn-sm" onClick={onToggleStatus}
                title={batch.status === 'open' ? 'Close this batch' : 'Reopen this batch'}>
          <Solid d={batch.status === 'open' ? I.lock : I.unlock} />
        </button>
        <button className="btn btn-q btn-sm" style={{ color: 'var(--hot)' }}
                onClick={onDelete} title="Delete this batch record">
          <Solid d={I.trash} />
        </button>
        </div>
      </div>
    </div>
  );
}

/* ---- Assign the chosen batches ------------------------------ */
function DistributeModal({ batches, onDone, onClose }: {
  batches: LeadBatch[]; onDone: () => void; onClose: () => void;
}) {
  const { showToast } = useToast();
  const [method, setMethod] = useState<DistributionMethod>('round_robin');
  const [agentIds, setAgentIds] = useState<number[]>([]);
  const [onlyUnassigned, setOnlyUnassigned] = useState(true);
  const [capEnabled, setCapEnabled] = useState(false);
  const [cap, setCap] = useState('100');

  const { data: agentsPage } = useQuery({
    queryKey: ['agents-for-distribute'],
    queryFn: () => authApi.listAgents({ page_size: 200 }).then(r => r.data),
  });
  const agents = agentsPage?.results ?? [];

  const toggle = (id: number) =>
    setAgentIds(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  const pool = batches.reduce(
    (n, b) => n + (onlyUnassigned ? b.unassigned_count : b.total_leads), 0,
  );

  const run = useMutation({
    mutationFn: () => leadsApi.distributeBatches({
      batch_ids: batches.map(b => b.id),
      agent_ids: agentIds,
      method,
      only_unassigned: onlyUnassigned,
      max_per_agent: capEnabled && Number(cap) > 0 ? Number(cap) : null,
    }),
    onSuccess: r => {
      const d = r.data;
      const summary = Object.entries(d.per_agent)
        .sort((a, b) => b[1] - a[1])
        .map(([n, c]) => `${n}: ${c}`)
        .join(' · ');
      if (d.distributed === 0) {
        showToast('warning', 'Nothing assigned', d.message ?? 'No leads matched.');
      } else {
        showToast('success', `${d.distributed} lead(s) assigned`, summary);
      }
      onDone();
    },
    onError: e => showToast('error', 'Could not assign', getErrorMessage(e)),
  });

  // Rough preview of the split. Exact for round robin and equal split; for
  // least-loaded it depends on each agent's current load, which only the
  // server knows — so it is labelled as approximate rather than quietly wrong.
  const perAgent = agentIds.length ? Math.floor(pool / agentIds.length) : 0;
  const remainder = agentIds.length ? pool % agentIds.length : 0;

  return (
    <Modal title="Assign batch leads"
           subtitle={batches.map(b => b.label).join(', ')}
           onClose={onClose} maxWidth="560px">
      <div className="flex flex-col gap-4">
        <div className="card-brutal" style={{ padding: '10px 12px', background: 'var(--paper)' }}>
          <div className="flex justify-between" style={{ fontSize: '0.85rem' }}>
            <span>Leads in scope</span>
            <b style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{pool.toLocaleString('en-IN')}</b>
          </div>
          <label className="flex items-center gap-2 mt-2" style={{ cursor: 'pointer', fontSize: '0.8rem' }}>
            <input type="checkbox" checked={onlyUnassigned}
                   onChange={e => setOnlyUnassigned(e.target.checked)} />
            Only leads that aren't assigned yet
          </label>
          {!onlyUnassigned && (
            <div style={{ fontSize: '0.73rem', color: 'var(--hot)', marginTop: 4 }}>
              Already-assigned leads will be moved to a different agent.
            </div>
          )}
        </div>

        <div>
          <label className="block font-heading font-bold mb-1"
                 style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Method</label>
          <select className="input-brutal w-full" style={{ cursor: 'pointer' }} value={method}
                  onChange={e => setMethod(e.target.value as DistributionMethod)}>
            {DISTRIBUTION_METHODS.map(m => (
              <option key={m.value} value={m.value}>{m.label}</option>
            ))}
          </select>
          <div style={{ fontSize: '0.74rem', color: 'var(--text-2)', marginTop: 4 }}>
            {DISTRIBUTION_METHODS.find(m => m.value === method)?.hint}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="font-heading font-bold"
                   style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
              Agents ({agentIds.length})
            </label>
            <div className="flex gap-2">
              <button className="btn-brutal px-2 py-1 font-heading font-bold"
                      style={{ fontSize: '0.68rem' }}
                      onClick={() => setAgentIds(agents.map(a => a.id))}>Select all</button>
              <button className="btn-brutal px-2 py-1 font-heading font-bold"
                      style={{ fontSize: '0.68rem' }}
                      onClick={() => setAgentIds([])}>Clear</button>
            </div>
          </div>
          <div className="card-brutal" style={{ padding: '8px 10px', maxHeight: 180, overflowY: 'auto' }}>
            {agents.map(a => (
              <label key={a.id} className="flex items-center gap-2"
                     style={{ fontSize: '0.8rem', padding: '3px 0', cursor: 'pointer' }}>
                <input type="checkbox" checked={agentIds.includes(a.id)}
                       onChange={() => toggle(a.id)} />
                {a.name}
                <span style={{ color: 'var(--text-3)', fontSize: '0.72rem' }}>
                  ({a.role?.replace('_', ' ')})
                </span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="flex items-center gap-2" style={{ cursor: 'pointer' }}>
            <input type="checkbox" checked={capEnabled}
                   onChange={e => setCapEnabled(e.target.checked)} />
            <span className="font-heading font-bold" style={{ fontSize: '0.8rem' }}>
              Cap open leads per agent
            </span>
          </label>
          {capEnabled && (
            <div className="flex items-center gap-2 mt-2" style={{ marginLeft: 24 }}>
              <input className="input-brutal" type="number" min="1" style={{ width: 110 }}
                     value={cap} onChange={e => setCap(e.target.value)} />
              <span style={{ fontSize: '0.75rem', color: 'var(--text-2)' }}>
                open leads each. Anyone already at this many is skipped; leftovers stay
                unassigned rather than piling onto a full agent.
              </span>
            </div>
          )}
        </div>

        {agentIds.length > 0 && pool > 0 && (
          <div className="card-brutal" style={{ padding: '10px 12px', background: 'var(--paper)' }}>
            <div style={{ fontSize: '0.8rem' }}>
              {method === 'least_loaded' ? (
                <>Roughly <b>{perAgent}</b> each, but least-loaded shifts more to whoever
                   has the lightest pipeline right now.</>
              ) : (
                <><b>{perAgent}</b> lead(s) each
                  {remainder > 0 && <>, with the first {remainder} agent(s) getting one extra</>}.</>
              )}
            </div>
          </div>
        )}

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                style={{ fontSize: '0.85rem' }}
                disabled={!agentIds.length || pool === 0 || run.isPending}
                onClick={() => run.mutate()}>
          {run.isPending
            ? 'Assigning…'
            : `Assign ${pool.toLocaleString('en-IN')} lead(s) to ${agentIds.length} agent(s)`}
        </button>
      </div>
    </Modal>
  );
}

/* ---- Rename ------------------------------------------------- */
function RenameModal({ batch, onDone, onClose }: {
  batch: LeadBatch; onDone: () => void; onClose: () => void;
}) {
  const { showToast } = useToast();
  const [name, setName] = useState(batch.name);
  const [notes, setNotes] = useState(batch.notes);

  const save = useMutation({
    mutationFn: () => leadsApi.updateBatch(batch.id, { name: name.trim(), notes: notes.trim() }),
    onSuccess: () => { showToast('success', 'Batch updated', ''); onDone(); },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  return (
    <Modal title={`Batch #${batch.number}`} onClose={onClose} maxWidth="440px">
      <div className="flex flex-col gap-3">
        <Input label="Name" value={name} onChange={e => setName(e.target.value)}
               placeholder={batch.label} maxLength={150} autoFocus />
        <Input label="Notes" value={notes} onChange={e => setNotes(e.target.value)}
               placeholder="Where these came from, what to do with them…" maxLength={300} />
        <p style={{ fontSize: '0.73rem', color: 'var(--text-3)' }}>
          Clearing the name puts the generated one back
          {batch.kind === 'webhook' ? ' (source and date).' : ` ("Batch ${batch.number}").`}
        </p>
        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                style={{ fontSize: '0.85rem' }}
                disabled={save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : 'Save'}
        </button>
      </div>
    </Modal>
  );
}

/* ---- Per-batch breakdown ------------------------------------ */
function BatchBreakdown({ batch, onClose }: { batch: LeadBatch; onClose: () => void }) {
  const { data, isLoading } = useQuery({
    queryKey: ['lead-batch-stats', batch.id],
    queryFn: () => leadsApi.batchStats(batch.id).then(r => r.data),
  });

  return (
    <Modal title={batch.label}
           subtitle={`Batch #${batch.number} · ${batch.source_display}`}
           onClose={onClose} maxWidth="520px">
      {isLoading || !data ? <Spinner /> : (
        <div className="flex flex-col gap-4">
          <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
            <StatCard label="Total" value={data.total} />
            <StatCard label="Assigned" value={data.total - data.unassigned} tone="green" />
            <StatCard label="Unassigned" value={data.unassigned}
                      tone={data.unassigned ? 'red' : 'green'} />
          </div>

          <div>
            <div className="font-heading font-black mb-2" style={{ fontSize: '0.85rem' }}>
              Who has these leads
            </div>
            {!data.by_agent.length ? (
              <p style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>
                Nobody yet — this batch has not been distributed.
              </p>
            ) : (
              <div className="card-brutal" style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <tbody>
                    {data.by_agent.map(a => (
                      <tr key={a.agent_id} style={{ borderBottom: '1px solid var(--line)' }}>
                        <td style={{ padding: '7px 10px', fontSize: '0.82rem' }}>{a.name}</td>
                        <td style={{ padding: '7px 10px', fontSize: '0.82rem',
                                     fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', textAlign: 'right', fontWeight: 700 }}>
                          {a.leads}
                        </td>
                        <td style={{ padding: '7px 10px', fontSize: '0.73rem',
                                     color: 'var(--text-3)', textAlign: 'right', width: 60 }}>
                          {data.total ? `${Math.round((a.leads / data.total) * 100)}%` : '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div>
            <div className="font-heading font-black mb-2" style={{ fontSize: '0.85rem' }}>
              Where they've got to
            </div>
            <div className="flex gap-2 flex-wrap">
              {Object.entries(data.by_status)
                .sort((a, b) => b[1] - a[1])
                .map(([s, n]) => (
                  <span key={s} className="font-heading font-bold"
                        style={{ background: 'var(--surface-2)', border: '1px solid var(--line)',
                                 padding: '3px 9px', fontSize: '0.74rem' }}>
                    {s.replace(/_/g, ' ')}: {n}
                  </span>
                ))}
            </div>
          </div>

          {batch.notes && (
            <p style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>{batch.notes}</p>
          )}
        </div>
      )}
    </Modal>
  );
}

/* ---- Take a batch back from every agent ---------------------
   So it can be assigned again — to other agents, or split differently.
   The leads keep their status, notes and call history. */
function UnassignModal({ batch, onDone, onClose }: {
  batch: LeadBatch; onDone: () => void; onClose: () => void;
}) {
  const { showToast } = useToast();
  const [onlyUncalled, setOnlyUncalled] = useState(false);

  const run = useMutation({
    mutationFn: () => leadsApi.unassignBatch(batch.id, onlyUncalled),
    onSuccess: r => {
      const per = Object.entries(r.data.per_agent).map(([name, count]) => `${name}: ${count}`).join(', ');
      showToast(r.data.unassigned ? 'success' : 'info',
        r.data.unassigned ? `${r.data.unassigned} lead${r.data.unassigned === 1 ? '' : 's'} unassigned` : 'Nothing to unassign',
        per || (onlyUncalled ? 'Every assigned lead here has been called already.' : ''));
      onDone();
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e)),
  });

  return (
    <Modal title={`Unassign batch #${batch.number}`} subtitle={batch.label} onClose={onClose} maxWidth="460px">
      <div className="flex flex-col gap-3">
        <p style={{ fontSize: '0.85rem' }}>
          Takes this batch's <b>{batch.assigned_count}</b> assigned lead{batch.assigned_count === 1 ? '' : 's'} back
          from every agent, so you can assign the batch again. Their status, notes and calls are kept.
        </p>
        <label className="flex items-center gap-2 cursor-pointer" style={{ fontSize: '0.82rem' }}>
          <input type="checkbox" checked={onlyUncalled} onChange={e => setOnlyUncalled(e.target.checked)} />
          Only leads that haven't been called yet (agents keep the ones they have worked)
        </label>
        <div className="flex gap-2 mt-2">
          <button className="btn btn-g" onClick={onClose}>Cancel</button>
          <button className="btn btn-p" disabled={run.isPending} onClick={() => run.mutate()}>
            {run.isPending ? 'Unassigning…' : 'Unassign'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
