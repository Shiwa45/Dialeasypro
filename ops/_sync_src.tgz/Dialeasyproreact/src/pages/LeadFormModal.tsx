// LeadFormModal.tsx — Create / Edit lead with Custom Fields support
import { useState, useEffect } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { leadsApi } from '../api';
import { Modal, Input, Select, Textarea } from '../components/ui';
import { LEAD_STATUSES, LEAD_PRIORITIES, LEAD_SOURCES, STATUS_NEEDS_REASON } from '../utils/fmt';
import { getErrorMessage } from '../utils/errors';
import type { Lead, CustomField } from '../types';

interface Props {
  lead?: Lead;
  onClose: () => void;
  onSuccess: () => void;
}

export default function LeadFormModal({ lead, onClose, onSuccess }: Props) {
  const isEdit = !!lead;

  // Standard fields
  // Lost / Invalid (and a sale, for agents) need a reason when the stage changes.
  const [statusReason, setStatusReason] = useState('');
  const [form, setForm] = useState({
    name: lead?.name ?? '',
    phone: lead?.phone ?? '',
    alternate_phone: lead?.alternate_phone ?? '',
    email: lead?.email ?? '',
    city: lead?.city ?? '',
    state: lead?.state ?? '',
    pincode: lead?.pincode ?? '',
    address: lead?.address ?? '',
    expected_close_date: lead?.expected_close_date ?? '',
    is_dnd: lead?.is_dnd ?? false,
    source: lead?.source ?? 'manual',
    status: lead?.status ?? 'new',
    priority: lead?.priority ?? 'warm',
    requirement: lead?.requirement ?? '',
    budget: lead?.budget ?? '',
    deal_value: lead?.deal_value ?? '',
    tags: (lead?.tags ?? []).join(', '),
  });

  // Custom fields state: { [field_key]: value }
  const [customFieldsState, setCustomFieldsState] = useState<Record<string, string>>({});

  // Fetch active Custom Fields definition for tenant
  const { data: customFields } = useQuery<CustomField[]>({
    queryKey: ['custom-fields'],
    queryFn: () => leadsApi.listCustomFields().then(r => r.data),
  });

  // Populate custom field values if editing an existing lead
  useEffect(() => {
    if (lead?.custom_field_values && lead.custom_field_values.length > 0) {
      const initialMap: Record<string, string> = {};
      lead.custom_field_values.forEach(cfv => {
        if (cfv.field_key) {
          initialMap[cfv.field_key] = cfv.value ?? '';
        }
      });
      setCustomFieldsState(initialMap);
    }
  }, [lead]);

  const mut = useMutation({
    mutationFn: () => {
      const payload: Record<string, unknown> = {
        name: form.name.trim(),
        phone: form.phone.trim(),
        source: form.source,
        status: form.status,
        ...(statusReason.trim() ? { status_reason: statusReason.trim() } : {}),
        priority: form.priority,
        requirement: form.requirement.trim(),
        tags: form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : [],
        custom_fields: customFieldsState,
      };
      // On edit every field is sent, so clearing one actually clears it —
      // blanks used to be left out, and an emptied email or city came back.
      const text = ['alternate_phone', 'email', 'city', 'state', 'pincode', 'address'] as const;
      for (const k of text) {
        const v = String(form[k] ?? '').trim();
        if (v || isEdit) payload[k] = v;
      }
      for (const k of ['budget', 'deal_value', 'expected_close_date'] as const) {
        const v = String(form[k] ?? '').trim();
        if (v) payload[k] = v; else if (isEdit) payload[k] = null;
      }
      payload.is_dnd = form.is_dnd;

      return isEdit ? leadsApi.update(lead!.id, payload) : leadsApi.create(payload);
    },
    onSuccess,
  });

  const f = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm(p => ({ ...p, [k]: e.target.value }));
  const toStr = (v: unknown) => (v == null ? '' : String(v));

  const handleCustomFieldChange = (fieldKey: string, val: string) => {
    setCustomFieldsState(prev => ({ ...prev, [fieldKey]: val }));
  };

  return (
    <Modal title={isEdit ? `Edit: ${lead!.name}` : 'New Lead'} onClose={onClose} maxWidth="680px">
      <div className="grid grid-cols-2 gap-3" style={{ maxHeight: '70vh', overflowY: 'auto', paddingRight: '4px' }}>
        <div className="col-span-2"><Input label="Full Name *" value={form.name} onChange={f('name')} placeholder="Rahul Sharma" /></div>
        <Input label="Phone *" value={form.phone} onChange={f('phone')} placeholder="+919876543210" />
        <Input label="Alternate Phone" value={form.alternate_phone} onChange={f('alternate_phone')} />
        <Input label="Email" type="email" value={form.email} onChange={f('email')} />
        <Input label="City" value={form.city} onChange={f('city')} />
        <Input label="State" value={form.state} onChange={f('state')} />
        <Input label="Pincode" value={form.pincode} onChange={f('pincode')} maxLength={6} inputMode="numeric" />
        <div className="col-span-2">
          <Textarea label="Address" value={form.address} onChange={f('address')} rows={2} />
        </div>
        <Select label="Source" value={form.source} onChange={f('source')}>
          {LEAD_SOURCES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </Select>
        <Select label="Status" value={form.status} onChange={f('status')}>
          {LEAD_STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </Select>
        {form.status !== (lead?.status ?? 'new') && (STATUS_NEEDS_REASON.includes(form.status) || form.status === 'converted') && (
          <Textarea label={form.status === 'converted' ? 'Sale note' : 'Reason for this status'}
                    required={STATUS_NEEDS_REASON.includes(form.status)}
                    value={statusReason} onChange={e => setStatusReason(e.target.value)} />
        )}
        <Select label="Priority" value={form.priority} onChange={f('priority')}>
          {LEAD_PRIORITIES.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
        </Select>
        <Input label="Budget (₹)" type="number" value={toStr(form.budget)} onChange={f('budget')} />
        <Input label="Deal Value (₹)" type="number" value={toStr(form.deal_value)} onChange={f('deal_value')} />
        <Input label="Expected close date" type="date" value={toStr(form.expected_close_date)} onChange={f('expected_close_date')} />
        <label className="flex items-center gap-2" style={{ fontSize: '0.82rem', cursor: 'pointer', alignSelf: 'end', paddingBottom: 10 }}>
          <input type="checkbox" checked={form.is_dnd} onChange={e => setForm(p => ({ ...p, is_dnd: e.target.checked }))} />
          Do not disturb (no calls or campaigns)
        </label>
        
        <div className="col-span-2">
          <Textarea label="Requirement" value={form.requirement} onChange={f('requirement')} placeholder="What is the lead looking for?" />
        </div>
        
        <div className="col-span-2">
          <Input label="Tags (comma-separated)" value={form.tags} onChange={f('tags')} placeholder="hot, referral, realty" />
        </div>

        {/* Dynamic Custom Fields Section */}
        {customFields && customFields.length > 0 && (
          <div className="col-span-2 mt-3 pt-3 border-t" style={{ borderColor: 'var(--text)' }}>
            <div className="font-heading font-black mb-3" style={{ fontSize: '0.9rem', color: 'var(--text)' }}>
              ⚙️ Custom Fields ({customFields.length})
            </div>
            <div className="grid grid-cols-2 gap-3">
              {customFields.map(field => {
                const val = customFieldsState[field.field_key] ?? '';
                const label = `${field.name}${field.is_required ? ' *' : ''}`;

                if (field.field_type === 'dropdown' && field.options && field.options.length > 0) {
                  return (
                    <div key={field.id}>
                      <Select
                        label={label}
                        value={val}
                        onChange={e => handleCustomFieldChange(field.field_key, e.target.value)}
                      >
                        <option value="">-- Select {field.name} --</option>
                        {(field.options ?? []).map(opt => (
                          <option key={opt} value={opt}>{opt}</option>
                        ))}
                      </Select>
                    </div>
                  );
                }

                if (field.field_type === 'checkbox') {
                  return (
                    <div key={field.id} className="flex items-center gap-2 pt-6">
                      <input
                        type="checkbox"
                        id={`cf_${field.id}`}
                        checked={val === 'true' || val === 'Yes' || val === '1'}
                        onChange={e => handleCustomFieldChange(field.field_key, e.target.checked ? 'Yes' : 'No')}
                        style={{ width: '18px', height: '18px', cursor: 'pointer' }}
                      />
                      <label htmlFor={`cf_${field.id}`} className="font-heading font-bold" style={{ fontSize: '0.8rem', cursor: 'pointer' }}>
                        {label}
                      </label>
                    </div>
                  );
                }

                return (
                  <div key={field.id}>
                    <Input
                      label={label}
                      type={field.field_type === 'number' ? 'number' : field.field_type === 'date' ? 'date' : 'text'}
                      value={val}
                      placeholder={field.placeholder}
                      onChange={e => handleCustomFieldChange(field.field_key, e.target.value)}
                    />
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {mut.error && (
        <div style={{ background: 'var(--lost-50)', border: '1px solid var(--hot)', padding: '8px 12px', fontSize: '0.8rem', marginTop: '12px' }}>
          {getErrorMessage(mut.error, 'An error occurred.')}
        </div>
      )}

      <div className="flex gap-3 mt-5 pt-4" style={{ borderTop: '2px solid var(--line)' }}>
        <button onClick={onClose} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black" style={{ fontSize: '0.85rem' }}>
          Cancel
        </button>
        <button
          onClick={() => mut.mutate()}
          disabled={mut.isPending || !form.name || !form.phone}
          className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black"
          style={{ fontSize: '0.85rem', boxShadow: 'var(--shadow)' }}
        >
          {mut.isPending ? '◌ Saving…' : isEdit ? 'Save Changes →' : 'Create Lead →'}
        </button>
      </div>
    </Modal>
  );
}
