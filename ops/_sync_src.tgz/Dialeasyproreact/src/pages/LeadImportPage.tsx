import { useState, useRef } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { leadsApi, authApi, DISTRIBUTION_METHODS, type DistributionMethod } from '../api';
import { SectionHeader, useToast, Spinner } from '../components/ui';
import { fmtDateTime } from '../utils/fmt';
import type { LeadImportJob } from '../types';
import { getErrorMessage } from '../utils/errors';

interface PreviewData {
  headers: string[];
  sample_rows: Record<string, string>[];
  total_rows: number;
  auto_mapping: Record<string, string>;
  available_fields: { key: string; label: string; required?: boolean }[];
}

export default function LeadImport() {
  const { showToast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [step, setStep] = useState<'upload' | 'mapping' | 'progress'>('upload');
  
  // Mapping state: { leadFieldKey: csvHeaderName }
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [previewData, setPreviewData] = useState<PreviewData | null>(null);
  const [options, setOptions] = useState({ duplicate_action: 'skip', source: 'csv_import' });

  // ---- Batch & auto-assign ----
  // Blank name is fine — the backend falls back to "Batch <n>".
  const [batchName, setBatchName] = useState('');
  const [autoAssign, setAutoAssign] = useState(false);
  const [assignMethod, setAssignMethod] = useState<DistributionMethod>('round_robin');
  const [assignAgents, setAssignAgents] = useState<number[]>([]);
  const [capEnabled, setCapEnabled] = useState(false);
  const [maxPerAgent, setMaxPerAgent] = useState('100');
  const [jobId, setJobId] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  // Only fetched once auto-assign is switched on — an admin who never uses
  // it should not pay for an agent list on every visit to this page.
  const { data: agentsPage } = useQuery({
    queryKey: ['agents-for-import'],
    queryFn: () => authApi.listAgents({ page_size: 200 }).then(r => r.data),
    enabled: autoAssign,
  });
  const agents = agentsPage?.results ?? [];

  const toggleAgent = (id: number) =>
    setAssignAgents(prev =>
      prev.includes(id) ? prev.filter(a => a !== id) : [...prev, id],
    );

  const { data: jobStatus } = useQuery({
    queryKey: ['import-job', jobId],
    queryFn: () => leadsApi.getImportJob(jobId!).then(r => r.data as LeadImportJob),
    enabled: !!jobId,
    refetchInterval: 3000,
  });

  // Step 1 -> Step 2: Upload file & fetch preview + headers
  const previewMut = useMutation({
    mutationFn: (f: File) => leadsApi.previewImport(f),
    onSuccess: res => {
      const data = res.data;
      setPreviewData(data);
      
      // Initialize mapping from auto_mapping suggestions
      const initialMap: Record<string, string> = {};
      data.available_fields.forEach(field => {
        if (data.auto_mapping[field.key]) {
          initialMap[field.key] = data.auto_mapping[field.key];
        }
      });
      setMapping(initialMap);
      setStep('mapping');
    },
    onError: (e: unknown) => {
      showToast('error', 'File preview failed', getErrorMessage(e, 'Could not read CSV/XLSX headers. Please check file format.'));
    },
  });

  // Step 2 -> Step 3: Start Import with column mapping
  const importMut = useMutation({
    mutationFn: () => {
      // Invert mapping to { crmField: csvHeader }
      const columnMappingJson = JSON.stringify(mapping);
      // Every value crosses as multipart form data, so everything must be a
      // string — including the booleans. The backend parses "true"/"false"
      // explicitly rather than trusting bool(), which is True for "false".
      return leadsApi.importLeads(file!, {
        ...options,
        column_mapping: columnMappingJson,
        batch_name: batchName.trim(),
        auto_assign: autoAssign ? 'true' : 'false',
        ...(autoAssign
          ? {
              assign_method: assignMethod,
              assign_to_agents: JSON.stringify(assignAgents),
              ...(capEnabled && Number(maxPerAgent) > 0
                ? { assign_max_per_agent: String(Number(maxPerAgent)) }
                : {}),
            }
          : {}),
      });
    },
    onSuccess: res => {
      setJobId(res.data.import_job_id);
      setStep('progress');
      showToast('success', 'Import started!', 'Tracking progress below.');
    },
    onError: (e: unknown) => {
      const msg = (e as { response?: { data?: { message?: string } } })?.response?.data?.message;
      showToast('error', 'Import failed', msg ?? 'Check your column mapping and file content.');
    },
  });

  const handleFileSelect = (f: File) => {
    if (f && (f.name.endsWith('.csv') || f.name.endsWith('.xlsx') || f.name.endsWith('.xls'))) {
      setFile(f);
      previewMut.mutate(f);
    } else {
      showToast('error', 'Invalid file', 'Only CSV and XLSX files are supported.');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    if (e.dataTransfer.files?.[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleMappingChange = (leadFieldKey: string, csvHeader: string) => {
    setMapping(prev => {
      const next = { ...prev };
      if (!csvHeader) {
        delete next[leadFieldKey];
      } else {
        next[leadFieldKey] = csvHeader;
      }
      return next;
    });
  };

  const job = jobStatus as LeadImportJob | undefined;
  const STATUS_BG: Record<string, string> = {
    processing: 'var(--warm-50)', completed: 'var(--won-50)', partial: 'var(--warm-50)',
    failed: 'var(--lost-50)', pending: 'var(--surface-2)',
  };

  return (
    <div className="p-6 flex flex-col gap-5" style={{ background: 'var(--paper)', minHeight: '100%' }}>
      <SectionHeader title="Import Leads" sub="Upload CSV or Excel (XLSX) and map your fields" />

      {/* Stepper indicator */}
      <div className="flex items-center gap-3 mb-2" style={{ maxWidth: '780px' }}>
        <div
          className="px-3 py-1 font-heading font-black"
          style={{
            background: step === 'upload' ? 'var(--brass-50)' : 'var(--line)',
            border: '1px solid var(--line)',
            fontSize: '0.8rem',
          }}
        >
          1. Upload File
        </div>
        <span style={{ fontWeight: 'bold' }}>→</span>
        <div
          className="px-3 py-1 font-heading font-black"
          style={{
            background: step === 'mapping' ? 'var(--brass-50)' : 'var(--line)',
            border: '1px solid var(--line)',
            fontSize: '0.8rem',
          }}
        >
          2. Map Fields
        </div>
        <span style={{ fontWeight: 'bold' }}>→</span>
        <div
          className="px-3 py-1 font-heading font-black"
          style={{
            background: step === 'progress' ? 'var(--brass-50)' : 'var(--line)',
            border: '1px solid var(--line)',
            fontSize: '0.8rem',
          }}
        >
          3. Import & Progress
        </div>
      </div>

      <div style={{ maxWidth: '780px' }}>
        {/* STEP 1: UPLOAD FILE */}
        {step === 'upload' && (
          <div className="card p-5 flex flex-col gap-4">
            <div
              onClick={() => fileRef.current?.click()}
              onDragOver={e => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
              style={{
                border: `3px dashed ${dragging ? 'var(--brass-50)' : 'var(--text)'}`,
                padding: '50px 20px',
                textAlign: 'center',
                cursor: 'pointer',
                background: file ? 'var(--brass-50)' : dragging ? 'var(--surface)ff0' : 'var(--surface-2)',
                transition: 'all 0.15s ease',
              }}
            >
              <input
                ref={fileRef}
                type="file"
                accept=".csv,.xlsx,.xls,.xlsm,.ods,.tsv,.txt"
                style={{ display: 'none' }}
                onChange={e => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
              />
              <div style={{ fontSize: '3rem', marginBottom: '10px', opacity: file ? 1 : 0.4 }}>
                {previewMut.isPending ? '◌' : file ? '✓' : '↑'}
              </div>
              <div className="font-heading font-black" style={{ fontSize: '1.05rem', marginBottom: '4px' }}>
                {previewMut.isPending ? 'Analyzing file columns…' : file ? file.name : 'Drop your CSV or XLSX file here'}
              </div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>
                {previewMut.isPending
                  ? 'Reading headers and previewing rows...'
                  : file
                  ? `${(file.size / 1024).toFixed(1)} KB · Click to change`
                  : 'or click to browse · CSV / XLSX supported'}
              </div>
            </div>

            {previewMut.isPending && (
              <div className="flex items-center justify-center gap-2 py-4">
                <Spinner />
                <span className="font-heading font-bold" style={{ fontSize: '0.85rem' }}>Processing file headers...</span>
              </div>
            )}
          </div>
        )}

        {/* STEP 2: FIELD MAPPING */}
        {step === 'mapping' && previewData && (
          <div className="card p-5 flex flex-col gap-5">
            <div className="flex items-center justify-between border-b pb-3" style={{ borderColor: 'var(--text)' }}>
              <div>
                <h3 className="font-heading font-black" style={{ fontSize: '1.1rem' }}>Map File Columns to Lead Fields</h3>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-2)' }}>
                  File: <strong>{file?.name}</strong> · Total Rows: <strong>{previewData.total_rows}</strong>
                </div>
              </div>
              <button
                onClick={() => setStep('upload')}
                className="btn-brutal px-3 py-1"
                style={{ fontSize: '0.75rem', background: 'var(--line)' }}
              >
                Change File
              </button>
            </div>

            {/* Mapping Table */}
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.82rem' }}>
                <thead>
                  <tr>
                    <th className="th">CRM Lead Field</th>
                    <th className="th">CSV / Excel Column</th>
                    <th className="th">Sample Data (Row 1)</th>
                  </tr>
                </thead>
                <tbody>
                  {previewData.available_fields.map((field, idx) => {
                    const selectedHeader = mapping[field.key] || '';
                    const sampleValue = selectedHeader && previewData.sample_rows[0] ? previewData.sample_rows[0][selectedHeader] : '—';

                    return (
                      <tr key={field.key} style={{ borderBottom: '1px solid var(--line)', background: idx % 2 === 0 ? 'var(--surface)' : 'var(--surface-2)' }}>
                        <td style={{ padding: '10px 12px', fontWeight: 'bold' }}>
                          {field.label} {field.required && <span style={{ color: 'var(--hot)' }}>*</span>}
                        </td>
                        <td style={{ padding: '8px 12px' }}>
                          <select
                            value={selectedHeader}
                            onChange={e => handleMappingChange(field.key, e.target.value)}
                            className="input-brutal w-full"
                            style={{ cursor: 'pointer', padding: '6px 8px', fontSize: '0.8rem' }}
                          >
                            <option value="">-- Do Not Import --</option>
                            {previewData.headers.map(h => (
                              <option key={h} value={h}>
                                {h}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td style={{ padding: '8px 12px', color: 'var(--text-2)', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>
                          {sampleValue || '—'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Unmapped custom fields.
                Leaving one unmapped is legitimate — the sheet may not carry that
                column — but it is silent, and the result on the lead detail
                screen (a label with no value) looks identical to the import
                having failed. Naming them here makes the choice deliberate. */}
            {(() => {
              const unmapped = previewData.available_fields.filter(
                f => f.key.startsWith('custom_') && !mapping[f.key]
              );
              if (unmapped.length === 0) return null;
              return (
                <div className="p-3" style={{ background: 'var(--brass-50)', border: '1px solid var(--brass-600)' }}>
                  <div className="font-heading font-bold" style={{ fontSize: '0.8rem', marginBottom: 4 }}>
                    ⚠ {unmapped.length} custom field{unmapped.length > 1 ? 's' : ''} will not be imported
                  </div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-2)', lineHeight: 1.5 }}>
                    {unmapped.map(f => f.label.replace(' (Custom Field)', '')).join(', ')}
                    {' — '}pick a column above for any of these you want filled in.
                    They will show as blank on every imported lead otherwise.
                  </div>
                </div>
              );
            })()}

            {/* Settings & Options */}
            <div className="grid grid-cols-2 gap-4 border-t pt-4" style={{ borderColor: 'var(--text)' }}>
              <div>
                <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.75rem', textTransform: 'uppercase' }}>
                  Duplicate Action
                </label>
                <select
                  value={options.duplicate_action}
                  onChange={e => setOptions(p => ({ ...p, duplicate_action: e.target.value }))}
                  className="input-brutal w-full"
                  style={{ cursor: 'pointer' }}
                >
                  <option value="skip">Skip duplicates (by Phone)</option>
                  <option value="update">Update existing lead</option>
                  <option value="create_new">Allow duplicates</option>
                </select>
              </div>

              <div>
                <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.75rem', textTransform: 'uppercase' }}>
                  Default Lead Source
                </label>
                <select
                  value={options.source}
                  onChange={e => setOptions(p => ({ ...p, source: e.target.value }))}
                  className="input-brutal w-full"
                  style={{ cursor: 'pointer' }}
                >
                  <option value="csv_import">CSV Import</option>
                  <option value="indiamart">IndiaMART</option>
                  <option value="manual">Manual</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            {/* ---- Batch ---- */}
            <div className="border-t pt-4" style={{ borderColor: 'var(--text)' }}>
              <label className="block font-heading font-bold mb-1"
                     style={{ fontSize: '0.75rem', textTransform: 'uppercase' }}>
                Batch name <span style={{ color: 'var(--hot)' }}>*</span>
              </label>
              <input
                className="input-brutal w-full"
                value={batchName}
                onChange={e => setBatchName(e.target.value)}
                placeholder={`e.g. Diwali campaign — ${new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}`}
                maxLength={150}
                style={!batchName.trim() ? { borderColor: 'var(--hot)' } : undefined}
              />
              <div style={{ fontSize: '0.74rem', color: batchName.trim() ? 'var(--text-2)' : 'var(--hot)', marginTop: 4 }}>
                {batchName.trim()
                  ? `These ${previewData.total_rows} leads become one batch you can assign, filter and report on as a unit.`
                  : 'Required. A name is how anyone finds this consignment again — "Batch 14" tells nobody where the leads came from.'}
              </div>
            </div>

            {/* ---- Auto-assign ---- */}
            <div className="border-t pt-4" style={{ borderColor: 'var(--text)' }}>
              <label className="flex items-center gap-2" style={{ cursor: 'pointer' }}>
                <input type="checkbox" checked={autoAssign}
                       onChange={e => setAutoAssign(e.target.checked)} />
                <span className="font-heading font-black" style={{ fontSize: '0.88rem' }}>
                  Auto-assign these leads to agents
                </span>
              </label>
              <div style={{ fontSize: '0.74rem', color: 'var(--text-2)', marginTop: 4, marginLeft: 24 }}>
                Leads are distributed as soon as the import finishes — agents see them
                straight away, with no second step.
              </div>

              {autoAssign && (
                <div className="flex flex-col gap-4 mt-4" style={{ marginLeft: 24 }}>
                  {/* Method */}
                  <div>
                    <label className="block font-heading font-bold mb-1"
                           style={{ fontSize: '0.75rem', textTransform: 'uppercase' }}>
                      Distribution method
                    </label>
                    <select className="input-brutal w-full" style={{ cursor: 'pointer' }}
                            value={assignMethod}
                            onChange={e => setAssignMethod(e.target.value as DistributionMethod)}>
                      {DISTRIBUTION_METHODS.map(m => (
                        <option key={m.value} value={m.value}>{m.label}</option>
                      ))}
                    </select>
                    <div style={{ fontSize: '0.74rem', color: 'var(--text-2)', marginTop: 4 }}>
                      {DISTRIBUTION_METHODS.find(m => m.value === assignMethod)?.hint}
                    </div>
                  </div>

                  {/* Agents */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-heading font-bold"
                             style={{ fontSize: '0.75rem', textTransform: 'uppercase' }}>
                        Assign to ({assignAgents.length} selected)
                      </label>
                      <div className="flex gap-2">
                        <button type="button"
                                className="btn-brutal px-2 py-1 font-heading font-bold"
                                style={{ fontSize: '0.68rem' }}
                                onClick={() => setAssignAgents(agents.map(a => a.id))}>
                          Select all
                        </button>
                        <button type="button"
                                className="btn-brutal px-2 py-1 font-heading font-bold"
                                style={{ fontSize: '0.68rem' }}
                                onClick={() => setAssignAgents([])}>
                          Clear
                        </button>
                      </div>
                    </div>
                    <div className="card-brutal"
                         style={{ padding: '8px 10px', maxHeight: 170, overflowY: 'auto' }}>
                      {!agents.length && (
                        <div style={{ fontSize: '0.78rem', color: 'var(--text-3)' }}>
                          Loading agents…
                        </div>
                      )}
                      {agents.map(a => (
                        <label key={a.id} className="flex items-center gap-2"
                               style={{ fontSize: '0.8rem', padding: '3px 0', cursor: 'pointer' }}>
                          <input type="checkbox"
                                 checked={assignAgents.includes(a.id)}
                                 onChange={() => toggleAgent(a.id)} />
                          {a.name}
                          <span style={{ color: 'var(--text-3)', fontSize: '0.72rem' }}>
                            ({a.role?.replace('_', ' ')})
                          </span>
                        </label>
                      ))}
                    </div>
                    {assignMethod === 'round_robin' && assignAgents.length > 1 && (
                      <div style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginTop: 4 }}>
                        Round robin starts with the first agent you ticked and cycles in
                        that order.
                      </div>
                    )}
                  </div>

                  {/* Cap */}
                  <div>
                    <label className="flex items-center gap-2" style={{ cursor: 'pointer' }}>
                      <input type="checkbox" checked={capEnabled}
                             onChange={e => setCapEnabled(e.target.checked)} />
                      <span className="font-heading font-bold" style={{ fontSize: '0.8rem' }}>
                        Cap open leads per agent
                      </span>
                    </label>
                    {capEnabled && (
                      <div className="flex items-center gap-2 mt-2" style={{ marginLeft: 24 }}>
                        <input className="input-brutal" type="number" min="1" style={{ width: 110 }}
                               value={maxPerAgent}
                               onChange={e => setMaxPerAgent(e.target.value)} />
                        <span style={{ fontSize: '0.76rem', color: 'var(--text-2)' }}>
                          open leads each. Agents already at this many are skipped, and
                          anything left over stays unassigned rather than piling onto
                          someone who is full.
                        </span>
                      </div>
                    )}
                  </div>

                  {!assignAgents.length && (
                    <div style={{ fontSize: '0.75rem', color: 'var(--hot)', fontWeight: 700 }}>
                      Pick at least one agent, or turn auto-assign off.
                    </div>
                  )}
                </div>
              )}
            </div>

            <button
              onClick={() => importMut.mutate()}
              disabled={
                importMut.isPending || !mapping['phone'] || !mapping['name']
                || !batchName.trim()
                || (autoAssign && assignAgents.length === 0)
              }
              className="btn-brutal btn-primary w-full py-3 font-heading font-black"
              style={{ fontSize: '0.95rem', boxShadow: 'var(--shadow)' }}
            >
              {importMut.isPending ? '◌ Starting Import...' : '🚀 Confirm & Start Import →'}
            </button>
            {(!mapping['phone'] || !mapping['name']) && (
              <div style={{ color: 'var(--hot)', fontSize: '0.75rem', textAlign: 'center', fontWeight: 'bold' }}>
                ⚠️ Please map at least "Full Name" and "Phone Number" before importing.
              </div>
            )}
            {!batchName.trim() && (
              <div style={{ color: 'var(--hot)', fontSize: '0.75rem', textAlign: 'center', fontWeight: 'bold' }}>
                ⚠️ Give this batch a name before importing.
              </div>
            )}
          </div>
        )}

        {/* STEP 3: PROGRESS & STATUS */}
        {step === 'progress' && job && (
          <div className="card p-5 flex flex-col gap-4" style={{ background: STATUS_BG[job.status] ?? 'var(--surface)' }}>
            <div className="flex items-center justify-between border-b pb-3" style={{ borderColor: 'var(--text)' }}>
              <div className="font-heading font-black" style={{ fontSize: '1rem' }}>
                {job.original_filename}
              </div>
              <span className="badge" style={{ background: STATUS_BG[job.status] ?? 'var(--line)', borderColor: 'var(--text)' }}>
                {job.status.toUpperCase()}
              </span>
            </div>

            <div className="progress-bar my-2" style={{ height: '14px', border: '1px solid var(--line)' }}>
              <div className="progress-fill" style={{ width: `${job.progress_percent}%`, background: 'var(--won)' }} />
            </div>

            <div className="grid grid-cols-3 gap-3 text-center my-2">
              <div className="card p-3" style={{ background: 'var(--surface)' }}>
                <div className="font-heading font-black" style={{ fontSize: '1.6rem', color: 'var(--won)' }}>
                  {job.successful_rows}
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-2)', fontWeight: 'bold' }}>Successful</div>
              </div>
              <div className="card p-3" style={{ background: 'var(--surface)' }}>
                <div className="font-heading font-black" style={{ fontSize: '1.6rem', color: 'var(--hot)' }}>
                  {job.failed_rows}
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-2)', fontWeight: 'bold' }}>Failed</div>
              </div>
              <div className="card p-3" style={{ background: 'var(--surface)' }}>
                <div className="font-heading font-black" style={{ fontSize: '1.6rem', color: 'var(--text-3)' }}>
                  {job.duplicate_rows}
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-2)', fontWeight: 'bold' }}>Duplicates</div>
              </div>
            </div>

            <div style={{ fontSize: '0.8rem', color: '#444', textAlign: 'center' }}>
              <strong>{job.processed_rows}</strong> of <strong>{job.total_rows}</strong> rows processed ({job.progress_percent}%)
            </div>

            {job.completed_at && (
              <div style={{ fontSize: '0.75rem', color: 'var(--text-2)', textAlign: 'center' }}>
                Completed at: {fmtDateTime(job.completed_at)}
              </div>
            )}

            {/* ---- Batch ---- */}
            {job.batch_label && (
              <div className="card p-3" style={{ background: 'var(--surface)' }}>
                <div className="font-heading font-black" style={{ fontSize: '0.85rem' }}>
                  Batch #{job.batch_number} · {job.batch_label}
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-2)', marginTop: 2 }}>
                  Distribute, filter or report on these leads as a unit from the
                  Batches screen.
                </div>
              </div>
            )}

            {/* ---- Auto-assign outcome ----
                Shown only once there is something to report. A distribution
                that partly failed still shows what DID land — reporting only
                the error would make an admin think nothing was assigned. */}
            {job.auto_assign && (job.assignment_result?.distributed !== undefined
                                 || job.assignment_result?.error) && (
              <div className="card p-3" style={{
                background: job.assignment_result?.error ? 'var(--lost-50)' : 'var(--won-50)',
              }}>
                <div className="font-heading font-black" style={{ fontSize: '0.85rem' }}>
                  {job.assignment_result?.distributed
                    ? `${job.assignment_result.distributed} lead(s) assigned`
                    : 'Auto-assign did not place any leads'}
                </div>
                {!!job.assignment_result?.per_agent
                  && Object.keys(job.assignment_result.per_agent).length > 0 && (
                  <div style={{ fontSize: '0.78rem', marginTop: 6 }}>
                    {Object.entries(job.assignment_result.per_agent)
                      .sort((a, b) => b[1] - a[1])
                      .map(([name, n]) => (
                        <div key={name} className="flex justify-between"
                             style={{ padding: '1px 0', maxWidth: 320 }}>
                          <span>{name}</span>
                          <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>{n}</span>
                        </div>
                      ))}
                  </div>
                )}
                {!!job.assignment_result?.unassigned && (
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-2)', marginTop: 6 }}>
                    {job.assignment_result.unassigned} lead(s) left unassigned.
                  </div>
                )}
                {job.assignment_result?.message && (
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-2)', marginTop: 4 }}>
                    {job.assignment_result.message}
                  </div>
                )}
              </div>
            )}

            <div className="flex gap-3 justify-center mt-3">
              <button
                onClick={() => {
                  setStep('upload');
                  setFile(null);
                  setPreviewData(null);
                  setJobId(null);
                }}
                className="btn-brutal px-4 py-2 font-heading font-bold"
                style={{ fontSize: '0.85rem', background: 'var(--surface)' }}
              >
                Import Another File
              </button>

              <a
                href="/leads"
                className="btn-brutal btn-primary px-5 py-2 font-heading font-black"
                style={{ fontSize: '0.85rem', textDecoration: 'none' }}
              >
                View Imported Leads →
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
