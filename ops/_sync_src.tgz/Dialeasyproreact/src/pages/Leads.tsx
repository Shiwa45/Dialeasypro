import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { DISTRIBUTION_METHODS, type DistributionMethod, leadsApi, authApi, callsApi } from '../api';
import {
  SectionHeader, StatusBadge, Pagination,
  Spinner, EmptyState, ConfirmDialog, Select, useToast,
  Modal, Input,
} from '../components/ui';
import { fmtDate, fmtRelative, LEAD_STATUSES, LEAD_SOURCES, localISODate } from '../utils/fmt';
import { getErrorMessage, isUpgradeRequired } from '../utils/errors';
import { useAuthStore } from '../store/authStore';
import { useWorkspace } from '../hooks/useWorkspace';
import LeadFormModal from './LeadFormModal';
import { isAdmin as isAdminRole } from '../utils/roles';
import { fetchAllPages } from '../utils/fetchAll';

export default function Leads() {
  const [params, setParams] = useSearchParams();
  const nav = useNavigate();
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { agent } = useAuthStore();
  const isAdmin = isAdminRole(agent);
  // Deleting a lead is manager-or-admin on the server; offering the button to
  // everyone else only produced a 403.
  const canDelete = isAdmin || agent?.role === 'manager';
  // Agent workspace (agent, read-only): their own leads to work, nothing to
  // manage. Every create/export/assign control below hides on this; the API
  // refuses those actions to these roles regardless.
  const { isAgentWorkspace } = useWorkspace();
  const manages = !isAgentWorkspace;

  const [selected, setSelected] = useState<number[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [bulkAgent, setBulkAgent] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);
  const [confirmBulkDelete, setConfirmBulkDelete] = useState(false);
  const [showDistribute, setShowDistribute] = useState(false);
  const [distAgents, setDistAgents] = useState<number[]>([]);
  const [distOnlyUnassigned, setDistOnlyUnassigned] = useState(true);
  const [distLimit, setDistLimit] = useState('');
  const [distBatches, setDistBatches] = useState<number[]>([]);
  const [distMethod, setDistMethod] = useState<DistributionMethod>('round_robin');
  const [distCap, setDistCap] = useState('');

  const page = Number(params.get('page') ?? 1);
  const status = params.get('status') ?? '';
  const priority = params.get('priority') ?? '';
  const source = params.get('source') ?? '';
  const search = params.get('search') ?? '';
  const assigned_to = params.get('assigned_to') ?? '';
  const overdue = params.get('overdue') ?? '';
  // Last call outcome: a disposition id, "connected"/"not_connected", "none",
  // or "never" (dialled but never answered).
  const lastCall = params.get('last_call') ?? '';

  const set = (k: string, v: string) => {
    const p = new URLSearchParams(params);
    if (v) p.set(k, v); else p.delete(k);
    // Reset to page 1 only when a filter changes — NOT when the page itself
    // is being changed (otherwise pagination can never leave page 1).
    if (k !== 'page') p.set('page', '1');
    setParams(p);
  };

  const { data, isLoading } = useQuery({
    queryKey: ['leads', page, status, priority, source, search, assigned_to, overdue, lastCall],
    queryFn: () => leadsApi.list({
      page, status: status || undefined, priority: priority || undefined,
      source: source || undefined, search: search || undefined,
      assigned_to: assigned_to || undefined, overdue: overdue || undefined,
      ...(lastCall === 'never' ? { never_connected: 'true' }
        : lastCall === 'uncalled' ? { never_called: 'true' }
        : lastCall ? { last_disposition: lastCall } : {}),
      page_size: 25,
    }).then(r => r.data),
    placeholderData: prev => prev,
  });

  const { data: dispositions } = useQuery({
    queryKey: ['dispositions'],
    queryFn: () => callsApi.dispositions().then(r => r.data),
    staleTime: 5 * 60 * 1000,
  });

  // Agents list for the bulk-assign dropdown (admin/manager only endpoint)
  const { data: agentsData } = useQuery({
    queryKey: ['agents-for-assign'],
    // Every page: the API caps one at 100.
    queryFn: () => fetchAllPages(page => authApi.listAgents({ page_size: 100, page })),
    // Manager-only endpoint: an agent's page must not fire a request that is
    // certain to be refused every time it loads.
    enabled: manages,
  });
  const agents = agentsData?.results ?? [];

  const deleteMut = useMutation({
    mutationFn: (id: number) => leadsApi.delete(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['leads'] });
      showToast('success', 'Lead deleted', 'Lead has been removed.');
      setConfirmDelete(null);
    },
  });

  // Delete the ticked leads together — one at a time was the only way.
  const bulkDeleteMut = useMutation({
    mutationFn: () => leadsApi.bulkDelete(selected),
    onSuccess: r => {
      qc.invalidateQueries({ queryKey: ['leads'] });
      qc.invalidateQueries({ queryKey: ['lead-batches'] });
      showToast('success', `${r.data.deleted} lead${r.data.deleted === 1 ? '' : 's'} deleted`, '');
      setSelected([]);
      setConfirmBulkDelete(false);
    },
    onError: (e: unknown) => {
      showToast('error', 'Delete failed', getErrorMessage(e, 'Please try again.'));
      setConfirmBulkDelete(false);
    },
  });

  const bulkAssignMut = useMutation({
    mutationFn: () => leadsApi.bulkAssign(selected, Number(bulkAgent)),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['leads'] });
      showToast('success', `${selected.length} leads assigned`, '');
      setSelected([]);
      setBulkAgent('');
    },
  });

  const statusMut = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => leadsApi.updateStatus(id, status),
    // ['leads'] — the list this table reads. It used to refresh the kanban
    // query instead, so changing a status in the table left the old one on
    // screen until the page was reloaded.
    onSuccess: () => qc.invalidateQueries({ queryKey: ['leads'] }),
  });

  // Only while the distribute modal is open — the leads grid itself has no
  // use for the batch list, and fetching it on every page view is waste.
  // Every batch with something left to place. The list is paginated and
  // capped at 100 per page server-side, so one request quietly hid the rest
  // once a tenant had more than a hundred such batches.
  const { data: pickableBatches = [] } = useQuery({
    queryKey: ['lead-batches-picker'],
    enabled: showDistribute,
    queryFn: async () => {
      const out: import('../types').LeadBatch[] = [];
      for (let pageNo = 1; pageNo <= 20; pageNo++) {
        const { data } = await leadsApi.batches({
          has_unassigned: 'true', page_size: 100, page: pageNo,
        });
        out.push(...(data.results ?? []));
        if (!data.next) break;
      }
      return out;
    },
  });

  const distributeMut = useMutation({
    mutationFn: () => leadsApi.distribute({
      agent_ids: distAgents,
      only_unassigned: distOnlyUnassigned,
      batch_ids: distBatches,
      method: distMethod,
      max_per_agent: distCap ? Number(distCap) : null,
      statuses: status ? [status] : [],
      priorities: priority ? [priority] : [],
      sources: source ? [source] : [],
      search: search || undefined,
      limit: distLimit ? Number(distLimit) : null,
    }).then(r => r.data),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['leads'] });
      if (data.distributed === 0) {
        showToast('info', 'No leads matched', data.message ?? 'Adjust filters and try again.');
      } else {
        const summary = Object.entries(data.per_agent).map(([n, c]) => `${n}: ${c}`).join(', ');
        showToast('success', `${data.distributed} leads assigned`, summary);
      }
      if (data.unassigned > 0) {
        showToast('warning', `${data.unassigned} lead(s) left unassigned`,
                  data.message ?? 'Every selected agent hit the cap.');
      }
      setShowDistribute(false);
      setDistAgents([]);
      setDistLimit('');
      setDistBatches([]);
      setDistCap('');
    },
    onError: (e: unknown) =>
      showToast('error', 'Distribution failed', getErrorMessage(e, 'Please try again.')),
  });

  const handleExport = async () => {
    try {
      // Every filter that is narrowing the screen, so the file matches what
      // the admin is looking at. Only status, source and owner used to be
      // sent, and source was ignored by the server anyway.
      const res = await leadsApi.export({
        ...(status ? { status } : {}),
        ...(source ? { source } : {}),
        ...(priority ? { priority } : {}),
        ...(assigned_to ? { assigned_to } : {}),
        ...(search ? { search } : {}),
        ...(overdue ? { overdue } : {}),
      });
      const url = URL.createObjectURL(new Blob([res.data as BlobPart], { type: 'text/csv;charset=utf-8' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = `leads_${localISODate()}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      showToast('success', 'Export ready', 'The CSV is downloading.');
    } catch (e: unknown) {
      // Not in the plan: the upgrade dialog is already open, and a second
      // "Export failed" behind it would read as a fault.
      if (isUpgradeRequired(e)) return;
      // The response is a blob, so the server's reason has to be read out of
      // it — otherwise a plan limit or a permission error both surfaced as
      // "Please try again", which is not something anyone can act on. (The
      // API client already turns a 402's blob back into JSON.)
      let reason = getErrorMessage(e, 'Please try again.');
      const blob = (e as { response?: { data?: Blob } })?.response?.data;
      if (blob instanceof Blob) {
        try {
          const parsed = JSON.parse(await blob.text());
          reason = parsed.message || parsed.detail || reason;
        } catch { /* not JSON — keep the fallback */ }
      }
      showToast('error', 'Export failed', reason);
    }
  };

  const leads = data?.results ?? [];
  const total = data?.count ?? 0;

  return (
    <div className="p-6 flex flex-col gap-4" style={{ background: 'var(--paper)', minHeight: '100%' }}>
      <SectionHeader title={manages ? "Leads" : "My Leads"}
                     sub={manages ? `${total.toLocaleString()} total`
                                  : `${total.toLocaleString()} assigned to you`}>
        {manages && (
          <>
{/* The order is the order these are reached for: adding a lead first,
            and Flush All — which permanently deletes every lead — last, well
            away from the button next to it. */}
        <button onClick={() => setShowCreate(true)}
                className="btn-brutal btn-primary px-4 py-2.5 font-heading font-black"
                style={{ fontSize: '0.85rem', boxShadow: 'var(--shadow)' }}>+ New Lead</button>
        <button onClick={handleExport}
                className="btn-brutal btn-secondary px-3 py-2 font-heading font-bold"
                style={{ fontSize: '0.8rem', boxShadow: 'var(--shadow)' }}>↓ Export CSV</button>
        <button onClick={() => setShowDistribute(true)}
                className="btn-brutal btn-yellow px-3 py-2 font-heading font-bold"
                style={{ fontSize: '0.8rem', boxShadow: 'var(--shadow)' }}>⇄ Assign Lead</button>
          </>
        )}
      </SectionHeader>

      {/* Filters */}
      <div className="card card-sm p-3 flex flex-wrap items-center gap-2">
        {/* Overdue first: it is the filter that changes what someone does
            next, and it was last in the row behind three dropdowns. */}
        <button onClick={() => { set('overdue', overdue ? '' : 'true'); }}
                className="btn-brutal px-3 py-2 font-heading font-bold"
                style={{ fontSize: '0.75rem', background: overdue ? 'var(--hot)' : 'var(--surface)',
                         color: overdue ? '#fff' : 'var(--text)', boxShadow: 'var(--shadow)' }}>
          ⏰ Overdue {overdue ? '✕' : ''}
        </button>
        <input placeholder="Search name, phone, email…" value={search}
               onChange={e => set('search', e.target.value)}
               className="input-brutal flex-1" style={{ minWidth: '180px', boxShadow: 'var(--shadow)' }} />
        <select value={status} onChange={e => set('status', e.target.value)}
                className="input-brutal" style={{ width: 'auto', boxShadow: 'var(--shadow)' }}>
          <option value="">All Statuses</option>
          {LEAD_STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
        <select value={source} onChange={e => set('source', e.target.value)}
                className="input-brutal" style={{ width: 'auto', boxShadow: 'var(--shadow)' }}>
          <option value="">All Sources</option>
          {LEAD_SOURCES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
        {manages && (
          <select value={assigned_to} onChange={e => set('assigned_to', e.target.value)} aria-label="Agent"
                  className="input-brutal" style={{ width: 'auto', boxShadow: 'var(--shadow)' }}>
            <option value="">All agents</option>
            <option value="unassigned">Unassigned</option>
            {agents.map(a => <option key={a.id} value={String(a.id)}>{a.name}</option>)}
          </select>
        )}
        <select value={lastCall} onChange={e => set('last_call', e.target.value)} aria-label="Last call outcome"
                className="input-brutal" style={{ width: 'auto', boxShadow: 'var(--shadow)' }}>
          <option value="">Any last call</option>
          <option value="never">Never answered</option>
          <option value="uncalled">Not called yet</option>
          <optgroup label="Answered">
            <option value="connected">Any answered outcome</option>
            {(dispositions ?? []).filter(d => d.category === 'connected').map(d =>
              <option key={d.id} value={String(d.id)}>{d.name}</option>)}
          </optgroup>
          <optgroup label="Not answered">
            <option value="not_connected">Any unanswered outcome</option>
            {(dispositions ?? []).filter(d => d.category === 'not_connected').map(d =>
              <option key={d.id} value={String(d.id)}>{d.name}</option>)}
          </optgroup>
        </select>
        {(status || priority || source || search || overdue || assigned_to || lastCall) && (
          <button onClick={() => setParams(new URLSearchParams({ page: '1' }))}
                  className="btn-brutal btn-secondary px-3 py-2 font-heading font-bold"
                  style={{ fontSize: '0.75rem' }}>Clear Filters</button>
        )}
      </div>

      {/* Bulk actions bar */}
      {manages && selected.length > 0 && (
        <div className="card card-sm p-3 flex items-center gap-3 flex-wrap"
             style={{ background: 'var(--brass-50)', borderColor: 'var(--text)' }}>
          <span className="font-heading font-black" style={{ fontSize: '0.85rem' }}>{selected.length} selected</span>
          <select value={bulkAgent} onChange={e => setBulkAgent(e.target.value)}
                  className="input-brutal" style={{ width: '200px', background: 'var(--surface)', boxShadow: 'var(--shadow)' }}>
            <option value="">Assign to agent…</option>
            {agents.map(a => (
              <option key={a.id} value={a.id}>{a.name} ({a.role_display})</option>
            ))}
          </select>
          <button onClick={() => bulkAssignMut.mutate()}
                  disabled={!bulkAgent || bulkAssignMut.isPending}
                  className="btn-brutal btn-primary px-3 py-2 font-heading font-black" style={{ fontSize: '0.8rem' }}>
            Assign All →
          </button>
          {canDelete && (
            <button onClick={() => setConfirmBulkDelete(true)}
                    disabled={bulkDeleteMut.isPending}
                    className="btn-brutal btn-danger px-3 py-2 font-heading font-black" style={{ fontSize: '0.8rem' }}>
              Delete {selected.length}
            </button>
          )}
          <button onClick={() => setSelected([])}
                  className="btn-brutal btn-secondary px-3 py-2 font-heading font-bold" style={{ fontSize: '0.8rem' }}>
            Clear
          </button>
        </div>
      )}

      {isLoading ? <Spinner /> : (
        <>
          {leads.length === 0 ? (
            <EmptyState icon="◎" title="No leads found"
                        message={manages
                          ? 'Try adjusting your filters or create a new lead.'
                          : 'No leads assigned to you match these filters.'}
                        action={manages ? { label: '+ New Lead', onClick: () => setShowCreate(true) } : undefined} />
          ) : (
            <div className="card" style={{ overflowX: 'auto' }}>
              <table className="table-brutal">
                <thead>
                  <tr>
                    {manages && (
                      <th><input type="checkbox"
                                 checked={selected.length === leads.length && leads.length > 0}
                                 onChange={e => setSelected(e.target.checked ? leads.map(l => l.id) : [])} /></th>
                    )}
                    {/* Every row an agent sees is assigned to them, so the
                        Assigned column would say their own name 25 times. */}
                    {['Created Date', 'Name', 'Phone', 'Source', 'Status', 'Notes', ...(manages ? ['Assigned'] : []),
                      'Last call', 'Follow-up', 'Actions'].map(h => (
                      <th key={h}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {leads.map(lead => (
                    <tr key={lead.id}>
                      {manages && (
                        <td><input type="checkbox" checked={selected.includes(lead.id)}
                                   onChange={e => setSelected(p => e.target.checked ? [...p, lead.id] : p.filter(x => x !== lead.id))} /></td>
                      )}
                      <td style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>{fmtDate(lead.created_at)}</td>
                      <td>
                        <div className="font-heading font-bold cursor-pointer" style={{ fontSize: '0.83rem' }}
                             onClick={() => nav(`/leads/${lead.id}`)}>{lead.name}</div>
                        {lead.city && <div style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>{lead.city}</div>}
                      </td>
                      <td className="font-mono" style={{ fontSize: '0.78rem' }}>{lead.phone}</td>
                      <td>
                        <span className="tag">{lead.source_display}</span>
                        {lead.campaign_name && (
                          <div title={lead.campaign_name} style={{ fontSize: '0.66rem', color: 'var(--text-3)', marginTop: '2px', maxWidth: '120px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            📣 {lead.campaign_name}
                          </div>
                        )}
                      </td>
                      <td><StatusBadge status={lead.status} label={lead.status_display} /></td>
                      {/* The latest note on the lead, or the notes saved with its
                          latest call — what the last conversation was about. */}
                      <td style={{ fontSize: '0.74rem', maxWidth: 220 }}>
                        {lead.latest_note ? (
                          <div title={lead.latest_note}
                               style={{ display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical',
                                        overflow: 'hidden', whiteSpace: 'normal', lineHeight: 1.35 }}>
                            {lead.latest_note}
                          </div>
                        ) : <span style={{ color: 'var(--line-2)' }}>—</span>}
                        {lead.latest_note_at && (
                          <div style={{ color: 'var(--text-3)', fontSize: '0.64rem' }}>{fmtRelative(lead.latest_note_at)}</div>
                        )}
                      </td>
                      {manages && (
                        <td style={{ fontSize: '0.78rem' }}>{lead.assigned_to_name ?? <span style={{ color: 'var(--line-2)' }}>Unassigned</span>}</td>
                      )}
                      <td style={{ fontSize: '0.72rem' }}>
                        {lead.dial_attempts ? (
                          <>
                            <span style={{ color: lead.last_call_connected ? 'var(--won)' : 'var(--text-3)', fontWeight: 700 }}>
                              {lead.last_call_connected ? '✓' : '✕'}
                            </span>{' '}
                            {lead.last_disposition_name ?? (lead.last_call_connected ? 'Answered' : 'Not answered')}
                            <div style={{ color: 'var(--text-3)', fontSize: '0.66rem' }}>
                              {fmtRelative(lead.last_dialed_at ?? null)} · {lead.dial_attempts} dial{lead.dial_attempts === 1 ? '' : 's'}
                            </div>
                          </>
                        ) : <span style={{ color: 'var(--line-2)' }}>Not called</span>}
                      </td>
                      <td style={{ fontSize: '0.75rem' }}>
                        {lead.next_followup_at ? (
                          <span style={{ color: lead.followup_overdue ? 'var(--hot)' : 'var(--text)', fontWeight: lead.followup_overdue ? 700 : 400 }}>
                            {lead.followup_overdue ? '⚠ ' : ''}{fmtRelative(lead.next_followup_at)}
                          </span>
                        ) : <span style={{ color: 'var(--line-2)' }}>—</span>}
                      </td>
                      <td>
                        <div className="flex gap-1">
                          <button onClick={() => nav(`/leads/${lead.id}`)}
                                  className="btn-brutal btn-yellow px-2 py-1 font-heading font-bold" style={{ fontSize: '0.68rem' }}>View</button>
                          {canDelete && (
                            <button onClick={() => setConfirmDelete(lead.id)}
                                    title="Delete lead" aria-label="Delete lead"
                                    className="btn-brutal btn-danger px-2 py-1"
                                    style={{ fontSize: '0.68rem', lineHeight: 0 }}>
                              <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true">
                                <path d="M9 3h6l1 2h4v2H4V5h4zm-3 6h12l-1 12H7zm3 2v8h2v-8zm4 0v8h2v-8z" />
                              </svg>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="px-4 pb-4">
                <Pagination page={page} totalPages={data?.total_pages ?? 1}
                            onPageChange={p => set('page', String(p))} />
              </div>
            </div>
          )}
        </>
      )}

      {showCreate && <LeadFormModal onClose={() => setShowCreate(false)} onSuccess={() => { qc.invalidateQueries({ queryKey: ['leads'] }); setShowCreate(false); showToast('success', 'Lead created', ''); }} />}

      {confirmBulkDelete && (
        <ConfirmDialog title={`Delete ${selected.length} lead${selected.length === 1 ? '' : 's'}?`}
                       message="The selected leads will be removed from every list, report and calling queue. This cannot be undone from here."
                       confirmLabel={bulkDeleteMut.isPending ? 'Deleting…' : 'Delete'} danger
                       onConfirm={() => bulkDeleteMut.mutate()}
                       onCancel={() => setConfirmBulkDelete(false)} />
      )}

      {confirmDelete !== null && (
        <ConfirmDialog title="Delete Lead?" message="This lead will be permanently removed. This action cannot be undone."
                       confirmLabel="Delete" danger
                       onConfirm={() => deleteMut.mutate(confirmDelete)}
                       onCancel={() => setConfirmDelete(null)} />
      )}

      {/* Assign Lead — bulk-assign leads matching filters across agents */}
      {showDistribute && (
        <Modal title="Assign Leads to Agents" onClose={() => setShowDistribute(false)} maxWidth="560px">
          <div className="flex flex-col gap-4">
            <div style={{ background: 'var(--brass-50)', border: '1px solid var(--brass-600)', padding: '10px 12px', fontSize: '0.8rem' }}>
              Assigns leads matching the <strong>current filters</strong>
              {(status || priority || source || search) ? '' : ' (no filters → all leads)'}
              {distBatches.length > 0 && <>, narrowed to <strong>{distBatches.length} batch
              {distBatches.length === 1 ? '' : 'es'}</strong></>} across the selected agents.
            </div>

            <div style={{ fontSize: '0.78rem', color: 'var(--text-2)' }}>
              Active filters:&nbsp;
              {[
                status && `status=${status}`,
                priority && `priority=${priority}`,
                source && `source=${source}`,
                search && `search="${search}"`,
              ].filter(Boolean).join(', ') || 'none'}
            </div>

            {/* Batches — narrows the filter to specific consignments. */}
            <div>
              <label className="block font-heading font-bold mb-1"
                     style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
                Limit to batches ({distBatches.length ? `${distBatches.length} selected` : 'all'})
              </label>
              {!pickableBatches.length ? (
                <div style={{ fontSize: '0.75rem', color: 'var(--text-3)' }}>
                  No batch currently has unassigned leads.
                </div>
              ) : (
                <div className="flex flex-wrap gap-2" style={{ maxHeight: '120px', overflowY: 'auto' }}>
                  {pickableBatches.map(b => {
                    const on = distBatches.includes(b.id);
                    return (
                      <button key={b.id} type="button"
                              onClick={() => setDistBatches(p =>
                                on ? p.filter(x => x !== b.id) : [...p, b.id])}
                              className="font-heading font-bold"
                              style={{ fontSize: '0.72rem', padding: '5px 10px', cursor: 'pointer',
                                       border: '1px solid var(--line)',
                                       background: on ? 'var(--brass-50)' : 'var(--surface)',
                                       boxShadow: on ? '2px 2px 0 var(--text)' : 'none' }}>
                        #{b.number} {b.label} · {b.unassigned_count}
                      </button>
                    );
                  })}
                </div>
              )}
              <div style={{ fontSize: '0.73rem', color: 'var(--text-3)', marginTop: 4 }}>
                Leave none selected to use the filters above instead. Batch selection
                combines with them.
              </div>
            </div>

            <div>
              <label className="block font-heading font-bold mb-1"
                     style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Method</label>
              <select className="input-brutal w-full" style={{ cursor: 'pointer' }} value={distMethod}
                      onChange={e => setDistMethod(e.target.value as DistributionMethod)}>
                {DISTRIBUTION_METHODS.map(m => (
                  <option key={m.value} value={m.value}>{m.label}</option>
                ))}
              </select>
              <div style={{ fontSize: '0.73rem', color: 'var(--text-2)', marginTop: 4 }}>
                {DISTRIBUTION_METHODS.find(m => m.value === distMethod)?.hint}
              </div>
            </div>

            <label className="flex items-center gap-2 cursor-pointer" style={{ fontSize: '0.82rem' }}>
              <input type="checkbox" checked={distOnlyUnassigned}
                     onChange={e => setDistOnlyUnassigned(e.target.checked)}
                     style={{ width: '16px', height: '16px', accentColor: 'var(--brass-50)' }} />
              <span className="font-medium">Only assign currently unassigned leads</span>
            </label>

            <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
              <Input label="Max leads to assign (optional)" type="number" value={distLimit}
                     onChange={e => setDistLimit(e.target.value)} placeholder="All matching" />
              <Input label="Cap open leads per agent (optional)" type="number" value={distCap}
                     onChange={e => setDistCap(e.target.value)} placeholder="No cap" />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-heading font-bold" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
                  Assign to agents * {distAgents.length > 0 && `(${distAgents.length})`}
                </label>
                {/* Picking fifteen agents one chip at a time was the slowest
                    part of assigning a batch. */}
                <div className="flex gap-2">
                  <button type="button" className="btn-brutal px-2 py-1 font-heading font-bold"
                          style={{ fontSize: '0.68rem' }}
                          onClick={() => setDistAgents(agents.map(a => a.id))}>Select all</button>
                  <button type="button" className="btn-brutal px-2 py-1 font-heading font-bold"
                          style={{ fontSize: '0.68rem' }}
                          onClick={() => setDistAgents([])}>Clear</button>
                </div>
              </div>
              <div className="flex flex-wrap gap-2" style={{ maxHeight: '160px', overflowY: 'auto' }}>
                {agents.map(a => {
                  const on = distAgents.includes(a.id);
                  return (
                    <button key={a.id} type="button"
                            onClick={() => setDistAgents(p => on ? p.filter(x => x !== a.id) : [...p, a.id])}
                            className="font-heading font-bold"
                            style={{ fontSize: '0.72rem', padding: '5px 10px', cursor: 'pointer',
                                     border: '1px solid var(--line)', background: on ? 'var(--brass-50)' : 'var(--surface)',
                                     boxShadow: on ? '2px 2px 0 var(--text)' : 'none' }}>
                      {a.name} ({a.role_display})
                    </button>
                  );
                })}
              </div>
              {agents.length === 0 && <div style={{ fontSize: '0.75rem', color: 'var(--text-3)' }}>No agents found.</div>}
            </div>
          </div>

          <div className="flex gap-3 mt-5 pt-4" style={{ borderTop: '2px solid var(--line)' }}>
            <button onClick={() => setShowDistribute(false)} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">Cancel</button>
            <button onClick={() => distributeMut.mutate()}
                    disabled={distributeMut.isPending || distAgents.length === 0}
                    className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black" style={{ boxShadow: 'var(--shadow)' }}>
              {distributeMut.isPending ? '◌ Assigning…' : `Assign → ${distAgents.length || ''} agent${distAgents.length === 1 ? '' : 's'}`}
            </button>
          </div>
        </Modal>
      )}

    </div>
  );
}
