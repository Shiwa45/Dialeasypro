// ============================================================
// DialSathi — Live Agents
//
// A supervisor's wallboard. The old version was six identical counter boxes
// above a grid of cards washed in status colour, with emoji labels for the
// time breakdown and no way to search, filter, or see who was over-running a
// break. Every timer was also measured against the browser's own clock, so a
// laptop a few minutes out of sync showed every duration wrong on the one
// screen whose entire job is durations.
//
// Rebuilt as: one floor summary with the split as a stacked bar, an alert
// strip for the things a supervisor steps in on, and one row per agent that
// carries a live timer, today's time split and an occupancy figure.
// ============================================================
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi, type LiveAgent } from '../api';
import { openTenantSocket } from '../api/client';
import { EmptyState, SectionHeader, Spinner } from '../components/ui';

type Status = LiveAgent['status'];

// One hue per status, all from the theme. The old map reached for a raw
// indigo for Break and used the same green for Available and Online, so two
// different things on the same screen were the same colour.
const STATUS: Record<Status, { label: string; fg: string; bg: string }> = {
  on_call:   { label: 'On call',   fg: 'var(--visit)', bg: 'var(--visit-50)' },
  available: { label: 'Available', fg: 'var(--won)',   bg: 'var(--won-50)' },
  wrap_up:   { label: 'Wrap-up',   fg: 'var(--warm-ink)',      bg: 'var(--warm-50)' },
  break:     { label: 'Break',     fg: 'var(--brass-ink)',      bg: 'var(--brass-50)' },
  offline:   { label: 'Offline',   fg: 'var(--text-3)', bg: 'var(--sunken)' },
};

const ORDER: Status[] = ['on_call', 'wrap_up', 'available', 'break', 'offline'];
const ONLINE: Status[] = ['on_call', 'wrap_up', 'available', 'break'];

// Thresholds a supervisor actually steps in on. Wrap-up is after-call work;
// past a few minutes it is usually someone who walked away with the dialer
// open. A break past twenty minutes is worth a look, not an accusation.
const LONG_WRAP_SECONDS = 3 * 60;
const LONG_BREAK_SECONDS = 20 * 60;

function fmtClock(secs: number): string {
  if (secs < 0) secs = 0;
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = Math.floor(secs % 60);
  const pad = (n: number) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}

/** Compact form for today's totals, where seconds are noise. */
function fmtSpan(secs: number): string {
  if (!secs) return '—';
  const h = Math.floor(secs / 3600);
  const m = Math.round((secs % 3600) / 60);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

function initials(name: string) {
  return name.split(' ').filter(Boolean).map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

/** The floor as a ring: one wedge per status, the headcount in the middle.
 *  SVG arcs by hand for the same reason the dashboard draws its own — a
 *  charting library for six numbers is more configuration than geometry. */
function FloorDonut({ counts, total, onPick, picked }: {
  counts: Record<Status, number>; total: number;
  onPick: (s: Status | 'all') => void; picked: string;
}) {
  const shown = ORDER.filter(s => counts[s] > 0);
  const sum = shown.reduce((n, s) => n + counts[s], 0);

  const cx = 80, cy = 80, r = 74, w = 24;
  const point = (radius: number, angle: number) =>
    [cx + radius * Math.cos(angle), cy + radius * Math.sin(angle)] as const;

  let angle = -Math.PI / 2;
  const wedges = shown.map(status => {
    const sweep = (counts[status] / sum) * Math.PI * 2;
    const end = angle + sweep;
    const large = sweep > Math.PI ? 1 : 0;
    const [x1, y1] = point(r, angle);
    const [x2, y2] = point(r, end);
    const [x3, y3] = point(r - w, end);
    const [x4, y4] = point(r - w, angle);
    angle = end;
    return {
      status,
      colour: STATUS[status].fg,
      d: `M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2} `
       + `L ${x3} ${y3} A ${r - w} ${r - w} 0 ${large} 0 ${x4} ${y4} Z`,
    };
  });
  // Everyone in one status sweeps a full turn, where the arc's start and end
  // are the same point and it collapses to nothing. Draw a plain ring.
  const whole = shown.length === 1;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
      <svg viewBox="0 0 160 160" style={{ width: 208, height: 208, display: 'block' }}
           role="img" aria-label="Agents by status">
        {!sum ? (
          <circle cx={cx} cy={cy} r={r - w / 2} fill="none" stroke="var(--sunken)" strokeWidth={w} />
        ) : whole ? (
          <circle cx={cx} cy={cy} r={r - w / 2} fill="none" stroke={wedges[0].colour} strokeWidth={w} />
        ) : (
          wedges.map(seg => (
            <path key={seg.status} d={seg.d} fill={seg.colour}
                  stroke="var(--surface)" strokeWidth={2} />
          ))
        )}
        <text x={cx} y={cy - 2} textAnchor="middle" dominantBaseline="middle"
              style={{ fontSize: 30, fontWeight: 800, fill: 'var(--text)' }}>{total}</text>
        <text x={cx} y={cy + 20} textAnchor="middle"
              style={{ fontSize: 10, letterSpacing: '.09em', fill: 'var(--text-3)' }}>AGENTS</text>
      </svg>

      <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {ORDER.map(st => (
          <button key={st} onClick={() => onPick(picked === st ? 'all' : st)}
                  className="flex items-center justify-between"
                  style={{
                    background: picked === st ? 'var(--sunken)' : 'none', border: 0,
                    padding: '6px 8px', borderRadius: 7, cursor: 'pointer', width: '100%',
                  }}>
            <span className="flex items-center gap-2" style={{ fontSize: 13 }}>
              <i style={{ width: 9, height: 9, borderRadius: 3, background: STATUS[st].fg }} />
              {STATUS[st].label}
            </span>
            <span className="num" style={{ fontWeight: 700 }}>
              {counts[st]}
              <span style={{ color: 'var(--text-3)', fontWeight: 500, marginLeft: 6 }}>
                {total ? Math.round((counts[st] / total) * 100) : 0}%
              </span>
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

export default function LiveAgents() {
  const nav = useNavigate();
  const [agents, setAgents] = useState<Record<number, LiveAgent>>({});
  const [loading, setLoading] = useState(true);
  const [connected, setConnected] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<'all' | 'online' | Status>('all');

  // Difference between this browser's clock and the server's. Every "since"
  // timestamp is generated server-side, so timing them against Date.now()
  // silently adds the user's clock error to every duration on the page.
  const skewRef = useRef(0);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const attemptRef = useRef(0);
  const closedRef = useRef(false);

  // 1s ticker so the live timers count up without server traffic.
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  // Initial snapshot.
  useEffect(() => {
    let mounted = true;
    authApi.liveAgents()
      .then(r => {
        if (!mounted) return;
        const serverNow = Date.parse(r.data.server_time);
        if (!Number.isNaN(serverNow)) skewRef.current = Date.now() - serverNow;

        const map: Record<number, LiveAgent> = {};
        r.data.agents.forEach(a => { map[a.agent_id] = a; });
        // A socket update can land before this request resolves. Overwriting
        // the map wholesale would throw that newer state away and leave the
        // board showing a status the agent has already left.
        setAgents(prev => ({ ...map, ...prev }));
      })
      .finally(() => { if (mounted) setLoading(false); });
    return () => { mounted = false; };
  }, []);

  // Live WebSocket with backoff.
  useEffect(() => {
    closedRef.current = false;

    const connect = () => {
      const ws = openTenantSocket('/ws/agent-monitor/');
      wsRef.current = ws;

      ws.onopen = () => { setConnected(true); attemptRef.current = 0; };
      ws.onclose = () => {
        setConnected(false);
        if (closedRef.current) return;
        // The old reconnect was a flat 3s forever, so a backend that stays
        // down gets hammered by every open dashboard for as long as it is
        // down. Back off to 30s and stay there.
        const wait = Math.min(30000, 1000 * 2 ** attemptRef.current);
        attemptRef.current += 1;
        reconnectRef.current = setTimeout(connect, wait);
      };
      ws.onerror = () => ws.close();
      ws.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data);
          if (msg.type === 'agent_status_update' && msg.agent) {
            const a: LiveAgent = msg.agent;
            setAgents(prev => ({ ...prev, [a.agent_id]: a }));
            setLastUpdate(Date.now());
          }
        } catch { /* ignore malformed frames */ }
      };
    };
    connect();

    const ping = setInterval(() => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'ping' }));
      }
    }, 25000);

    return () => {
      closedRef.current = true;
      clearInterval(ping);
      if (reconnectRef.current) clearTimeout(reconnectRef.current);
      wsRef.current?.close();
    };
  }, []);

  const all = useMemo(() => {
    const arr = Object.values(agents);
    arr.sort((a, b) => {
      const oi = ORDER.indexOf(a.status) - ORDER.indexOf(b.status);
      return oi !== 0 ? oi : a.name.localeCompare(b.name);
    });
    return arr;
  }, [agents]);

  /** Seconds in the current status, corrected for clock skew. */
  const elapsed = (a: LiveAgent): number => {
    if (!a.since || a.status === 'offline') return 0;
    return Math.floor((now - skewRef.current - new Date(a.since).getTime()) / 1000);
  };

  const counts = useMemo(() => {
    const c: Record<string, number> = {
      on_call: 0, wrap_up: 0, available: 0, break: 0, offline: 0,
    };
    all.forEach(a => { c[a.status] += 1; });
    return c;
  }, [all]);

  const online = ONLINE.reduce((sum, s) => sum + counts[s], 0);

  // Occupancy: how much of the floor's logged-on time went into talking.
  // The standard contact-centre read, and derivable from the totals already
  // on every payload.
  const floorTotals = useMemo(() => {
    return all.reduce((acc, a) => ({
      on_call: acc.on_call + a.totals.on_call,
      wrap_up: acc.wrap_up + a.totals.wrap_up,
      break: acc.break + a.totals.break,
      online: acc.online + a.totals.online,
      calls: acc.calls + (a.calls?.calls ?? 0),
      connected: acc.connected + (a.calls?.connected ?? 0),
      talk: acc.talk + (a.calls?.talk_seconds ?? 0),
    }), { on_call: 0, wrap_up: 0, break: 0, online: 0, calls: 0, connected: 0, talk: 0 });
  }, [all]);
  const occupancy = floorTotals.online
    ? Math.round((floorTotals.on_call / floorTotals.online) * 100) : 0;

  // Things worth stepping in on, recomputed every tick.
  const alerts = useMemo(() => {
    const longWrap = all.filter(a => a.status === 'wrap_up' && elapsed(a) > LONG_WRAP_SECONDS);
    const longBreak = all.filter(a => a.status === 'break' && elapsed(a) > LONG_BREAK_SECONDS);
    return { longWrap, longBreak };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [all, now]);

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return all.filter(a => {
      if (filter === 'online' && !ONLINE.includes(a.status)) return false;
      if (filter !== 'all' && filter !== 'online' && a.status !== filter) return false;
      if (q && !a.name.toLowerCase().includes(q) && !a.email.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [all, filter, query]);

  if (loading) return <div className="flex justify-center py-16"><Spinner /></div>;

  const FILTERS: Array<{ key: 'all' | 'online' | Status; label: string; count: number }> = [
    { key: 'all',       label: 'Everyone',  count: all.length },
    { key: 'online',    label: 'Online',    count: online },
    { key: 'on_call',   label: 'On call',   count: counts.on_call },
    { key: 'wrap_up',   label: 'Wrap-up',   count: counts.wrap_up },
    { key: 'available', label: 'Available', count: counts.available },
    { key: 'break',     label: 'Break',     count: counts.break },
    { key: 'offline',   label: 'Offline',   count: counts.offline },
  ];

  return (
    <div style={{ padding: 20 }}>
      <SectionHeader title="Live Agents" sub="Updates as agents change status. No refresh needed.">
        <span className={`live-pill ${connected ? 'on' : 'off'}`}>
          <i />
          {connected ? 'Live' : 'Reconnecting…'}
          {connected && lastUpdate && (
            <span className="num" style={{ opacity: 0.75, marginLeft: 4 }}>
              {Math.max(0, Math.round((now - lastUpdate) / 1000))}s ago
            </span>
          )}
        </span>
      </SectionHeader>

      {/* ---- Floor summary ---- */}
      <div className="plate mb-4">
        <div className="plate-b" style={{ display: 'flex', gap: 28, alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ flex: 'none' }}>
            <div className="kpi-l">On the floor</div>
            <div className="num" style={{ fontSize: 30, fontWeight: 600, lineHeight: 1, marginTop: 8 }}>
              {online}
              <span style={{ fontSize: 15, color: 'var(--text-3)', fontWeight: 500 }}> / {all.length}</span>
            </div>
          </div>

          <div style={{ flex: 1, minWidth: 260 }}>
            {/* One bar for the whole floor. Six identical counter boxes made
                you read every number to see the shape of the shift. */}
            <div className="floor-bar">
              {ORDER.map(s => counts[s] > 0 && (
                <span key={s} title={`${STATUS[s].label}: ${counts[s]}`}
                      style={{ flex: counts[s], background: STATUS[s].fg }} />
              ))}
              {!all.length && <span style={{ flex: 1, background: 'var(--sunken)' }} />}
            </div>
            <div className="floor-legend">
              {ORDER.map(s => (
                <button key={s} onClick={() => setFilter(filter === s ? 'all' : s)}
                        className={filter === s ? 'on' : ''}>
                  <i style={{ background: STATUS[s].fg }} />
                  {STATUS[s].label}
                  <b className="num">{counts[s]}</b>
                </button>
              ))}
            </div>
          </div>

          <div style={{ flex: 'none', textAlign: 'right' }}>
            <div className="kpi-l">Occupancy today</div>
            <div className="num" style={{ fontSize: 30, fontWeight: 600, lineHeight: 1, marginTop: 8 }}>
              {occupancy}<span style={{ fontSize: 15, color: 'var(--text-3)' }}>%</span>
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 6 }}>
              {fmtSpan(floorTotals.on_call)} on calls of {fmtSpan(floorTotals.online)} online
            </div>
            {/* The Calls page's figures, so the two screens agree. */}
            <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 3 }}>
              {floorTotals.calls} calls · {floorTotals.connected} connected · {fmtSpan(floorTotals.talk)} talk
            </div>
          </div>
        </div>
      </div>

      {/* ---- Alerts ---- */}
      {(alerts.longWrap.length > 0 || alerts.longBreak.length > 0) && (
        <div className="flex gap-3 flex-wrap mb-4">
          {alerts.longWrap.length > 0 && (
            <Alert tone="var(--warm)" bg="var(--warm-50)"
                   text={`${alerts.longWrap.length} in wrap-up over 3 minutes`}
                   names={alerts.longWrap.map(a => a.name)}
                   onClick={() => setFilter('wrap_up')} />
          )}
          {alerts.longBreak.length > 0 && (
            <Alert tone="var(--brass)" bg="var(--brass-50)"
                   text={`${alerts.longBreak.length} on break over 20 minutes`}
                   names={alerts.longBreak.map(a => a.name)}
                   onClick={() => setFilter('break')} />
          )}
        </div>
      )}

      <div className="la-row">
      {/* minWidth 0: without it the filter tabs stretched this column past
          a phone's screen and cut off the right side of the agent list. */}
      <div style={{ minWidth: 0 }}>
      {/* ---- Toolbar ---- */}
      <div className="flex gap-3 items-center flex-wrap mb-4">
        <div className="seg" style={{ maxWidth: '100%', overflowX: 'auto' }}>
          {FILTERS.map(f => (
            <button key={f.key} onClick={() => setFilter(f.key)}
                    className={`seg-btn ${filter === f.key ? 'on' : ''}`}>
              {f.label}
              <span className="num" style={{ opacity: 0.7, marginLeft: 5 }}>{f.count}</span>
            </button>
          ))}
        </div>
        <input className="input-brutal" placeholder="Search an agent…" value={query}
               onChange={e => setQuery(e.target.value)} style={{ width: 220 }} />
      </div>

      {/* ---- Agents ---- */}
      {!shown.length ? (
        <EmptyState
          icon="○"
          title={all.length ? 'Nobody matches' : 'No agents yet'}
          message={all.length
            ? 'No agent matches this filter right now.'
            : 'Agents appear here once they start an auto-dial session.'}
          action={all.length ? {
            label: 'Show everyone',
            onClick: () => { setFilter('all'); setQuery(''); },
          } : undefined}
        />
      ) : (
        // One row per agent — the same figures the cards showed, laid out as a
        // list so a whole floor can be scanned top to bottom.
        <div className="plate no-ticks la-list">
          <div className="la-lh">
            <span>Agent</span>
            <span>Status</span>
            <span>Time in status</span>
            <span>Today</span>
            <span className="la-right">Online · Occ.</span>
          </div>
          {shown.map(a => {
            const st = STATUS[a.status];
            const secs = elapsed(a);
            const t = a.totals;
            const over = (a.status === 'wrap_up' && secs > LONG_WRAP_SECONDS)
                      || (a.status === 'break' && secs > LONG_BREAK_SECONDS);
            const busiest = Math.max(1, t.online);
            const agentOcc = t.online ? Math.round((t.on_call / t.online) * 100) : 0;

            return (
              <div key={a.agent_id} className="la-item">
                <span className="la-rail" style={{ background: st.fg }} />

                <div className="la-head">
                  <span className="la-avatar" style={{ background: st.bg, color: st.fg }}>
                    {initials(a.name)}
                  </span>
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div className="la-name">{a.name}</div>
                    <div className="la-sub">{a.role.replace(/_/g, ' ')}</div>
                  </div>
                </div>

                <div>
                  <span className="chip" style={{ background: st.bg, color: st.fg }}>
                    <i className="pip" />{st.label}
                  </span>
                </div>

                <div>
                  <div className="la-timer">
                    {a.status === 'offline' ? (
                      <span className="la-off">
                        {a.last_seen ? `Last seen ${new Date(a.last_seen).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}` : 'Not seen today'}
                      </span>
                    ) : (
                      <>
                        <b className="num" style={{ color: over ? 'var(--hot)' : 'var(--text)' }}>
                          {fmtClock(secs)}
                        </b>
                        <span>
                          in {st.label.toLowerCase()}
                          {a.status === 'break' && a.break_reason ? ` · ${a.break_reason}` : ''}
                        </span>
                      </>
                    )}
                  </div>
                  {a.status === 'on_call' && a.current_lead_id && (
                    <button className="la-lead" onClick={() => nav(`/leads/${a.current_lead_id}`)}>
                      Open the lead they are on
                    </button>
                  )}
                </div>

                <div className="la-today">
                  <div className="la-split">
                    <span style={{ width: `${(t.on_call / busiest) * 100}%`, background: STATUS.on_call.fg }} />
                    <span style={{ width: `${(t.wrap_up / busiest) * 100}%`, background: STATUS.wrap_up.fg }} />
                    <span style={{ width: `${(t.break / busiest) * 100}%`, background: STATUS.break.fg }} />
                  </div>
                  <div className="la-figs">
                    {/* Dialer time on calls — dialling and ringing included —
                        so not the talk time, which is below. */}
                    <span title="Time in the dialer's On call status, dialling and ringing included"><i style={{ background: STATUS.on_call.fg }} />On call <b className="num">{fmtSpan(t.on_call)}</b></span>
                    <span><i style={{ background: STATUS.wrap_up.fg }} />Wrap <b className="num">{fmtSpan(t.wrap_up)}</b></span>
                    <span><i style={{ background: STATUS.break.fg }} />Break <b className="num">{fmtSpan(t.break)}</b></span>
                  </div>
                </div>

                <div className="la-occ">
                  <span title="As on the Calls page: connected calls' durations">
                    <b className="num">{a.calls?.calls ?? 0}</b> calls · {a.calls?.connected ?? 0} connected · {fmtSpan(a.calls?.talk_seconds ?? 0)} talk
                  </span>
                  <span>{fmtSpan(t.online)} online</span>
                  <span className="num">{agentOcc}% occupancy</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
      </div>

      {/* The same floor as a ring. The bar above says how the shift is
          shaped; this says who is in each state, and clicking a slice
          filters the list beside it. */}
      <div className="plate" style={{ alignSelf: 'start' }}>
        <div className="plate-h">
          <div className="plate-t" style={{ fontSize: 16 }}>By status</div>
        </div>
        <div className="plate-b">
          <FloorDonut counts={counts} total={all.length}
                      picked={filter} onPick={setFilter} />
        </div>
      </div>
      </div>
    </div>
  );
}

function Alert({ tone, bg, text, names, onClick }: {
  tone: string; bg: string; text: string; names: string[]; onClick: () => void;
}) {
  return (
    <button className="la-alert" style={{ background: bg, borderColor: tone }} onClick={onClick}>
      <span className="la-alert-dot" style={{ background: tone }} />
      <span>
        <b style={{ display: 'block', fontSize: 12.5 }}>{text}</b>
        <span style={{ fontSize: 11, color: 'var(--text-2)' }}>{names.join(', ')}</span>
      </span>
    </button>
  );
}
