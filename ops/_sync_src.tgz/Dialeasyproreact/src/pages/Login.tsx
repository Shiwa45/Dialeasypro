// ============================================================
// DialSathi — Sign in
//
// Split layout: the brand field on the left carries the identity (deep green,
// blueprint grid, display serif), the right side is the form on drafting
// paper. Below 900px the left panel drops away entirely rather than shrinking
// — a decorative panel squeezed to a stripe just steals height from the form
// on the phones agents actually sign in on.
// ============================================================
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { authApi } from '../api';
import { useToast } from '../components/ui';
import BrandMark from '../components/BrandMark';
import { getErrorMessage } from '../utils/errors';

const POINTS = [
  ['Auto-dialer', 'Queue, dial, dispose — without leaving the app.'],
  ['Every channel', 'Calls, WhatsApp and email against one lead record.'],
  ['Nothing dropped', 'Follow-ups, recordings and attribution captured automatically.'],
];

export default function Login() {
  const [workspace, setWorkspace] = useState(localStorage.getItem('tenant_workspace') || '');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { setAuth: storeAuth } = useAuthStore();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const workspaceRef = useRef<HTMLInputElement>(null);
  const emailRef = useRef<HTMLInputElement>(null);

  // Land the cursor on the first field that still needs an answer: a returning
  // user has their workspace remembered and should start at the email.
  useEffect(() => {
    (workspace ? emailRef : workspaceRef).current?.focus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!workspace) {
      showToast('error', 'Workspace required', 'Please enter your workspace ID.');
      workspaceRef.current?.focus();
      return;
    }

    // Save workspace to localStorage so the apiClient interceptor picks it up
    localStorage.setItem('tenant_workspace', workspace);

    setLoading(true);
    try {
      const { data } = await authApi.login(email, password);
      storeAuth(data.agent, data.access, data.refresh, data.must_change_password);
      showToast('success', 'Welcome back!', `Signed in as ${data.agent.name}`);
      navigate('/dashboard');
    } catch (err: unknown) {
      // The company switched web sign-in off for agents. The server's own
      // message says so and points at the app; it isn't a password problem,
      // so it must not read as "Sign in failed".
      const code = (err as { response?: { data?: { error?: string } } })?.response?.data?.error;
      if (code === 'web_access_disabled') {
        showToast('info', 'Use the mobile app',
          getErrorMessage(err, 'Web sign-in is not available for agents in your company.'));
        return;
      }
      if (code === 'plan_expired' || code === 'account_suspended') {
        showToast('warning', 'Plan expired',
          getErrorMessage(err, 'Your plan has expired. Please contact support to renew your account.'));
        return;
      }
      if (code === 'recruitment_not_in_plan') {
        showToast('info', 'Recruitment is not on your plan',
          getErrorMessage(err, 'Recruiter accounts need the Recruitment module. Please ask your admin.'));
        return;
      }
      const msg = getErrorMessage(err, 'Invalid credentials.');
      showToast('error', 'Sign in failed', msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', background: 'var(--paper)' }}>

      {/* ---- Brand field ---- */}
      <aside className="login-brand">
        <div className="login-brand-grid" />
        <div style={{ position: 'relative', zIndex: 1, display: 'flex', flexDirection: 'column', height: '100%' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
            <BrandMark />
            <div>
              <div className="brand-name">Dial<b>Sathi</b></div>
              <div className="brand-sub">TeleCRM</div>
            </div>
          </div>

          <div style={{ marginTop: 'auto', marginBottom: 'auto', paddingTop: 40, paddingBottom: 40 }}>
            <h1 style={{
              fontFamily: 'var(--disp)', fontSize: 'clamp(28px, 3vw, 40px)', fontWeight: 800,
              color: '#fff', lineHeight: 1.12, letterSpacing: '-0.6px', margin: 0,
            }}>
              Close more of<br />what you already have.
            </h1>
            <p style={{ color: '#A8C9C1', fontSize: 14.5, lineHeight: 1.6, marginTop: 14, maxWidth: 400 }}>
              Your leads, calls and conversations in one place — so nothing sits
              waiting for someone to remember it.
            </p>

            <div style={{ marginTop: 32, display: 'flex', flexDirection: 'column', gap: 16 }}>
              {POINTS.map(([title, body]) => (
                <div key={title} style={{ display: 'flex', gap: 11 }}>
                  <span style={{
                    width: 3, borderRadius: 2, background: '#7de8b3', flex: 'none', marginTop: 2,
                  }} />
                  <div>
                    <div style={{ color: '#EAF4F0', fontSize: 13.5, fontWeight: 600 }}>{title}</div>
                    <div style={{ color: '#8FB5AC', fontSize: 12.5, marginTop: 2, lineHeight: 1.5 }}>{body}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{
            fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '.12em',
            textTransform: 'uppercase', color: '#6E9990',
          }}>
            Powered by easyian.com
          </div>
        </div>
      </aside>

      {/* ---- Form ---- */}
      <main className="login-form-side">
        <div style={{ width: '100%', maxWidth: 384 }}>

          {/* Shown only when the brand panel is hidden, so the page is never
              unbranded on a phone. */}
          <div className="login-compact-brand">
            <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-0.03em' }}>
              Dial<span style={{ color: 'var(--brand)' }}>Sathi</span>
              <span style={{ display: 'block', fontSize: 11.5, fontWeight: 600, letterSpacing: '.2em', color: 'var(--text-2)', marginTop: 2 }}>TeleCRM</span>
            </div>
          </div>

          <h2 style={{
            fontFamily: 'var(--disp)', fontSize: 28, fontWeight: 800,
            letterSpacing: '-0.4px', margin: 0,
          }}>
            Sign in
          </h2>
          <p style={{ color: 'var(--text-2)', fontSize: 13.5, marginTop: 6 }}>
            Admin access to your workspace.
          </p>

          <form onSubmit={handleSubmit} style={{ marginTop: 26, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <label className="login-label" htmlFor="workspace">Workspace ID</label>
              {/*
                Allow underscores. The backend's slugify_company_name turns
                spaces and hyphens INTO underscores — "Acme Realty Pvt Ltd"
                becomes schema `acme_realty_pvt_ltd`, and collision suffixes
                are `_2`, `_3`. This filter used to strip `_` while keeping
                `-`, the exact inverse, so every tenant whose company name has
                more than one word was silently unable to type their own
                workspace id. Single-word tenants masked it.
              */}
              <input
                id="workspace" ref={workspaceRef} type="text" value={workspace}
                onChange={(e) => setWorkspace(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                required autoCapitalize="none" autoCorrect="off" spellCheck={false}
                className="input-brutal" style={{ width: '100%' }}
                placeholder="acme_realty"
              />
              {/* Echo the resulting address back. Getting this wrong is the most
                  common sign-in failure, and it fails looking like a bad
                  password rather than a bad workspace. */}
              <div className="login-hint">
                {workspace
                  ? <>Signing in to <b style={{ color: 'var(--text-2)' }}>{workspace}</b></>
                  : 'The short name in your CRM address.'}
              </div>
            </div>

            <div>
              <label className="login-label" htmlFor="email">Email address</label>
              <input
                id="email" ref={emailRef} type="email" value={email}
                onChange={(e) => setEmail(e.target.value)} required
                autoComplete="username"
                className="input-brutal" style={{ width: '100%' }}
                placeholder="you@yourcompany.com"
              />
            </div>

            <div>
              <label className="login-label" htmlFor="password">Password</label>
              <div style={{ position: 'relative' }}>
                <input
                  id="password" type={showPassword ? 'text' : 'password'} value={password}
                  onChange={(e) => setPassword(e.target.value)} required
                  autoComplete="current-password"
                  className="input-brutal" style={{ width: '100%', paddingRight: 68 }}
                  placeholder="••••••••"
                />
                <button
                  type="button" onClick={() => setShowPassword(v => !v)}
                  className="login-reveal"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13, color: 'var(--text-2)' }}>
                <input type="checkbox" style={{ width: 15, height: 15, accentColor: 'var(--brand)', cursor: 'pointer' }} />
                Remember me
              </label>
              <button type="button" className="login-link">Forgot password?</button>
            </div>

            <button type="submit" disabled={loading}
                    className="btn btn-p" style={{ width: '100%', padding: '11px 14px', fontSize: 14 }}>
              {loading ? 'Signing in…' : 'Sign in'}
            </button>
          </form>

          <div style={{
            marginTop: 22, paddingTop: 16, borderTop: '1px solid var(--line)',
            fontSize: 12.5, color: 'var(--text-3)', lineHeight: 1.6,
          }}>
            Admins, managers, agents and recruiters all sign in here — each sees
            only their own part of the workspace. Agents can also use the
            DialSathi mobile app. Ask your admin if you need an account.
          </div>
        </div>
      </main>
    </div>
  );
}
