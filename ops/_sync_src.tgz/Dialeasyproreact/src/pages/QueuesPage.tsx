import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { queuesApi, authApi } from '../api';
import {
  SectionHeader, Modal, Input, Select, Textarea, ConfirmDialog,
  Spinner, EmptyState, useToast,
} from '../components/ui';
import { LEAD_STATUSES, LEAD_SOURCES } from '../utils/fmt';
import { getErrorMessage } from '../utils/errors';
import { fetchAllPages } from '../utils/fetchAll';
import type { CallQueue } from '../types';

// A queue never serves closed leads (converted, lost, not interested,
// duplicate, invalid), so only open statuses can be picked. Offering all of
// them let an admin build a queue that could never serve anything.
const OPEN_STATUSES = ['new', 'attempted', 'contacted', 'interested', 'follow_up', 'negotiation'];
const QUEUE_STATUSES = LEAD_STATUSES.filter(s => OPEN_STATUSES.includes(s.value));
const KNOWN_SOURCES = new Set(LEAD_SOURCES.map(s => s.value));
const label = (list: { value: string; label: string }[], v: string) => list.find(x => x.value === v)?.label ?? v;

// Backend priority values are hot / warm / cold
const QUEUE_PRIORITIES = [
  { value: 'hot', label: '🔥 Hot' },
  { value: 'warm', label: 'Warm' },
  { value: 'cold', label: 'Cold' },
];

const ORDER_OPTIONS = [
  { value: 'priority', label: 'Highest priority first' },
  { value: 'oldest', label: 'Oldest leads first' },
  { value: 'newest', label: 'Newest leads first' },
  { value: 'score', label: 'Highest score first' },
  { value: 'followup_due', label: 'Follow-up due first' },
];

type QueueForm = {
  id?: number;
  name: string;
  description: string;
  is_active: boolean;
  filter_statuses: string[];
  filter_priorities: string[];
  filter_sources: string[];
  /** Comma-separated in the form; a list on the API. */
  filter_tags: string;
  only_unworked: boolean;
  only_followup_due: boolean;
  exclude_dnd: boolean;
  order_by: string;
  mode: string;
  redial_cooldown_hours: number;
  lock_ttl_minutes: number;
  agent_ids: number[];
};

const EMPTY_FORM: QueueForm = {
  name: '', description: '', is_active: true,
  filter_statuses: [], filter_priorities: [], filter_sources: [], filter_tags: '',
  only_unworked: false, only_followup_due: false, exclude_dnd: true,
  order_by: 'priority', mode: 'manual',
  redial_cooldown_hours: 24, lock_ttl_minutes: 30,
  agent_ids: [],
};

export default function Queues() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState<QueueForm>(EMPTY_FORM);
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);

  const { data: queues, isLoading } = useQuery({
    queryKey: ['queues'],
    queryFn: () => queuesApi.list().then(r => r.data),
  });

  const { data: agentsData } = useQuery({
    queryKey: ['agents-for-queue'],
    // Every page (the API caps one at 100). Read-only users can't dial, so
    // they aren't offered.
    queryFn: () => fetchAllPages(page => authApi.listAgents({ page_size: 100, page })),
  });
  const agents = (agentsData?.results ?? []).filter(a => a.role !== 'readonly');

  const saveMut = useMutation({
    mutationFn: () => {
      const { id, filter_tags, ...rest } = form;
      const payload = {
        ...rest,
        name: rest.name.trim(),
        filter_tags: filter_tags.split(',').map(t => t.trim()).filter(Boolean),
      };
      return id ? queuesApi.update(id, payload) : queuesApi.create(payload);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['queues'] });
      setShowModal(false);
      setForm(EMPTY_FORM);
      showToast('success', 'Queue saved', '');
    },
    onError: (e: unknown) =>
      showToast('error', 'Error', getErrorMessage(e, 'Failed to save queue')),
  });

  const deleteMut = useMutation({
    mutationFn: (id: number) => queuesApi.delete(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['queues'] });
      setConfirmDelete(null);
      showToast('info', 'Queue deleted', 'Leads checked out from it went back to their agents.');
    },
    onError: (e: unknown) => {
      setConfirmDelete(null);
      showToast('error', 'Error', getErrorMessage(e, 'Failed to delete the queue'));
    },
  });

  // Deactivated members of the queue being edited — not in the picker (it
  // lists active agents only), so they'd vanish silently on save.
  const [editingGone, setEditingGone] = useState<CallQueue['agents']>([]);
  const openCreate = () => { setForm(EMPTY_FORM); setEditingGone([]); setShowModal(true); };
  const openEdit = (q: CallQueue) => {
    setEditingGone(q.agents.filter(a => a.is_active === false));
    setForm({
      id: q.id,
      name: q.name, description: q.description, is_active: q.is_active,
      // Values a queue can't use any more (a closed status, a source that
      // no longer exists) are dropped here; the server refuses them.
      filter_statuses: (q.filter_statuses ?? []).filter(s => OPEN_STATUSES.includes(s)),
      filter_priorities: (q.filter_priorities ?? []).filter(p => QUEUE_PRIORITIES.some(x => x.value === p)),
      filter_sources: (q.filter_sources ?? []).filter(s => KNOWN_SOURCES.has(s)),
      filter_tags: (q.filter_tags ?? []).join(', '),
      only_unworked: q.only_unworked, only_followup_due: q.only_followup_due,
      exclude_dnd: q.exclude_dnd, order_by: q.order_by, mode: q.mode,
      redial_cooldown_hours: q.redial_cooldown_hours, lock_ttl_minutes: q.lock_ttl_minutes,
      agent_ids: q.agents.map(a => a.id),
    });
    setShowModal(true);
  };

  const toggleIn = (key: 'filter_statuses' | 'filter_priorities' | 'filter_sources' | 'agent_ids', value: string | number) =>
    setForm(p => {
      const arr = p[key] as (string | number)[];
      const next = arr.includes(value) ? arr.filter(v => v !== value) : [...arr, value];
      return { ...p, [key]: next };
    });

  const Chip = ({ active, label, onClick }: { active: boolean; label: string; onClick: () => void }) => (
    <button type="button" onClick={onClick}
            className="font-heading font-bold"
            style={{
              fontSize: '0.72rem', padding: '5px 10px', cursor: 'pointer',
              border: '1px solid var(--line)', background: active ? 'var(--brass-50)' : 'var(--surface)',
              boxShadow: active ? '2px 2px 0 var(--text)' : 'none',
            }}>
      {label}
    </button>
  );

  return (
    <div className="p-6 flex flex-col gap-4" style={{ background: 'var(--paper)', minHeight: '100%' }}>
      <SectionHeader title="Call Queues" sub={`${queues?.length ?? 0} queues`}>
        <button onClick={openCreate}
                className="btn-brutal btn-primary px-4 py-2.5 font-heading font-black"
                style={{ fontSize: '0.85rem', boxShadow: 'var(--shadow)' }}>
          + New Queue
        </button>
      </SectionHeader>

      {isLoading ? <Spinner /> : (queues?.length ?? 0) === 0 ? (
        <EmptyState icon="▤" title="No queues yet"
                    message="Create a calling queue and assign agents. Agents pull leads one at a time — no lead is ever served to two agents or repeated."
                    action={{ label: '+ New Queue', onClick: openCreate }} />
      ) : (
        <div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(320px,1fr))' }}>
          {(queues ?? []).map(q => (
            <div key={q.id} className="card p-4" style={{ opacity: q.is_active ? 1 : 0.6 }}>
              <div className="flex items-start justify-between mb-2">
                <div className="font-heading font-black" style={{ fontSize: '1rem' }}>{q.name}</div>
                <div className="flex gap-1">
                  {!q.is_active && <span className="tag" style={{ background: 'var(--lost-50)' }}>Off</span>}
                  <span className="tag" style={{ background: q.mode === 'auto' ? 'var(--warm-50)' : 'var(--brand-50)' }}>
                    {q.mode === 'auto' ? '⚡ Auto' : 'Manual'}
                  </span>
                </div>
              </div>
              {/* What the queue holds right now — the screen never said. */}
              {q.waiting !== undefined && (
                <div className="flex gap-4 mb-2" style={{ fontSize: '0.78rem' }}>
                  <span><b className="num">{q.waiting}</b> <span style={{ color: 'var(--text-3)' }}>waiting</span></span>
                  <span><b className="num">{q.checked_out ?? 0}</b> <span style={{ color: 'var(--text-3)' }}>being called</span></span>
                  <span style={{ color: 'var(--text-3)' }}>{label(ORDER_OPTIONS, q.order_by)}</span>
                </div>
              )}
              {q.description && <p style={{ fontSize: '0.78rem', color: 'var(--text-2)', marginBottom: '8px' }}>{q.description}</p>}
              <div className="flex flex-wrap gap-1 mb-3">
                {q.filter_statuses.map(s => <span key={s} className="tag" style={{ fontSize: '0.66rem' }}>{label(LEAD_STATUSES, s)}</span>)}
                {q.filter_priorities.map(p => <span key={p} className="tag" style={{ fontSize: '0.66rem', background: 'var(--brass-50)' }}>{label(QUEUE_PRIORITIES, p)}</span>)}
                {q.filter_sources.length > 0 && (
                  <span className="tag" style={{ fontSize: '0.66rem' }}
                        title={q.filter_sources.map(s => label(LEAD_SOURCES, s)).join(', ')}>
                    {q.filter_sources.length <= 2
                      ? q.filter_sources.map(s => label(LEAD_SOURCES, s)).join(', ')
                      : `${q.filter_sources.length} sources`}
                  </span>
                )}
                {(q.filter_tags ?? []).map(t => <span key={t} className="tag" style={{ fontSize: '0.66rem' }}>#{t}</span>)}
                {q.only_unworked && <span className="tag" style={{ fontSize: '0.66rem', background: 'var(--won-50)' }}>fresh only</span>}
                {q.only_followup_due && <span className="tag" style={{ fontSize: '0.66rem', background: 'var(--lost-50)' }}>f/u due</span>}
              </div>
              {(() => {
                const working = q.agents.filter(a => a.is_active !== false);
                const gone = q.agents.filter(a => a.is_active === false);
                return (
                  <>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginBottom: '4px' }}>
                      {working.length} agent{working.length === 1 ? '' : 's'} · cooldown {q.redial_cooldown_hours}h · lock {q.lock_ttl_minutes}m
                    </div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-2)', marginBottom: gone.length ? '4px' : '10px' }}>
                      {working.length
                        ? <>{working.slice(0, 4).map(a => a.name).join(', ')}{working.length > 4 ? ` +${working.length - 4}` : ''}</>
                        : <span style={{ color: 'var(--hot)', fontWeight: 700 }}>No active agent — nobody can work this queue.</span>}
                    </div>
                    {gone.length > 0 && (
                      <div style={{ fontSize: '0.7rem', color: 'var(--hot)', marginBottom: '10px' }}>
                        Deactivated: {gone.map(a => a.name).join(', ')} — edit the queue to replace {gone.length === 1 ? 'them' : 'them'}.
                      </div>
                    )}
                  </>
                );
              })()}
              <div className="flex gap-2">
                <button onClick={() => openEdit(q)}
                        className="btn-brutal btn-yellow px-3 py-1.5 font-heading font-bold" style={{ fontSize: '0.72rem' }}>
                  Edit
                </button>
                <button onClick={() => setConfirmDelete(q.id)}
                        className="btn-brutal btn-danger px-3 py-1.5 font-heading font-bold" style={{ fontSize: '0.72rem' }}>
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <Modal title={form.id ? `Edit Queue: ${form.name}` : 'New Call Queue'} onClose={() => { setShowModal(false); setForm(EMPTY_FORM); }} maxWidth="640px">
          <div className="flex flex-col gap-4">
            <Input label="Queue Name *" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="e.g. Hot New Leads" />
            <Textarea label="Description" value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} placeholder="What this queue is for…" />

            <div>
              <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Statuses (any)</label>
              <p style={{ fontSize: '0.7rem', color: 'var(--text-3)', marginBottom: 6 }}>
                Open statuses only — closed leads (converted, lost, not interested, invalid) are never served. None picked = all open leads.
              </p>
              <div className="flex flex-wrap gap-2">
                {QUEUE_STATUSES.map(s => <Chip key={s.value} label={s.label} active={form.filter_statuses.includes(s.value)} onClick={() => toggleIn('filter_statuses', s.value)} />)}
              </div>
            </div>

            <div>
              <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Priorities (any)</label>
              <div className="flex flex-wrap gap-2">
                {QUEUE_PRIORITIES.map(p => <Chip key={p.value} label={p.label} active={form.filter_priorities.includes(p.value)} onClick={() => toggleIn('filter_priorities', p.value)} />)}
              </div>
            </div>

            <div>
              <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Sources (any)</label>
              <div className="flex flex-wrap gap-2">
                {LEAD_SOURCES.map(s => <Chip key={s.value} label={s.label} active={form.filter_sources.includes(s.value)} onClick={() => toggleIn('filter_sources', s.value)} />)}
              </div>
            </div>

            <Input label="Tags (any, comma-separated)" value={form.filter_tags}
                   onChange={e => setForm(p => ({ ...p, filter_tags: e.target.value }))}
                   placeholder="e.g. vip, renewal" />

            <div className="grid grid-cols-2 gap-3">
              <Select label="Order By" value={form.order_by} onChange={e => setForm(p => ({ ...p, order_by: e.target.value }))}>
                {ORDER_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </Select>
              <Select label="Mode" value={form.mode} onChange={e => setForm(p => ({ ...p, mode: e.target.value }))}>
                <option value="manual">Manual pull</option>
                <option value="auto">Auto / power-dialer</option>
              </Select>
              <Input label="Redial cooldown (hours)" type="number" min={0} max={720} value={form.redial_cooldown_hours} onChange={e => setForm(p => ({ ...p, redial_cooldown_hours: Number(e.target.value) }))} />
              <Input label="Lock TTL (minutes)" type="number" min={1} max={480} value={form.lock_ttl_minutes} onChange={e => setForm(p => ({ ...p, lock_ttl_minutes: Number(e.target.value) }))} />
            </div>
            <p style={{ fontSize: '0.7rem', color: 'var(--text-3)', marginTop: -8 }}>
              Cooldown: a dialled lead isn't served again for this long (0–720 h), unless a follow-up booked after
              the call is due. Lock: how long a pulled or skipped lead stays with the agent before it goes back (1–480 min).
            </p>

            <div className="flex flex-col gap-2">
              {[
                { k: 'only_unworked', label: 'Only fresh leads (never worked before)' },
                { k: 'only_followup_due', label: 'Only leads with a follow-up due' },
                { k: 'exclude_dnd', label: 'Skip DND (Do Not Disturb) numbers' },
                { k: 'is_active', label: 'Queue is active' },
              ].map(opt => (
                <label key={opt.k} className="flex items-center gap-2 cursor-pointer" style={{ fontSize: '0.82rem' }}>
                  <input type="checkbox" checked={form[opt.k as keyof QueueForm] as boolean}
                         onChange={e => setForm(p => ({ ...p, [opt.k]: e.target.checked }))}
                         style={{ width: '16px', height: '16px', accentColor: 'var(--brass-50)' }} />
                  <span className="font-medium">{opt.label}</span>
                </label>
              ))}
            </div>

            <div>
              <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Assigned Agents *</label>
              <div className="flex flex-wrap gap-2" style={{ maxHeight: '160px', overflowY: 'auto' }}>
                {agents.map(a => <Chip key={a.id} label={`${a.name} (${a.role_display})`} active={form.agent_ids.includes(a.id)} onClick={() => toggleIn('agent_ids', a.id)} />)}
              </div>
              {editingGone.length > 0 && (
                <div style={{ fontSize: '0.72rem', color: 'var(--hot)', marginTop: 6 }}>
                  {editingGone.map(a => a.name).join(', ')} {editingGone.length === 1 ? 'is' : 'are'} deactivated and will be removed from this queue when you save.
                </div>
              )}
              {agents.length === 0 && <div style={{ fontSize: '0.75rem', color: 'var(--text-3)' }}>No agents found.</div>}
            </div>
          </div>

          <div className="flex gap-3 mt-5 pt-4" style={{ borderTop: '2px solid var(--line)' }}>
            <button onClick={() => { setShowModal(false); setForm(EMPTY_FORM); }} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">Cancel</button>
            <button onClick={() => saveMut.mutate()}
                    disabled={saveMut.isPending || !form.name.trim() || form.agent_ids.length === 0
                              || form.lock_ttl_minutes < 1 || form.lock_ttl_minutes > 480
                              || form.redial_cooldown_hours < 0 || form.redial_cooldown_hours > 720}
                    className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black" style={{ boxShadow: 'var(--shadow)' }}>
              {saveMut.isPending ? '◌ Saving…' : form.id ? 'Save Changes →' : 'Create Queue →'}
            </button>
          </div>
        </Modal>
      )}

      {confirmDelete !== null && (
        <ConfirmDialog
          title="Delete Queue?"
          message="Agents will no longer be able to pull leads from this queue. Leads themselves are not affected."
          confirmLabel="Delete"
          danger
          onConfirm={() => deleteMut.mutate(confirmDelete)}
          onCancel={() => setConfirmDelete(null)}
        />
      )}
    </div>
  );
}
