import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { callsApi, reportsApi } from '../api';
import {
  SectionHeader, Spinner, StatCard, Kpi, RangePicker, useDateRange,
} from '../components/ui';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  PieChart, Pie, Cell, Legend, AreaChart, Area,
} from 'recharts';
import { formatDuration } from '../utils/fmt';

// Categorical series colours.
//
// The previous list opened with brass-50 (near-white cream) and ink (near
// black): as chart fills those two read as "missing" and "border", and as chip
// backgrounds they needed a contrast hack to stay readable at all. These are
// the theme's situational colours, ordered so neighbouring slices never sit
// adjacent on the wheel, and every one takes white text.
const COLORS = [
  'var(--brand)', 'var(--brass)', 'var(--visit)', 'var(--won)',
  'var(--hot)', 'var(--cold)', 'var(--brand-700)', 'var(--warm)',
  'var(--lost)', '#4E7C8A',
];
type Tab = 'agents' | 'outcomes' | 'sources' | 'calls' | 'funnel';

export default function Reports() {
  const [tab, setTab] = useState<Tab>('agents');
  // Today by default, like the dashboard. Reports opened on a 30-day window
  // while the dashboard beside it showed today, and the two were read as the
  // same period.
  const range = useDateRange('today');
  const dateFrom = range.date_from;
  const dateTo = range.date_to;

  const params = { date_from: dateFrom, date_to: dateTo };

  // The call boxes from the Calls screen, so the numbers a supervisor
  // reports on are in the reporting screen too.
  const { data: callStats } = useQuery({
    queryKey: ['reports-call-stats', dateFrom, dateTo],
    queryFn: () => callsApi.stats(params).then(r => r.data),
  });

  const agentQ = useQuery({ queryKey: ['r-agents', dateFrom, dateTo], queryFn: () => reportsApi.agentPerformance(params).then(r => r.data), enabled: tab === 'agents' });
  const sourceQ = useQuery({ queryKey: ['r-sources', dateFrom, dateTo], queryFn: () => reportsApi.leadSources(params).then(r => r.data), enabled: tab === 'sources' });
  const callQ = useQuery({ queryKey: ['r-calls', dateFrom, dateTo], queryFn: () => reportsApi.callAnalytics(params).then(r => r.data), enabled: tab === 'calls' });
  const outcomeQ = useQuery({ queryKey: ['r-outcomes', dateFrom, dateTo], queryFn: () => reportsApi.agentOutcomes(params).then(r => r.data), enabled: tab === 'outcomes' });
  const funnelQ = useQuery({ queryKey: ['r-funnel', dateFrom, dateTo], queryFn: () => reportsApi.conversionFunnel(params).then(r => r.data), enabled: tab === 'funnel' });

  const TABS: { k: Tab; l: string }[] = [
    { k: 'agents', l: 'Agent Performance' },
    { k: 'outcomes', l: 'Call Outcomes' },
    { k: 'sources', l: 'Lead Sources' },
    { k: 'calls', l: 'Call Analytics' },
    { k: 'funnel', l: 'Conversion Funnel' },
  ];

  const isLoading = agentQ.isLoading || outcomeQ.isLoading || sourceQ.isLoading || callQ.isLoading || funnelQ.isLoading;

  // Space Grotesk is no longer loaded, and borderRadius:0 is a leftover from
  // the brutalist theme.
  const TOOLTIP_STYLE = {
    border: '1px solid var(--line)', borderRadius: 8,
    boxShadow: 'var(--shadow)', fontSize: '0.78rem',
    padding: '8px 10px',
  };

  return (
    <div className="p-6 flex flex-col gap-4" style={{ background: 'var(--paper)', minHeight: '100%' }}>
      <SectionHeader title="Reports & Analytics">
        <RangePicker preset={range.preset} onPreset={range.setPreset}
                     from={range.from} to={range.to}
                     onFrom={range.setFrom} onTo={range.setTo} />
      </SectionHeader>

      {/* Calls at a glance, for the period selected above. */}
      <div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))' }}>
        {/* Every box is the selected range — they used to be today's counts
            beside the range's rate, whatever range was picked. */}
        <Kpi label="Calls" value={callStats?.period.total_calls ?? 0} tone="brand"
             note={dateFrom === dateTo ? dateFrom : `${dateFrom} → ${dateTo}`} />
        <Kpi label="Connected calls" value={callStats?.period.connected_calls ?? 0} tone="won"
             note={`${callStats?.period.connection_rate ?? 0}% connection rate`} />
        <Kpi label="Talk time"
             value={formatDuration(callStats?.period.total_duration_seconds ?? 0)} tone="visit" />
        <Kpi label="Average call duration"
             value={formatDuration(callStats?.period.avg_duration_seconds ?? 0)} tone="cold"
             note="Connected calls" />
      </div>

      <div className="tabs" style={{ overflowX: 'auto' }}>
            {TABS.map(t => (
              <button key={t.k} onClick={() => setTab(t.k)}
                      className={`tab ${tab === t.k ? 'on' : ''}`}
                      style={{ whiteSpace: 'nowrap' }}>
                {t.l}
              </button>
            ))}
          </div>

          {isLoading && <Spinner />}

          {/* Agent Performance */}
          {tab === 'agents' && agentQ.data && !agentQ.isLoading && (
            <div className="flex flex-col gap-5">
              <div className="plate" style={{ overflowX: 'auto' }}>
                <div className="plate-h">
                  <div>
                    <div className="plate-t">Agent performance</div>
                    <div className="plate-s">
                      {agentQ.data.period.date_from} → {agentQ.data.period.date_to}
                    </div>
                  </div>
                </div>
                <table className="table-brutal">
                  <thead>
                    <tr>
                      {['Agent', 'Role', 'Assigned leads', 'Not called yet', 'Converted', 'Win %', 'Avg Score', 'Calls', 'Connected', 'Conn %', 'Talk Time'].map(h => <th key={h}>{h}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {agentQ.data.agents.map(a => (
                      <tr key={a.agent_id}>
                        <td className="font-heading font-bold" style={{ fontSize: '0.83rem' }}>{a.agent_name}</td>
                        <td><span className="tag">{a.agent_role}</span></td>
                        {/* Right now, whatever the period: everything they own,
                            and how much of it they have never dialled. */}
                        <td style={{ fontSize: '0.82rem' }} title="Every lead assigned to them right now">
                          <Link to={`/leads?assigned_to=${a.agent_id}`} style={{ color: 'inherit' }}>
                            {a.leads.assigned ?? a.leads.owned ?? '—'}
                          </Link>
                        </td>
                        <td style={{ fontSize: '0.82rem', fontWeight: 700,
                                     color: a.leads.not_called ? 'var(--hot)' : 'var(--text-3)' }}
                            title="Assigned to them and never dialled — open the list">
                          {a.leads.not_called === undefined ? '—' : (
                            <Link to={`/leads?assigned_to=${a.agent_id}&last_call=uncalled`} style={{ color: 'inherit' }}>
                              {a.leads.not_called}
                            </Link>
                          )}
                        </td>
                        <td className="font-heading font-black" style={{ fontSize: '0.82rem', color: 'var(--won)' }}>{a.leads.converted}</td>
                        <td style={{ fontSize: '0.82rem' }}>{a.leads.conversion_rate}%</td>
                        <td style={{ fontSize: '0.82rem' }}>{Math.round(a.leads.avg_score)}</td>
                        <td style={{ fontSize: '0.82rem' }}>{a.calls.total}</td>
                        <td style={{ fontSize: '0.82rem' }}>{a.calls.connected}</td>
                        <td style={{ fontSize: '0.82rem' }}>{a.calls.connection_rate}%</td>
                        <td className="font-mono" style={{ fontSize: '0.78rem' }}>{formatDuration(a.calls.total_duration_seconds)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="grid gap-5" style={{ gridTemplateColumns: '1fr 1fr' }}>
                <div className="card p-4">
                  <div className="font-heading font-black mb-3" style={{ fontSize: '0.9rem' }}>▸ Conversions by Agent</div>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={agentQ.data.agents}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" />
                      <XAxis dataKey="agent_name" tick={{ fontSize: 10 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <Tooltip contentStyle={TOOLTIP_STYLE} />
                      <Legend />
                      <Bar dataKey="leads.converted" name="Converted" fill="var(--won)" />
                      <Bar dataKey="leads.lost" name="Lost" fill="var(--hot)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="card p-4">
                  <div className="font-heading font-black mb-3" style={{ fontSize: '0.9rem' }}>▸ Calls by Agent</div>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={agentQ.data.agents}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" />
                      <XAxis dataKey="agent_name" tick={{ fontSize: 10 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <Tooltip contentStyle={TOOLTIP_STYLE} />
                      <Legend />
                      <Bar dataKey="calls.total" name="Total" fill="var(--brass-50)" />
                      <Bar dataKey="calls.connected" name="Connected" fill="var(--ink)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* Lead Sources */}
          {tab === 'sources' && sourceQ.data && !sourceQ.isLoading
            && !((sourceQ.data as { by_source?: unknown[] }).by_source ?? []).length && (
            <div className="plate" style={{ padding: 40, textAlign: 'center', color: 'var(--text-3)', fontSize: '0.88rem' }}>
              No leads came in during this period. Pick a longer range to see where your leads come from.
            </div>
          )}
          {tab === 'sources' && sourceQ.data && !sourceQ.isLoading
            && ((sourceQ.data as { by_source?: unknown[] }).by_source ?? []).length > 0 && (
            <div className="grid gap-5" style={{ gridTemplateColumns: '3fr 2fr' }}>
              <div className="plate" style={{ overflowX: 'auto' }}>
                <div className="plate-h">
                  <div>
                    <div className="plate-t">Leads by source</div>
                    <div className="plate-s">Selected period</div>
                  </div>
                </div>
                <table className="table-brutal">
                  <thead><tr>{['Source', 'Total', 'Converted', 'Lost', 'Conv %', 'Avg Score', 'Deal Value'].map(h => <th key={h}>{h}</th>)}</tr></thead>
                  <tbody>
                    {((sourceQ.data as { by_source: Array<{ source: string; source_display: string; total: number; converted: number; lost: number; conversion_rate: number; avg_score: number; total_deal_value: number }> }).by_source ?? []).map((s, i) => (
                      <tr key={s.source}>
                        {/* One neutral chip with a coloured pip, rather than
                            a differently-coloured background per row. Ten
                            filled chips in a column is noise, and half of them
                            could not carry readable text. The pip is what ties
                            the row to its slice in the donut. */}
                        <td>
                          <span className="chip c-mute">
                            <i className="pip" style={{ background: COLORS[i % COLORS.length] }} />
                            {s.source_display}
                          </span>
                        </td>
                        <td className="font-heading font-black" style={{ fontSize: '0.82rem' }}>{s.total}</td>
                        <td style={{ color: 'var(--won)', fontWeight: 700, fontSize: '0.82rem' }}>{s.converted}</td>
                        <td style={{ color: 'var(--hot)', fontSize: '0.82rem' }}>{s.lost}</td>
                        <td style={{ fontSize: '0.82rem' }}>{s.conversion_rate}%</td>
                        <td style={{ fontSize: '0.82rem' }}>{s.avg_score}</td>
                        <td style={{ fontSize: '0.78rem' }}>₹{(s.total_deal_value / 100000).toFixed(1)}L</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="plate">
                <div className="plate-h">
                  <div>
                    <div className="plate-t">Volume by source</div>
                    <div className="plate-s">Share of leads</div>
                  </div>
                </div>
                <div className="plate-b">
                  {/* A donut with its own legend below, not Recharts' <Legend/>:
                      with ten sources that component wrapped to three lines and
                      drew straight over the chart. The ring is also inset far
                      enough that its labels cannot collide. */}
                  <ResponsiveContainer width="100%" height={210}>
                    <PieChart>
                      <Pie
                        data={(sourceQ.data as { by_source: Array<{ source_display: string; total: number }> }).by_source}
                        dataKey="total" nameKey="source_display"
                        cx="50%" cy="50%" innerRadius={54} outerRadius={92}
                        paddingAngle={1.5}
                      >
                        {((sourceQ.data as { by_source: unknown[] }).by_source ?? []).map((_, i) => (
                          <Cell key={i} fill={COLORS[i % COLORS.length]}
                                stroke="var(--surface)" strokeWidth={2} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={TOOLTIP_STYLE} />
                    </PieChart>
                  </ResponsiveContainer>

                  <div style={{ marginTop: 12, borderTop: '1px solid var(--line)', paddingTop: 8 }}>
                    {(() => {
                      const rows = (sourceQ.data as { by_source: Array<{ source: string; source_display: string; total: number }> }).by_source ?? [];
                      const total = rows.reduce((sum, r) => sum + r.total, 0) || 1;
                      return rows.map((r, i) => (
                        <div key={r.source}
                             style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '3px 0', fontSize: '12.5px' }}>
                          <i style={{ width: 9, height: 9, borderRadius: 2.5, flex: 'none', background: COLORS[i % COLORS.length] }} />
                          <span style={{ color: 'var(--text-2)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {r.source_display}
                          </span>
                          <b className="num" style={{ marginLeft: 'auto', fontSize: 12 }}>{r.total}</b>
                          <span className="num" style={{ color: 'var(--text-3)', fontSize: 11, width: 38, textAlign: 'right' }}>
                            {Math.round((r.total / total) * 100)}%
                          </span>
                        </div>
                      ));
                    })()}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Call Outcomes by agent — from the calls each agent made */}
          {tab === 'outcomes' && outcomeQ.data && !outcomeQ.isLoading && (() => {
            const groups = [
              { key: 'connected', label: 'Answered calls', cols: outcomeQ.data.dispositions.filter(d => d.category === 'connected') },
              { key: 'not_connected', label: 'Unanswered calls', cols: outcomeQ.data.dispositions.filter(d => d.category === 'not_connected') },
            ];
            const cell: React.CSSProperties = { textAlign: 'right', fontVariantNumeric: 'tabular-nums', fontSize: '0.78rem' };
            return (
              <div className="plate" style={{ overflowX: 'auto' }}>
                <div className="plate-h">
                  <div>
                    <div className="plate-t">Call outcomes by agent</div>
                    <div className="plate-s">
                      {outcomeQ.data.period.date_from} → {outcomeQ.data.period.date_to} · credited to the agent who made the call
                    </div>
                  </div>
                </div>
                {outcomeQ.data.agents.length === 0 ? (
                  <div style={{ color: 'var(--text-3)', fontSize: '0.85rem', padding: 24, textAlign: 'center' }}>No calls in this period.</div>
                ) : (
                  <table className="table-brutal">
                    <thead>
                      <tr>
                        <th rowSpan={2}>Agent</th>
                        <th rowSpan={2} style={cell}>Dials</th>
                        <th rowSpan={2} style={cell}>Answered</th>
                        <th rowSpan={2} style={cell}>Ans. %</th>
                        <th rowSpan={2} style={cell}>Talk time</th>
                        {groups.map(g => g.cols.length > 0 && (
                          <th key={g.key} colSpan={g.cols.length} style={{ textAlign: 'center' }}>{g.label}</th>
                        ))}
                        <th rowSpan={2} style={cell}>No outcome</th>
                      </tr>
                      <tr>
                        {groups.flatMap(g => g.cols.map(d => (
                          <th key={d.id} style={{ ...cell, whiteSpace: 'normal', minWidth: 80, fontSize: '0.66rem' }}>{d.name}</th>
                        )))}
                      </tr>
                    </thead>
                    <tbody>
                      {outcomeQ.data.agents.map(a => (
                        <tr key={a.agent_id}>
                          <td className="font-heading font-bold" style={{ fontSize: '0.8rem' }}>{a.agent_name}</td>
                          <td style={cell}>{a.dials}</td>
                          <td style={cell}>{a.connected}</td>
                          <td style={cell}>{a.connection_rate}%</td>
                          <td style={cell}>{formatDuration(a.talk_seconds)}</td>
                          {groups.flatMap(g => g.cols.map(d => (
                            <td key={d.id} style={{ ...cell, color: a.outcomes[String(d.id)] ? undefined : 'var(--text-3)' }}>
                              {a.outcomes[String(d.id)] ?? 0}
                            </td>
                          )))}
                          <td style={{ ...cell, color: a.no_outcome ? 'var(--hot)' : 'var(--text-3)' }}>{a.no_outcome}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            );
          })()}

          {/* Call Analytics */}
          {tab === 'calls' && callQ.data && !callQ.isLoading && (
            <div className="flex flex-col gap-5">
              <div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))' }}>
                <StatCard label="Total Calls" value={callQ.data.summary.total_calls} accent />
                <StatCard label="Connected" value={callQ.data.summary.connected_calls} />
                <StatCard label="Connection %" value={`${callQ.data.summary.connection_rate}%`} />
                <StatCard label="Avg Duration" value={formatDuration(callQ.data.summary.avg_duration_seconds)} />
                <StatCard label="Total Talk Time" value={formatDuration(callQ.data.summary.total_duration_seconds)} />
                <StatCard label="Total Cost" value={`₹${callQ.data.summary.total_cost_rupees.toFixed(2)}`} />
              </div>
              <div className="grid gap-5" style={{ gridTemplateColumns: '2fr 1fr' }}>
                <div className="card p-4">
                  <div className="font-heading font-black mb-3" style={{ fontSize: '0.9rem' }}>▸ Daily Call Trend</div>
                  <ResponsiveContainer width="100%" height={220}>
                    <AreaChart data={callQ.data.daily_trend}>
                      <defs>
                        <linearGradient id="gTotal" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="var(--brass-50)" stopOpacity={0.5} />
                          <stop offset="95%" stopColor="var(--brass-50)" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="gConn" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="var(--won)" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="var(--won)" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" />
                      <XAxis dataKey="date" tick={{ fontSize: 9 }} tickFormatter={v => v.slice(5)} />
                      <YAxis tick={{ fontSize: 9 }} />
                      <Tooltip contentStyle={TOOLTIP_STYLE} />
                      <Legend />
                      <Area type="monotone" dataKey="total" name="Total" stroke="var(--brass-50)" fill="url(#gTotal)" strokeWidth={2} />
                      <Area type="monotone" dataKey="connected" name="Connected" stroke="var(--won)" fill="url(#gConn)" strokeWidth={2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                <div className="card p-4">
                  <div className="font-heading font-black mb-3" style={{ fontSize: '0.9rem' }}>▸ By Outcome</div>
                  {callQ.data.by_disposition.length === 0 ? (
                    <div style={{ color: 'var(--text-3)', fontSize: '0.8rem', textAlign: 'center', padding: '30px' }}>No outcome data</div>
                  ) : (() => {
                    const max = Math.max(...callQ.data.by_disposition.map(d => d.count), 1);
                    const groups: Array<[string, typeof callQ.data.by_disposition]> = [
                      ['Answered calls', callQ.data.by_disposition.filter(d => d.disposition__category === 'connected')],
                      ['Unanswered calls', callQ.data.by_disposition.filter(d => d.disposition__category === 'not_connected')],
                      ['No outcome', callQ.data.by_disposition.filter(d => !d.disposition__category)],
                    ];
                    return groups.filter(([, rows]) => rows.length).map(([title, rows]) => (
                      <div key={title} className="mb-3">
                        <div className="font-heading font-bold mb-1" style={{ fontSize: '0.68rem', textTransform: 'uppercase', color: 'var(--text-3)' }}>{title}</div>
                        {rows.map(d => (
                          <div key={d.disposition_id ?? d.disposition__name} className="mb-2">
                            <div className="flex justify-between mb-0.5">
                              <span style={{ fontSize: '0.72rem', color: 'var(--text-2)' }}>{d.disposition__name}</span>
                              <span className="font-heading font-black" style={{ fontSize: '0.72rem' }}>{d.count}</span>
                            </div>
                            <div className="progress-bar">
                              <div className="progress-fill" style={{ width: `${(d.count / max) * 100}%`, background: !d.disposition__category ? 'var(--warm)' : d.disposition__is_positive ? 'var(--won)' : 'var(--text-3)' }} />
                            </div>
                          </div>
                        ))}
                      </div>
                    ));
                  })()}
                  {!!callQ.data.summary.connected_without_duration && (
                    <p style={{ fontSize: '0.7rem', color: 'var(--text-3)', marginTop: 8 }}>
                      {callQ.data.summary.connected_without_duration} answered call{callQ.data.summary.connected_without_duration === 1 ? ' has' : 's have'} no
                      talk time recorded, so talk-time figures undercount.
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Conversion Funnel */}
          {tab === 'funnel' && funnelQ.data && !funnelQ.isLoading && (
            <div className="grid gap-5" style={{ gridTemplateColumns: '2fr 1fr' }}>
              <div className="card p-5">
                <div className="font-heading font-black mb-4" style={{ fontSize: '0.95rem' }}>
                  ▸ Lead Conversion Funnel ({funnelQ.data.total} leads created in this period)
                </div>
                {funnelQ.data.funnel.map((stage, i) => (
                  <div key={stage.status} className="mb-4">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-heading font-bold" style={{ fontSize: '0.83rem' }}>{stage.label}</span>
                      <div className="flex gap-3">
                        <span className="font-heading font-black" style={{ fontSize: '0.85rem' }}>{stage.count}</span>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-3)', minWidth: '36px', textAlign: 'right' }}>{stage.pct_of_total}%</span>
                      </div>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${stage.pct_of_total}%`, background: COLORS[i % COLORS.length] }} />
                    </div>
                  </div>
                ))}
                {!!funnelQ.data.closed?.length && (
                  <>
                    <div className="font-heading font-bold mt-2 mb-2" style={{ fontSize: '0.72rem', textTransform: 'uppercase', color: 'var(--text-3)' }}>
                      Closed without a sale
                    </div>
                    {funnelQ.data.closed.map(stage => (
                      <div key={stage.status} className="flex items-center justify-between mb-2">
                        <span style={{ fontSize: '0.8rem' }}>{stage.label}</span>
                        <span className="font-heading font-black" style={{ fontSize: '0.8rem' }}>
                          {stage.count} <span style={{ color: 'var(--text-3)', fontWeight: 400 }}>· {stage.pct_of_total}%</span>
                        </span>
                      </div>
                    ))}
                  </>
                )}
              </div>
              <div className="card p-5 flex flex-col gap-3">
                <div className="font-heading font-black mb-2" style={{ fontSize: '0.95rem' }}>▸ Summary</div>
                <StatCard label="Total Leads" value={funnelQ.data.total} accent />
                <StatCard
                  label="Converted"
                  value={funnelQ.data.funnel.find(f => f.status === 'converted')?.count ?? 0}
                />
                <StatCard label="Lost" value={funnelQ.data.lost} />
                <StatCard
                  label="Win Rate"
                  value={`${funnelQ.data.total > 0
                    ? Math.round(((funnelQ.data.funnel.find(f => f.status === 'converted')?.count ?? 0) / funnelQ.data.total) * 100)
                    : 0}%`}
                />
              </div>
            </div>
          )}
    </div>
  );
}
