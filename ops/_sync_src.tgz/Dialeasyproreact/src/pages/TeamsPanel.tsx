// ============================================================
// DialSathi — Teams (Settings)
//
// This tab used to list teams and tell the admin to "create teams via the
// Django admin panel or API". Nothing in the product could put an agent in a
// team, which left both rules that depend on membership permanently inert: a
// manager sees only agents who share a team with them, so a manager saw
// nobody; and a senior agent sees their teammates' leads, so they saw only
// their own.
//
// So the panel is built around membership rather than around the team record:
// who is in each team, who leads it, and what that changes.
// ============================================================
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

import { authApi } from '../api';
import {
  ConfirmDialog, EmptyState, Input, Modal, Select, Spinner, useToast,
} from '../components/ui';
import { getErrorMessage } from '../utils/errors';
import type { Team, TeamMember } from '../types';

const ROLE_LABEL: Record<string, string> = {
  admin: 'Admin',
  manager: 'Manager',
  senior_agent: 'Senior agent',
  agent: 'Agent',
  read_only: 'Read only',
  trainee: 'Trainee',
};

export default function TeamsPanel({ canEdit }: { canEdit: boolean }) {
  const qc = useQueryClient();
  const { showToast } = useToast();

  const [showArchived, setShowArchived] = useState(false);
  const [editing, setEditing] = useState<null | { id?: number; name: string; description: string }>(null);
  const [disbanding, setDisbanding] = useState<Team | null>(null);
  const [addingTo, setAddingTo] = useState<Team | null>(null);
  const [pickedAgent, setPickedAgent] = useState('');
  const [pickedLead, setPickedLead] = useState(false);

  const teamsQ = useQuery({
    queryKey: ['teams', showArchived],
    queryFn: () => authApi.listTeams(showArchived ? { include_inactive: true } : undefined)
      .then(r => r.data),
  });

  const agentsQ = useQuery({
    queryKey: ['agents-for-teams'],
    queryFn: () => authApi.listAgents({ page_size: 200 }).then(r => r.data),
  });

  const refresh = () => qc.invalidateQueries({ queryKey: ['teams'] });
  const fail = (title: string) => (e: unknown) =>
    showToast('error', title, getErrorMessage(e, 'Please try again.'));

  const saveTeam = useMutation({
    mutationFn: () => {
      const t = editing!;
      const payload = { name: t.name.trim(), description: t.description.trim() };
      return t.id ? authApi.updateTeam(t.id, payload) : authApi.createTeam(payload);
    },
    onSuccess: () => {
      const edited = !!editing?.id;
      refresh();
      setEditing(null);
      showToast('success', edited ? 'Team updated' : 'Team created', '');
    },
    onError: fail('Could not save the team'),
  });

  const disband = useMutation({
    mutationFn: (team: Team) => authApi.disbandTeam(team.id),
    onSuccess: () => {
      refresh();
      setDisbanding(null);
      showToast('success', 'Team disbanded', 'Its members are kept, so it can be brought back.');
    },
    onError: fail('Could not disband'),
  });

  const restore = useMutation({
    mutationFn: (team: Team) => authApi.updateTeam(team.id, { is_active: true }),
    onSuccess: () => { refresh(); showToast('success', 'Team restored', ''); },
    onError: fail('Could not restore'),
  });

  const addMember = useMutation({
    mutationFn: () => authApi.addTeamMember(addingTo!.id, Number(pickedAgent), pickedLead),
    onSuccess: () => {
      refresh();
      setAddingTo(null);
      setPickedAgent('');
      setPickedLead(false);
      showToast('success', 'Added to the team', '');
    },
    onError: fail('Could not add them'),
  });

  const setLead = useMutation({
    mutationFn: ({ team, member, lead }: { team: Team; member: TeamMember; lead: boolean }) =>
      authApi.addTeamMember(team.id, member.agent_id, lead),
    onSuccess: (_r, v) => {
      refresh();
      showToast('success', v.lead ? `${v.member.name} leads this team` : 'No longer a team lead',
        v.lead ? 'They can now see the leads of everyone in it.' : '');
    },
    onError: fail('Could not change that'),
  });

  const removeMember = useMutation({
    mutationFn: ({ team, member }: { team: Team; member: TeamMember }) =>
      authApi.removeTeamMember(team.id, member.agent_id),
    onSuccess: () => { refresh(); showToast('success', 'Removed from the team', ''); },
    onError: fail('Could not remove them'),
  });

  if (teamsQ.isLoading) return <Spinner />;

  const teams = teamsQ.data?.results ?? [];
  const allAgents = agentsQ.data?.results ?? [];
  const notInTeam = (team: Team) => {
    const already = new Set(team.members.map(m => m.agent_id));
    return allAgents.filter(a => !already.has(a.id));
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="card p-4" style={{ fontSize: '0.84rem', lineHeight: 1.6, color: 'var(--text-2)' }}>
        <b style={{ color: 'var(--text)' }}>What a team changes.</b>{' '}
        A <b>manager</b> sees only the agents who share a team with them. A{' '}
        <b>senior agent</b> sees the leads of everyone in their teams. Whoever you mark as{' '}
        <b>team lead</b> sees their team's leads too, whatever their role. Everyone else
        sees only what is assigned to them.
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        {canEdit && (
          <button className="btn btn-p"
                  onClick={() => setEditing({ name: '', description: '' })}>
            + New team
          </button>
        )}
        <label className="flex items-center gap-2" style={{ fontSize: '0.82rem', cursor: 'pointer' }}>
          <input type="checkbox" checked={showArchived}
                 onChange={e => setShowArchived(e.target.checked)} />
          Show disbanded teams
        </label>
      </div>

      {teams.length === 0 ? (
        <EmptyState icon="◉" title="No teams yet"
                    message="Teams decide who can see whom: a manager sees the agents in their teams, and a team lead sees their team's leads."
                    action={canEdit ? { label: '+ New team', onClick: () => setEditing({ name: '', description: '' }) } : undefined} />
      ) : (
        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(330px, 1fr))' }}>
          {teams.map(team => (
            <div key={team.id} className="card p-4 flex flex-col gap-3"
                 style={team.is_active ? undefined : { opacity: 0.7 }}>
              <div className="flex items-start justify-between gap-2">
                <div style={{ minWidth: 0 }}>
                  <div className="font-heading font-black" style={{ fontSize: '1rem' }}>{team.name}</div>
                  {team.description && (
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-2)', marginTop: 2 }}>
                      {team.description}
                    </div>
                  )}
                </div>
                <span className={`chip ${team.is_active ? 'c-brand' : 'c-mute'}`}>
                  {team.is_active ? `${team.member_count} member${team.member_count === 1 ? '' : 's'}` : 'Disbanded'}
                </span>
              </div>

              {/* ---- Members ---- */}
              {team.members.length === 0 ? (
                <div style={{ fontSize: '0.8rem', color: 'var(--text-3)' }}>
                  Nobody in this team yet — it changes nothing until someone is in it.
                </div>
              ) : (
                <div className="flex flex-col" style={{ gap: 2 }}>
                  {team.members.map(m => (
                    <div key={m.agent_id} className="flex items-center justify-between gap-2"
                         style={{ padding: '5px 0', borderBottom: '1px solid var(--line)' }}>
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: '0.84rem', fontWeight: 600 }}>
                          {m.name}
                          {!m.is_active && (
                            <span className="chip c-mute" style={{ marginLeft: 6 }}>inactive</span>
                          )}
                        </div>
                        <div style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>
                          {ROLE_LABEL[m.role] ?? m.role}
                          {m.is_team_lead && ' · team lead'}
                        </div>
                      </div>
                      {canEdit && (
                        <div className="flex gap-1" style={{ flex: 'none' }}>
                          <button className="btn btn-q btn-sm"
                                  title={m.is_team_lead
                                    ? 'Stop them seeing the whole team’s leads'
                                    : 'Let them see the whole team’s leads'}
                                  onClick={() => setLead.mutate({ team, member: m, lead: !m.is_team_lead })}>
                            {m.is_team_lead ? '★' : '☆'}
                          </button>
                          <button className="btn btn-q btn-sm" style={{ color: 'var(--hot)' }}
                                  title="Remove from this team"
                                  onClick={() => removeMember.mutate({ team, member: m })}>×</button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {canEdit && (
                <div className="flex gap-2 flex-wrap" style={{ marginTop: 'auto' }}>
                  {team.is_active && (
                    <button className="btn btn-g btn-sm"
                            onClick={() => { setAddingTo(team); setPickedAgent(''); setPickedLead(false); }}>
                      + Add member
                    </button>
                  )}
                  <button className="btn btn-q btn-sm"
                          onClick={() => setEditing({ id: team.id, name: team.name, description: team.description })}>
                    Rename
                  </button>
                  {team.is_active ? (
                    <button className="btn btn-q btn-sm" style={{ color: 'var(--hot)' }}
                            onClick={() => setDisbanding(team)}>Disband</button>
                  ) : (
                    <button className="btn btn-q btn-sm" onClick={() => restore.mutate(team)}>Restore</button>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ---- New / rename ---- */}
      {editing && (
        <Modal title={editing.id ? 'Rename team' : 'New team'} onClose={() => setEditing(null)} maxWidth="440px">
          <div className="flex flex-col gap-3">
            <Input label="Team name" required autoFocus value={editing.name}
                   placeholder="North Zone"
                   onChange={e => setEditing(p => p && ({ ...p, name: e.target.value }))} />
            <Input label="Description" value={editing.description}
                   placeholder="Which patch, which product, whatever separates them"
                   onChange={e => setEditing(p => p && ({ ...p, description: e.target.value }))} />
          </div>
          <div className="flex gap-3 mt-4">
            <button className="btn btn-g flex-1" onClick={() => setEditing(null)}>Cancel</button>
            <button className="btn btn-p flex-1"
                    disabled={!editing.name.trim() || saveTeam.isPending}
                    onClick={() => saveTeam.mutate()}>
              {saveTeam.isPending ? 'Saving…' : editing.id ? 'Save' : 'Create team'}
            </button>
          </div>
        </Modal>
      )}

      {/* ---- Add a member ---- */}
      {addingTo && (
        <Modal title={`Add to ${addingTo.name}`} onClose={() => setAddingTo(null)} maxWidth="440px">
          {notInTeam(addingTo).length === 0 ? (
            <p style={{ fontSize: '0.85rem', color: 'var(--text-2)' }}>
              Every active agent is already in this team.
            </p>
          ) : (
            <div className="flex flex-col gap-3">
              <Select label="Agent" value={pickedAgent}
                      onChange={e => setPickedAgent(e.target.value)}>
                <option value="">Choose an agent…</option>
                {notInTeam(addingTo).map(a => (
                  <option key={a.id} value={a.id}>
                    {a.name} — {ROLE_LABEL[a.role] ?? a.role}
                  </option>
                ))}
              </Select>
              <label className="flex items-center gap-2" style={{ cursor: 'pointer', fontSize: '0.84rem' }}>
                <input type="checkbox" checked={pickedLead}
                       onChange={e => setPickedLead(e.target.checked)} />
                Make them a team lead — they will see the leads of everyone in this team
              </label>
            </div>
          )}
          <div className="flex gap-3 mt-4">
            <button className="btn btn-g flex-1" onClick={() => setAddingTo(null)}>Cancel</button>
            <button className="btn btn-p flex-1" disabled={!pickedAgent || addMember.isPending}
                    onClick={() => addMember.mutate()}>
              {addMember.isPending ? 'Adding…' : 'Add to team'}
            </button>
          </div>
        </Modal>
      )}

      {disbanding && (
        <ConfirmDialog
          title={`Disband ${disbanding.name}?`}
          message={`Its ${disbanding.member_count} member(s) stay on the system and keep their leads, but the team stops deciding who can see whom. You can restore it later.`}
          confirmLabel="Disband"
          danger
          onConfirm={() => disband.mutate(disbanding)}
          onCancel={() => setDisbanding(null)}
        />
      )}
    </div>
  );
}
