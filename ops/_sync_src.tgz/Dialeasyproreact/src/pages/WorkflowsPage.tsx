// ============================================================
// Outreach → Workflows
//
// "When X happens to a lead, do Y" — WhatsApp welcomes, missed-call
// follow-ups, keyword auto-replies, round-robin assignment. Each card shows
// what starts it, what it does, and how often it has run; the run log shows
// exactly what every step did for every lead, and why a step was skipped.
//
// Gated on "Follow-up Automation Rules"; tenant admins only (the API says so).
// ============================================================
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  automationApi, leadsApi, type Workflow, type WorkflowInput, type WorkflowRun, type WorkflowStep,
} from '../api';
import {
  ConfirmDialog, EmptyState, Modal, Pagination, SectionHeader, Spinner, useToast,
} from '../components/ui';
import { fmtDateTime, fmtRelative } from '../utils/fmt';
import { getErrorMessage } from '../utils/errors';
import WorkflowEditor from './workflows/WorkflowEditor';
import { BLANK, PRESETS } from './workflows/presets';

const STEP_WORD: Record<WorkflowStep['type'], string> = {
  wait: 'Wait', send_whatsapp: 'WhatsApp', send_sms: 'SMS', assign: 'Assign', change_status: 'Status',
  create_followup: 'Follow-up', add_note: 'Note', notify: 'Notify', webhook: 'Webhook',
};

function stepSummary(s: WorkflowStep): string {
  if (s.type === 'wait') return `Wait ${s.amount} ${s.unit === 'minutes' ? 'min' : s.unit === 'hours' ? 'h' : s.amount === 1 ? 'day' : 'days'}`;
  return STEP_WORD[s.type];
}

const RUN_CHIP: Record<WorkflowRun['status'], string> = {
  pending: 'c-cold', waiting: 'c-warm', completed: 'c-won', cancelled: 'c-mute', failed: 'c-hot',
};
const RESULT_MARK: Record<string, { mark: string; color: string }> = {
  done: { mark: '✓', color: 'var(--won)' },
  skipped: { mark: '–', color: 'var(--text-3)' },
  failed: { mark: '✕', color: 'var(--hot)' },
  waiting: { mark: '⏳', color: 'var(--warm-ink)' },
};

export default function WorkflowsPage() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [editing, setEditing] = useState<{ initial: Partial<WorkflowInput>; id?: number } | null>(null);
  const [gallery, setGallery] = useState(false);
  const [runsFor, setRunsFor] = useState<Workflow | null>(null);
  const [tryOn, setTryOn] = useState<Workflow | null>(null);
  const [deleting, setDeleting] = useState<Workflow | null>(null);

  const { data: workflows, isLoading, error } = useQuery({
    queryKey: ['workflows'],
    queryFn: () => automationApi.list().then(r => r.data),
  });

  const toggle = useMutation({
    mutationFn: (w: Workflow) => automationApi.toggle(w.id, !w.is_active),
    onSuccess: r => {
      qc.invalidateQueries({ queryKey: ['workflows'] });
      showToast(r.data.is_active ? 'success' : 'info', r.data.is_active ? 'Switched on' : 'Switched off',
        r.data.is_active ? `“${r.data.name}” now runs on new events.`
          : 'Nothing new starts; runs on a wait stop at their next step.');
    },
    onError: e => showToast('error', 'Could not switch it', getErrorMessage(e)),
  });
  const duplicate = useMutation({
    mutationFn: (w: Workflow) => automationApi.duplicate(w.id),
    onSuccess: r => {
      qc.invalidateQueries({ queryKey: ['workflows'] });
      setEditing({ initial: r.data, id: r.data.id });
    },
    onError: e => showToast('error', 'Could not duplicate', getErrorMessage(e)),
  });
  const remove = useMutation({
    mutationFn: (w: Workflow) => automationApi.remove(w.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['workflows'] });
      setDeleting(null);
      showToast('success', 'Workflow deleted', '');
    },
    onError: e => showToast('error', 'Could not delete', getErrorMessage(e)),
  });

  const list = workflows ?? [];

  return (
    <div style={{ padding: 20 }}>
      <SectionHeader title="Workflows"
                     sub="When something happens to a lead, the CRM does the follow-up for you">
        <button className="btn btn-p" onClick={() => setGallery(true)}>+ New workflow</button>
      </SectionHeader>

      {isLoading ? (
        <div className="flex justify-center py-16"><Spinner /></div>
      ) : error ? (
        <EmptyState icon="⚠" title="Workflows unavailable" message={getErrorMessage(error)} />
      ) : !list.length ? (
        <>
          <div style={{ fontSize: '0.85rem', color: 'var(--text-2)', margin: '6px 0 14px' }}>
            Start from one of these — you&apos;ll pick the template and agents before anything is switched on.
          </div>
          <Gallery onPick={w => setEditing({ initial: w })} />
        </>
      ) : (
        <div className="flex flex-col gap-3">
          {list.map(w => (
            <div key={w.id} className="plate no-ticks" style={{ padding: '14px 16px' }}>
              <div className="flex items-start justify-between gap-3" style={{ flexWrap: 'wrap' }}>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div className="flex items-center gap-2" style={{ flexWrap: 'wrap' }}>
                    <span style={{ fontSize: 14.5, fontWeight: 700 }}>{w.name}</span>
                    <span className={`chip ${w.is_active ? 'c-won' : 'c-mute'}`}>
                      <i className="pip" />{w.is_active ? 'On' : 'Off'}
                    </span>
                    {w.repeat && <span className="chip c-mute">Every time</span>}
                  </div>
                  {w.description && (
                    <div style={{ fontSize: 12.5, color: 'var(--text-2)', marginTop: 2 }}>{w.description}</div>
                  )}
                  <div className="flex items-center gap-1" style={{ flexWrap: 'wrap', marginTop: 8, fontSize: 12.5 }}>
                    <span className="chip c-brand">⚡ {w.trigger_label}</span>
                    {w.steps.map((s, i) => (
                      <span key={i} className="flex items-center gap-1">
                        <span style={{ color: 'var(--text-3)' }}>→</span>
                        <span className={`chip ${s.type === 'wait' ? 'c-warm' : 'c-mute'}`}>{stepSummary(s)}</span>
                      </span>
                    ))}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 8 }}>
                    {w.runs_count} run{w.runs_count === 1 ? '' : 's'}
                    {w.open_runs > 0 && ` · ${w.open_runs} in progress`}
                    {w.last_run_at && ` · last ${fmtRelative(w.last_run_at)}`}
                  </div>
                </div>
                <div className="flex items-center gap-2" style={{ flexWrap: 'wrap' }}>
                  <button className="btn btn-g" style={{ fontSize: '0.75rem' }}
                          onClick={() => setEditing({ initial: w, id: w.id })}>Edit</button>
                  <button className="btn btn-g" style={{ fontSize: '0.75rem' }} onClick={() => setRunsFor(w)}>Run log</button>
                  <button className="btn btn-g" style={{ fontSize: '0.75rem' }} onClick={() => setTryOn(w)}>Try on a lead</button>
                  <button className="btn btn-g" style={{ fontSize: '0.75rem' }} disabled={duplicate.isPending}
                          onClick={() => duplicate.mutate(w)}>Duplicate</button>
                  <button className="btn btn-g" style={{ fontSize: '0.75rem', color: 'var(--hot)' }}
                          onClick={() => setDeleting(w)}>Delete</button>
                  <button className={`btn ${w.is_active ? 'btn-g' : 'btn-p'}`} style={{ fontSize: '0.75rem', minWidth: 92 }}
                          disabled={toggle.isPending} onClick={() => toggle.mutate(w)}>
                    {w.is_active ? 'Switch off' : 'Switch on'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {gallery && (
        <Modal title="New workflow" subtitle="Start from a common one, or from scratch" onClose={() => setGallery(false)} maxWidth="820px">
          <Gallery onPick={w => { setGallery(false); setEditing({ initial: w }); }} withBlank />
        </Modal>
      )}
      {editing && (
        <WorkflowEditor initial={editing.initial} workflowId={editing.id}
                        onClose={() => setEditing(null)} onSaved={() => setEditing(null)} />
      )}
      {runsFor && <RunLog workflow={runsFor} onClose={() => setRunsFor(null)} />}
      {tryOn && <TryOnLead workflow={tryOn} onClose={() => setTryOn(null)} onStarted={() => { setRunsFor(tryOn); setTryOn(null); }} />}
      {deleting && (
        <ConfirmDialog title={`Delete “${deleting.name}”?`} danger confirmLabel="Delete"
                       message="Its run log is deleted too, and runs that are waiting stop. Switching it off keeps the history."
                       onConfirm={() => remove.mutate(deleting)} onCancel={() => setDeleting(null)} />
      )}
    </div>
  );
}

function Gallery({ onPick, withBlank }: { onPick: (w: Partial<WorkflowInput>) => void; withBlank?: boolean }) {
  return (
    <div style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fill, minmax(230px, 1fr))' }}>
      {PRESETS.map(p => (
        <button key={p.key} className="plate no-ticks" onClick={() => onPick(structuredClone(p.workflow))}
                style={{ textAlign: 'left', padding: '14px 16px', cursor: 'pointer' }}>
          <div style={{ fontSize: '1.4rem' }}>{p.icon}</div>
          <div style={{ fontWeight: 700, fontSize: 14, marginTop: 6 }}>{p.title}</div>
          <div style={{ fontSize: 12.5, color: 'var(--text-2)', marginTop: 4, lineHeight: 1.45 }}>{p.blurb}</div>
        </button>
      ))}
      {withBlank && (
        <button className="plate no-ticks" onClick={() => onPick(structuredClone(BLANK))}
                style={{ textAlign: 'left', padding: '14px 16px', cursor: 'pointer', borderStyle: 'dashed' }}>
          <div style={{ fontSize: '1.4rem' }}>＋</div>
          <div style={{ fontWeight: 700, fontSize: 14, marginTop: 6 }}>Start from scratch</div>
          <div style={{ fontSize: 12.5, color: 'var(--text-2)', marginTop: 4 }}>Pick your own trigger and steps.</div>
        </button>
      )}
    </div>
  );
}

function RunLog({ workflow, onClose }: { workflow: Workflow; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('');
  const [open, setOpen] = useState<number | null>(null);
  const { data, isLoading } = useQuery({
    queryKey: ['workflow-runs', workflow.id, page, status],
    queryFn: () => automationApi.runs({
      workflow: workflow.id, page, ...(status === 'errors' ? { errors: true } : status ? { status } : {}),
    }).then(r => r.data),
    refetchInterval: 10_000,
  });
  const cancel = useMutation({
    mutationFn: (id: number) => automationApi.cancelRun(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['workflow-runs', workflow.id] });
      showToast('info', 'Run stopped', 'Its remaining steps will not run.');
    },
    onError: e => showToast('error', 'Could not stop it', getErrorMessage(e)),
  });
  const runs = data?.results ?? [];

  return (
    <Modal title={`Run log — ${workflow.name}`} subtitle="What every step did, for every lead" onClose={onClose} maxWidth="820px">
      <div className="seg" style={{ display: 'inline-flex', marginBottom: 12 }}>
        {[['', 'All'], ['waiting', 'Waiting'], ['completed', 'Completed'], ['errors', 'With errors'], ['cancelled', 'Stopped']].map(([k, l]) => (
          <button key={k} className={`seg-btn ${status === k ? 'on' : ''}`} onClick={() => { setStatus(k); setPage(1); }}>{l}</button>
        ))}
      </div>
      {isLoading ? <div className="flex justify-center py-8"><Spinner /></div> : !runs.length ? (
        <div style={{ fontSize: '0.85rem', color: 'var(--text-3)', padding: '20px 0' }}>No runs yet.</div>
      ) : (
        <div className="flex flex-col gap-2">
          {runs.map(r => (
            <div key={r.id} style={{ border: '1px solid var(--line)', borderRadius: 8 }}>
              <button onClick={() => setOpen(open === r.id ? null : r.id)} className="flex items-center gap-2"
                      style={{ width: '100%', padding: '8px 10px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
                <span className={`chip ${RUN_CHIP[r.status]}`}>{r.status}</span>
                {r.has_errors && <span className="chip c-hot">errors</span>}
                <span style={{ fontWeight: 600, fontSize: 13 }}>{r.lead_name}</span>
                <span style={{ fontSize: 12, color: 'var(--text-3)' }}>{r.lead_phone}</span>
                <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--text-3)' }}>
                  step {Math.min(r.current_step, r.total_steps)}/{r.total_steps} · {fmtDateTime(r.created_at)}
                </span>
              </button>
              {open === r.id && (
                <div style={{ padding: '4px 12px 10px 12px', borderTop: '1px solid var(--line)' }}>
                  {r.trigger === 'manual' && (
                    <div style={{ fontSize: 12, color: 'var(--text-3)', margin: '6px 0' }}>Started by hand (“Try on a lead”).</div>
                  )}
                  {r.log.map((e, i) => {
                    const m = RESULT_MARK[e.result] ?? RESULT_MARK.done;
                    return (
                      <div key={i} className="flex gap-2" style={{ fontSize: 12.5, padding: '4px 0' }}>
                        <span style={{ color: m.color, fontWeight: 800, width: 16 }}>{m.mark}</span>
                        <span style={{ minWidth: 70, color: 'var(--text-2)' }}>
                          {e.type === 'end' ? 'Stopped' : `Step ${e.step + 1}`}
                        </span>
                        <span style={{ flex: 1 }}>{e.detail}</span>
                        <span style={{ color: 'var(--text-3)' }}>{fmtDateTime(e.at)}</span>
                      </div>
                    );
                  })}
                  {r.next_run_at && r.status === 'waiting' && (
                    <div style={{ fontSize: 12, color: 'var(--warm-ink)', marginTop: 4 }}>
                      Next step {fmtRelative(r.next_run_at)} ({fmtDateTime(r.next_run_at)}).
                    </div>
                  )}
                  {(r.status === 'waiting' || r.status === 'pending') && (
                    <button className="btn btn-g" style={{ fontSize: '0.72rem', marginTop: 8, color: 'var(--hot)' }}
                            disabled={cancel.isPending} onClick={() => cancel.mutate(r.id)}>Stop this run</button>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      {(data?.total_pages ?? 1) > 1 && (
        <div style={{ marginTop: 10 }}>
          <Pagination page={page} totalPages={data?.total_pages ?? 1} onPageChange={setPage} />
        </div>
      )}
    </Modal>
  );
}

function TryOnLead({ workflow, onClose, onStarted }: { workflow: Workflow; onClose: () => void; onStarted: () => void }) {
  const { showToast } = useToast();
  const [q, setQ] = useState('');
  const { data: matches } = useQuery({
    queryKey: ['workflow-try-search', q],
    queryFn: () => leadsApi.list({ search: q, page_size: 8 }).then(r => r.data.results),
    enabled: q.trim().length >= 2,
  });
  const run = useMutation({
    mutationFn: (leadId: number) => automationApi.runOn(workflow.id, leadId),
    onSuccess: () => {
      showToast('success', 'Started', 'Its steps run now — waits and quiet hours still apply.');
      onStarted();
    },
    onError: e => showToast('error', 'Could not start', getErrorMessage(e)),
  });
  return (
    <Modal title={`Try “${workflow.name}” on a lead`}
           subtitle="Runs its steps on one lead now, ignoring the trigger and conditions — try it on your own number first."
           onClose={onClose}>
      <input className="input-brutal" autoFocus placeholder="Search a lead by name or phone…" value={q}
             onChange={e => setQ(e.target.value)} style={{ width: '100%' }} />
      <div className="flex flex-col" style={{ marginTop: 8 }}>
        {(matches ?? []).map(l => (
          <button key={l.id} disabled={run.isPending} onClick={() => run.mutate(l.id)}
                  className="flex items-center justify-between"
                  style={{ padding: '8px 6px', borderBottom: '1px solid var(--line)', background: 'none', cursor: 'pointer' }}>
            <span style={{ fontWeight: 600, fontSize: 13 }}>{l.name}</span>
            <span style={{ fontSize: 12, color: 'var(--text-3)' }}>{l.phone} · Run →</span>
          </button>
        ))}
        {q.trim().length >= 2 && matches && !matches.length && (
          <div style={{ fontSize: 12.5, color: 'var(--text-3)', padding: 8 }}>No lead matches “{q}”.</div>
        )}
      </div>
    </Modal>
  );
}
