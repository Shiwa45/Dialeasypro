// ============================================================
// DialSathi — My Performance (agent workspace home)
//
// An agent's own day, and nothing else. Every number comes from
// /reports/my-performance/, which takes no agent id at all — so this page has
// no way to show a colleague's figures even by accident.
//
// Chart colours use --chart-calls / --chart-connected (index.css), validated
// for lightness band, colour-blind separation and contrast in both themes.
// ============================================================
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import {
  Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';
import { reportsApi } from '../../api';
import { SectionHeader, Spinner, StatCard } from '../../components/ui';
import { useAuthStore } from '../../store/authStore';
import { useWorkspace } from '../../hooks/useWorkspace';
import { fmtDate, LEAD_STATUSES } from '../../utils/fmt';

type Days = 1 | 7 | 30;
const PERIODS: Array<{ days: Days; label: string }> = [
  { days: 1, label: 'Today' },
  { days: 7, label: 'Last 7 days' },
  { days: 30, label: 'Last 30 days' },
];

/** 4h 12m · 38m · 0m — talk time reads in hours and minutes, never seconds. */
function talk(seconds: number) {
  const h = Math.floor(seconds / 3600);
  const m = Math.round((seconds % 3600) / 60);
  return h ? `${h}h ${m}m` : `${m}m`;
}

function clock(iso: string | null) {
  if (!iso) return '—';
  return new Date(iso).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' });
}

const statusLabel = (s: string) => LEAD_STATUSES.find(x => x.value === s)?.label ?? s.replace(/_/g, ' ');

export default function MyPerformancePage() {
  const navigate = useNavigate();
  const { agent } = useAuthStore();
  const { isReadOnly } = useWorkspace();
  const [days, setDays] = useState<Days>(7);
  const [asTable, setAsTable] = useState(false);

  const { data, isLoading, isError } = useQuery({
    queryKey: ['my-performance', days],
    queryFn: () => reportsApi.myPerformance(days).then(r => r.data),
    refetchInterval: 60_000, // the day moves; a dashboard left open should too
  });

  const periodLabel = PERIODS.find(p => p.days === days)?.label.toLowerCase();

  return (
    <div className="p-6 flex flex-col gap-4" style={{ background: 'var(--paper)', minHeight: '100%' }}>
      <SectionHeader
        title={`Hi ${agent?.name?.split(' ')[0] ?? 'there'}`}
        sub={isReadOnly ? 'Your leads and calls · view only' : 'Your calls, leads and follow-ups'}
      >
        {/* Filters sit in one row above everything they drive. */}
        <div className="flex gap-2" role="group" aria-label="Period">
          {PERIODS.map(p => (
            <button key={p.days} type="button" onClick={() => setDays(p.days)}
                    aria-pressed={days === p.days}
                    className="btn-brutal px-3 py-1.5 font-heading font-bold"
                    style={{ fontSize: '0.78rem', background: days === p.days ? 'var(--brass-50)' : 'var(--surface)' }}>
              {p.label}
            </button>
          ))}
        </div>
      </SectionHeader>

      {isLoading && <div className="flex justify-center py-16"><Spinner /></div>}
      {isError && (
        <div className="card p-5" style={{ color: 'var(--text-2)' }}>
          Couldn't load your numbers just now. They refresh every minute — or reload the page.
        </div>
      )}

      {data && (
        <>
          {/* ---- Headline numbers: tiles, not charts ---- */}
          <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))' }}>
            <StatCard label="Calls" value={data.calls.total}
                      sub={`${data.calls.outbound} out · ${data.calls.inbound} in${data.calls.missed ? ` · ${data.calls.missed} missed` : ''}`}
                      icon="☎" />
            <StatCard label="Connected" value={data.calls.connected}
                      sub={data.calls.total ? `${data.calls.connection_rate}% of calls` : `No calls ${periodLabel}`}
                      tone="blue" icon="✓" />
            <StatCard label="Talk time" value={talk(data.calls.talk_seconds)}
                      sub={data.calls.connected ? `${talk(data.calls.avg_talk_seconds)} per connected call` : '—'}
                      tone="teal" icon="◷" />
            <StatCard label="Converted" value={data.leads.converted_in_period}
                      sub={`${data.leads.conversion_rate}% of all your leads won`}
                      tone="green" icon="★" />
            <StatCard label="Follow-ups overdue" value={data.followups.overdue}
                      sub={`${data.followups.due_today} more due today`}
                      tone={data.followups.overdue ? 'red' : 'green'}
                      icon={data.followups.overdue ? '!' : '✓'} />
          </div>

          {/* ---- Today strip ---- */}
          <div className="card card-sm p-3 flex gap-5 flex-wrap" style={{ fontSize: '0.82rem' }}>
            <span><b>{data.today.calls}</b> call{data.today.calls === 1 ? '' : 's'} today</span>
            <span style={{ color: 'var(--text-2)' }}>First call <b style={{ color: 'var(--text)' }}>{clock(data.today.first_call_at)}</b></span>
            <span style={{ color: 'var(--text-2)' }}>Last call <b style={{ color: 'var(--text)' }}>{clock(data.today.last_call_at)}</b></span>
            <span style={{ color: 'var(--text-2)' }}>
              <b style={{ color: 'var(--text)' }}>{data.leads.new_in_period}</b> lead{data.leads.new_in_period === 1 ? '' : 's'} assigned to you {periodLabel}
            </span>
          </div>

          <div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))' }}>
            {/* ---- Calls per day ----
                Two series in one unit (calls), so one axis. Connected is a
                subset of calls; side-by-side bars keep both readable without
                a second scale. Not drawn for "Today" — one bar is a tile. */}
            {days > 1 && (
              <div className="plate" style={{ gridColumn: '1 / -1' }}>
                <div className="plate-h" style={{ borderBottom: 0, alignItems: 'center' }}>
                  <div className="plate-t" style={{ fontSize: 16 }}>Calls per day</div>
                  <div className="flex items-center gap-3" style={{ marginLeft: 'auto' }}>
                    <div className="legend">
                      <span><i style={{ background: 'var(--chart-calls)' }} />Calls</span>
                      <span><i style={{ background: 'var(--chart-connected)' }} />Connected</span>
                    </div>
                    <button type="button" className="btn-brutal px-2 py-1 font-heading font-bold"
                            style={{ fontSize: '0.7rem' }} onClick={() => setAsTable(t => !t)}>
                      {asTable ? 'Show chart' : 'Show as table'}
                    </button>
                  </div>
                </div>
                <div className="plate-b" style={{ paddingTop: 0 }}>
                  {data.calls.total === 0 ? (
                    <div className="flex items-center justify-center"
                         style={{ height: 220, color: 'var(--text-3)', fontSize: '0.85rem' }}>
                      No calls {periodLabel}.
                    </div>
                  ) : asTable ? (
                    <div style={{ overflowX: 'auto' }}>
                      <table className="table-brutal">
                        <thead><tr><th>Date</th><th>Calls</th><th>Connected</th><th>Talk time</th></tr></thead>
                        <tbody>
                          {data.calls_by_day.map(d => (
                            <tr key={d.date}>
                              <td>{fmtDate(d.date, 'EEE dd MMM')}</td>
                              <td>{d.calls}</td>
                              <td>{d.connected}</td>
                              <td>{talk(d.talk_seconds)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height={240}>
                      <BarChart data={data.calls_by_day} barGap={2} barCategoryGap={days > 7 ? '18%' : '30%'}
                                margin={{ top: 10, right: 8, bottom: 0, left: -14 }}>
                        <CartesianGrid vertical={false} strokeDasharray="3 4" stroke="var(--line)" />
                        <XAxis dataKey="date"
                               tickFormatter={(v: string) => fmtDate(v, days > 7 ? 'dd MMM' : 'EEE')}
                               tick={{ fontSize: 12, fontWeight: 600, fill: 'var(--text-2)' }}
                               tickLine={false} axisLine={{ stroke: 'var(--line)' }} minTickGap={16} dy={6} />
                        <YAxis allowDecimals={false} width={44} tickLine={false} axisLine={false}
                               tick={{ fontSize: 12, fontWeight: 600, fill: 'var(--text-2)' }} />
                        <Tooltip content={<DayTip />} cursor={{ fill: 'var(--sunken)' }} />
                        <Bar dataKey="calls" name="Calls" fill="var(--chart-calls)"
                             radius={[4, 4, 0, 0]} maxBarSize={22} />
                        <Bar dataKey="connected" name="Connected" fill="var(--chart-connected)"
                             radius={[4, 4, 0, 0]} maxBarSize={22} />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>
            )}

            {/* ---- My leads by status ----
                Magnitude across categories → sorted horizontal bars in one
                hue, value labelled at the end. Not a pie. */}
            <div className="plate">
              <div className="plate-h" style={{ borderBottom: 0 }}>
                <div className="plate-t" style={{ fontSize: 16 }}>My leads</div>
                <span style={{ marginLeft: 'auto', fontSize: '0.8rem', color: 'var(--text-2)' }}>
                  {data.leads.assigned_total} assigned
                </span>
              </div>
              <div className="plate-b" style={{ paddingTop: 4 }}>
                {data.leads.assigned_total === 0 ? (
                  <p style={{ fontSize: '0.85rem', color: 'var(--text-3)' }}>
                    No leads are assigned to you yet.
                  </p>
                ) : (
                  <StatusBars byStatus={data.leads.by_status}
                              onPick={s => navigate(`/leads?status=${encodeURIComponent(s)}`)} />
                )}
              </div>
            </div>

            {/* ---- Follow-ups ---- */}
            <div className="plate">
              <div className="plate-h" style={{ borderBottom: 0 }}>
                <div className="plate-t" style={{ fontSize: 16 }}>Next follow-ups</div>
                <span style={{ marginLeft: 'auto', fontSize: '0.8rem', color: 'var(--text-2)' }}>
                  {data.followups.upcoming_7d} more this week · {data.followups.completed_in_period} done {periodLabel}
                </span>
              </div>
              <div className="plate-b" style={{ paddingTop: 4 }}>
                {!data.followups.next.length ? (
                  <p style={{ fontSize: '0.85rem', color: 'var(--text-3)' }}>
                    Nothing scheduled. You're clear.
                  </p>
                ) : (
                  <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
                    {data.followups.next.map(f => (
                      <li key={f.id}>
                        <button type="button" onClick={() => navigate(`/leads/${f.lead_id}`)}
                                className="flex items-center gap-3 w-full"
                                style={{ padding: '8px 2px', background: 'none', border: 'none',
                                         borderBottom: '1px solid var(--line)',
                                         cursor: 'pointer', textAlign: 'left', color: 'var(--text)' }}>
                          {/* State is never colour alone: overdue carries a word. */}
                          <span className="font-heading font-bold"
                                style={{
                                  fontSize: '0.66rem', padding: '2px 7px', border: '1px solid var(--line)',
                                  background: f.overdue ? 'var(--hot-50)' : 'var(--surface-2)',
                                  color: f.overdue ? 'var(--hot)' : 'var(--text-2)', whiteSpace: 'nowrap',
                                }}>
                            {f.overdue ? 'OVERDUE' : f.type.replace(/_/g, ' ').toUpperCase()}
                          </span>
                          <span style={{ flex: 1, fontSize: '0.85rem', fontWeight: 600 }}>{f.lead_name}</span>
                          <span style={{ fontSize: '0.78rem', color: 'var(--text-2)', whiteSpace: 'nowrap' }}>
                            {fmtDate(f.scheduled_at, 'dd MMM, h:mm a')}
                          </span>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function DayTip({ active, payload, label }: {
  active?: boolean; label?: string;
  payload?: Array<{ dataKey: string; value: number; payload: { talk_seconds: number } }>;
}) {
  if (!active || !payload?.length || !label) return null;
  const v = (k: string) => payload.find(p => p.dataKey === k)?.value ?? 0;
  return (
    <div className="chart-tip">
      <div className="chart-tip-d">{fmtDate(label, 'EEE dd MMM')}</div>
      <div className="chart-tip-r"><i style={{ background: 'var(--chart-calls)' }} /><span>Calls</span><b>{v('calls')}</b></div>
      <div className="chart-tip-r"><i style={{ background: 'var(--chart-connected)' }} /><span>Connected</span><b>{v('connected')}</b></div>
      <div className="chart-tip-r"><i style={{ background: 'transparent' }} /><span>Talk time</span><b>{talk(payload[0].payload.talk_seconds)}</b></div>
    </div>
  );
}

/** Sorted bars, one hue, value at the end. Each row opens My Leads filtered to that status. */
function StatusBars({ byStatus, onPick }: { byStatus: Record<string, number>; onPick: (s: string) => void }) {
  const rows = Object.entries(byStatus).filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1]);
  const max = Math.max(1, ...rows.map(([, n]) => n));
  return (
    <div className="flex flex-col" style={{ gap: 6 }}>
      {rows.map(([status, n]) => (
        <button key={status} type="button" onClick={() => onPick(status)}
                title={`Open my ${statusLabel(status)} leads`}
                style={{ display: 'grid', gridTemplateColumns: '120px 1fr 40px', alignItems: 'center',
                         gap: 10, background: 'none', border: 'none', padding: '3px 0', cursor: 'pointer',
                         color: 'var(--text)', textAlign: 'left' }}>
          <span style={{ fontSize: '0.8rem' }}>{statusLabel(status)}</span>
          <span style={{ height: 12, background: 'var(--sunken)', borderRadius: 4, overflow: 'hidden' }}>
            <span style={{ display: 'block', height: '100%', width: `${(n / max) * 100}%`,
                           background: 'var(--chart-calls)', borderRadius: 4 }} />
          </span>
          <b style={{ fontSize: '0.82rem', textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{n}</b>
        </button>
      ))}
    </div>
  );
}
