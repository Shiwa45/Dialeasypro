// Mirrors apps/communications/whatsapp_ready.py :: LEAD_VARIABLE_FIELDS.
// A template variable ({{1}}, {{2}}…) is filled from one of these per lead;
// "custom:<field_key>" fills it from a custom field.
export const LEAD_VARIABLE_FIELDS: Array<{ value: string; label: string }> = [
  { value: 'name', label: 'Lead name' },
  { value: 'first_name', label: 'First name' },
  { value: 'phone', label: 'Phone' },
  { value: 'email', label: 'Email' },
  { value: 'city', label: 'City' },
  { value: 'state', label: 'State' },
  { value: 'requirement', label: 'Requirement' },
  { value: 'budget', label: 'Budget' },
  { value: 'deal_value', label: 'Deal value' },
  { value: 'campaign_name', label: 'Campaign name' },
  { value: 'agent_name', label: "Assigned agent's name" },
  { value: 'agent_phone', label: "Assigned agent's phone" },
];

/** {{N}} numbers in a body, sorted and de-duplicated. */
export function placeholdersIn(text: string): number[] {
  const nums = new Set<number>();
  for (const m of (text || '').matchAll(/\{\{\s*(\d+)\s*\}\}/g)) nums.add(Number(m[1]));
  return [...nums].sort((a, b) => a - b);
}
