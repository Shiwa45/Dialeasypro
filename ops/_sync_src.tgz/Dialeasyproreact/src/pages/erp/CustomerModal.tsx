// ============================================================
// ERP — Add/Edit Customer
// ============================================================
import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { erpApi } from '../../api';
import { Modal, Input, Textarea, useToast } from '../../components/ui';
import type { ErpCustomer } from '../../types';
import { getErrorMessage } from '../../utils/errors';
import { INDIAN_STATES, STATE_ALIASES, stateFromGstin, stateName } from './erpShared';

export default function CustomerModal({ customer, onClose }: { customer?: ErpCustomer; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const isEdit = !!customer;

  const [form, setForm] = useState({
    name: customer?.name ?? '',
    email: customer?.email ?? '',
    phone: customer?.phone ?? '',
    gstin: customer?.gstin ?? '',
    state_code: STATE_ALIASES[customer?.state_code ?? ''] ?? customer?.state_code ?? '',
    billing_address: customer?.billing_address ?? '',
    shipping_address: customer?.shipping_address ?? '',
    is_active: customer?.is_active ?? true,
  });

  const set = (k: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm(f => ({ ...f, [k]: e.target.value }));

  // The state is part of the GSTIN (first two digits). Fill it in as soon as
  // the number is typed, so IGST vs CGST/SGST is right without a second step.
  const onGstin = (e: React.ChangeEvent<HTMLInputElement>) => {
    const gstin = e.target.value.toUpperCase().replace(/\s/g, '');
    const derived = gstin.length >= 2 ? stateFromGstin(gstin) : '';
    setForm(f => ({ ...f, gstin, state_code: derived || f.state_code }));
  };

  const gstinState = form.gstin.length >= 2 ? stateFromGstin(form.gstin) : '';
  const stateMismatch = !!gstinState && !!form.state_code && gstinState !== form.state_code;

  const save = useMutation({
    mutationFn: () => {
      const payload = { ...form, gstin: form.gstin.trim().toUpperCase() };
      return isEdit ? erpApi.updateCustomer(customer!.id, payload) : erpApi.createCustomer(payload);
    },
    onSuccess: () => {
      showToast('success', isEdit ? 'Customer updated' : 'Customer added', form.name);
      qc.invalidateQueries({ queryKey: ['erp-customers'] });
      qc.invalidateQueries({ queryKey: ['erp-customers-picker'] });
      onClose();
    },
    onError: (e: unknown) => {
      showToast('error', 'Could not save the customer', getErrorMessage(e, 'Could not save the customer.'));
    },
  });

  const canSave = form.name.trim().length > 0 && !stateMismatch;

  return (
    <Modal title={isEdit ? 'Edit customer' : 'Add customer'} onClose={onClose} maxWidth="560px">
      <div className="flex flex-col gap-3">
        <Input label="Name" required value={form.name} onChange={set('name')} placeholder="Acme Realty Pvt Ltd" />
        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
          <Input label="Phone" value={form.phone} onChange={set('phone')} placeholder="+91 98765 43210" />
          <Input label="Email" type="email" value={form.email} onChange={set('email')} placeholder="billing@acme.in" />
        </div>
        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
          <Input label="GSTIN (optional)" value={form.gstin} onChange={onGstin}
                 placeholder="27ABCDE1234F1Z5" maxLength={15}
                 style={{ fontFamily: 'monospace', letterSpacing: '0.04em' }} />
          <div>
            <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
              State {form.gstin ? '' : '(needed for GST)'}
            </label>
            <select className="input-brutal" style={{ cursor: 'pointer', width: '100%' }}
                    value={form.state_code} onChange={set('state_code')}>
              <option value="">—</option>
              {INDIAN_STATES.map(([c, n]) => <option key={c} value={c}>{n} ({c})</option>)}
            </select>
          </div>
        </div>
        <p style={{ fontSize: '0.7rem', color: stateMismatch ? 'var(--hot)' : 'var(--text-3)', marginTop: '-6px' }}>
          {stateMismatch
            ? `This GSTIN is registered in ${stateName(gstinState)} (${gstinState}), not ${stateName(form.state_code)}. Fix the GSTIN or the state.`
            : gstinState
              ? `State read from the GSTIN: ${stateName(gstinState)}.`
              : 'The state decides IGST vs CGST + SGST on every quotation and invoice. With a GSTIN it is filled in automatically.'}
        </p>
        <Textarea label="Billing address" value={form.billing_address} onChange={set('billing_address')} />
        <Textarea label="Shipping address (optional)" value={form.shipping_address} onChange={set('shipping_address')} />

        {isEdit && (
          <label className="flex items-center gap-2" style={{ fontSize: '0.82rem', cursor: 'pointer' }}>
            <input type="checkbox" checked={form.is_active}
                   onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))} />
            Active — inactive customers keep their history but can't get new quotations
          </label>
        )}

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-2"
                style={{ fontSize: '0.85rem' }}
                disabled={!canSave || save.isPending}
                onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : isEdit ? 'Save changes' : 'Add customer'}
        </button>
      </div>
    </Modal>
  );
}
