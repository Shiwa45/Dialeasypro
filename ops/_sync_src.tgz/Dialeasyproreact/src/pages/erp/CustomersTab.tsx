// ============================================================
// Sales & Billing — Customers
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { erpApi } from '../../api';
import { AddButton, Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { ConfirmDialog, Modal, Select, Spinner, StatCard, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINRExact } from '../../utils/fmt';
import CustomerModal from './CustomerModal';
import { docNumber } from './erpShared';
import type { ErpCustomer } from '../../types';

export default function CustomersTab() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canManage = can(Cap.ERP_MANAGE);

  const [search, setSearch] = useState('');
  const [active, setActive] = useState('');
  const [gstOnly, setGstOnly] = useState('');
  const [editing, setEditing] = useState<ErpCustomer | null>(null);
  const [adding, setAdding] = useState(false);
  const [deleting, setDeleting] = useState<ErpCustomer | null>(null);
  const [viewing, setViewing] = useState<ErpCustomer | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['erp-customers'],
    queryFn: () => erpApi.customers({ page_size: 500 }).then(r => r.data),
  });

  const remove = useMutation({
    mutationFn: (id: number) => erpApi.deleteCustomer(id),
    onSuccess: () => {
      showToast('success', 'Removed', 'The customer was deleted.');
      qc.invalidateQueries({ queryKey: ['erp-customers'] });
      qc.invalidateQueries({ queryKey: ['erp-customers-picker'] });
      setDeleting(null);
    },
    onError: e => showToast('error', 'Could not delete', getErrorMessage(e)),
  });

  const all = data?.results ?? [];
  const rows = useMemo(() => {
    let list = all;
    if (active) list = list.filter(c => String(c.is_active) === active);
    if (gstOnly === 'yes') list = list.filter(c => !!c.gstin);
    if (gstOnly === 'no') list = list.filter(c => !c.gstin);
    const q = search.trim().toLowerCase();
    if (q) list = list.filter(c =>
      c.name?.toLowerCase().includes(q) || c.gstin?.toLowerCase().includes(q) ||
      c.phone?.includes(q) || c.email?.toLowerCase().includes(q));
    return list;
  }, [all, search, active, gstOnly]);

  const columns: Column<ErpCustomer>[] = [
    { key: 'name', header: 'Name', sortable: true, render: c => <b>{c.name}</b> },
    { key: 'gstin', header: 'GSTIN', sortable: true,
      render: c => c.gstin
        ? <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{c.gstin}</span>
        : <span style={{ color: 'var(--text-3)' }}>B2C</span> },
    { key: 'state_code', header: 'State', render: c => c.state_code || '—' },
    { key: 'phone', header: 'Phone', render: c => <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{c.phone || '—'}</span> },
    { key: 'email', header: 'Email', render: c => c.email || '—' },
    { key: 'is_active', header: 'Status',
      render: c => <StatusPill value={c.is_active ? 'active' : 'inactive'} /> },
  ];

  const withGst = all.filter(c => c.gstin).length;

  return (
    <>
      <div className="grid gap-3 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))' }}>
        <StatCard label="Customers" value={all.length} sub={`${all.filter(c => c.is_active).length} active`} icon="◉" />
        <StatCard label="Registered (B2B)" value={withGst} sub={`${all.length - withGst} B2C`} icon="▣" />
      </div>

      {canManage && <AddButton label="Add customer" onClick={() => setAdding(true)} />}

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search name, GSTIN, phone, email…">
        <Select label="GST" value={gstOnly} onChange={e => setGstOnly(e.target.value)}>
          <option value="">All</option>
          <option value="yes">Registered (B2B)</option>
          <option value="no">Unregistered (B2C)</option>
        </Select>
        <Select label="Status" value={active} onChange={e => setActive(e.target.value)}>
          <option value="">All</option>
          <option value="true">Active</option>
          <option value="false">Inactive</option>
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={c => c.id}
        isLoading={isLoading}
        pageSize={25}
        onRowClick={c => setViewing(c)}
        actions={c => (
          <>
            <RowAction label="History" onClick={() => setViewing(c)} />
            {canManage && <RowAction label="Edit" onClick={() => setEditing(c)} />}
            {canManage && <RowAction label="Delete" danger onClick={() => setDeleting(c)} />}
          </>
        )}
        empty={{
          icon: '◉', title: 'No customers',
          message: 'Add your first billing customer, or convert one from a lead.',
          action: canManage ? { label: 'Add customer', onClick: () => setAdding(true) } : undefined,
        }}
      />

      {adding && <CustomerModal onClose={() => setAdding(false)} />}
      {editing && <CustomerModal customer={editing} onClose={() => setEditing(null)} />}
      {viewing && <CustomerHistory customer={viewing} onClose={() => setViewing(null)} />}

      {deleting && (
        <ConfirmDialog
          title={`Delete ${deleting.name}?`}
          message="This only works if the customer has no quotations, orders or invoices against them — the database protects those. If they do, mark the customer inactive instead."
          confirmLabel="Delete customer"
          danger
          onConfirm={() => remove.mutate(deleting.id)}
          onCancel={() => setDeleting(null)}
        />
      )}
    </>
  );
}

/* ---- Customer history ---------------------------------------
   What this customer has been invoiced and what they still owe. Answering
   that used to mean filtering the invoice list by hand and adding up the
   due column. */
function CustomerHistory({ customer, onClose }: { customer: ErpCustomer; onClose: () => void }) {
  const { data: invoices, isLoading } = useQuery({
    queryKey: ['erp-customer-invoices', customer.id],
    queryFn: () => erpApi.invoices({ customer: customer.id, page_size: 200 }).then(r => r.data),
  });
  const { data: payments } = useQuery({
    queryKey: ['erp-customer-payments', customer.id],
    queryFn: () => erpApi.payments({ customer: customer.id, page_size: 200 }).then(r => r.data),
  });

  const rows = invoices?.results ?? [];
  // Only issued invoices are money owed: a draft hasn't been sent and a
  // cancelled one is void (its total used to show up as outstanding).
  const live = rows.filter(i => i.status !== 'cancelled' && i.status !== 'draft');
  const billed = live.reduce((s, i) => s + Number(i.total_amount || 0), 0);
  const due = live.reduce((s, i) => s + Number(i.amount_due || 0), 0);
  const received = (payments?.results ?? []).reduce((s, p) => s + Number(p.amount || 0), 0);

  return (
    <Modal title={customer.name}
           subtitle={customer.gstin ? `GSTIN ${customer.gstin}` : 'Unregistered (B2C)'}
           onClose={onClose} maxWidth="720px">
      {isLoading ? <Spinner /> : (
        <>
          <div className="grid gap-3 mb-4" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
            <StatCard label="Total billed" value={formatINRExact(billed)} sub={`${live.length} issued invoice${live.length === 1 ? '' : 's'}`} />
            <StatCard label="Received" value={formatINRExact(received)} tone="green" />
            <StatCard label="Outstanding" value={formatINRExact(due)} tone={due > 0 ? 'red' : 'green'} />
          </div>

          {!rows.length ? (
            <p style={{ fontSize: '0.82rem', color: 'var(--text-2)' }}>
              No invoices raised for this customer yet.
            </p>
          ) : (
            <div className="card-brutal" style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 520 }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid var(--line)' }}>
                    {['Number', 'Date', 'Total', 'Due', 'Status'].map(h => (
                      <th key={h} className="th bare">
                        {h.toUpperCase()}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map(i => (
                    <tr key={i.id} style={{ borderBottom: '1px solid var(--line)' }}>
                      <td style={{ padding: '7px 10px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>
                        {docNumber(i.number)}
                      </td>
                      <td style={{ padding: '7px 10px', fontSize: '0.8rem' }}>{fmtDate(i.invoice_date)}</td>
                      <td style={{ padding: '7px 10px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', textAlign: 'right' }}>
                        {formatINRExact(i.total_amount)}
                      </td>
                      <td style={{ padding: '7px 10px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', textAlign: 'right',
                                   color: Number(i.amount_due) > 0 && i.status !== 'cancelled' && i.status !== 'draft' ? 'var(--hot)' : 'var(--text-3)' }}>
                        {i.status === 'cancelled' || i.status === 'draft' ? '—' : formatINRExact(i.amount_due)}
                      </td>
                      <td style={{ padding: '7px 10px' }}><StatusPill value={i.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {customer.billing_address && (
            <p style={{ fontSize: '0.78rem', color: 'var(--text-2)', marginTop: '12px', whiteSpace: 'pre-wrap' }}>
              {customer.billing_address}
            </p>
          )}
        </>
      )}
    </Modal>
  );
}
