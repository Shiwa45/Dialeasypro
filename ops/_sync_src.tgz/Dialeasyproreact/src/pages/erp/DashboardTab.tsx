// ============================================================
// Sales & Billing — Dashboard
//
// Receivables ageing is the number this module exists to surface: which
// money is late, and how late. Buckets come from the backend, which measures
// from the DUE date where one is set rather than the invoice date — an
// invoice inside its payment terms is not overdue.
// ============================================================
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { erpApi } from '../../api';
import { Spinner, StatCard } from '../../components/ui';
import { fmtDate, formatINR, formatINRExact, localISOMonth } from '../../utils/fmt';

const BUCKETS: Array<{ key: keyof AgeingShape; label: string; tone: string }> = [
  { key: 'current', label: 'Not yet due',  tone: 'var(--won-50)'  },
  { key: '1_30',    label: '1–30 days',    tone: 'var(--warm-50)' },
  { key: '31_60',   label: '31–60 days',   tone: 'var(--warm-50)' },
  { key: '61_90',   label: '61–90 days',   tone: 'var(--lost-50)' },
  { key: '90_plus', label: '90+ days',     tone: 'var(--lost-50)' },
];

type AgeingShape = { current: string; '1_30': string; '31_60': string; '61_90': string; '90_plus': string };

export default function DashboardTab() {
  const [month, setMonth] = useState(localISOMonth());

  const { data, isLoading } = useQuery({
    queryKey: ['erp-dashboard', month],
    queryFn: () => erpApi.dashboard(month).then(r => r.data),
  });

  if (isLoading) return <div className="flex justify-center py-16"><Spinner /></div>;
  if (!data) return null;

  const ageingTotal = BUCKETS.reduce((s, b) => s + Number(data.ageing[b.key] || 0), 0);
  const overdue = ageingTotal - Number(data.ageing.current || 0);

  return (
    <>
      <div className="card-brutal flex gap-2 items-end mb-4" style={{ padding: '10px 12px' }}>
        <div>
          <label className="block font-heading font-bold mb-1"
                 style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Month</label>
          <input className="input-brutal" type="month" value={month}
                 onChange={e => setMonth(e.target.value)} />
        </div>
      </div>

      <div className="grid gap-3 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))' }}>
        <StatCard label="Revenue this month" value={formatINR(data.revenue.total)}
                  sub={`${data.revenue.invoices} invoice${data.revenue.invoices === 1 ? '' : 's'} · GST ${formatINR(data.revenue.tax)}`}
                  tone="green" icon="₹" />
        <StatCard label="Collected this month" value={formatINR(data.collected_this_month)}
                  sub="Payments received" tone="teal" icon="✓" />
        <StatCard label="Outstanding" value={formatINR(data.outstanding)}
                  sub={`${data.open_invoices} open invoice${data.open_invoices === 1 ? '' : 's'}`}
                  tone={overdue > 0 ? 'red' : 'blue'} icon="◷" />
        <StatCard label="Overdue" value={formatINR(overdue)}
                  sub={ageingTotal ? `${Math.round((overdue / ageingTotal) * 100)}% of receivables` : 'Nothing overdue'}
                  tone={overdue > 0 ? 'red' : 'green'} icon="!" />
      </div>

      {/* ---- Ageing ---- */}
      <div className="card-brutal mb-4" style={{ padding: '14px' }}>
        <div className="font-heading font-black mb-3" style={{ fontSize: '0.9rem' }}>
          Receivables ageing
        </div>
        {ageingTotal === 0 ? (
          <p className="font-medium" style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>
            Nothing outstanding — every issued invoice is paid.
          </p>
        ) : (
          <>
            {/* Proportional bar, so the shape of the problem reads before the numbers do. */}
            <div style={{ display: 'flex', height: 26, border: '1px solid var(--line)', marginBottom: 12 }}>
              {BUCKETS.map(b => {
                const v = Number(data.ageing[b.key] || 0);
                if (v <= 0) return null;
                return (
                  <div key={b.key}
                       title={`${b.label}: ${formatINRExact(data.ageing[b.key])}`}
                       style={{
                         width: `${(v / ageingTotal) * 100}%`,
                         background: b.tone,
                         borderRight: '1px solid var(--line)',
                       }} />
                );
              })}
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 480 }}>
                <tbody>
                  {BUCKETS.map(b => {
                    const v = Number(data.ageing[b.key] || 0);
                    return (
                      <tr key={b.key} style={{ borderBottom: '1px solid var(--line)' }}>
                        <td style={{ padding: '7px 10px', width: 18 }}>
                          <span style={{ display: 'inline-block', width: 12, height: 12,
                                         background: b.tone, border: '1px solid var(--line)' }} />
                        </td>
                        <td style={{ padding: '7px 10px', fontSize: '0.82rem' }}>{b.label}</td>
                        <td style={{ padding: '7px 10px', fontSize: '0.82rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums',
                                     textAlign: 'right', fontWeight: v > 0 ? 700 : 400,
                                     color: v > 0 ? undefined : 'var(--text-3)' }}>
                          {formatINRExact(data.ageing[b.key])}
                        </td>
                        <td style={{ padding: '7px 10px', fontSize: '0.75rem', color: 'var(--text-3)',
                                     textAlign: 'right', width: 60 }}>
                          {ageingTotal ? `${Math.round((v / ageingTotal) * 100)}%` : '—'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))' }}>
        <div className="card-brutal" style={{ padding: '14px' }}>
          <div className="font-heading font-black mb-3" style={{ fontSize: '0.9rem' }}>
            Top customers · {fmtDate(data.month, 'MMMM yyyy')}
          </div>
          {!data.top_customers.length ? (
            <p style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>No invoices issued this month.</p>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <tbody>
                {data.top_customers.map(c => (
                  <tr key={c.id} style={{ borderBottom: '1px solid var(--line)' }}>
                    <td style={{ padding: '7px 0', fontSize: '0.82rem' }}>{c.name}</td>
                    <td style={{ padding: '7px 0', fontSize: '0.75rem', color: 'var(--text-3)', textAlign: 'right' }}>
                      {c.invoices} inv
                    </td>
                    <td style={{ padding: '7px 0 7px 12px', fontSize: '0.82rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums',
                                 textAlign: 'right', fontWeight: 700 }}>
                      {formatINRExact(c.total)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr', alignContent: 'start' }}>
          <StatCard label="Draft invoices" value={data.counts.draft_invoices} sub="Not yet issued" icon="▤" />
          <StatCard label="Open quotations" value={data.counts.open_quotations} sub="Draft or sent" icon="◫" />
          <StatCard label="Customers" value={data.counts.customers} sub="Active" icon="◉" />
          <StatCard label="Products" value={data.counts.products} sub="Active" icon="⊞" />
        </div>
      </div>
    </>
  );
}
