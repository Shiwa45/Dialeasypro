// ============================================================
// Sales & Billing — Exports & GST summary
//
// The Tally export endpoint has been live since the module shipped and the
// API layer never wrapped it, so there was no way to reach it from the app.
// ============================================================
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { erpApi, type GstSummaryRow } from '../../api';
import { Input, Spinner, useToast } from '../../components/ui';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINRExact, localISOMonth } from '../../utils/fmt';

export default function ExportsTab() {
  const { showToast } = useToast();
  const [month, setMonth] = useState(localISOMonth());
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [downloading, setDownloading] = useState(false);

  const { data: gst, isLoading } = useQuery({
    queryKey: ['erp-gst-summary', month],
    queryFn: () => erpApi.gstSummary(month).then(r => r.data),
  });

  const downloadTally = async () => {
    setDownloading(true);
    try {
      const res = await erpApi.tallyExport({
        date_from: from || undefined,
        date_to: to || undefined,
      });
      // The endpoint streams CSV; turn the blob into a file the browser saves.
      const url = URL.createObjectURL(new Blob([res.data as BlobPart], { type: 'text/csv' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = `tally-export-${from || 'all'}-${to || 'all'}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      showToast('success', 'Downloaded', 'Import the CSV into Tally or Zoho Books.');
    } catch (e) {
      showToast('error', 'Export failed', getErrorMessage(e));
    } finally {
      setDownloading(false);
    }
  };

  const downloadGstCsv = () => {
    if (!gst) return;
    const lines = [['Section', 'GST rate %', 'Taxable', 'CGST', 'SGST', 'IGST', 'Total tax', 'Invoices']];
    const push = (section: string, rows: GstSummaryRow[]) =>
      rows.forEach(r => lines.push([
        section, r.gst_rate, r.taxable, r.cgst, r.sgst, r.igst, r.total_tax, String(r.invoices),
      ]));
    push('B2B', gst.b2b);
    push('B2C', gst.b2c);
    const csv = lines.map(l => l.map(c => `"${c}"`).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `gst-summary-${month}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const sum = (rows: GstSummaryRow[], key: keyof GstSummaryRow) =>
    rows.reduce((s, r) => s + Number(r[key] || 0), 0);

  return (
    <>
      {/* ---- Tally ---- */}
      <div className="card-brutal mb-4" style={{ padding: '14px' }}>
        <div className="font-heading font-black mb-1" style={{ fontSize: '0.9rem' }}>
          Tally / Zoho Books export
        </div>
        <p className="font-medium mb-3" style={{ fontSize: '0.78rem', color: 'var(--text-2)' }}>
          Issued invoices as a CSV your accountant can import. Leave the dates blank to export everything.
        </p>
        <div className="flex gap-2 items-end flex-wrap">
          <Input label="From" type="date" value={from} onChange={e => setFrom(e.target.value)} />
          <Input label="To" type="date" value={to} onChange={e => setTo(e.target.value)} />
          <button className="btn-brutal btn-primary px-3 py-2 font-heading font-bold"
                  style={{ fontSize: '0.78rem' }}
                  disabled={downloading} onClick={downloadTally}>
            {downloading ? 'Preparing…' : 'Download CSV'}
          </button>
        </div>
      </div>

      {/* ---- GST summary ---- */}
      <div className="card-brutal" style={{ padding: '14px' }}>
        <div className="flex items-end justify-between flex-wrap gap-2 mb-3">
          <div>
            <div className="font-heading font-black" style={{ fontSize: '0.9rem' }}>GST summary</div>
            <p className="font-medium" style={{ fontSize: '0.78rem', color: 'var(--text-2)' }}>
              This month's issued invoices, split B2B / B2C by rate.
            </p>
          </div>
          <div className="flex gap-2 items-end">
            <div>
              <label className="block font-heading font-bold mb-1"
                     style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Month</label>
              <input className="input-brutal" type="month" value={month}
                     onChange={e => setMonth(e.target.value)} />
            </div>
            <button className="btn-brutal btn-secondary px-3 py-2 font-heading font-bold"
                    style={{ fontSize: '0.78rem' }} disabled={!gst} onClick={downloadGstCsv}>
              Download CSV
            </button>
          </div>
        </div>

        {isLoading ? <Spinner /> : !gst ? null : (
          <>
            {!gst.b2b.length && !gst.b2c.length ? (
              <p style={{ fontSize: '0.82rem', color: 'var(--text-2)' }}>
                No invoices issued in {fmtDate(gst.month, 'MMMM yyyy')}.
              </p>
            ) : (
              <>
                <Section title="B2B — registered buyers" rows={gst.b2b} sum={sum} />
                <Section title="B2C — unregistered buyers" rows={gst.b2c} sum={sum} />
              </>
            )}

            <p className="font-medium" style={{
              fontSize: '0.75rem', color: 'var(--text-2)', marginTop: '12px',
              background: 'var(--warm-50)', border: '1px solid var(--line)', padding: '8px 10px',
            }}>
              <b>Filing aid, not a return.</b> {gst.note}
            </p>
          </>
        )}
      </div>
    </>
  );
}

function Section({ title, rows, sum }: {
  title: string;
  rows: GstSummaryRow[];
  sum: (r: GstSummaryRow[], k: keyof GstSummaryRow) => number;
}) {
  if (!rows.length) return null;
  return (
    <div style={{ marginBottom: '16px' }}>
      <div className="font-heading font-bold mb-2" style={{ fontSize: '0.78rem', letterSpacing: '0.04em' }}>
        {title.toUpperCase()}
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 560 }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--line)' }}>
              {['Rate', 'Taxable', 'CGST', 'SGST', 'IGST', 'Total tax', 'Invoices'].map(h => (
                <th key={h} className="th bare"
                    style={{ textAlign: h === 'Rate' ? 'left' : 'right' }}>
                  {h.toUpperCase()}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.gst_rate} style={{ borderBottom: '1px solid var(--line)' }}>
                <td style={{ padding: '7px 10px', fontSize: '0.8rem', fontWeight: 700 }}>{Number(r.gst_rate)}%</td>
                <Num v={r.taxable} /><Num v={r.cgst} /><Num v={r.sgst} /><Num v={r.igst} />
                <Num v={r.total_tax} bold />
                <td style={{ padding: '7px 10px', fontSize: '0.8rem', textAlign: 'right', color: 'var(--text-3)' }}>
                  {r.invoices}
                </td>
              </tr>
            ))}
            <tr style={{ borderTop: '2px solid var(--line)', background: 'var(--paper)' }}>
              <td style={{ padding: '7px 10px', fontSize: '0.75rem' }} className="font-heading font-bold">TOTAL</td>
              <Num v={sum(rows, 'taxable')} bold /><Num v={sum(rows, 'cgst')} bold />
              <Num v={sum(rows, 'sgst')} bold /><Num v={sum(rows, 'igst')} bold />
              <Num v={sum(rows, 'total_tax')} bold />
              <td />
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Num({ v, bold }: { v: string | number; bold?: boolean }) {
  return (
    <td style={{
      padding: '7px 10px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums',
      textAlign: 'right', fontWeight: bold ? 700 : 400,
    }}>
      {formatINRExact(v)}
    </td>
  );
}
