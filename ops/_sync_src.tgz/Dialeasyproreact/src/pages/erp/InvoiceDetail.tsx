// ============================================================
// ERP — Invoice detail: line items, payments, lifecycle
//
// An invoice is a legal record once issued: line items, customer and totals
// all become read-only (enforced server-side too — see apps/erp/views.py).
// The only actions left on an issued invoice are recording a payment or
// cancelling it, and cancelling keeps the number so the GST sequence has no
// hole in it.
//
// Drafts are fully editable here, which they weren't before: the add/edit/
// delete line endpoints existed and nothing on this screen called them, so a
// draft raised from an order could never be corrected.
// ============================================================
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { erpApi, type ErpLineItemInput } from '../../api';
import { ConfirmDialog, Input, Modal, Select, Spinner, Textarea, useToast } from '../../components/ui';
import {
  DocumentBlock, DocumentLetterhead, DocumentPaper, DocumentTotal, DocumentWords,
  useCompany, useDocumentPrint,
} from '../../components/DocumentShell';
import { StatusPill } from '../../components/DataTable';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINRExact, localISODate } from '../../utils/fmt';
import type { ErpInvoice, ErpLineItem } from '../../types';
import type { ErpPayment } from '../../api';
import { GST_RATES, docNumber, formatSignedINR, normalizeRate, todayISO } from './erpShared';

const PAYMENT_MODES = [
  { value: 'cash', label: 'Cash' },
  { value: 'bank_transfer', label: 'Bank Transfer' },
  { value: 'upi', label: 'UPI' },
  { value: 'cheque', label: 'Cheque' },
  { value: 'card', label: 'Card' },
  { value: 'other', label: 'Other' },
];

export default function InvoiceDetail({ invoiceId, onClose }: { invoiceId: number; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canManage = can(Cap.ERP_MANAGE);
  const canIssue = can(Cap.ERP_INVOICE_ISSUE);
  const canCancel = can(Cap.ERP_INVOICE_CANCEL);
  const canPay = can(Cap.ERP_PAYMENTS);

  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [cancelReason, setCancelReason] = useState<string | null>(null);
  const [editingItem, setEditingItem] = useState<ErpLineItem | 'new' | null>(null);
  const [confirmIssue, setConfirmIssue] = useState(false);
  const [editingDetails, setEditingDetails] = useState(false);
  const [removingPayment, setRemovingPayment] = useState<ErpPayment | null>(null);

  const { data: inv, isLoading } = useQuery({
    queryKey: ['erp-invoice', invoiceId],
    queryFn: () => erpApi.invoice(invoiceId).then(r => r.data),
  });

  const { data: payments } = useQuery({
    queryKey: ['erp-invoice-payments', invoiceId],
    queryFn: () => erpApi.payments({ invoice: invoiceId }).then(r => r.data),
  });

  const { data: company } = useCompany();
  const { ref: paperRef, print } = useDocumentPrint(docNumber(inv?.number, 'Draft invoice'));

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['erp-invoice', invoiceId] });
    qc.invalidateQueries({ queryKey: ['erp-invoices'] });
    qc.invalidateQueries({ queryKey: ['erp-invoice-payments', invoiceId] });
    qc.invalidateQueries({ queryKey: ['erp-payments'] });
    qc.invalidateQueries({ queryKey: ['erp-dashboard'] });
    qc.invalidateQueries({ queryKey: ['erp-orders'] });
    qc.invalidateQueries({ queryKey: ['erp-products'] });
  };

  const issue = useMutation({
    mutationFn: () => erpApi.issueInvoice(invoiceId),
    onSuccess: () => {
      showToast('success', 'Issued', 'This invoice now has its GST number and is a legal record.');
      invalidate(); setConfirmIssue(false);
    },
    onError: e => { showToast('error', 'Could not issue', getErrorMessage(e)); setConfirmIssue(false); },
  });

  const cancel = useMutation({
    mutationFn: (reason: string) => erpApi.cancelInvoice(invoiceId, reason),
    onSuccess: () => { showToast('success', 'Cancelled', 'The number stays reserved.'); invalidate(); setCancelReason(null); },
    onError: e => showToast('error', 'Could not cancel', getErrorMessage(e)),
  });

  const removePayment = useMutation({
    mutationFn: (paymentId: number) => erpApi.deletePayment(paymentId),
    onSuccess: () => {
      showToast('success', 'Payment removed', 'The balance due was restored.');
      invalidate(); setRemovingPayment(null);
    },
    onError: e => { showToast('error', 'Could not remove the payment', getErrorMessage(e)); setRemovingPayment(null); },
  });

  const removeItem = useMutation({
    mutationFn: (itemId: number) => erpApi.deleteInvoiceItem(invoiceId, itemId),
    onSuccess: () => { showToast('success', 'Removed', 'Totals recalculated.'); invalidate(); },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  if (isLoading || !inv) {
    return <Modal title="Invoice" onClose={onClose} maxWidth="760px"><Spinner /></Modal>;
  }

  const amountDue = Number(inv.amount_due ?? 0);
  const isDraft = inv.status === 'draft';
  const editable = isDraft && canManage;

  // A draft has no legal standing yet, so it must not present itself as a
  // tax invoice — issuing is what turns it into one.
  const docLabel = isDraft ? 'Draft Invoice'
    : inv.status === 'cancelled' ? 'Tax Invoice (Cancelled)'
    : 'Tax Invoice';

  const meta: Array<[string, string]> = [['Date', fmtDate(inv.invoice_date)]];
  if (inv.due_date) meta.push(['Due', fmtDate(inv.due_date)]);
  if (inv.sales_order) meta.push(['Order ref', `#${inv.sales_order}`]);

  return (
    <Modal title={docNumber(inv.number, 'Draft invoice')} subtitle={inv.customer_name}
           onClose={onClose} maxWidth="880px">
      {/* Controls live above the paper, never on it. */}
      <div className="flex items-center justify-between flex-wrap gap-2 mb-4">
        <StatusPill value={inv.status} />
        <div className="flex gap-2 flex-wrap">
          {isDraft && canIssue && (
            <button className="btn btn-p"
                    disabled={issue.isPending || !inv.items.length} onClick={() => setConfirmIssue(true)}
                    title={!inv.items.length ? 'Add at least one line item first' : undefined}>
              Issue invoice
            </button>
          )}
          {(inv.status === 'issued' || inv.status === 'partially_paid') && canPay && (
            <button className="btn btn-p" onClick={() => setShowPaymentForm(true)}>
              Record payment
            </button>
          )}
          {(inv.status === 'issued' || inv.status === 'partially_paid') && canCancel && (
            <button className="btn btn-g" onClick={() => setCancelReason('')}>
              Cancel invoice
            </button>
          )}
          {editable && (
            <button className="btn btn-g" onClick={() => setEditingItem('new')}>
              Add line
            </button>
          )}
          {editable && !editingDetails && (
            <button className="btn btn-g" onClick={() => setEditingDetails(true)}>
              Edit dates / notes
            </button>
          )}
          <button className="btn btn-g" onClick={print}>Print / Save as PDF</button>
        </div>
      </div>

      {editingDetails && (
        <InvoiceDetailsForm invoice={inv}
          onDone={() => { invalidate(); setEditingDetails(false); }}
          onCancel={() => setEditingDetails(false)} />
      )}

      {showPaymentForm && (
        <PaymentForm invoiceId={invoiceId} maxAmount={amountDue}
                     onDone={() => { invalidate(); setShowPaymentForm(false); }}
                     onCancel={() => setShowPaymentForm(false)} />
      )}

      <DocumentPaper innerRef={paperRef}>
        <DocumentLetterhead company={company} docLabel={docLabel}
                            docNumber={docNumber(inv.number, 'Not yet issued')} meta={meta} />

        <div style={{ display: 'grid', gap: 24, gridTemplateColumns: '1fr 1fr', marginBottom: 20 }}>
          <DocumentBlock title="Bill to">
            <div className="doc-party-name">{inv.customer_name}</div>
            {inv.billing_address_snapshot && (
              <div className="doc-party-line" style={{ whiteSpace: 'pre-line' }}>
                {inv.billing_address_snapshot}
              </div>
            )}
            {inv.buyer_gstin && <div className="doc-gstin">GSTIN&nbsp;&nbsp;{inv.buyer_gstin}</div>}
          </DocumentBlock>

          <DocumentBlock title="Place of supply">
            <div className="doc-party-line">
              {inv.buyer_state || '—'}
              {inv.is_interstate ? ' · Inter-state (IGST)' : ' · Intra-state (CGST + SGST)'}
            </div>
            {inv.seller_state && (
              <div className="doc-party-line">Supplied from {inv.seller_state}</div>
            )}
            {inv.seller_gstin && <div className="doc-gstin">GSTIN&nbsp;&nbsp;{inv.seller_gstin}</div>}
          </DocumentBlock>
        </div>

        {/* ---- Line items ---- */}
        <div style={{ overflowX: 'auto' }}>
          <table className="doc-table" style={{ minWidth: 620 }}>
            <thead>
              <tr>
                <th style={{ width: 26 }}>#</th>
                <th>Description</th>
                <th>HSN/SAC</th>
                <th className="n">Qty</th>
                <th className="n">Rate</th>
                <th className="n">Disc</th>
                <th className="n">GST</th>
                <th className="n">Amount</th>
                {editable && <th className="doc-noprint" />}
              </tr>
            </thead>
            <tbody>
              {!inv.items.length && (
                <tr>
                  <td colSpan={editable ? 9 : 8}
                      style={{ padding: '18px 10px', color: 'var(--text-3)', textAlign: 'center' }}>
                    No line items yet.{editable && ' Add one above before issuing.'}
                  </td>
                </tr>
              )}
              {inv.items.map((item, i) => (
                <tr key={item.id}>
                  <td className="n" style={{ textAlign: 'left' }}>{i + 1}</td>
                  <td>
                    <div className="doc-item-desc">{item.description}</div>
                    {item.product_name && item.product_name !== item.description && (
                      <div className="doc-item-sub">{item.product_name}</div>
                    )}
                  </td>
                  <td className="n" style={{ textAlign: 'left' }}>{item.hsn_sac || '—'}</td>
                  <td className="n">{item.quantity}</td>
                  <td className="n">{formatINRExact(item.unit_price)}</td>
                  <td className="n">{Number(item.discount_percent) ? `${item.discount_percent}%` : '—'}</td>
                  <td className="n">{normalizeRate(item.gst_rate)}%</td>
                  <td className="n" style={{ fontWeight: 600 }}>{formatINRExact(item.line_total)}</td>
                  {editable && (
                    <td className="doc-noprint" style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                      <button onClick={() => setEditingItem(item)}
                              style={{ background: 'none', border: 'none', cursor: 'pointer',
                                       textDecoration: 'underline', fontSize: '0.75rem' }}>Edit</button>
                      <button onClick={() => removeItem.mutate(item.id)} disabled={removeItem.isPending}
                              style={{ background: 'none', border: 'none', cursor: 'pointer',
                                       color: 'var(--hot)', fontSize: '0.75rem', marginLeft: 8 }}>Remove</button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* ---- Totals ---- */}
        <div className="doc-totals">
          <DocumentTotal label="Taxable value" value={formatINRExact(inv.subtotal)} />
          {inv.is_interstate ? (
            <DocumentTotal label="IGST" value={formatINRExact(inv.igst_amount)} />
          ) : (
            <>
              <DocumentTotal label="CGST" value={formatINRExact(inv.cgst_amount)} />
              <DocumentTotal label="SGST" value={formatINRExact(inv.sgst_amount)} />
            </>
          )}
          {Number(inv.round_off) !== 0 && (
            <DocumentTotal label="Round off" value={formatSignedINR(inv.round_off)} />
          )}
          <DocumentTotal label="Total" value={formatINRExact(inv.total_amount)} variant="grand" />
          {Number(inv.amount_paid) > 0 && (
            <DocumentTotal label="Received" value={formatINRExact(inv.amount_paid)} />
          )}
          {amountDue > 0 && (
            <DocumentTotal label="Balance due" value={formatINRExact(inv.amount_due)} variant="due" />
          )}
        </div>

        <DocumentWords amount={inv.total_amount} />

        {/* ---- Payments ---- */}
        {!!payments?.results?.length && (
          <div style={{ marginTop: 20 }}>
            <table className="doc-table">
              <thead>
                <tr>
                  <th>Payments received</th>
                  <th>Mode</th>
                  <th>Reference</th>
                  <th className="n">Amount</th>
                  {canPay && inv.status !== 'cancelled' && <th className="doc-noprint" />}
                </tr>
              </thead>
              <tbody>
                {payments.results.map(p => (
                  <tr key={p.id}>
                    <td>{fmtDate(p.paid_on)}</td>
                    <td>{PAYMENT_MODES.find(m => m.value === p.mode)?.label ?? p.mode}</td>
                    <td style={{ color: 'var(--text-3)' }}>{p.reference || '—'}</td>
                    <td className="n" style={{ fontWeight: 600 }}>{formatINRExact(p.amount)}</td>
                    {canPay && inv.status !== 'cancelled' && (
                      <td className="doc-noprint" style={{ textAlign: 'right' }}>
                        <button onClick={() => setRemovingPayment(p)}
                                style={{ background: 'none', border: 'none', cursor: 'pointer',
                                         color: 'var(--hot)', fontSize: '0.75rem' }}>Remove</button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {inv.notes && (
          <div style={{ marginTop: 18 }}>
            <DocumentBlock title="Notes">
              <div className="doc-party-line" style={{ whiteSpace: 'pre-line' }}>{inv.notes}</div>
            </DocumentBlock>
          </div>
        )}

        {inv.cancellation_reason && (
          <div className="doc-words" style={{ borderColor: 'var(--lost)', color: 'var(--lost)', marginTop: 14 }}>
            <b>Cancelled:</b> {inv.cancellation_reason}
          </div>
        )}

        <div className="doc-foot">
          <div style={{ maxWidth: 400 }}>
            {isDraft
              ? 'Draft — not a tax invoice until issued. Numbers may still change.'
              : 'Certified that the particulars given above are true and correct.'}
            <div style={{ marginTop: 4 }}>
              Goods or services once supplied are governed by the terms agreed with the customer.
            </div>
          </div>
          <div className="doc-sign">
            For {company?.company_name || 'the company'}
            <div className="doc-sign-rule">Authorised signatory</div>
          </div>
        </div>
      </DocumentPaper>

      {editingItem && (
        <LineItemModal invoiceId={invoiceId}
                       item={editingItem === 'new' ? null : editingItem}
                       onDone={() => { invalidate(); setEditingItem(null); }}
                       onClose={() => setEditingItem(null)} />
      )}

      {confirmIssue && (
        <ConfirmDialog
          title="Issue this invoice?"
          message={`${inv.customer_name} · ${formatINRExact(inv.total_amount)}. Issuing gives it the next GST invoice number and locks it: after that it can only be cancelled, never edited or deleted. Stock is reduced for stock-tracked items.`}
          confirmLabel={issue.isPending ? 'Issuing…' : 'Issue invoice'}
          onConfirm={() => { if (!issue.isPending) issue.mutate(); }}
          onCancel={() => setConfirmIssue(false)}
        />
      )}

      {removingPayment && (
        <ConfirmDialog
          title="Remove this payment?"
          message={`${formatINRExact(removingPayment.amount)} received on ${fmtDate(removingPayment.paid_on)}. Use this for a payment recorded by mistake — the invoice's balance due goes back up by the same amount.`}
          confirmLabel={removePayment.isPending ? 'Removing…' : 'Remove payment'}
          danger
          onConfirm={() => { if (!removePayment.isPending) removePayment.mutate(removingPayment.id); }}
          onCancel={() => setRemovingPayment(null)}
        />
      )}

      {cancelReason !== null && (
        <Modal title="Cancel this invoice?" onClose={() => setCancelReason(null)} maxWidth="440px">
          <div className="flex flex-col gap-3">
            <p className="font-medium" style={{ fontSize: '0.82rem', lineHeight: 1.6 }}>
              A GST invoice is never deleted, only cancelled. {inv.number} stays reserved in the
              sequence and the reason below is recorded against it. Stock taken out by this
              invoice is put back.
            </p>
            {Number(inv.amount_paid) > 0 && (
              <p style={{ fontSize: '0.78rem', color: 'var(--hot)' }}>
                This invoice has payments recorded against it. Remove them first (Payments received →
                Remove), then cancel.
              </p>
            )}
            <Textarea label="Reason" required rows={3} value={cancelReason}
                      onChange={e => setCancelReason(e.target.value)}
                      placeholder="Duplicate of INV-2026-0042 / customer cancelled the order" />
            <div className="flex gap-3">
              <button className="btn btn-g flex-1" onClick={() => setCancelReason(null)}>
                Keep invoice
              </button>
              <button className="btn-brutal flex-1 py-2 font-heading font-black"
                      style={{ fontSize: '0.82rem', background: 'var(--hot)', color: 'var(--surface)',
                               border: '1px solid var(--line)' }}
                      disabled={!cancelReason.trim() || cancel.isPending}
                      onClick={() => cancel.mutate(cancelReason)}>
                {cancel.isPending ? 'Cancelling…' : 'Cancel invoice'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </Modal>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex justify-between"
         style={{ padding: '2px 0', fontWeight: bold ? 700 : 400, fontSize: bold ? '0.92rem' : '0.82rem' }}>
      <span>{label}</span>
      <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{value}</span>
    </div>
  );
}

/* ---- Add / edit a draft line -------------------------------
   Picking a product pre-fills description, HSN, price and GST rate from the
   product master, but every field stays editable — a one-off discount or a
   custom description on a line is normal, and forcing a new product record
   for it is how product masters fill with junk. */
function LineItemModal({ invoiceId, item, onDone, onClose }: {
  invoiceId: number; item: ErpLineItem | null; onDone: () => void; onClose: () => void;
}) {
  const { showToast } = useToast();
  const isEdit = !!item;

  const { data: productsPage } = useQuery({
    queryKey: ['erp-products-picker'],
    queryFn: () => erpApi.products({ page_size: 500 }).then(r => r.data),
  });
  // Inactive products can't go on new lines, but a line that already uses one
  // must still show it.
  const products = (productsPage?.results ?? []).filter(p => p.is_active || p.id === item?.product);

  const [form, setForm] = useState<ErpLineItemInput>({
    product: item?.product ?? null,
    description: item?.description ?? '',
    hsn_sac: item?.hsn_sac ?? '',
    quantity: item?.quantity ?? '1',
    unit_price: item?.unit_price ?? '',
    discount_percent: item?.discount_percent ?? '0',
    gst_rate: normalizeRate(item?.gst_rate),
  });

  const pickProduct = (id: string) => {
    const p = products.find(x => String(x.id) === id);
    setForm(f => ({
      ...f,
      product: p ? p.id : null,
      description: p ? p.name : f.description,
      hsn_sac: p ? p.hsn_sac : f.hsn_sac,
      unit_price: p ? String(p.unit_price) : f.unit_price,
      gst_rate: p ? normalizeRate(p.gst_rate) : f.gst_rate,
    }));
  };

  const save = useMutation({
    mutationFn: () => isEdit
      ? erpApi.updateInvoiceItem(invoiceId, item!.id, form)
      : erpApi.addInvoiceItem(invoiceId, form),
    onSuccess: () => { showToast('success', isEdit ? 'Line updated' : 'Line added', 'Totals recalculated.'); onDone(); },
    onError: e => showToast('error', 'Could not save the line', getErrorMessage(e)),
  });

  const qty = Number(form.quantity || 0);
  const price = Number(form.unit_price || 0);
  const disc = Number(form.discount_percent || 0);
  const taxable = qty * price * (1 - disc / 100);
  const preview = taxable * (1 + Number(form.gst_rate || 0) / 100);

  const valid = form.description.trim() && qty > 0 && form.unit_price !== '' && price >= 0;

  return (
    <Modal title={isEdit ? 'Edit line item' : 'Add line item'} onClose={onClose} maxWidth="500px">
      <div className="flex flex-col gap-3">
        <Select label="Product" value={form.product ?? ''} onChange={e => pickProduct(e.target.value)}>
          <option value="">— Custom line (no product) —</option>
          {products.map(p => (
            <option key={p.id} value={p.id}>{p.sku} · {p.name}</option>
          ))}
        </Select>

        <Input label="Description" required value={form.description}
               onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="HSN / SAC" value={form.hsn_sac}
                 onChange={e => setForm(f => ({ ...f, hsn_sac: e.target.value }))} />
          <Select label="GST rate" value={form.gst_rate}
                  onChange={e => setForm(f => ({ ...f, gst_rate: e.target.value }))}>
            {GST_RATES.map(r => <option key={r} value={r}>{r}%</option>)}
          </Select>
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr 1fr' }}>
          <Input label="Quantity" type="number" step="0.01" min="0.01" required value={form.quantity}
                 onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} />
          <Input label="Unit price ₹" type="number" step="0.01" min="0" required value={form.unit_price}
                 onChange={e => setForm(f => ({ ...f, unit_price: e.target.value }))} />
          <Input label="Discount %" type="number" step="0.01" min="0" max="100" value={form.discount_percent}
                 onChange={e => setForm(f => ({ ...f, discount_percent: e.target.value }))} />
        </div>

        {/* Indicative only. The server recomputes tax from the buyer's state,
            so a CGST/SGST vs IGST split is never guessed here. */}
        <div className="card-brutal" style={{ padding: '10px 12px', background: 'var(--paper)' }}>
          <Row label="Taxable value" value={formatINRExact(taxable)} />
          <Row label="Line total (incl. GST)" value={formatINRExact(preview)} bold />
          <p style={{ fontSize: '0.7rem', color: 'var(--text-3)', marginTop: 4 }}>
            Indicative — the server recomputes GST from the buyer's state.
          </p>
        </div>

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                style={{ fontSize: '0.85rem' }}
                disabled={!valid || save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : isEdit ? 'Save line' : 'Add line'}
        </button>
      </div>
    </Modal>
  );
}

function PaymentForm({ invoiceId, maxAmount, onDone, onCancel }: {
  invoiceId: number; maxAmount: number; onDone: () => void; onCancel: () => void;
}) {
  const { showToast } = useToast();
  const [amount, setAmount] = useState(maxAmount > 0 ? maxAmount.toFixed(2) : '');
  const [paidOn, setPaidOn] = useState(localISODate());
  const [mode, setMode] = useState('bank_transfer');
  const [reference, setReference] = useState('');
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    const amt = Number(amount);
    if (!amt || amt <= 0) {
      showToast('error', 'Invalid amount', 'Enter an amount greater than zero.');
      return;
    }
    setSaving(true);
    try {
      await erpApi.addPayment(invoiceId, { amount, paid_on: paidOn, mode, reference });
      showToast('success', 'Payment recorded', formatINRExact(amount));
      onDone();
    } catch (e) {
      showToast('error', 'Failed', getErrorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  const over = Number(amount) > maxAmount;
  const future = !!paidOn && paidOn > todayISO();

  return (
    <div className="card-brutal" style={{ padding: '14px', marginBottom: '14px', background: 'var(--brass-50)' }}>
      <div className="grid gap-2 mb-2" style={{ gridTemplateColumns: '1fr 1fr' }}>
        <Input label="Amount (₹)" type="number" min="0.01" step="0.01" value={amount}
               onChange={e => setAmount(e.target.value)} />
        <Input label="Date" type="date" value={paidOn} max={todayISO()}
               error={future ? "Can't be in the future" : undefined}
               onChange={e => setPaidOn(e.target.value)} />
      </div>
      {over && (
        <p style={{ fontSize: '0.72rem', color: 'var(--hot)', marginBottom: 8 }}>
          That's more than the {formatINRExact(maxAmount)} outstanding — the server will refuse it.
        </p>
      )}
      <div className="grid gap-2 mb-3" style={{ gridTemplateColumns: '1fr 2fr' }}>
        <Select label="Mode" value={mode} onChange={e => setMode(e.target.value)}>
          {PAYMENT_MODES.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
        </Select>
        <Input label="Reference (optional)" value={reference} onChange={e => setReference(e.target.value)}
               placeholder="UTR / cheque no." />
      </div>
      <div className="flex gap-2">
        <button className="btn-brutal btn-primary px-3 py-1.5 font-heading font-bold" style={{ fontSize: '0.78rem' }}
                disabled={saving || over || future} onClick={submit}>
          {saving ? 'Saving…' : 'Record payment'}
        </button>
        <button className="btn-brutal btn-secondary px-3 py-1.5 font-heading font-bold" style={{ fontSize: '0.78rem' }}
                onClick={onCancel}>
          Cancel
        </button>
      </div>
    </div>
  );
}

/* ---- Draft header: dates and notes ---------------------------
   updateInvoice existed but no screen called it, so a draft raised from an
   order could never get a due date — and overdue/ageing never worked. */
function InvoiceDetailsForm({ invoice, onDone, onCancel }: {
  invoice: ErpInvoice; onDone: () => void; onCancel: () => void;
}) {
  const { showToast } = useToast();
  const [invoiceDate, setInvoiceDate] = useState(invoice.invoice_date);
  const [dueDate, setDueDate] = useState(invoice.due_date ?? '');
  const [notes, setNotes] = useState(invoice.notes ?? '');
  const bad = !!dueDate && !!invoiceDate && dueDate < invoiceDate;

  const save = useMutation({
    mutationFn: () => erpApi.updateInvoice(invoice.id, {
      invoice_date: invoiceDate, due_date: dueDate || null, notes,
    }),
    onSuccess: () => { showToast('success', 'Saved', 'Invoice details updated.'); onDone(); },
    onError: e => showToast('error', 'Could not save', getErrorMessage(e)),
  });

  return (
    <div className="card-brutal" style={{ padding: '14px', marginBottom: '14px', background: 'var(--brass-50)' }}>
      <div className="grid gap-2 mb-2" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))' }}>
        <Input label="Invoice date" type="date" value={invoiceDate} onChange={e => setInvoiceDate(e.target.value)} />
        <Input label="Due date" type="date" value={dueDate} min={invoiceDate || undefined}
               error={bad ? "Can't be before the invoice date" : undefined}
               onChange={e => setDueDate(e.target.value)} />
      </div>
      <Textarea label="Notes" rows={2} value={notes} onChange={e => setNotes(e.target.value)} />
      <div className="flex gap-2 mt-2">
        <button className="btn btn-p" disabled={bad || !invoiceDate || save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : 'Save'}
        </button>
        <button className="btn btn-g" onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}
