// ============================================================
// Sales & Billing — Invoices
//
// Adds the standalone-invoice path: before this, an invoice could only be
// born from a sales order, so an over-the-counter sale had to be faked by
// raising a throwaway quotation and converting it twice — leaving two bogus
// documents in the numbering sequence.
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { erpApi } from '../../api';
import { AddButton, Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { ConfirmDialog, Input, Modal, Select, Textarea, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINRExact, localISODate } from '../../utils/fmt';
import InvoiceDetail from './InvoiceDetail';
import { docNumber } from './erpShared';
import type { ErpInvoice } from '../../types';

export default function InvoicesTab() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canManage = can(Cap.ERP_MANAGE);
  const canIssue = can(Cap.ERP_INVOICE_ISSUE);

  const [status, setStatus] = useState('');
  const [customer, setCustomer] = useState('');
  const [search, setSearch] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [openId, setOpenId] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState<ErpInvoice | null>(null);
  const [issuing, setIssuing] = useState<ErpInvoice | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['erp-invoices', status, customer, dateFrom, dateTo],
    queryFn: () => erpApi.invoices({
      status: status || undefined,
      customer: customer || undefined,
      date_from: dateFrom || undefined,
      date_to: dateTo || undefined,
      page_size: 200,
    }).then(r => r.data),
  });

  const { data: customers } = useQuery({
    queryKey: ['erp-customers-picker'],
    queryFn: () => erpApi.customers({ page_size: 500 }).then(r => r.data),
  });

  const issue = useMutation({
    mutationFn: (id: number) => erpApi.issueInvoice(id),
    onSuccess: () => {
      showToast('success', 'Issued', 'The invoice now carries a GST number.');
      qc.invalidateQueries({ queryKey: ['erp-invoices'] });
      qc.invalidateQueries({ queryKey: ['erp-dashboard'] });
      qc.invalidateQueries({ queryKey: ['erp-products'] });
      setIssuing(null);
    },
    onError: e => { showToast('error', 'Could not issue', getErrorMessage(e)); setIssuing(null); },
  });

  const remove = useMutation({
    mutationFn: (id: number) => erpApi.deleteInvoice(id),
    onSuccess: () => {
      showToast('success', 'Deleted', 'The draft invoice was removed.');
      qc.invalidateQueries({ queryKey: ['erp-invoices'] });
      qc.invalidateQueries({ queryKey: ['erp-orders'] });
      setDeleting(null);
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const rows = useMemo(() => {
    const all = data?.results ?? [];
    const q = search.trim().toLowerCase();
    return q ? all.filter(i => i.number?.toLowerCase().includes(q)
                            || i.customer_name?.toLowerCase().includes(q)) : all;
  }, [data, search]);

  const totals = rows.reduce(
    (acc, i) => ({
      total: acc.total + Number(i.total_amount || 0),
      due: acc.due + (i.status === 'cancelled' || i.status === 'draft' ? 0 : Number(i.amount_due || 0)),
    }),
    { total: 0, due: 0 },
  );

  const columns: Column<ErpInvoice>[] = [
    { key: 'number', header: 'Number', sortable: true,
      render: i => <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', fontWeight: 700, color: i.status === 'draft' ? 'var(--text-3)' : undefined }}>{docNumber(i.number)}</span> },
    { key: 'invoice_date', header: 'Date', sortable: true, render: i => fmtDate(i.invoice_date) },
    { key: 'due_date', header: 'Due', sortable: true,
      render: i => {
        if (!i.due_date) return '—';
        const overdue = i.status !== 'cancelled' && i.status !== 'draft'
          && Number(i.amount_due) > 0 && new Date(i.due_date) < new Date();
        return <span style={{ color: overdue ? 'var(--hot)' : undefined, fontWeight: overdue ? 700 : 400 }}>
          {fmtDate(i.due_date)}
        </span>;
      } },
    { key: 'customer_name', header: 'Customer', sortable: true,
      render: i => (
        <>
          {i.customer_name}
          {i.is_interstate && (
            <span className="font-mono" style={{ fontSize: '0.65rem', color: 'var(--text-3)', marginLeft: 6 }}>IGST</span>
          )}
        </>
      ) },
    { key: 'subtotal', header: 'Taxable', numeric: true, render: i => formatINRExact(i.subtotal) },
    { key: 'total_tax', header: 'GST', numeric: true, render: i => formatINRExact(i.total_tax) },
    { key: 'total_amount', header: 'Total', numeric: true, sortable: true,
      sortValue: i => Number(i.total_amount), render: i => <b>{formatINRExact(i.total_amount)}</b> },
    { key: 'amount_due', header: 'Due', numeric: true, sortable: true,
      sortValue: i => Number(i.amount_due),
      render: i => i.status === 'cancelled'
        ? <span style={{ color: 'var(--text-3)' }}>—</span>
        : <span style={{ color: Number(i.amount_due) > 0 && i.status !== 'draft' ? 'var(--hot)' : 'var(--text-3)' }}>
            {formatINRExact(i.amount_due)}
          </span> },
    { key: 'status', header: 'Status', sortable: true, render: i => <StatusPill value={i.status} /> },
  ];

  return (
    <>
      {canManage && <AddButton label="New invoice" onClick={() => setCreating(true)} />}

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search number or customer…">
        <Select label="Status" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="draft">Draft</option>
          <option value="issued">Issued</option>
          <option value="partially_paid">Partially paid</option>
          <option value="paid">Paid</option>
          <option value="cancelled">Cancelled</option>
        </Select>
        <Select label="Customer" value={customer} onChange={e => setCustomer(e.target.value)}>
          <option value="">All customers</option>
          {(customers?.results ?? []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
        <Input label="From" type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
        <Input label="To" type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} />
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={i => i.id}
        isLoading={isLoading}
        pageSize={25}
        minWidth="960px"
        onRowClick={i => setOpenId(i.id)}
        actions={i => (
          <>
            <RowAction label="Open" onClick={() => setOpenId(i.id)} />
            {canIssue && i.status === 'draft' && (
              <RowAction label="Issue" disabled={issue.isPending || !i.items?.length}
                         onClick={() => setIssuing(i)} />
            )}
            {canManage && i.status === 'draft' && (
              <RowAction label="Delete" danger onClick={() => setDeleting(i)} />
            )}
          </>
        )}
        empty={{
          icon: '▤', title: 'No invoices',
          message: 'Raise one directly, or convert a sales order.',
          action: canManage ? { label: 'New invoice', onClick: () => setCreating(true) } : undefined,
        }}
        footer={rows.length ? (
          <tr style={{ borderTop: '2px solid var(--line)', background: 'var(--paper)' }}>
            <td colSpan={6} style={{ padding: '10px 12px', fontSize: '0.75rem' }} className="font-heading font-bold">
              {rows.length} INVOICE{rows.length === 1 ? '' : 'S'}
            </td>
            <td style={{ padding: '10px 12px', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', textAlign: 'right', fontWeight: 700 }}>
              {formatINRExact(totals.total)}
            </td>
            <td style={{ padding: '10px 12px', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', textAlign: 'right', fontWeight: 700,
                         color: totals.due > 0 ? 'var(--hot)' : undefined }}>
              {formatINRExact(totals.due)}
            </td>
            <td colSpan={2} />
          </tr>
        ) : undefined}
      />

      {openId !== null && <InvoiceDetail invoiceId={openId} onClose={() => setOpenId(null)} />}
      {creating && <NewInvoiceModal onCreated={id => { setCreating(false); setOpenId(id); }}
                                    onClose={() => setCreating(false)} />}

      {issuing && (
        <ConfirmDialog
          title="Issue this invoice?"
          message={`${issuing.customer_name} · ${formatINRExact(issuing.total_amount)}. Issuing gives it the next GST invoice number and locks it — after that it can only be cancelled, not edited or deleted. Stock is reduced for stock-tracked items.`}
          confirmLabel={issue.isPending ? 'Issuing…' : 'Issue invoice'}
          onConfirm={() => { if (!issue.isPending) issue.mutate(issuing.id); }}
          onCancel={() => setIssuing(null)}
        />
      )}

      {deleting && (
        <ConfirmDialog
          title="Delete this draft invoice?"
          message={`${deleting.customer_name} · ${formatINRExact(deleting.total_amount)}. Drafts have no GST number yet, so deleting one leaves no hole in the sequence. Issued invoices can only be cancelled, never deleted.`}
          confirmLabel="Delete draft"
          danger
          onConfirm={() => remove.mutate(deleting.id)}
          onCancel={() => setDeleting(null)}
        />
      )}
    </>
  );
}

/* ---- New standalone invoice ---------------------------------
   Creates the header only; the detail drawer that opens next is where lines
   are added. That mirrors the order-derived path, where the invoice also
   exists before its lines are priced. */
function NewInvoiceModal({ onCreated, onClose }: { onCreated: (id: number) => void; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const today = localISODate();
  const [form, setForm] = useState({ customer: '', invoice_date: today, due_date: '', notes: '' });

  const { data: customers } = useQuery({
    queryKey: ['erp-customers-picker'],
    queryFn: () => erpApi.customers({ page_size: 500 }).then(r => r.data),
  });

  const create = useMutation({
    mutationFn: () => erpApi.createInvoice({
      customer: Number(form.customer),
      invoice_date: form.invoice_date,
      due_date: form.due_date || null,
      notes: form.notes,
    }),
    onSuccess: r => {
      showToast('success', 'Draft created', 'Add line items, then issue it.');
      qc.invalidateQueries({ queryKey: ['erp-invoices'] });
      onCreated(r.data.id);
    },
    onError: e => showToast('error', 'Could not create the invoice', getErrorMessage(e)),
  });

  const activeCustomers = (customers?.results ?? []).filter(c => c.is_active);
  const selected = activeCustomers.find(c => String(c.id) === form.customer);
  const badDue = !!form.due_date && !!form.invoice_date && form.due_date < form.invoice_date;

  return (
    <Modal title="New invoice" subtitle="Raised directly, without a sales order"
           onClose={onClose} maxWidth="480px">
      <div className="flex flex-col gap-3">
        <Select label="Customer" required value={form.customer}
                onChange={e => setForm(f => ({ ...f, customer: e.target.value }))}>
          <option value="">Select a customer…</option>
          {activeCustomers.map(c => (
            <option key={c.id} value={c.id}>{c.name}{c.gstin ? ` · ${c.gstin}` : ''}</option>
          ))}
        </Select>

        {selected && !selected.state_code && (
          <p style={{ fontSize: '0.72rem', color: 'var(--hot)' }}>
            This customer has no state code, so GST can't tell interstate from intrastate.
            Set it on the customer first or the tax split will be wrong.
          </p>
        )}

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Invoice date" type="date" value={form.invoice_date}
                 onChange={e => setForm(f => ({ ...f, invoice_date: e.target.value }))} />
          <Input label="Due date" type="date" value={form.due_date} min={form.invoice_date || undefined}
                 error={badDue ? "Can't be before the invoice date" : undefined}
                 onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))} />
        </div>

        <Textarea label="Notes" rows={2} value={form.notes}
                  onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                  placeholder="Payment terms, PO reference…" />

        <p className="font-medium" style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>
          Creates a <b>draft</b>. It gets its GST number only when you issue it,
          so nothing is consumed from the numbering sequence yet.
        </p>

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-1"
                style={{ fontSize: '0.85rem' }}
                disabled={!form.customer || badDue || create.isPending} onClick={() => create.mutate()}>
          {create.isPending ? 'Creating…' : 'Create draft & add items'}
        </button>
      </div>
    </Modal>
  );
}
