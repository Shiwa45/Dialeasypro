// ============================================================
// Sales & Billing — Sales orders
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { erpApi } from '../../api';
import { Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { Input, Modal, Select, Spinner, Textarea, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINRExact } from '../../utils/fmt';
import type { ErpSalesOrder } from '../../types';
import { formatSignedINR, normalizeRate, todayISO } from './erpShared';

export default function OrdersTab() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canManage = can(Cap.ERP_MANAGE);

  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [openId, setOpenId] = useState<number | null>(null);
  const [invoicing, setInvoicing] = useState<ErpSalesOrder | null>(null);
  const [cancelling, setCancelling] = useState<ErpSalesOrder | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['erp-orders', status],
    queryFn: () => erpApi.orders({ status: status || undefined, page_size: 200 }).then(r => r.data),
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['erp-orders'] });
    qc.invalidateQueries({ queryKey: ['erp-order'] });
    qc.invalidateQueries({ queryKey: ['erp-invoices'] });
    qc.invalidateQueries({ queryKey: ['erp-dashboard'] });
  };

  const rows = useMemo(() => {
    const all = data?.results ?? [];
    const q = search.trim().toLowerCase();
    return q ? all.filter(o => o.number?.toLowerCase().includes(q)
                            || o.customer_name?.toLowerCase().includes(q)) : all;
  }, [data, search]);

  const columns: Column<ErpSalesOrder>[] = [
    { key: 'number', header: 'Number', sortable: true,
      render: o => <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>{o.number}</span> },
    { key: 'order_date', header: 'Date', sortable: true, render: o => fmtDate(o.order_date) },
    { key: 'customer_name', header: 'Customer', sortable: true, render: o => o.customer_name },
    { key: 'subtotal', header: 'Taxable', numeric: true, render: o => formatINRExact(o.subtotal) },
    { key: 'total_tax', header: 'GST', numeric: true, render: o => formatINRExact(o.total_tax) },
    { key: 'total_amount', header: 'Total', numeric: true, sortable: true,
      sortValue: o => Number(o.total_amount), render: o => <b>{formatINRExact(o.total_amount)}</b> },
    { key: 'status', header: 'Status', sortable: true, render: o => <StatusPill value={o.status} /> },
  ];

  return (
    <>
      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search number or customer…">
        <Select label="Status" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="open">Open</option>
          <option value="fulfilled">Fulfilled</option>
          <option value="invoiced">Invoiced</option>
          <option value="cancelled">Cancelled</option>
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={o => o.id}
        isLoading={isLoading}
        pageSize={25}
        onRowClick={o => setOpenId(o.id)}
        actions={o => (
          <>
            <RowAction label="Open" onClick={() => setOpenId(o.id)} />
            {canManage && o.status !== 'invoiced' && o.status !== 'cancelled' && (
              <RowAction label="Raise invoice" onClick={() => setInvoicing(o)} />
            )}
            {canManage && o.status !== 'invoiced' && o.status !== 'cancelled' && (
              <RowAction label="Cancel" danger onClick={() => setCancelling(o)} />
            )}
          </>
        )}
        empty={{ icon: '▣', title: 'No sales orders', message: 'Accept a quotation to turn it into an order.' }}
      />

      {openId !== null && <OrderDetail orderId={openId} onClose={() => setOpenId(null)} />}
      {invoicing && (
        <RaiseInvoiceDialog order={invoicing} onClose={() => setInvoicing(null)}
          onDone={() => {
            showToast('success', 'Draft invoice created',
              'Check the lines in the Invoices tab, then issue it to give it a GST number.');
            refresh();
            setInvoicing(null);
          }} />
      )}
      {cancelling && (
        <CancelOrderDialog order={cancelling} onClose={() => setCancelling(null)}
          onDone={() => { showToast('success', 'Order cancelled', cancelling.number); refresh(); setCancelling(null); }} />
      )}
    </>
  );
}

/* ---- Raise invoice: ask for the due date up front ------------
   Without one, overdue tracking and ageing could never work for these
   invoices (there was no way to add it afterwards either). */
function RaiseInvoiceDialog({ order, onClose, onDone }: {
  order: ErpSalesOrder; onClose: () => void; onDone: () => void;
}) {
  const { showToast } = useToast();
  const plus30 = (() => { const d = new Date(); d.setDate(d.getDate() + 30);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; })();
  const [dueDate, setDueDate] = useState(plus30);
  const bad = !!dueDate && dueDate < todayISO();
  const raise = useMutation({
    mutationFn: () => erpApi.invoiceOrder(order.id, { due_date: dueDate || null }),
    onSuccess: onDone,
    onError: e => showToast('error', 'Could not raise the invoice', getErrorMessage(e)),
  });
  return (
    <Modal title="Raise invoice" subtitle={`${order.number} · ${order.customer_name}`} onClose={onClose} maxWidth="420px">
      <div className="flex flex-col gap-3">
        <p style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>
          A draft invoice is created from this order for {formatINRExact(order.total_amount)}.
          It gets its GST invoice number when you issue it.
        </p>
        <Input label="Payment due by" type="date" value={dueDate} min={todayISO()}
               error={bad ? "Can't be in the past" : undefined}
               hint="Leave empty if there are no payment terms."
               onChange={e => setDueDate(e.target.value)} />
        <button className="btn btn-p" disabled={bad || raise.isPending} onClick={() => raise.mutate()}>
          {raise.isPending ? 'Creating…' : 'Create draft invoice'}
        </button>
      </div>
    </Modal>
  );
}

function CancelOrderDialog({ order, onClose, onDone }: {
  order: ErpSalesOrder; onClose: () => void; onDone: () => void;
}) {
  const { showToast } = useToast();
  const [reason, setReason] = useState('');
  const cancel = useMutation({
    mutationFn: () => erpApi.cancelOrder(order.id, reason.trim()),
    onSuccess: onDone,
    onError: e => showToast('error', 'Could not cancel the order', getErrorMessage(e)),
  });
  return (
    <Modal title={`Cancel ${order.number}?`} subtitle={order.customer_name} onClose={onClose} maxWidth="420px">
      <div className="flex flex-col gap-3">
        <p style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>
          The order is kept for the record, marked cancelled, and can no longer be invoiced.
        </p>
        <Textarea label="Reason" value={reason} onChange={e => setReason(e.target.value)}
                  placeholder="Customer withdrew the order" />
        <button className="btn-brutal btn-danger py-2 font-heading font-black"
                disabled={!reason.trim() || cancel.isPending} onClick={() => cancel.mutate()}>
          {cancel.isPending ? 'Cancelling…' : 'Cancel order'}
        </button>
      </div>
    </Modal>
  );
}

/* ---- Order detail -------------------------------------------
   The list showed a total and nothing else; the detail endpoint existed and
   was never called, so there was no way to see what an order actually
   contained before invoicing it. */
function OrderDetail({ orderId, onClose }: { orderId: number; onClose: () => void }) {
  const { data: order, isLoading } = useQuery({
    queryKey: ['erp-order', orderId],
    queryFn: () => erpApi.order(orderId).then(r => r.data),
  });

  if (isLoading || !order) {
    return <Modal title="Sales order" onClose={onClose} maxWidth="720px"><Spinner /></Modal>;
  }

  return (
    <Modal title={order.number} subtitle={order.customer_name} onClose={onClose} maxWidth="820px">
      <div className="flex items-center gap-2 mb-4">
        <StatusPill value={order.status} />
        <span style={{ fontSize: '0.75rem', color: 'var(--text-2)' }}>{fmtDate(order.order_date)}</span>
      </div>

      <div className="card-brutal" style={{ overflowX: 'auto', marginBottom: '14px' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '680px' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--line)' }}>
              {['Item', 'HSN/SAC', 'Qty', 'Price', 'Disc', 'Taxable', 'GST', 'Total'].map(h => (
                <th key={h} className="th bare">
                  {h.toUpperCase()}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {order.items.map(item => (
              <tr key={item.id} style={{ borderBottom: '1px solid var(--line)' }}>
                <td style={{ padding: '8px 10px', fontSize: '0.8rem' }}>{item.description}</td>
                <td style={{ padding: '8px 10px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{item.hsn_sac || '—'}</td>
                <td style={{ padding: '8px 10px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{item.quantity}</td>
                <td style={{ padding: '8px 10px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{formatINRExact(item.unit_price)}</td>
                <td style={{ padding: '8px 10px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{Number(item.discount_percent) ? `${Number(item.discount_percent)}%` : '—'}</td>
                <td style={{ padding: '8px 10px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{formatINRExact(item.taxable_value)}</td>
                <td style={{ padding: '8px 10px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{normalizeRate(item.gst_rate)}%</td>
                <td style={{ padding: '8px 10px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>
                  {formatINRExact(item.line_total)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex justify-end">
        <div style={{ width: '260px', fontSize: '0.82rem' }}>
          <div className="flex justify-between" style={{ padding: '2px 0' }}>
            <span>Taxable value</span><span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{formatINRExact(order.subtotal)}</span>
          </div>
          {(order.is_interstate
            ? [['IGST', order.igst_amount]]
            : [['CGST', order.cgst_amount], ['SGST', order.sgst_amount]]
          ).map(([label, amount]) => (
            <div key={label} className="flex justify-between" style={{ padding: '2px 0' }}>
              <span>{label}</span><span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{formatINRExact(amount)}</span>
            </div>
          ))}
          {Number(order.round_off) !== 0 && (
            <div className="flex justify-between" style={{ padding: '2px 0' }}>
              <span>Round off</span><span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{formatSignedINR(order.round_off)}</span>
            </div>
          )}
          <div className="flex justify-between"
               style={{ padding: '6px 0 0', borderTop: '1px solid var(--line)', marginTop: 4,
                        fontWeight: 700, fontSize: '0.92rem' }}>
            <span>Total</span><span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{formatINRExact(order.total_amount)}</span>
          </div>
        </div>
      </div>

      {order.notes && (
        <p style={{ fontSize: '0.78rem', color: 'var(--text-2)', marginTop: '12px' }}>{order.notes}</p>
      )}
    </Modal>
  );
}
