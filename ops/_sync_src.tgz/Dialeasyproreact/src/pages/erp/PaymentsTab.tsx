// ============================================================
// Sales & Billing — Payments ledger
//
// Payments could be recorded from day one but never read back anywhere: the
// only way to see what a customer had paid was to open each of their invoices
// in turn and add up the differences.
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { erpApi, type ErpPayment } from '../../api';
import { Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { ConfirmDialog, Input, Select, StatCard, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINRExact } from '../../utils/fmt';

const MODES = [
  { value: 'cash', label: 'Cash' },
  { value: 'bank_transfer', label: 'Bank Transfer' },
  { value: 'upi', label: 'UPI' },
  { value: 'cheque', label: 'Cheque' },
  { value: 'card', label: 'Card' },
  { value: 'other', label: 'Other' },
];

export default function PaymentsTab() {
  const [customer, setCustomer] = useState('');
  const [mode, setMode] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [search, setSearch] = useState('');
  const [removing, setRemoving] = useState<ErpPayment | null>(null);
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canPay = can(Cap.ERP_PAYMENTS);

  // A payment recorded by mistake (wrong invoice, wrong amount) had no way
  // back; reversing it reopens the invoice's balance.
  const remove = useMutation({
    mutationFn: (id: number) => erpApi.deletePayment(id),
    onSuccess: () => {
      showToast('success', 'Payment removed', 'The invoice balance was restored.');
      qc.invalidateQueries({ queryKey: ['erp-payments'] });
      qc.invalidateQueries({ queryKey: ['erp-invoices'] });
      qc.invalidateQueries({ queryKey: ['erp-invoice'] });
      qc.invalidateQueries({ queryKey: ['erp-invoice-payments'] });
      qc.invalidateQueries({ queryKey: ['erp-dashboard'] });
      setRemoving(null);
    },
    onError: e => { showToast('error', 'Could not remove the payment', getErrorMessage(e)); setRemoving(null); },
  });

  const { data, isLoading } = useQuery({
    queryKey: ['erp-payments', customer, mode, dateFrom, dateTo],
    queryFn: () => erpApi.payments({
      customer: customer || undefined,
      mode: mode || undefined,
      date_from: dateFrom || undefined,
      date_to: dateTo || undefined,
      page_size: 200,
    }).then(r => r.data),
  });

  const { data: customers } = useQuery({
    queryKey: ['erp-customers-picker'],
    queryFn: () => erpApi.customers({ page_size: 500 }).then(r => r.data),
  });

  const rows = useMemo(() => {
    const all = data?.results ?? [];
    const q = search.trim().toLowerCase();
    return q ? all.filter(p => p.invoice_number?.toLowerCase().includes(q)
                            || p.customer_name?.toLowerCase().includes(q)
                            || p.reference?.toLowerCase().includes(q)) : all;
  }, [data, search]);

  const total = rows.reduce((s, p) => s + Number(p.amount || 0), 0);
  const byMode = useMemo(() => {
    const m: Record<string, number> = {};
    for (const p of rows) m[p.mode] = (m[p.mode] ?? 0) + Number(p.amount || 0);
    return Object.entries(m).sort((a, b) => b[1] - a[1]);
  }, [rows]);

  const columns: Column<ErpPayment>[] = [
    { key: 'paid_on', header: 'Date', sortable: true, render: p => fmtDate(p.paid_on) },
    { key: 'invoice_number', header: 'Invoice', sortable: true,
      render: p => <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>{p.invoice_number ?? '—'}</span> },
    { key: 'customer_name', header: 'Customer', sortable: true, render: p => p.customer_name ?? '—' },
    { key: 'mode', header: 'Mode', sortable: true,
      render: p => <StatusPill value={p.mode} label={MODES.find(m => m.value === p.mode)?.label ?? p.mode} /> },
    { key: 'reference', header: 'Reference',
      render: p => <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', fontSize: '0.75rem', color: 'var(--text-2)' }}>
        {p.reference || '—'}
      </span> },
    { key: 'amount', header: 'Amount', numeric: true, sortable: true,
      sortValue: p => Number(p.amount), render: p => <b>{formatINRExact(p.amount)}</b> },
  ];

  return (
    <>
      <div className="grid gap-3 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))' }}>
        <StatCard label="Total received" value={formatINRExact(total)}
                  sub={`${rows.length} payment${rows.length === 1 ? '' : 's'}`} tone="green" icon="₹" />
        {byMode.slice(0, 3).map(([m, amt]) => (
          <StatCard key={m} label={MODES.find(x => x.value === m)?.label ?? m}
                    value={formatINRExact(amt)}
                    sub={total ? `${Math.round((amt / total) * 100)}% of receipts` : ''} />
        ))}
      </div>

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search invoice, customer, reference…">
        <Select label="Customer" value={customer} onChange={e => setCustomer(e.target.value)}>
          <option value="">All customers</option>
          {(customers?.results ?? []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
        <Select label="Mode" value={mode} onChange={e => setMode(e.target.value)}>
          <option value="">All modes</option>
          {MODES.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
        </Select>
        <Input label="From" type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
        <Input label="To" type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} />
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={p => p.id}
        isLoading={isLoading}
        pageSize={25}
        actions={canPay ? (p => <RowAction label="Remove" danger onClick={() => setRemoving(p)} />) : undefined}
        empty={{
          icon: '₹', title: 'No payments recorded',
          message: 'Payments are recorded against an invoice — open one from the Invoices tab.',
        }}
        footer={rows.length ? (
          <tr style={{ borderTop: '2px solid var(--line)', background: 'var(--paper)' }}>
            <td colSpan={5} style={{ padding: '10px 12px', fontSize: '0.75rem' }} className="font-heading font-bold">
              TOTAL RECEIVED
            </td>
            <td style={{ padding: '10px 12px', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', textAlign: 'right', fontWeight: 700 }}>
              {formatINRExact(total)}
            </td>
            {canPay && <td />}
          </tr>
        ) : undefined}
      />

      {removing && (
        <ConfirmDialog
          title="Remove this payment?"
          message={`${formatINRExact(removing.amount)} on ${fmtDate(removing.paid_on)} against ${removing.invoice_number ?? 'the invoice'}. Use this only for a payment recorded by mistake — the invoice's balance due goes back up.`}
          confirmLabel={remove.isPending ? 'Removing…' : 'Remove payment'}
          danger
          onConfirm={() => { if (!remove.isPending) remove.mutate(removing.id); }}
          onCancel={() => setRemoving(null)}
        />
      )}
    </>
  );
}
