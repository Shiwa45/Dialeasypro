// ============================================================
// ERP — Add/Edit Product
// ============================================================
import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { erpApi } from '../../api';
import { Modal, Input, Textarea, useToast } from '../../components/ui';
import type { ErpProduct } from '../../types';
import { getErrorMessage } from '../../utils/errors';
import { GST_RATES, UNITS, normalizeRate } from './erpShared';

export default function ProductModal({ product, onClose }: { product?: ErpProduct; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const isEdit = !!product;

  const [form, setForm] = useState({
    name: product?.name ?? '',
    sku: product?.sku ?? '',
    description: product?.description ?? '',
    hsn_sac: product?.hsn_sac ?? '',
    is_service: product?.is_service ?? false,
    unit: product?.unit || 'nos',
    unit_price: product?.unit_price ?? '',
    gst_rate: normalizeRate(product?.gst_rate),
    track_stock: product?.track_stock ?? false,
    stock_quantity: product?.stock_quantity ?? '0',
    is_active: product?.is_active ?? true,
  });

  const set = (k: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm(f => ({ ...f, [k]: e.target.value }));

  const save = useMutation({
    mutationFn: () => isEdit ? erpApi.updateProduct(product!.id, form) : erpApi.createProduct(form),
    onSuccess: () => {
      showToast('success', isEdit ? 'Product updated' : 'Product added', form.name);
      qc.invalidateQueries({ queryKey: ['erp-products'] });
      qc.invalidateQueries({ queryKey: ['erp-products-picker'] });
      onClose();
    },
    onError: (e: unknown) => {
      showToast('error', 'Could not save the product', getErrorMessage(e, 'Could not save the product.'));
    },
  });

  const hsnOk = /^\d{4}(\d{2}(\d{2})?)?$/.test(form.hsn_sac.trim());
  const canSave = form.name.trim().length > 0 && form.sku.trim().length > 0 &&
                  hsnOk && Number(form.unit_price) > 0;

  return (
    <Modal title={isEdit ? 'Edit product' : 'Add product'} onClose={onClose} maxWidth="520px">
      <div className="flex flex-col gap-3">
        <div className="grid gap-3" style={{ gridTemplateColumns: '2fr 1fr' }}>
          <Input label="Name" required value={form.name} onChange={set('name')} placeholder="Premium CRM License" />
          <Input label="SKU" required value={form.sku} onChange={set('sku')} placeholder="LIC-001" />
        </div>
        <Textarea label="Description (optional)" value={form.description} onChange={set('description')} />

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="HSN / SAC code" required value={form.hsn_sac} onChange={set('hsn_sac')}
                 placeholder="998314" inputMode="numeric" maxLength={8}
                 error={form.hsn_sac.trim() && !hsnOk ? '4, 6 or 8 digits' : undefined} />
          <div>
            <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
              GST rate
            </label>
            <select className="input-brutal" style={{ cursor: 'pointer' }}
                    value={form.gst_rate} onChange={set('gst_rate')}>
              {GST_RATES.map(r => <option key={r} value={r}>{r}%</option>)}
            </select>
          </div>
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Unit price (₹)" required type="number" min="0" step="0.01"
                 value={form.unit_price} onChange={set('unit_price')} placeholder="9999.00" />
          <div>
            <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
              Unit
            </label>
            <select className="input-brutal" style={{ cursor: 'pointer', width: '100%' }}
                    value={form.unit} onChange={set('unit')}>
              {UNITS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </div>
        </div>

        <label className="flex items-center gap-2" style={{ fontSize: '0.82rem', cursor: 'pointer' }}>
          <input type="checkbox" checked={form.is_service}
                 onChange={e => setForm(f => ({ ...f, is_service: e.target.checked }))} />
          This is a service (no physical stock)
        </label>

        {!form.is_service && (
          <label className="flex items-center gap-2" style={{ fontSize: '0.82rem', cursor: 'pointer' }}>
            <input type="checkbox" checked={form.track_stock}
                   onChange={e => setForm(f => ({ ...f, track_stock: e.target.checked }))} />
            Track stock quantity
          </label>
        )}

        {!form.is_service && form.track_stock && (
          <Input label="Stock quantity" type="number" min="0" step="1"
                 value={form.stock_quantity} onChange={set('stock_quantity')} />
        )}

        {isEdit && (
          <label className="flex items-center gap-2" style={{ fontSize: '0.82rem', cursor: 'pointer' }}>
            <input type="checkbox" checked={form.is_active}
                   onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))} />
            Active — inactive products stay on old documents but can't be added to new ones
          </label>
        )}

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-2"
                style={{ fontSize: '0.85rem' }}
                disabled={!canSave || save.isPending}
                onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : isEdit ? 'Save changes' : 'Add product'}
        </button>
      </div>
    </Modal>
  );
}
