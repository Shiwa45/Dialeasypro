// ============================================================
// Sales & Billing — Products & services
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { erpApi } from '../../api';
import { AddButton, Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { ConfirmDialog, Input, Modal, Select, StatCard, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { formatINRExact } from '../../utils/fmt';
import ProductModal from './ProductModal';
import { normalizeRate } from './erpShared';
import type { ErpProduct } from '../../types';

export default function ProductsTab() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canManage = can(Cap.ERP_MANAGE);

  const [search, setSearch] = useState('');
  const [kind, setKind] = useState('');
  const [rate, setRate] = useState('');
  const [editing, setEditing] = useState<ErpProduct | null>(null);
  const [adding, setAdding] = useState(false);
  const [deleting, setDeleting] = useState<ErpProduct | null>(null);
  const [adjusting, setAdjusting] = useState<ErpProduct | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['erp-products'],
    queryFn: () => erpApi.products({ page_size: 500 }).then(r => r.data),
  });

  const remove = useMutation({
    mutationFn: (id: number) => erpApi.deleteProduct(id),
    onSuccess: () => {
      showToast('success', 'Removed', 'The product was deleted.');
      qc.invalidateQueries({ queryKey: ['erp-products'] });
      qc.invalidateQueries({ queryKey: ['erp-products-picker'] });
      setDeleting(null);
    },
    onError: e => showToast('error', 'Could not delete', getErrorMessage(e)),
  });

  const all = data?.results ?? [];
  const rates = useMemo(
    () => [...new Set(all.map(p => normalizeRate(p.gst_rate)))].sort((a, b) => Number(a) - Number(b)),
    [all],
  );

  const rows = useMemo(() => {
    let list = all;
    if (kind === 'service') list = list.filter(p => p.is_service);
    if (kind === 'goods') list = list.filter(p => !p.is_service);
    if (rate) list = list.filter(p => normalizeRate(p.gst_rate) === rate);
    const q = search.trim().toLowerCase();
    if (q) list = list.filter(p =>
      p.name?.toLowerCase().includes(q) || p.sku?.toLowerCase().includes(q) ||
      p.hsn_sac?.toLowerCase().includes(q));
    return list;
  }, [all, search, kind, rate]);

  const columns: Column<ErpProduct>[] = [
    { key: 'sku', header: 'SKU', sortable: true,
      render: p => <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{p.sku}</span> },
    { key: 'name', header: 'Name', sortable: true, render: p => <b>{p.name}</b> },
    { key: 'hsn_sac', header: 'HSN/SAC', sortable: true,
      render: p => <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{p.hsn_sac || '—'}</span> },
    { key: 'unit_price', header: 'Unit price', numeric: true, sortable: true,
      sortValue: p => Number(p.unit_price), render: p => formatINRExact(p.unit_price) },
    { key: 'gst_rate', header: 'GST', numeric: true, sortable: true,
      sortValue: p => Number(p.gst_rate), render: p => `${normalizeRate(p.gst_rate)}%` },
    { key: 'is_service', header: 'Type', render: p => p.is_service ? 'Service' : 'Goods' },
    { key: 'stock_quantity', header: 'Stock', numeric: true,
      render: p => {
        if (!p.track_stock) return <span style={{ color: 'var(--text-3)' }}>—</span>;
        const low = Number(p.stock_quantity) <= 0;
        return <span style={{ color: low ? 'var(--hot)' : undefined, fontWeight: low ? 700 : 400 }}>
          {p.stock_quantity}
        </span>;
      } },
    { key: 'is_active', header: 'Status',
      render: p => <StatusPill value={p.is_active ? 'active' : 'inactive'} /> },
  ];

  const outOfStock = all.filter(p => p.track_stock && Number(p.stock_quantity) <= 0).length;

  return (
    <>
      <div className="grid gap-3 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))' }}>
        <StatCard label="Products" value={all.length}
                  sub={`${all.filter(p => p.is_service).length} services`} icon="⊞" />
        <StatCard label="Out of stock" value={outOfStock}
                  sub={outOfStock ? 'Tracked items at zero' : 'Everything in stock'}
                  tone={outOfStock ? 'red' : 'green'} icon="!" />
      </div>

      {canManage && <AddButton label="Add product" onClick={() => setAdding(true)} />}

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search name, SKU, HSN…">
        <Select label="Type" value={kind} onChange={e => setKind(e.target.value)}>
          <option value="">All</option>
          <option value="goods">Goods</option>
          <option value="service">Services</option>
        </Select>
        <Select label="GST rate" value={rate} onChange={e => setRate(e.target.value)}>
          <option value="">All rates</option>
          {rates.map(r => <option key={r} value={r}>{r}%</option>)}
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={p => p.id}
        isLoading={isLoading}
        pageSize={25}
        minWidth="860px"
        onRowClick={canManage ? p => setEditing(p) : undefined}
        actions={canManage ? p => (
          <>
            <RowAction label="Edit" onClick={() => setEditing(p)} />
            {p.track_stock && <RowAction label="Stock" onClick={() => setAdjusting(p)} />}
            <RowAction label="Delete" danger onClick={() => setDeleting(p)} />
          </>
        ) : undefined}
        empty={{
          icon: '⊞', title: 'No products',
          message: 'Add the products or services you invoice for.',
          action: canManage ? { label: 'Add product', onClick: () => setAdding(true) } : undefined,
        }}
      />

      {adding && <ProductModal onClose={() => setAdding(false)} />}
      {editing && <ProductModal product={editing} onClose={() => setEditing(null)} />}
      {adjusting && <StockModal product={adjusting} onClose={() => setAdjusting(null)} />}

      {deleting && (
        <ConfirmDialog
          title={`Delete ${deleting.name}?`}
          message="This only works if the product has never been used on a quotation, order or invoice — the database protects those lines. If it has, mark it inactive instead."
          confirmLabel="Delete product"
          danger
          onConfirm={() => remove.mutate(deleting.id)}
          onCancel={() => setDeleting(null)}
        />
      )}
    </>
  );
}

/* ---- Stock adjustment ---------------------------------------
   Deliberately an absolute set with a reason, not a +/- delta: stock counts
   drift, and the action people actually take after a physical count is
   "it is 47 now", not "add 3". */
function StockModal({ product, onClose }: { product: ErpProduct; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [qty, setQty] = useState(String(product.stock_quantity));

  const save = useMutation({
    mutationFn: () => erpApi.updateProduct(product.id, { stock_quantity: qty }),
    onSuccess: () => {
      showToast('success', 'Stock updated', `${product.name} → ${qty}`);
      qc.invalidateQueries({ queryKey: ['erp-products'] });
      qc.invalidateQueries({ queryKey: ['erp-products-picker'] });
      onClose();
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const delta = Number(qty) - Number(product.stock_quantity);

  return (
    <Modal title="Adjust stock" subtitle={`${product.sku} · ${product.name}`} onClose={onClose} maxWidth="380px">
      <div className="flex flex-col gap-3">
        <Input label="Counted quantity" type="number" step="0.01" value={qty}
               onChange={e => setQty(e.target.value)} autoFocus />
        <p style={{ fontSize: '0.78rem', color: 'var(--text-2)' }}>
          Currently <b>{product.stock_quantity}</b>.
          {delta !== 0 && (
            <> This is a change of <b style={{ color: delta > 0 ? 'var(--won)' : 'var(--hot)' }}>
              {delta > 0 ? '+' : ''}{delta.toFixed(2)}
            </b>.</>
          )}
        </p>
        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                style={{ fontSize: '0.85rem' }}
                disabled={save.isPending || delta === 0} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : 'Set stock'}
        </button>
      </div>
    </Modal>
  );
}
