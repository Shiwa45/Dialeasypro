// ============================================================
// ERP — Quotation Builder
//
// Two-step by design (mirrors the backend): create the draft header first
// (customer + dates), then add/edit/remove line items against the returned
// id. Every number shown after the header step — taxable value, tax split,
// totals — comes back from the server on each mutation; nothing here
// computes GST itself.
// ============================================================
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { erpApi, type ErpLineItemInput } from '../../api';
import { ConfirmDialog, Input, Modal, Select, Textarea, useToast } from '../../components/ui';
import {
  DocumentBlock, DocumentLetterhead, DocumentPaper, DocumentTotal, DocumentWords,
  useCompany, useDocumentPrint,
} from '../../components/DocumentShell';
import { fmtDate, formatINRExact } from '../../utils/fmt';
import { getErrorMessage } from '../../utils/errors';
import { GST_RATES, formatSignedINR, normalizeRate, todayISO } from './erpShared';

const STATUS_LABEL: Record<string, string> = {
  draft: 'DRAFT', sent: 'SENT', accepted: 'ACCEPTED',
  rejected: 'REJECTED', expired: 'EXPIRED', converted: 'CONVERTED',
};

interface Props {
  quotationId?: number;
  onClose: () => void;
  onConverted?: () => void;
}

export default function QuotationBuilder({ quotationId, onClose, onConverted }: Props) {
  return quotationId
    ? <EditQuotation id={quotationId} onClose={onClose} onConverted={onConverted} />
    : <CreateQuotation onClose={onClose} />;
}

// ---- Step 1: create the draft header ------------------------
function CreateQuotation({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [customerId, setCustomerId] = useState<number | ''>('');
  const [quotationDate, setQuotationDate] = useState(todayISO());
  const [validUntil, setValidUntil] = useState('');
  const [notes, setNotes] = useState('');
  const [createdId, setCreatedId] = useState<number | null>(null);

  // Same key, same shape as the Invoices/Payments pickers: this one used to
  // cache the bare array under the shared key, and once Quotations had been
  // opened the New-invoice customer list read `.results` of an array — empty.
  const { data: customersPage } = useQuery({
    queryKey: ['erp-customers-picker'],
    queryFn: () => erpApi.customers({ page_size: 500 }).then(r => r.data),
  });
  // Inactive customers can't be quoted (the server refuses), so don't offer them.
  const customers = customersPage?.results?.filter(c => c.is_active);
  const badValidity = !!validUntil && !!quotationDate && validUntil < quotationDate;

  const create = useMutation({
    mutationFn: () => erpApi.createQuotation({
      customer: Number(customerId),
      quotation_date: quotationDate || undefined,
      valid_until: validUntil || undefined,
      notes,
    }),
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ['erp-quotations'] });
      setCreatedId(r.data.id);
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not create the quotation.')),
  });

  // Once the draft exists, hand off to the item-editing view — same modal,
  // no extra click, since a quotation with no lines isn't useful yet.
  if (createdId !== null) {
    return <EditQuotation id={createdId} onClose={onClose} justCreated />;
  }

  return (
    <Modal title="New quotation" onClose={onClose} maxWidth="480px">
      <div className="flex flex-col gap-3">
        <Select label="Customer" required value={customerId}
                hint={!customers?.length ? 'No customers yet — add one from the Customers tab first.' : undefined}
                onChange={e => setCustomerId(e.target.value ? Number(e.target.value) : '')}>
          <option value="">Select a customer…</option>
          {(customers ?? []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))' }}>
          <Input label="Quotation date" type="date" value={quotationDate}
                 onChange={e => setQuotationDate(e.target.value)} />
          <Input label="Valid until (optional)" type="date" value={validUntil} min={quotationDate || undefined}
                 error={badValidity ? "Can't be before the quotation date" : undefined}
                 onChange={e => setValidUntil(e.target.value)} />
        </div>
        <Textarea label="Notes (optional)" value={notes} onChange={e => setNotes(e.target.value)} />
        <button className="btn btn-p mt-2"
                disabled={!customerId || badValidity || create.isPending}
                onClick={() => create.mutate()}>
          {create.isPending ? 'Creating…' : 'Create draft'}
        </button>
      </div>
    </Modal>
  );
}

// ---- Step 2: edit lines, status, convert ---------------------
function EditQuotation({ id, onClose, onConverted, justCreated }: {
  id: number; onClose: () => void; onConverted?: () => void; justCreated?: boolean;
}) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [addingLine, setAddingLine] = useState(false);
  const [editingDetails, setEditingDetails] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);

  const { data: q, isLoading } = useQuery({
    queryKey: ['erp-quotation', id],
    queryFn: () => erpApi.quotation(id).then(r => r.data),
  });

  const { data: productsPage } = useQuery({
    queryKey: ['erp-products-picker'],
    queryFn: () => erpApi.products({ page_size: 500 }).then(r => r.data),
  });
  const products = productsPage?.results?.filter(p => p.is_active);

  const { data: company } = useCompany();
  const { ref: paperRef, print } = useDocumentPrint(q?.number || 'Quotation');

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['erp-quotation', id] });
    qc.invalidateQueries({ queryKey: ['erp-quotations'] });
  };

  const removeItem = useMutation({
    mutationFn: (itemId: number) => erpApi.deleteQuotationItem(id, itemId),
    onSuccess: () => { invalidate(); setConfirmDelete(null); },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not remove the line.')),
  });

  const setStatus = useMutation({
    mutationFn: (status: 'draft' | 'sent' | 'accepted' | 'rejected') => erpApi.setQuotationStatus(id, status),
    onSuccess: (_r, status) => {
      showToast('success', 'Updated',
        status === 'draft' ? 'Back to draft — you can change the lines now.' : `Marked as ${status}.`);
      invalidate();
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not update the status.')),
  });

  const convert = useMutation({
    mutationFn: () => erpApi.convertQuotation(id),
    onSuccess: () => {
      showToast('success', 'Converted', 'A sales order was created from this quotation.');
      qc.invalidateQueries({ queryKey: ['erp-quotations'] });
      qc.invalidateQueries({ queryKey: ['erp-orders'] });
      onConverted?.();
      onClose();
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not convert the quotation.')),
  });

  if (isLoading || !q) {
    return (
      <Modal title="Quotation" onClose={onClose} maxWidth="720px">
        <div className="flex justify-center py-10"><span>Loading…</span></div>
      </Modal>
    );
  }

  // Lines change only while the quotation is a draft: once it has been sent,
  // the record must match what the customer received. "Revise" reopens it.
  const editable = q.status === 'draft';
  const canConvert = !['converted', 'rejected', 'expired'].includes(q.status) && q.items.length > 0;

  const meta: Array<[string, string]> = [['Date', fmtDate(q.quotation_date)]];
  if (q.valid_until) meta.push(['Valid until', fmtDate(q.valid_until)]);
  meta.push(['Status', STATUS_LABEL[q.status] ?? q.status]);

  return (
    <Modal title={q.number || 'Draft quotation'}
           subtitle={justCreated ? 'Add line items below' : q.customer_name}
           onClose={onClose} maxWidth="880px">
      {/* Controls above the paper, so none of them reach the print. */}
      <div className="flex items-center justify-between flex-wrap gap-2 mb-4">
        <span className="doc-stamp" style={{
          color: q.status === 'accepted' ? 'var(--won)'
               : q.status === 'rejected' ? 'var(--lost)'
               : q.status === 'converted' ? 'var(--visit)'
               : q.status === 'draft' ? 'var(--text-3)' : 'var(--brand)',
        }}>
          {STATUS_LABEL[q.status] ?? q.status}
        </span>
        <div className="flex gap-2 flex-wrap">
          {q.status === 'draft' && (
            <button className="btn btn-p" disabled={setStatus.isPending || !q.items.length}
                    title={!q.items.length ? 'Add at least one line first' : undefined}
                    onClick={() => setStatus.mutate('sent')}>
              Mark sent to customer
            </button>
          )}
          {(q.status === 'draft' || q.status === 'sent') && (
            <>
              <button className={`btn ${q.status === 'sent' ? 'btn-p' : 'btn-g'}`}
                      disabled={setStatus.isPending || !q.items.length}
                      onClick={() => setStatus.mutate('accepted')}>
                Customer accepted
              </button>
              <button className="btn btn-g" disabled={setStatus.isPending}
                      onClick={() => setStatus.mutate('rejected')}>
                Customer rejected
              </button>
            </>
          )}
          {q.status === 'sent' && (
            <button className="btn btn-g" disabled={setStatus.isPending}
                    title="Reopen the quotation to change its lines"
                    onClick={() => setStatus.mutate('draft')}>
              Revise (back to draft)
            </button>
          )}
          {editable && !addingLine && (
            <button className="btn btn-g" onClick={() => setAddingLine(true)}>Add line item</button>
          )}
          {editable && !editingDetails && (
            <button className="btn btn-g" onClick={() => setEditingDetails(true)}>Edit validity / notes</button>
          )}
          <button className="btn btn-g" onClick={print}>Print / Save as PDF</button>
        </div>
      </div>

      {editable && editingDetails && (
        <QuotationDetailsForm quotation={q}
          onDone={() => { setEditingDetails(false); invalidate(); }}
          onCancel={() => setEditingDetails(false)} />
      )}

      {editable && addingLine && (
        <LineItemForm
          products={products ?? []}
          onCancel={() => setAddingLine(false)}
          onSubmit={async (data) => { await erpApi.addQuotationItem(id, data); invalidate(); setAddingLine(false); }}
        />
      )}

      <DocumentPaper innerRef={paperRef}>
        <DocumentLetterhead company={company} docLabel="Quotation"
                            docNumber={q.number || 'Draft'} meta={meta} />

        <div style={{ display: 'grid', gap: 24, gridTemplateColumns: '1fr 1fr', marginBottom: 20 }}>
          <DocumentBlock title="Prepared for">
            <div className="doc-party-name">{q.customer_name}</div>
            {q.customer_billing_address && (
              <div className="doc-party-line" style={{ whiteSpace: 'pre-line' }}>
                {q.customer_billing_address}
              </div>
            )}
            {(q.customer_phone || q.customer_email) && (
              <div className="doc-party-line">
                {[q.customer_phone, q.customer_email].filter(Boolean).join('  ·  ')}
              </div>
            )}
            {q.customer_gstin && <div className="doc-gstin">GSTIN&nbsp;&nbsp;{q.customer_gstin}</div>}
          </DocumentBlock>

          <DocumentBlock title="Tax treatment">
            <div className="doc-party-line">
              {q.buyer_state || '—'}
              {q.is_interstate ? ' · Inter-state (IGST)' : ' · Intra-state (CGST + SGST)'}
            </div>
            {q.seller_state && <div className="doc-party-line">Quoted from {q.seller_state}</div>}
          </DocumentBlock>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="doc-table" style={{ minWidth: 600 }}>
            <thead>
              <tr>
                <th style={{ width: 26 }}>#</th>
                <th>Description</th>
                <th className="n">Qty</th>
                <th className="n">Rate</th>
                <th className="n">Disc</th>
                <th className="n">GST</th>
                <th className="n">Taxable</th>
                <th className="n">Amount</th>
                {editable && <th className="doc-noprint" />}
              </tr>
            </thead>
            <tbody>
              {!q.items.length && (
                <tr>
                  <td colSpan={editable ? 9 : 8}
                      style={{ padding: '18px 10px', textAlign: 'center', color: 'var(--text-3)' }}>
                    No line items yet.
                  </td>
                </tr>
              )}
              {q.items.map((item, i) => (
                <tr key={item.id}>
                  <td className="n" style={{ textAlign: 'left' }}>{i + 1}</td>
                  <td>
                    <div className="doc-item-desc">{item.description}</div>
                    {item.hsn_sac && <div className="doc-item-sub">HSN/SAC {item.hsn_sac}</div>}
                  </td>
                  <td className="n">{item.quantity}</td>
                  <td className="n">{formatINRExact(item.unit_price)}</td>
                  <td className="n">{Number(item.discount_percent) ? `${item.discount_percent}%` : '—'}</td>
                  <td className="n">{normalizeRate(item.gst_rate)}%</td>
                  <td className="n">{formatINRExact(item.taxable_value)}</td>
                  <td className="n" style={{ fontWeight: 600 }}>{formatINRExact(item.line_total)}</td>
                  {editable && (
                    <td className="doc-noprint" style={{ textAlign: 'right' }}>
                      <button onClick={() => setConfirmDelete(item.id)}
                              style={{ background: 'none', border: 'none', cursor: 'pointer',
                                       color: 'var(--hot)', fontSize: '0.75rem' }}>
                        Remove
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="doc-totals">
          <DocumentTotal label="Taxable value" value={formatINRExact(q.subtotal)} />
          {q.is_interstate ? (
            <DocumentTotal label="IGST" value={formatINRExact(q.igst_amount)} />
          ) : (
            <>
              <DocumentTotal label="CGST" value={formatINRExact(q.cgst_amount)} />
              <DocumentTotal label="SGST" value={formatINRExact(q.sgst_amount)} />
            </>
          )}
          {Number(q.round_off) !== 0 && (
            <DocumentTotal label="Round off" value={formatSignedINR(q.round_off)} />
          )}
          <DocumentTotal label="Total" value={formatINRExact(q.total_amount)} variant="grand" />
        </div>

        <DocumentWords amount={q.total_amount} />

        {q.notes && (
          <div style={{ marginTop: 18 }}>
            <DocumentBlock title="Notes">
              <div className="doc-party-line" style={{ whiteSpace: 'pre-line' }}>{q.notes}</div>
            </DocumentBlock>
          </div>
        )}

        <div className="doc-foot">
          <div style={{ maxWidth: 400 }}>
            {q.valid_until
              ? `This quotation is valid until ${fmtDate(q.valid_until)}. Prices and availability may change after that date.`
              : 'Prices and availability are subject to change until the quotation is accepted.'}
            <div style={{ marginTop: 4 }}>Taxes are shown at the rates applicable on the date above.</div>
          </div>
          <div className="doc-sign">
            For {company?.company_name || 'the company'}
            <div className="doc-sign-rule">Authorised signatory</div>
          </div>
        </div>
      </DocumentPaper>

      <div className="flex justify-between items-center mt-4 flex-wrap gap-2">
        <span style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>
          {q.valid_until ? `Valid until ${fmtDate(q.valid_until)}` : 'No expiry set'}
        </span>
        {canConvert && (
          <button className="btn btn-p" disabled={convert.isPending} onClick={() => convert.mutate()}>
            {convert.isPending ? 'Converting…' : 'Convert to sales order'}
          </button>
        )}
      </div>

      {confirmDelete !== null && (
        <ConfirmDialog
          title="Remove this line?"
          message="Totals will be recalculated."
          confirmLabel="Remove"
          danger
          onConfirm={() => removeItem.mutate(confirmDelete)}
          onCancel={() => setConfirmDelete(null)}
        />
      )}
    </Modal>
  );
}

// ---- Add-line inline form -------------------------------------
function LineItemForm({ products, onCancel, onSubmit }: {
  products: Array<{ id: number; name: string; hsn_sac: string; unit_price: string; gst_rate: string }>;
  onCancel: () => void;
  onSubmit: (data: ErpLineItemInput) => Promise<void>;
}) {
  const { showToast } = useToast();
  const [productId, setProductId] = useState<number | ''>('');
  const [description, setDescription] = useState('');
  const [hsnSac, setHsnSac] = useState('');
  const [quantity, setQuantity] = useState('1');
  const [unitPrice, setUnitPrice] = useState('');
  const [discountPercent, setDiscountPercent] = useState('0');
  const [gstRate, setGstRate] = useState('18');
  const [saving, setSaving] = useState(false);

  const applyProduct = (id: number | '') => {
    setProductId(id);
    const p = products.find(x => x.id === id);
    if (p) {
      setDescription(p.name);
      setHsnSac(p.hsn_sac);
      setUnitPrice(p.unit_price);
      setGstRate(normalizeRate(p.gst_rate));
    }
  };

  const canSubmit = description.trim() && Number(quantity) > 0 &&
                    unitPrice !== '' && Number(unitPrice) >= 0;

  const submit = async () => {
    setSaving(true);
    try {
      await onSubmit({
        product: productId || null,
        description: description.trim(),
        hsn_sac: hsnSac.trim(),
        quantity, unit_price: unitPrice,
        discount_percent: discountPercent, gst_rate: gstRate,
      });
    } catch (e) {
      showToast('error', 'Could not add the line', getErrorMessage(e, 'Could not add the line item.'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="card-brutal" style={{ padding: '14px', marginBottom: '16px', background: 'var(--brass-50)' }}>
      {products.length > 0 && (
        <div className="mb-2">
          <Select label="Product" value={productId}
                  onChange={e => applyProduct(e.target.value ? Number(e.target.value) : '')}>
            <option value="">Custom line (no product) — fill in below…</option>
            {products.map(p => <option key={p.id} value={p.id}>{p.name} — {formatINRExact(p.unit_price)}</option>)}
          </Select>
        </div>
      )}
      <div className="grid gap-2 mb-2" style={{ gridTemplateColumns: '2fr 1fr' }}>
        <Input label="Description" value={description} onChange={e => setDescription(e.target.value)} />
        <Input label="HSN/SAC" value={hsnSac} onChange={e => setHsnSac(e.target.value)} />
      </div>
      <div className="grid gap-2 mb-3" style={{ gridTemplateColumns: '1fr 1fr 1fr 1fr' }}>
        <Input label="Qty" type="number" min="0.01" step="0.01" value={quantity} onChange={e => setQuantity(e.target.value)} />
        <Input label="Unit price" type="number" min="0" step="0.01" value={unitPrice} onChange={e => setUnitPrice(e.target.value)} />
        <Input label="Discount %" type="number" min="0" max="100" step="0.01" value={discountPercent} onChange={e => setDiscountPercent(e.target.value)} />
        <Select label="GST" value={gstRate} onChange={e => setGstRate(e.target.value)}>
          {GST_RATES.map(r => <option key={r} value={r}>{r}%</option>)}
        </Select>
      </div>
      <div className="flex gap-2">
        <button className="btn btn-p" disabled={!canSubmit || saving} onClick={submit}>
          {saving ? 'Adding…' : 'Add line'}
        </button>
        <button className="btn btn-g" onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}

// ---- Header details (draft only) ----------------------------
function QuotationDetailsForm({ quotation, onDone, onCancel }: {
  quotation: { id: number; quotation_date: string; valid_until: string | null; notes: string };
  onDone: () => void;
  onCancel: () => void;
}) {
  const { showToast } = useToast();
  const [validUntil, setValidUntil] = useState(quotation.valid_until ?? '');
  const [notes, setNotes] = useState(quotation.notes ?? '');
  const bad = !!validUntil && validUntil < quotation.quotation_date;

  const save = useMutation({
    mutationFn: () => erpApi.updateQuotation(quotation.id, { valid_until: validUntil || null, notes }),
    onSuccess: () => { showToast('success', 'Saved', 'Quotation details updated.'); onDone(); },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not save the details.')),
  });

  return (
    <div className="card-brutal" style={{ padding: '14px', marginBottom: '16px', background: 'var(--brass-50)' }}>
      <div className="grid gap-2 mb-2" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
        <Input label="Valid until" type="date" value={validUntil} min={quotation.quotation_date}
               error={bad ? "Can't be before the quotation date" : undefined}
               onChange={e => setValidUntil(e.target.value)} />
      </div>
      <Textarea label="Notes" value={notes} onChange={e => setNotes(e.target.value)} />
      <div className="flex gap-2 mt-2">
        <button className="btn btn-p" disabled={bad || save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : 'Save'}
        </button>
        <button className="btn btn-g" onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}
