// ============================================================
// Sales & Billing — Quotations
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { erpApi } from '../../api';
import { AddButton, Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { ConfirmDialog, Select, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINRExact } from '../../utils/fmt';
import QuotationBuilder from './QuotationBuilder';
import type { ErpQuotation } from '../../types';

export default function QuotationsTab() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canManage = can(Cap.ERP_MANAGE);

  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [openId, setOpenId] = useState<number | null>(null);
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState<ErpQuotation | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['erp-quotations', status],
    queryFn: () => erpApi.quotations({ status: status || undefined, page_size: 200 }).then(r => r.data),
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['erp-quotations'] });
    qc.invalidateQueries({ queryKey: ['erp-dashboard'] });
  };

  const setStatusMut = useMutation({
    mutationFn: ({ id, status }: { id: number; status: 'sent' | 'accepted' | 'rejected' }) =>
      erpApi.setQuotationStatus(id, status),
    onSuccess: (_r, v) => { showToast('success', 'Updated', `Marked ${v.status}.`); invalidate(); },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const convert = useMutation({
    mutationFn: (id: number) => erpApi.convertQuotation(id),
    onSuccess: () => {
      showToast('success', 'Converted', 'A sales order was opened from this quotation.');
      invalidate();
      qc.invalidateQueries({ queryKey: ['erp-orders'] });
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const remove = useMutation({
    mutationFn: (id: number) => erpApi.deleteQuotation(id),
    onSuccess: () => { showToast('success', 'Deleted', ''); invalidate(); setDeleting(null); },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const rows = useMemo(() => {
    const all = data?.results ?? [];
    const q = search.trim().toLowerCase();
    return q ? all.filter(x => x.number?.toLowerCase().includes(q)
                            || x.customer_name?.toLowerCase().includes(q)) : all;
  }, [data, search]);

  const columns: Column<ErpQuotation>[] = [
    { key: 'number', header: 'Number', sortable: true,
      render: q => <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>{q.number}</span> },
    { key: 'quotation_date', header: 'Date', sortable: true, render: q => fmtDate(q.quotation_date) },
    { key: 'valid_until', header: 'Valid until', sortable: true,
      render: q => {
        if (!q.valid_until) return '—';
        const lapsed = new Date(q.valid_until) < new Date() && ['draft', 'sent'].includes(q.status);
        return <span style={{ color: lapsed ? 'var(--hot)' : undefined }}>
          {fmtDate(q.valid_until)}{lapsed && ' · lapsed'}
        </span>;
      } },
    { key: 'customer_name', header: 'Customer', sortable: true, render: q => q.customer_name },
    { key: 'total_amount', header: 'Total', numeric: true, sortable: true,
      sortValue: q => Number(q.total_amount), render: q => <b>{formatINRExact(q.total_amount)}</b> },
    { key: 'status', header: 'Status', sortable: true, render: q => <StatusPill value={q.status} /> },
  ];

  return (
    <>
      {canManage && <AddButton label="New quotation" onClick={() => setCreating(true)} />}

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search number or customer…">
        <Select label="Status" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="draft">Draft</option>
          <option value="sent">Sent</option>
          <option value="accepted">Accepted</option>
          <option value="rejected">Rejected</option>
          <option value="expired">Expired</option>
          <option value="converted">Converted</option>
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={q => q.id}
        isLoading={isLoading}
        pageSize={25}
        onRowClick={q => setOpenId(q.id)}
        actions={canManage ? q => (
          <>
            <RowAction label="Open" onClick={() => setOpenId(q.id)} />
            {q.status === 'draft' && (
              <RowAction label="Mark sent" disabled={setStatusMut.isPending}
                         onClick={() => setStatusMut.mutate({ id: q.id, status: 'sent' })} />
            )}
            {q.status === 'sent' && (
              <RowAction label="Accepted" disabled={setStatusMut.isPending}
                         onClick={() => setStatusMut.mutate({ id: q.id, status: 'accepted' })} />
            )}
            {q.status === 'accepted' && (
              <RowAction label="Convert to order" disabled={convert.isPending}
                         onClick={() => convert.mutate(q.id)} />
            )}
            {q.status === 'draft' && <RowAction label="Delete" danger onClick={() => setDeleting(q)} />}
          </>
        ) : undefined}
        empty={{
          icon: '◫', title: 'No quotations',
          message: 'Quotations you send to customers appear here.',
          action: canManage ? { label: 'New quotation', onClick: () => setCreating(true) } : undefined,
        }}
      />

      {creating && <QuotationBuilder onClose={() => { setCreating(false); invalidate(); }} />}
      {openId !== null && <QuotationBuilder quotationId={openId} onClose={() => { setOpenId(null); invalidate(); }} />}

      {deleting && (
        <ConfirmDialog
          title="Delete this quotation?"
          message={`${deleting.number} · ${deleting.customer_name}. Only drafts can be deleted; a sent quotation is kept for the record.`}
          confirmLabel="Delete"
          danger
          onConfirm={() => remove.mutate(deleting.id)}
          onCancel={() => setDeleting(null)}
        />
      )}
    </>
  );
}
