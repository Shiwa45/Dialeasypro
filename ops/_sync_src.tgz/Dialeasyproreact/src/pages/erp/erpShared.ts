// ============================================================
// ERP — shared constants and small helpers
//
// Each list mirrors a server-side constant; the server stays the authority
// (it validates every one of these), the lists only keep the forms from
// offering values that would be refused.
// ============================================================

/** apps/erp/gst.py :: VALID_GST_RATES */
export const GST_RATES = ['0', '5', '12', '18', '28'];

/**
 * The server sends rates as decimals ("18.00"); the selects use "18". Without
 * this the select matched no option and showed 0 % — saving the form then
 * silently changed the product's rate.
 */
export const normalizeRate = (rate: string | number | null | undefined, fallback = '18'): string => {
  if (rate === null || rate === undefined || rate === '') return fallback;
  const n = Number(rate);
  return Number.isFinite(n) ? String(n) : fallback;
};

/** apps/erp/constants.py :: UnitOfMeasure.CHOICES */
export const UNITS: Array<[string, string]> = [
  ['nos', 'Nos'], ['pcs', 'Pieces'], ['box', 'Box'], ['set', 'Set'], ['pack', 'Pack'],
  ['dozen', 'Dozen'], ['pair', 'Pair'],
  ['hour', 'Hour'], ['day', 'Day'], ['month', 'Month'], ['year', 'Year'], ['job', 'Job'],
  ['kg', 'Kg'], ['gram', 'Gram'], ['ton', 'Tonne'], ['litre', 'Litre'], ['ml', 'ml'],
  ['meter', 'Meter'], ['sqft', 'Sq. ft'], ['sqm', 'Sq. m'],
];

/** apps/core/constants.py :: INDIAN_STATES */
export const INDIAN_STATES: Array<[string, string]> = [
  ['AN', 'Andaman and Nicobar Islands'], ['AP', 'Andhra Pradesh'], ['AR', 'Arunachal Pradesh'],
  ['AS', 'Assam'], ['BR', 'Bihar'], ['CH', 'Chandigarh'], ['CG', 'Chhattisgarh'],
  ['DN', 'Dadra and Nagar Haveli and Daman and Diu'], ['DL', 'Delhi'], ['GA', 'Goa'],
  ['GJ', 'Gujarat'], ['HR', 'Haryana'], ['HP', 'Himachal Pradesh'], ['JK', 'Jammu and Kashmir'],
  ['JH', 'Jharkhand'], ['KA', 'Karnataka'], ['KL', 'Kerala'], ['LA', 'Ladakh'], ['LD', 'Lakshadweep'],
  ['MP', 'Madhya Pradesh'], ['MH', 'Maharashtra'], ['MN', 'Manipur'], ['ML', 'Meghalaya'],
  ['MZ', 'Mizoram'], ['NL', 'Nagaland'], ['OD', 'Odisha'], ['PY', 'Puducherry'], ['PB', 'Punjab'],
  ['RJ', 'Rajasthan'], ['SK', 'Sikkim'], ['TN', 'Tamil Nadu'], ['TS', 'Telangana'],
  ['TR', 'Tripura'], ['UP', 'Uttar Pradesh'], ['UK', 'Uttarakhand'], ['WB', 'West Bengal'],
];
export const STATE_ALIASES: Record<string, string> = { CT: 'CG', OR: 'OD', TG: 'TS', UT: 'UK', DD: 'DN' };

/** apps/erp/gstin.py :: GST_STATE_BY_NUMBER — the first two digits of a GSTIN. */
const GST_STATE_BY_NUMBER: Record<string, string> = {
  '01': 'JK', '02': 'HP', '03': 'PB', '04': 'CH', '05': 'UK', '06': 'HR', '07': 'DL',
  '08': 'RJ', '09': 'UP', '10': 'BR', '11': 'SK', '12': 'AR', '13': 'NL', '14': 'MN',
  '15': 'MZ', '16': 'TR', '17': 'ML', '18': 'AS', '19': 'WB', '20': 'JH', '21': 'OD',
  '22': 'CG', '23': 'MP', '24': 'GJ', '25': 'DN', '26': 'DN', '27': 'MH', '28': 'AP', '29': 'KA',
  '30': 'GA', '31': 'LD', '32': 'KL', '33': 'TN', '34': 'PY', '35': 'AN', '36': 'TS',
  '37': 'AP', '38': 'LA',
};

/** State code a GSTIN belongs to, or '' when it can't be read yet. */
export const stateFromGstin = (gstin: string): string =>
  GST_STATE_BY_NUMBER[gstin.trim().slice(0, 2)] ?? '';

export const stateName = (code: string): string =>
  INDIAN_STATES.find(([c]) => c === code)?.[1] ?? code;

/**
 * Draft invoices carry a placeholder ("DRAFT-…") until they are issued — the
 * GST number is only taken at issue, so deleting a draft leaves no gap.
 */
export const isDraftNumber = (n: string | null | undefined): boolean => !n || n.startsWith('DRAFT-');
export const docNumber = (n: string | null | undefined, draftLabel = 'Draft'): string =>
  isDraftNumber(n) ? draftLabel : (n as string);

/** Round-off as "−₹0.40" / "+₹0.60" — a signed amount, not "₹-0.40". */
export const formatSignedINR = (amount: string | number): string => {
  const n = Number(amount);
  if (!Number.isFinite(n) || n === 0) return '₹0.00';
  const abs = Math.abs(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${n < 0 ? '−' : '+'}₹${abs}`;
};

export const todayISO = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
