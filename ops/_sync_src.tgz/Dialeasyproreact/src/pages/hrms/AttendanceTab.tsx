// ============================================================
// HRMS — Attendance
//
// Attendance is derived from dialer session logs by a nightly job, so the
// check-in/out buttons are a manual override for people who work off the
// dialer, not the primary source of truth.
//
// The correction modal stamps source=admin server-side. That flag is what
// stops the next nightly sync from overwriting a row a human just fixed.
// ============================================================
import { useMyEmployee } from '../../hooks/useMyEmployee';
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { hrmsApi } from '../../api';
import { Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { ConfirmDialog, Input, Modal, Select, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { fmtDate, fmtDateTime, localISODate, localISOMonth } from '../../utils/fmt';
import type { Attendance } from '../../types';
import { getErrorMessage } from '../../utils/errors';
import { fetchAllPages } from '../../utils/fetchAll';

const STATUSES = ['present', 'half_day', 'absent', 'on_leave', 'holiday', 'week_off'];

/** First and last day of a 'YYYY-MM' month, as ISO dates. */
function monthRange(month: string) {
  const [y, m] = month.split('-').map(Number);
  const last = new Date(y, m, 0).getDate();
  return { from: `${month}-01`, to: `${month}-${String(last).padStart(2, '0')}` };
}

export default function AttendanceTab() {
  // Only someone on the HRMS roster can punch in, apply for leave or claim.
  const { enrolled } = useMyEmployee();
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canManage = can(Cap.HRMS_MANAGE);
  const canViewAll = can(Cap.HRMS_VIEW_ALL);

  const [month, setMonth] = useState(localISOMonth());
  const [employeeId, setEmployeeId] = useState('');
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<Attendance | null>(null);
  const [syncDate, setSyncDate] = useState(localISODate());
  const [confirmSync, setConfirmSync] = useState(false);
  const [adding, setAdding] = useState(false);

  const range = monthRange(month);

  const { data, isLoading } = useQuery({
    queryKey: ['hrms-attendance', month, employeeId, status],
    // Every page: the API caps a page at 100 rows, and a month for a team
    // is more than that.
    queryFn: () => fetchAllPages(page => hrmsApi.attendance({
      date_from: range.from,
      date_to: range.to,
      employee: employeeId || undefined,
      status: status || undefined,
      page_size: 100,
      page,
    })),
  });

  const { data: employees } = useQuery({
    queryKey: ['hrms-employees-picker'],
    queryFn: () => fetchAllPages(page => hrmsApi.employees({ page_size: 100, page })),
    enabled: canViewAll,
  });

  const punch = useMutation({
    mutationFn: (kind: 'in' | 'out') => (kind === 'in' ? hrmsApi.checkIn() : hrmsApi.checkOut()),
    onSuccess: () => {
      showToast('success', 'Recorded', 'Attendance updated.');
      qc.invalidateQueries({ queryKey: ['hrms-attendance'] });
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not record attendance.')),
  });

  const sync = useMutation({
    mutationFn: () => hrmsApi.syncAttendance(syncDate),
    onSuccess: r => {
      const kept = r.data.kept ?? 0;
      showToast('success', 'Synced',
        `${r.data.rows_written} row(s) rebuilt from dialer sessions`
        + (kept ? `; ${kept} kept as they were (corrected, checked in or on leave).` : '.'));
      qc.invalidateQueries({ queryKey: ['hrms-attendance'] });
      qc.invalidateQueries({ queryKey: ['hrms-dashboard'] });
      setConfirmSync(false);
    },
    onError: (e: unknown) => {
      showToast('error', 'Failed', getErrorMessage(e, 'Could not sync attendance.'));
      setConfirmSync(false);
    },
  });

  const rows = useMemo(() => {
    const all = data?.results ?? [];
    const q = search.trim().toLowerCase();
    return q ? all.filter(a => a.employee_name?.toLowerCase().includes(q)
                            || a.employee_code?.toLowerCase().includes(q)) : all;
  }, [data, search]);

  const columns: Column<Attendance>[] = [
    { key: 'date', header: 'Date', sortable: true, render: a => fmtDate(a.date) },
    { key: 'employee_name', header: 'Employee', sortable: true,
      render: a => (
        <>
          {a.employee_name}
          <span className="font-mono" style={{ fontSize: '0.68rem', color: 'var(--text-3)', marginLeft: 6 }}>
            {a.employee_code}
          </span>
        </>
      ) },
    { key: 'status', header: 'Status', sortable: true, render: a => <StatusPill value={a.status} /> },
    { key: 'source', header: 'Source',
      render: a => (
        <span style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>
          {a.source === 'admin' ? 'Corrected' : a.source === 'manual' ? 'Manual' : 'Dialer'}
        </span>
      ) },
    { key: 'check_in', header: 'In', render: a => a.check_in ? fmtDateTime(a.check_in).slice(-8) : '—' },
    { key: 'check_out', header: 'Out', render: a => a.check_out ? fmtDateTime(a.check_out).slice(-8) : '—' },
    { key: 'worked_hours', header: 'Worked', numeric: true, sortable: true,
      sortValue: a => a.worked_hours, render: a => `${a.worked_hours.toFixed(2)} h` },
    { key: 'break', header: 'Break', numeric: true,
      render: a => `${(a.break_seconds / 3600).toFixed(2)} h` },
    { key: 'note', header: 'Note', render: a => <span style={{ color: 'var(--text-2)' }}>{a.note || '—'}</span> },
  ];

  return (
    <>
      <div className="flex gap-2 mb-3 flex-wrap">
        {enrolled && (
          <>
        <button className="btn-brutal btn-primary px-3 py-2 font-heading font-bold"
                style={{ fontSize: '0.78rem' }}
                disabled={punch.isPending} onClick={() => punch.mutate('in')}>
          Check in
        </button>
        <button className="btn-brutal btn-secondary px-3 py-2 font-heading font-bold"
                style={{ fontSize: '0.78rem' }}
                disabled={punch.isPending} onClick={() => punch.mutate('out')}>
          Check out
        </button>
          </>
        )}

        {canManage && (
          <div className="flex gap-2 items-center" style={{ marginLeft: 'auto' }}>
            <button className="btn-brutal px-3 py-2 font-heading font-bold"
                    style={{ fontSize: '0.78rem' }} onClick={() => setAdding(true)}>
              + Add day
            </button>
            <input className="input-brutal" type="date" value={syncDate} style={{ width: 150 }}
                   max={localISODate()} onChange={e => setSyncDate(e.target.value)} />
            <button className="btn-brutal px-3 py-2 font-heading font-bold"
                    style={{ fontSize: '0.78rem' }}
                    disabled={sync.isPending || !syncDate} onClick={() => setConfirmSync(true)}>
              {sync.isPending ? 'Syncing…' : 'Sync from dialer'}
            </button>
          </div>
        )}
      </div>

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search employee…">
        <div>
          <label className="block font-heading font-bold mb-1"
                 style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Month</label>
          <input className="input-brutal" type="month" value={month} onChange={e => setMonth(e.target.value)} />
        </div>
        {canViewAll && (
          <Select label="Employee" value={employeeId} onChange={e => setEmployeeId(e.target.value)}>
            <option value="">All employees</option>
            {(employees?.results ?? []).map(e => (
              <option key={e.id} value={e.id}>{e.name}</option>
            ))}
          </Select>
        )}
        <Select label="Status" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          {STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={a => a.id}
        isLoading={isLoading}
        pageSize={25}
        actions={canManage ? a => <RowAction label="Correct" onClick={() => setEditing(a)} /> : undefined}
        empty={{
          icon: '▤', title: 'No attendance for this month',
          message: 'Attendance is derived from dialer sessions overnight, recorded manually above, or synced on demand.',
        }}
      />

      {editing && <CorrectionModal row={editing} onClose={() => setEditing(null)} />}
      {adding && <AddDayModal employees={employees?.results ?? []} onClose={() => setAdding(false)} />}
      {confirmSync && (
        <ConfirmDialog
          title={`Sync attendance for ${fmtDate(syncDate)}?`}
          message="Every employee's row for this date is rebuilt from their dialer sessions. Rows corrected by hand, checked in, or on approved leave are kept as they are."
          confirmLabel="Sync"
          onConfirm={() => sync.mutate()}
          onCancel={() => setConfirmSync(false)}
        />
      )}
    </>
  );
}

/* ---- Correction modal ---------------------------------------
   AttendanceSource.ADMIN existed in the backend from day one but nothing in
   the app could ever set it — a wrong row could only be fixed in the Django
   admin. This is that path. */
function CorrectionModal({ row, onClose }: { row: Attendance; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [form, setForm] = useState({
    status: row.status as string,
    worked_hours: (row.worked_seconds / 3600).toFixed(2),
    break_hours: (row.break_seconds / 3600).toFixed(2),
    note: row.note ?? '',
  });

  const save = useMutation({
    mutationFn: () => hrmsApi.updateAttendance(row.id, {
      // Status left as it was → the server works it out from the hours, so
      // entering 8 h on an absent day makes it present.
      ...(form.status !== row.status ? { status: form.status } : {}),
      // The API stores seconds; hours are the humane unit to type.
      worked_seconds: Math.round(Number(form.worked_hours || 0) * 3600),
      break_seconds: Math.round(Number(form.break_hours || 0) * 3600),
      note: form.note,
    }),
    onSuccess: () => {
      showToast('success', 'Corrected', `${row.employee_name} — ${fmtDate(row.date)}`);
      qc.invalidateQueries({ queryKey: ['hrms-attendance'] });
      qc.invalidateQueries({ queryKey: ['hrms-dashboard'] });
      onClose();
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not save the correction.')),
  });

  return (
    <Modal title="Correct attendance"
           subtitle={`${row.employee_name} · ${fmtDate(row.date)}`}
           onClose={onClose} maxWidth="440px">
      <div className="flex flex-col gap-3">
        <Select label="Status" value={form.status}
                onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
          {STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
        </Select>
        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Worked hours" type="number" step="0.25" min="0" value={form.worked_hours}
                 onChange={e => setForm(f => ({ ...f, worked_hours: e.target.value }))} />
          <Input label="Break hours" type="number" step="0.25" min="0" value={form.break_hours}
                 onChange={e => setForm(f => ({ ...f, break_hours: e.target.value }))} />
        </div>
        <Input label="Note" value={form.note} placeholder="Reason for the correction"
               onChange={e => setForm(f => ({ ...f, note: e.target.value }))} />

        <p className="font-medium" style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>
          Saving marks this row as an admin correction, so tonight's dialer sync
          will leave it alone. Leave the status unchanged to have it worked out from
          the hours.
        </p>

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-1"
                style={{ fontSize: '0.85rem' }}
                disabled={save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : 'Save correction'}
        </button>
      </div>
    </Modal>
  );
}

/* ---- Add a missing day (HR) ---------------------------------
   A day with no row could only be created by "Sync from dialer"; someone who
   worked off the dialer had no way to be marked present for it. */
function AddDayModal({ employees, onClose }: {
  employees: Array<{ id: number; name: string; employee_code: string; is_active: boolean }>;
  onClose: () => void;
}) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [form, setForm] = useState({
    employee: '', date: localISODate(), status: '', worked_hours: '', note: '',
  });

  const save = useMutation({
    mutationFn: () => hrmsApi.createAttendance({
      employee: Number(form.employee),
      date: form.date,
      ...(form.status ? { status: form.status } : {}),
      worked_seconds: Math.round(Number(form.worked_hours || 0) * 3600),
      note: form.note,
    }),
    onSuccess: r => {
      showToast('success', 'Added', `${r.data.employee_name} — ${fmtDate(r.data.date)}: ${r.data.status.replace('_', ' ')}`);
      qc.invalidateQueries({ queryKey: ['hrms-attendance'] });
      qc.invalidateQueries({ queryKey: ['hrms-dashboard'] });
      onClose();
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not add the day.')),
  });

  return (
    <Modal title="Add attendance for a day" onClose={onClose} maxWidth="440px">
      <div className="flex flex-col gap-3">
        <Select label="Employee" required value={form.employee}
                onChange={e => setForm(f => ({ ...f, employee: e.target.value }))}>
          <option value="">Select…</option>
          {employees.filter(e => e.is_active).map(e => (
            <option key={e.id} value={e.id}>{e.name} ({e.employee_code})</option>
          ))}
        </Select>
        <Input label="Date" type="date" max={localISODate()} value={form.date}
               onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Worked hours" type="number" step="0.25" min="0" max="24" value={form.worked_hours}
                 onChange={e => setForm(f => ({ ...f, worked_hours: e.target.value }))} />
          <Select label="Status" value={form.status}
                  onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
            <option value="">From the hours</option>
            {STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
          </Select>
        </div>
        <Input label="Note" value={form.note} placeholder="e.g. Field visit, no dialer"
               onChange={e => setForm(f => ({ ...f, note: e.target.value }))} />
        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-1"
                style={{ fontSize: '0.85rem' }}
                disabled={!form.employee || !form.date || save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : 'Add day'}
        </button>
      </div>
    </Modal>
  );
}
