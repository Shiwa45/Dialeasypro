// ============================================================
// HRMS — Dashboard
//
// One backend call. The alternative (six list calls added up in the browser)
// gets the wrong answer the moment a list paginates, which it does at 25 rows.
// ============================================================
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { hrmsApi } from '../../api';
import { Spinner, StatCard } from '../../components/ui';
import { formatINRExact, localISOMonth } from '../../utils/fmt';

const thisMonth = () => localISOMonth();

export default function DashboardTab() {
  const [month, setMonth] = useState(thisMonth());

  const { data, isLoading } = useQuery({
    queryKey: ['hrms-dashboard', month],
    queryFn: () => hrmsApi.dashboard(month).then(r => r.data),
  });

  if (isLoading) return <div className="flex justify-center py-16"><Spinner /></div>;
  if (!data) return null;

  const a = data.attendance_today;
  const marked = a.present + a.absent + a.half_day + a.on_leave;

  return (
    <>
      <div className="card-brutal flex gap-2 items-end mb-4" style={{ padding: '10px 12px' }}>
        <div>
          <label className="block font-heading font-bold mb-1"
                 style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Payroll month</label>
          <input className="input-brutal" type="month" value={month}
                 onChange={e => setMonth(e.target.value)} />
        </div>
      </div>

      <div className="grid gap-3 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))' }}>
        <StatCard label="Headcount" value={data.headcount} sub="Active employees" icon="☷" />
        <StatCard label="Present today" value={a.present}
                  sub={marked ? `${marked} of ${data.headcount} marked` : 'Nobody marked yet'}
                  tone="green" icon="✓" />
        <StatCard label="On leave today" value={a.on_leave} sub={`${a.half_day} on half day`} tone="blue" icon="◷" />
        <StatCard label="Absent today" value={a.absent} sub={`${a.not_marked} not marked`} tone="red" icon="✕" />
      </div>

      <div className="grid gap-3 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))' }}>
        <StatCard label="Leave awaiting you" value={data.pending.leave} sub="Pending approval" tone="purple" icon="◷" />
        <StatCard label="Claims awaiting you" value={data.pending.expenses} sub="Pending approval" tone="purple" icon="₹" />
        <StatCard label="Payslips this month" value={data.payroll.payslips} sub="Generated" icon="▦" />
        <StatCard label="Net payroll cost" value={formatINRExact(data.payroll.net)}
                  sub={`Gross ${formatINRExact(data.payroll.gross)} · incentives ${formatINRExact(data.payroll.incentives)}`
                       + (Number(data.payroll.reimbursements ?? 0) ? ` · reimbursements ${formatINRExact(data.payroll.reimbursements!)}` : '')
                       + (Number(data.payroll.deductions ?? 0) ? ` · − deductions ${formatINRExact(data.payroll.deductions!)}` : '')}
                  tone="teal" icon="₹" />
      </div>

      {a.not_marked > 0 && (
        <div className="card-brutal" style={{ padding: '12px 14px', background: 'var(--warm-50)' }}>
          <span className="font-heading font-bold" style={{ fontSize: '0.8rem' }}>
            {a.not_marked} employee{a.not_marked === 1 ? ' has' : 's have'} no attendance row for today.
          </span>
          <p className="font-medium" style={{ fontSize: '0.75rem', color: 'var(--text-2)', marginTop: '4px' }}>
            Rows are written by the nightly dialer sync. Use <b>Sync from dialer</b> on the
            Attendance tab to build them now, or leave it — tonight's job will.
          </p>
        </div>
      )}
    </>
  );
}
