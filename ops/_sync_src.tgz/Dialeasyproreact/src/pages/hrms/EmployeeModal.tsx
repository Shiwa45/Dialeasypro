// ============================================================
// HRMS — Onboard/edit an employee
//
// An Employee record wraps an existing Agent (one-to-one) — you're not
// creating a login here, just attaching employment data to one that already
// exists. The agent picker only offers agents not yet enrolled.
// ============================================================
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { authApi, hrmsApi } from '../../api';
import { Modal, Input, useToast } from '../../components/ui';
import type { Employee } from '../../types';
import { localISODate } from '../../utils/fmt';
import { getErrorMessage } from '../../utils/errors';
import { fetchAllPages } from '../../utils/fetchAll';

const EMPLOYMENT_TYPES = [
  { value: 'full_time', label: 'Full Time' },
  { value: 'part_time', label: 'Part Time' },
  { value: 'contract', label: 'Contract' },
  { value: 'intern', label: 'Intern' },
];

export default function EmployeeModal({ employee, onClose }: { employee?: Employee; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const isEdit = !!employee;

  const { data: agentsPage } = useQuery({
    queryKey: ['agents-for-employee'],
    queryFn: () => fetchAllPages(page => authApi.listAgents({ page_size: 100, page })),
    enabled: !isEdit,
  });
  const { data: employees } = useQuery({
    queryKey: ['hrms-employees-picker'],
    queryFn: () => fetchAllPages(page => hrmsApi.employees({ page_size: 100, page })),
  });

  const enrolledAgentIds = new Set((employees?.results ?? []).map(e => e.agent));
  const availableAgents = (agentsPage?.results ?? []).filter(a => !enrolledAgentIds.has(a.id));
  const reportingOptions = (employees?.results ?? []).filter(e => e.id !== employee?.id);

  const [form, setForm] = useState({
    agent: employee?.agent ?? ('' as number | ''),
    employee_code: employee?.employee_code ?? '',
    designation: employee?.designation ?? '',
    department: employee?.department ?? '',
    employment_type: employee?.employment_type ?? 'full_time',
    reporting_to: employee?.reporting_to ?? ('' as number | ''),
    date_of_joining: employee?.date_of_joining ?? localISODate(),
    date_of_exit: employee?.date_of_exit ?? '',
    pan: employee?.pan ?? '',
    uan: employee?.uan ?? '',
    esi_number: employee?.esi_number ?? '',
    bank_account_number: employee?.bank_account_number ?? '',
    bank_ifsc: employee?.bank_ifsc ?? '',
  });

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }));

  const save = useMutation({
    mutationFn: () => {
      const payload = {
        ...form,
        reporting_to: form.reporting_to || null,
        date_of_exit: form.date_of_exit || null,
      };
      return isEdit
        ? hrmsApi.updateEmployee(employee!.id, payload)
        : hrmsApi.createEmployee({ ...payload, agent: Number(form.agent) });
    },
    onSuccess: () => {
      showToast('success', isEdit ? 'Employee updated' : 'Employee onboarded', form.employee_code);
      qc.invalidateQueries({ queryKey: ['hrms-employees'] });
      qc.invalidateQueries({ queryKey: ['hrms-employees-picker'] });
      onClose();
    },
    onError: (e: unknown) => {
      showToast('error', 'Failed', getErrorMessage(e, 'Could not save the employee.'));
    },
  });

  const canSave = (isEdit || form.agent !== '') && form.employee_code.trim().length > 0;

  return (
    <Modal title={isEdit ? 'Edit employee' : 'Onboard employee'} onClose={onClose} maxWidth="560px">
      <div className="flex flex-col gap-3">
        {!isEdit && (
          <div>
            <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
              Agent *
            </label>
            <select className="input-brutal" style={{ cursor: 'pointer' }}
                    value={form.agent} onChange={set('agent')}>
              <option value="">Select an agent…</option>
              {availableAgents.map(a => <option key={a.id} value={a.id}>{a.name} ({a.email})</option>)}
            </select>
            {agentsPage && availableAgents.length === 0 && (
              <p style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginTop: '4px' }}>
                Every agent is already enrolled in HRMS.
              </p>
            )}
          </div>
        )}
        {isEdit && (
          <div className="card-brutal" style={{ padding: '10px 12px', background: 'var(--paper)' }}>
            <span className="font-heading font-bold" style={{ fontSize: '0.85rem' }}>{employee!.name}</span>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-2)', marginLeft: '8px' }}>{employee!.email}</span>
          </div>
        )}

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Employee code" required value={form.employee_code} onChange={set('employee_code')} placeholder="EMP-001" />
          <Input label="Date of joining" type="date" value={form.date_of_joining} onChange={set('date_of_joining')} />
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Designation" value={form.designation} onChange={set('designation')} placeholder="Sales Executive" />
          <Input label="Department" value={form.department} onChange={set('department')} placeholder="Sales" />
        </div>

        {isEdit && (
          <Input label="Date of exit (leave blank if still active)" type="date"
                 value={form.date_of_exit} onChange={set('date_of_exit')} />
        )}

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <div>
            <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
              Employment type
            </label>
            <select className="input-brutal" style={{ cursor: 'pointer' }}
                    value={form.employment_type} onChange={set('employment_type')}>
              {EMPLOYMENT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </div>
          <div>
            <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
              Reports to
            </label>
            <select className="input-brutal" style={{ cursor: 'pointer' }}
                    value={form.reporting_to} onChange={set('reporting_to')}>
              <option value="">— None —</option>
              {reportingOptions.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
            </select>
          </div>
        </div>

        <div style={{ borderTop: '1px solid var(--line)', paddingTop: '10px', marginTop: '4px' }}>
          <span className="font-heading font-bold" style={{ fontSize: '0.72rem', letterSpacing: '0.06em' }}>
            STATUTORY & BANKING (OPTIONAL)
          </span>
        </div>
        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="PAN" value={form.pan} onChange={set('pan')} placeholder="ABCDE1234F" />
          <Input label="UAN" value={form.uan} onChange={set('uan')} />
        </div>
        <Input label="ESI number" value={form.esi_number} onChange={set('esi_number')} />
        <div className="grid gap-3" style={{ gridTemplateColumns: '2fr 1fr' }}>
          <Input label="Bank account number" value={form.bank_account_number} onChange={set('bank_account_number')} />
          <Input label="IFSC" value={form.bank_ifsc} onChange={set('bank_ifsc')} />
        </div>

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-2"
                style={{ fontSize: '0.85rem' }}
                disabled={!canSave || save.isPending}
                onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : isEdit ? 'Save changes' : 'Onboard employee'}
        </button>
      </div>
    </Modal>
  );
}
