// ============================================================
// HRMS — Employee roster
//
// Row click opens the edit modal; the actions column carries the exit path.
// Exiting is a soft delete server-side: a hard one would cascade through
// finalized payslips and approved claims, which a company has to be able to
// produce years later.
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { hrmsApi } from '../../api';
import { Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { AddButton } from '../../components/DataTable';
import { ConfirmDialog, Select, StatCard, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate } from '../../utils/fmt';
import EmployeeModal from './EmployeeModal';
import type { Employee } from '../../types';
import { fetchAllPages } from '../../utils/fetchAll';

export default function EmployeesTab() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canManage = can(Cap.HRMS_MANAGE);

  const [search, setSearch] = useState('');
  const [department, setDepartment] = useState('');
  const [active, setActive] = useState('true');
  const [editing, setEditing] = useState<Employee | null>(null);
  const [adding, setAdding] = useState(false);
  const [exiting, setExiting] = useState<Employee | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['hrms-employees'],
    queryFn: () => fetchAllPages(page => hrmsApi.employees({ page_size: 100, page })),
  });

  const exit = useMutation({
    mutationFn: (id: number) => hrmsApi.deleteEmployee(id),
    onSuccess: () => {
      showToast('success', 'Exited', 'The employee is marked inactive; their records are kept.');
      qc.invalidateQueries({ queryKey: ['hrms-employees'] });
      qc.invalidateQueries({ queryKey: ['hrms-dashboard'] });
      setExiting(null);
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const all = data?.results ?? [];
  const departments = useMemo(
    () => [...new Set(all.map(e => e.department).filter(Boolean))].sort(),
    [all],
  );

  const rows = useMemo(() => {
    let list = all;
    if (active) list = list.filter(e => String(e.is_active) === active);
    if (department) list = list.filter(e => e.department === department);
    const q = search.trim().toLowerCase();
    if (q) list = list.filter(e =>
      e.name?.toLowerCase().includes(q) ||
      e.employee_code?.toLowerCase().includes(q) ||
      e.designation?.toLowerCase().includes(q) ||
      e.email?.toLowerCase().includes(q));
    return list;
  }, [all, search, department, active]);

  const columns: Column<Employee>[] = [
    { key: 'employee_code', header: 'Code', sortable: true,
      render: e => <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{e.employee_code}</span> },
    { key: 'name', header: 'Name', sortable: true,
      render: e => (
        <>
          <b>{e.name}</b>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>{e.email}</div>
        </>
      ) },
    { key: 'role', header: 'Role', sortable: true, render: e => e.role?.replace('_', ' ') },
    { key: 'designation', header: 'Designation', sortable: true, render: e => e.designation || '—' },
    { key: 'department', header: 'Department', sortable: true, render: e => e.department || '—' },
    { key: 'employment_type', header: 'Type', render: e => e.employment_type?.replace('_', ' ') },
    { key: 'reporting_to_name', header: 'Reports to', render: e => e.reporting_to_name || '—' },
    { key: 'date_of_joining', header: 'Joined', sortable: true, render: e => fmtDate(e.date_of_joining) },
    { key: 'is_active', header: 'Status',
      render: e => (
        <span className="flex items-center gap-1" style={{ flexWrap: 'wrap' }}>
          <StatusPill value={e.is_active ? 'active' : 'inactive'} />
          {e.is_active && e.login_active === false && (
            <span title="Their CRM login is deactivated but they are still on payroll. Exit them if they have left."
                  style={{ fontSize: '0.68rem', fontWeight: 700, color: 'var(--hot)' }}>
              LOGIN OFF
            </span>
          )}
        </span>
      ) },
  ];

  const activeCount = all.filter(e => e.is_active).length;

  return (
    <>
      <div className="grid gap-3 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))' }}>
        <StatCard label="Active employees" value={activeCount} sub={`${all.length - activeCount} exited`} icon="☷" />
        <StatCard label="Departments" value={departments.length || '—'}
                  sub={departments.slice(0, 3).join(', ') || 'None set'} icon="▣" />
      </div>

      {canManage && <AddButton label="Onboard employee" onClick={() => setAdding(true)} />}

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search name, code, designation…">
        <Select label="Department" value={department} onChange={e => setDepartment(e.target.value)}>
          <option value="">All departments</option>
          {departments.map(d => <option key={d} value={d}>{d}</option>)}
        </Select>
        <Select label="Status" value={active} onChange={e => setActive(e.target.value)}>
          <option value="true">Active</option>
          <option value="false">Exited</option>
          <option value="">All</option>
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={e => e.id}
        isLoading={isLoading}
        pageSize={25}
        minWidth="900px"
        onRowClick={canManage ? e => setEditing(e) : undefined}
        actions={canManage ? e => (
          <>
            <RowAction label="Edit" onClick={() => setEditing(e)} />
            {e.is_active && <RowAction label="Exit" danger onClick={() => setExiting(e)} />}
          </>
        ) : undefined}
        empty={{
          icon: '☷', title: 'No employees onboarded',
          message: 'Onboard an existing agent to enable their attendance, leave and payroll.',
          action: canManage ? { label: 'Onboard employee', onClick: () => setAdding(true) } : undefined,
        }}
      />

      {adding && <EmployeeModal onClose={() => setAdding(false)} />}
      {editing && <EmployeeModal employee={editing} onClose={() => setEditing(null)} />}

      {exiting && (
        <ConfirmDialog
          title={`Exit ${exiting.name}?`}
          message={`${exiting.employee_code} is marked inactive and dated today. Their attendance, leave, claims and payslips are kept — a company has to be able to produce those years later — and they stop appearing in payroll runs. You can undo this by editing the employee.`}
          confirmLabel="Exit employee"
          danger
          onConfirm={() => exit.mutate(exiting.id)}
          onCancel={() => setExiting(null)}
        />
      )}
    </>
  );
}
