// ============================================================
// HRMS — Expense claims
//
// The submit path was missing entirely: claims could be approved or rejected,
// but there was no way to raise one from the app — the endpoint existed and
// the API layer didn't even wrap it. Receipts upload as multipart.
// ============================================================
import { useMyEmployee } from '../../hooks/useMyEmployee';
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { hrmsApi } from '../../api';
import { Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { Input, Modal, Select, Textarea, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINRExact, localISODate } from '../../utils/fmt';
import type { ExpenseClaim } from '../../types';
import { fetchAllPages } from '../../utils/fetchAll';

const CATEGORIES = [
  { value: 'travel', label: 'Travel' },
  { value: 'food', label: 'Food' },
  { value: 'accommodation', label: 'Accommodation' },
  { value: 'communication', label: 'Communication' },
  { value: 'other', label: 'Other' },
];

export default function ExpensesTab() {
  // Only someone on the HRMS roster can punch in, apply for leave or claim.
  const { enrolled } = useMyEmployee();
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canApprove = can(Cap.HRMS_APPROVE);
  const canManage = can(Cap.HRMS_MANAGE);

  const [status, setStatus] = useState('');
  const [category, setCategory] = useState('');
  const [search, setSearch] = useState('');
  const [claiming, setClaiming] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['hrms-expenses', status],
    queryFn: () => fetchAllPages(page => hrmsApi.expenses({ status: status || undefined, page_size: 100, page })),
  });

  const decide = useMutation({
    mutationFn: ({ id, action }: { id: number; action: 'approve' | 'reject' }) =>
      hrmsApi.decideExpense(id, action),
    onSuccess: (_r, v) => {
      showToast('success', 'Done', `Claim ${v.action}d.`);
      qc.invalidateQueries({ queryKey: ['hrms-expenses'] });
      qc.invalidateQueries({ queryKey: ['hrms-dashboard'] });
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const rows = useMemo(() => {
    let all = data?.results ?? [];
    if (category) all = all.filter(x => x.category === category);
    const q = search.trim().toLowerCase();
    return q ? all.filter(x => x.employee_name?.toLowerCase().includes(q)
                            || x.description?.toLowerCase().includes(q)) : all;
  }, [data, search, category]);

  const total = rows.reduce((sum, r) => sum + Number(r.amount || 0), 0);
  const pendingTotal = rows.filter(r => r.status === 'pending')
                           .reduce((sum, r) => sum + Number(r.amount || 0), 0);

  const columns: Column<ExpenseClaim>[] = [
    { key: 'date', header: 'Date', sortable: true, render: x => fmtDate(x.date) },
    { key: 'employee_name', header: 'Employee', sortable: true, render: x => x.employee_name },
    { key: 'category', header: 'Category', sortable: true,
      render: x => CATEGORIES.find(c => c.value === x.category)?.label ?? x.category },
    { key: 'description', header: 'Description',
      render: x => <span style={{ color: 'var(--text-2)' }}>{x.description || '—'}</span> },
    { key: 'amount', header: 'Amount', numeric: true, sortable: true,
      sortValue: x => Number(x.amount), render: x => formatINRExact(x.amount) },
    { key: 'receipt', header: 'Receipt',
      render: x => x.receipt
        ? <a href={x.receipt} target="_blank" rel="noreferrer"
             onClick={e => e.stopPropagation()}
             style={{ textDecoration: 'underline', fontSize: '0.75rem' }}>View</a>
        : <span style={{ color: 'var(--text-3)' }}>—</span> },
    { key: 'status', header: 'Status', sortable: true, render: x => <StatusPill value={x.status} /> },
  ];

  return (
    <>
      <div className="flex gap-2 mb-3">
        {/* HR can file a claim on an employee's behalf. */}
        {(enrolled || canManage) && (
          <button className="btn-brutal btn-primary px-3 py-2 font-heading font-black"
                  style={{ fontSize: '0.8rem' }} onClick={() => setClaiming(true)}>
            {enrolled ? '+ Submit a claim' : '+ Claim for an employee'}
          </button>
        )}
      </div>

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search employee or description…">
        <Select label="Status" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
        </Select>
        <Select label="Category" value={category} onChange={e => setCategory(e.target.value)}>
          <option value="">All categories</option>
          {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={x => x.id}
        isLoading={isLoading}
        pageSize={25}
        actions={x => canApprove && x.status === 'pending' ? (
          <>
            <RowAction label="Approve" positive onClick={() => decide.mutate({ id: x.id, action: 'approve' })}
                       disabled={decide.isPending} />
            <RowAction label="Reject" danger onClick={() => decide.mutate({ id: x.id, action: 'reject' })}
                       disabled={decide.isPending} />
          </>
        ) : null}
        empty={{ icon: '₹', title: 'No expense claims', message: 'Submit one above, or wait for your team to raise one.' }}
        footer={rows.length ? (
          <tr style={{ borderTop: '2px solid var(--line)', background: 'var(--paper)' }}>
            <td colSpan={4} style={{ padding: '10px 12px', fontSize: '0.75rem' }} className="font-heading font-bold">
              {rows.length} CLAIM{rows.length === 1 ? '' : 'S'}
              {pendingTotal > 0 && ` · ${formatINRExact(pendingTotal)} AWAITING APPROVAL`}
            </td>
            <td style={{ padding: '10px 12px', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', textAlign: 'right', fontWeight: 700 }}>
              {formatINRExact(total)}
            </td>
            <td colSpan={3} />
          </tr>
        ) : undefined}
      />

      {claiming && <ClaimModal onClose={() => setClaiming(false)} forOthers={canManage} />}
    </>
  );
}

/* ---- Submit a claim ----------------------------------------- */
function ClaimModal({ onClose, forOthers }: { onClose: () => void; forOthers: boolean }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { data: me } = useQuery({
    queryKey: ['hrms-me'],
    queryFn: () => hrmsApi.me().then(r => r.data),
    retry: false,
  });
  const [employee, setEmployee] = useState('');
  const { data: employees } = useQuery({
    queryKey: ['hrms-employees-active'],
    queryFn: () => fetchAllPages(page => hrmsApi.employees({ active: 'true', page_size: 100, page })),
    enabled: forOthers,
  });
  // The company's limits, so the form says what the server will refuse.
  const { data: policy } = useQuery({
    queryKey: ['hrms-policy'],
    queryFn: () => hrmsApi.policy().then(r => r.data),
  });
  const [form, setForm] = useState({
    date: localISODate(),
    category: 'travel',
    amount: '',
    description: '',
  });
  const [receipt, setReceipt] = useState<File | null>(null);

  const submit = useMutation({
    mutationFn: () => {
      // Multipart rather than JSON because of the receipt. Fields are appended
      // individually so an absent file simply isn't sent, rather than being
      // sent as the string "null" — which DRF's FileField would reject.
      const fd = new FormData();
      if (forOthers && employee && Number(employee) !== me?.id) fd.append('employee', employee);
      fd.append('date', form.date);
      fd.append('category', form.category);
      fd.append('amount', form.amount);
      fd.append('description', form.description);
      if (receipt) fd.append('receipt', receipt);
      return hrmsApi.createExpense(fd);
    },
    onSuccess: () => {
      showToast('success', 'Submitted', 'Your claim is pending approval.');
      qc.invalidateQueries({ queryKey: ['hrms-expenses'] });
      onClose();
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const amount = Number(form.amount);
  const maxAmount = policy ? Number(policy.expense_max_amount) : Infinity;
  const receiptAbove = policy?.expense_receipt_above != null ? Number(policy.expense_receipt_above) : null;
  const needsReceipt = receiptAbove !== null && amount > receiptAbove && !receipt;
  const problem = form.date > localISODate() ? 'An expense can\'t be dated in the future.'
    : amount > maxAmount ? `The most one claim can be is ${formatINRExact(maxAmount)}.`
    : needsReceipt ? `Attach a receipt for claims above ${formatINRExact(receiptAbove!)}.`
    : '';
  const valid = amount > 0 && !!form.date && !problem && (!forOthers || !!employee || !!me?.id);

  return (
    <Modal title="Submit an expense claim" onClose={onClose} maxWidth="460px">
      <div className="flex flex-col gap-3">
        {forOthers && (
          <Select label="Employee" required value={employee} onChange={e => setEmployee(e.target.value)}>
            <option value="">{me?.id ? 'Myself' : 'Select an employee…'}</option>
            {(employees?.results ?? []).filter(e => e.id !== me?.id).map(e => (
              <option key={e.id} value={e.id}>{e.name} ({e.employee_code})</option>
            ))}
          </Select>
        )}
        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Date" type="date" required value={form.date} max={localISODate()}
                 onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
          <Input label="Amount (₹)" type="number" step="0.01" min="0.01" required value={form.amount}
                 onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} placeholder="1250.00" />
        </div>

        <Select label="Category" value={form.category}
                onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
          {CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
        </Select>

        <Textarea label="Description" rows={3} value={form.description}
                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  placeholder="Cab from airport to client site" />

        <div>
          <label className="block font-heading font-bold mb-1"
                 style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Receipt</label>
          <input className="input-brutal" type="file" accept="image/*,application/pdf"
                 onChange={e => setReceipt(e.target.files?.[0] ?? null)} />
          {receipt && (
            <p style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginTop: '4px' }}>
              {receipt.name} · {(receipt.size / 1024).toFixed(0)} KB
            </p>
          )}
        </div>
        {problem && form.amount !== '' && (
          <p style={{ fontSize: '0.72rem', color: 'var(--hot)' }}>{problem}</p>
        )}

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-1"
                style={{ fontSize: '0.85rem' }}
                disabled={!valid || submit.isPending} onClick={() => submit.mutate()}>
          {submit.isPending ? 'Submitting…' : 'Submit claim'}
        </button>
      </div>
    </Modal>
  );
}
