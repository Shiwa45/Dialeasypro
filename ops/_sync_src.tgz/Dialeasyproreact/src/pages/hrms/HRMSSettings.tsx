// ============================================================
// HRMS — Settings: holidays, leave types, incentive rules, salary structures.
//
// Configuration masters an admin sets up once and revisits rarely. Each day
// is paid at the salary structure in force that day, so a raise is a new
// dated row. A structure can be corrected or removed until a finalized
// payslip has used it; after that it is locked (the server refuses).
// Policy holds the present / half-day hours and the expense-claim limits.
// ============================================================
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { hrmsApi } from '../../api';
import { ConfirmDialog, EmptyState, Input, Modal, Spinner, useToast } from '../../components/ui';
import { fmtDate, formatINR, localISODate, localISOMonth } from '../../utils/fmt';
import type {
  Holiday, IncentiveMetric, IncentiveRuleConfig, LeaveTypeConfig, Employee, SalaryStructureConfig,
} from '../../types';
import type { HrmsPolicy } from '../../api';
import { getErrorMessage } from '../../utils/errors';
import { fetchAllPages } from '../../utils/fetchAll';

type Section = 'holidays' | 'leave-types' | 'incentives' | 'salary' | 'policy';

const SECTIONS: Array<{ id: Section; label: string }> = [
  { id: 'holidays',    label: 'Holidays' },
  { id: 'leave-types', label: 'Leave Types' },
  { id: 'incentives',  label: 'Incentive Rules' },
  { id: 'salary',      label: 'Salary Structures' },
  { id: 'policy',      label: 'Policy' },
];

export default function HRMSSettings() {
  const [section, setSection] = useState<Section>('holidays');

  return (
    <div>
      <div className="flex gap-2 flex-wrap mb-4">
        {SECTIONS.map(s => (
          <button key={s.id} onClick={() => setSection(s.id)}
                  className="btn-brutal px-3 py-1.5 font-heading font-bold"
                  style={{ fontSize: '0.75rem', background: section === s.id ? 'var(--brass-50)' : 'var(--surface)' }}>
            {s.label}
          </button>
        ))}
      </div>
      {section === 'holidays'    && <HolidaysSection />}
      {section === 'leave-types' && <LeaveTypesSection />}
      {section === 'incentives'  && <IncentiveRulesSection />}
      {section === 'salary'      && <SalaryStructuresSection />}
      {section === 'policy'      && <PolicySection />}
    </div>
  );
}

const CELL: React.CSSProperties = { padding: '8px 10px', fontSize: '0.8rem' };

function Table({ headers, children }: { headers: string[]; children: React.ReactNode }) {
  return (
    <div className="card-brutal" style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '520px' }}>
        <thead>
          <tr style={{ borderBottom: '1px solid var(--line)' }}>
            {headers.map(h => (
              <th key={h} className="th bare">
                {h.toUpperCase()}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

// ---- Holidays -------------------------------------------------
function HolidaysSection() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [date, setDate] = useState('');
  const [name, setName] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<Holiday | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['hrms-holidays'],
    queryFn: () => hrmsApi.holidays().then(r => r.data),
  });

  const add = useMutation({
    mutationFn: () => hrmsApi.createHoliday({ date, name }),
    onSuccess: () => {
      showToast('success', 'Added', name);
      setDate(''); setName('');
      qc.invalidateQueries({ queryKey: ['hrms-holidays'] });
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not add the holiday.')),
  });

  const remove = useMutation({
    mutationFn: (id: number) => hrmsApi.deleteHoliday(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['hrms-holidays'] }); setConfirmDelete(null); },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not remove the holiday.')),
  });

  if (isLoading) return <div className="flex justify-center py-10"><Spinner /></div>;
  const rows = [...(data ?? [])].sort((a, b) => a.date.localeCompare(b.date));

  return (
    <>
      <div className="card-brutal flex gap-2 items-end mb-4" style={{ padding: '12px', flexWrap: 'wrap' }}>
        <Input label="Date" type="date" value={date} onChange={e => setDate(e.target.value)} />
        <div style={{ flex: 1, minWidth: '160px' }}>
          <Input label="Name" value={name} onChange={e => setName(e.target.value)} placeholder="Diwali" />
        </div>
        <button className="btn-brutal btn-primary px-3 py-2 font-heading font-bold" style={{ fontSize: '0.78rem' }}
                disabled={!date || !name.trim() || add.isPending} onClick={() => add.mutate()}>
          + Add
        </button>
      </div>

      {!rows.length ? (
        <EmptyState icon="◷" title="No holidays configured" message="Add your company's holiday calendar — it counts as a paid day in attendance and payroll." />
      ) : (
        <Table headers={['Date', 'Name', '']}>
          {rows.map(h => (
            <tr key={h.id} style={{ borderBottom: '1px solid var(--line)' }}>
              <td style={CELL}>{fmtDate(h.date)}</td>
              <td style={CELL}>{h.name}</td>
              <td style={{ ...CELL, textAlign: 'right' }}>
                <button onClick={() => setConfirmDelete(h)}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--hot)', fontSize: '0.85rem' }}>
                  Remove
                </button>
              </td>
            </tr>
          ))}
        </Table>
      )}

      {confirmDelete && (
        <ConfirmDialog title="Remove this holiday?" message={`${confirmDelete.name} — ${fmtDate(confirmDelete.date)}`}
                       confirmLabel="Remove" danger
                       onConfirm={() => remove.mutate(confirmDelete.id)}
                       onCancel={() => setConfirmDelete(null)} />
      )}
    </>
  );
}

// ---- Leave Types ------------------------------------------------
function LeaveTypesSection() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [editing, setEditing] = useState<LeaveTypeConfig | 'new' | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['hrms-leave-types-config'],
    // Switched-off types too, so one removed by mistake can be switched back on.
    queryFn: () => hrmsApi.leaveTypes(true).then(r => r.data),
  });

  const invalidateTypes = () => {
    qc.invalidateQueries({ queryKey: ['hrms-leave-types-config'] });
    qc.invalidateQueries({ queryKey: ['hrms-leave-types'] });
  };
  const deactivate = useMutation({
    mutationFn: (id: number) => hrmsApi.deactivateLeaveType(id),
    onSuccess: () => { showToast('success', 'Deactivated', ''); invalidateTypes(); },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not deactivate.')),
  });
  const reactivate = useMutation({
    mutationFn: (id: number) => hrmsApi.updateLeaveType(id, { is_active: true }),
    onSuccess: () => { showToast('success', 'Switched on', ''); invalidateTypes(); },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not switch it on.')),
  });

  if (isLoading) return <div className="flex justify-center py-10"><Spinner /></div>;
  const rows = data ?? [];

  return (
    <>
      <div className="flex justify-end mb-3">
        <button className="btn-brutal btn-primary px-3 py-2 font-heading font-bold" style={{ fontSize: '0.78rem' }}
                onClick={() => setEditing('new')}>
          + Add leave type
        </button>
      </div>

      {!rows.length ? (
        <EmptyState icon="◷" title="No leave types" message="Add Casual Leave, Sick Leave, Earned Leave — whatever your policy offers." />
      ) : (
        <Table headers={['Name', 'Annual quota', 'Paid', 'Carry forward', 'Status', '']}>
          {rows.map(lt => (
            <tr key={lt.id} style={{ borderBottom: '1px solid var(--line)' }}>
              <td style={CELL}>{lt.name}</td>
              <td style={{ ...CELL, fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{lt.annual_quota_days}</td>
              <td style={CELL}>{lt.is_paid ? 'Yes' : 'No'}</td>
              <td style={CELL}>{lt.carry_forward ? 'Yes' : 'No'}</td>
              <td style={CELL}>{lt.is_active ? 'Active' : 'Inactive'}</td>
              <td style={{ ...CELL, textAlign: 'right', whiteSpace: 'nowrap' }}>
                <button onClick={() => setEditing(lt)}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '0.85rem', marginRight: '10px' }}>
                  Edit
                </button>
                {lt.is_active ? (
                  <button onClick={() => deactivate.mutate(lt.id)}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--hot)', fontSize: '0.85rem' }}>
                    Deactivate
                  </button>
                ) : (
                  <button onClick={() => reactivate.mutate(lt.id)} disabled={reactivate.isPending}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--brand)', fontSize: '0.85rem' }}>
                    Switch on
                  </button>
                )}
              </td>
            </tr>
          ))}
        </Table>
      )}

      {editing && <LeaveTypeModal leaveType={editing === 'new' ? undefined : editing} onClose={() => setEditing(null)} />}
    </>
  );
}

function LeaveTypeModal({ leaveType, onClose }: { leaveType?: LeaveTypeConfig; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const isEdit = !!leaveType;
  const [name, setName] = useState(leaveType?.name ?? '');
  const [quota, setQuota] = useState(leaveType?.annual_quota_days ?? '12');
  const [isPaid, setIsPaid] = useState(leaveType?.is_paid ?? true);
  const [carryForward, setCarryForward] = useState(leaveType?.carry_forward ?? false);

  const save = useMutation({
    mutationFn: () => {
      const payload = { name, annual_quota_days: quota, is_paid: isPaid, carry_forward: carryForward };
      return isEdit ? hrmsApi.updateLeaveType(leaveType!.id, payload) : hrmsApi.createLeaveType(payload);
    },
    onSuccess: () => {
      showToast('success', 'Saved', name);
      qc.invalidateQueries({ queryKey: ['hrms-leave-types-config'] });
      qc.invalidateQueries({ queryKey: ['hrms-leave-types'] });
      onClose();
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not save the leave type.')),
  });

  return (
    <Modal title={isEdit ? 'Edit leave type' : 'Add leave type'} onClose={onClose} maxWidth="420px">
      <div className="flex flex-col gap-3">
        <Input label="Name" value={name} onChange={e => setName(e.target.value)} placeholder="Casual Leave" />
        <Input label="Annual quota (days)" type="number" min="0" step="0.5" value={quota} onChange={e => setQuota(e.target.value)} />
        <label className="flex items-center gap-2" style={{ fontSize: '0.82rem', cursor: 'pointer' }}>
          <input type="checkbox" checked={isPaid} onChange={e => setIsPaid(e.target.checked)} /> Paid leave
        </label>
        <label className="flex items-center gap-2" style={{ fontSize: '0.82rem', cursor: 'pointer' }}>
          <input type="checkbox" checked={carryForward} onChange={e => setCarryForward(e.target.checked)} /> Carries forward to next year
        </label>
        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-2" style={{ fontSize: '0.85rem' }}
                disabled={!name.trim() || save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : 'Save'}
        </button>
      </div>
    </Modal>
  );
}

// ---- Incentive Rules ---------------------------------------------
const METRICS = [
  { value: 'converted_leads', label: 'Converted Leads', unit: '₹ per lead' },
  { value: 'connected_calls', label: 'Connected Calls', unit: '₹ per call' },
  { value: 'talk_minutes', label: 'Talk Minutes', unit: '₹ per minute' },
  { value: 'revenue', label: 'Revenue (deal value)', unit: '% of revenue' },
];
const ROLES = ['admin', 'manager', 'hr', 'accounts', 'recruiter', 'senior_agent', 'agent', 'readonly'];

function IncentiveRulesSection() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [editing, setEditing] = useState<IncentiveRuleConfig | 'new' | null>(null);
  const [month, setMonth] = useState(localISOMonth());

  const { data, isLoading } = useQuery({
    queryKey: ['hrms-incentive-rules-config'],
    queryFn: () => hrmsApi.incentiveRules().then(r => r.data),
  });

  const deactivate = useMutation({
    mutationFn: (id: number) => hrmsApi.deactivateIncentiveRule(id),
    onSuccess: () => {
      showToast('success', 'Deactivated', 'Its unpaid earnings were removed.');
      qc.invalidateQueries({ queryKey: ['hrms-incentive-rules-config'] });
      qc.invalidateQueries({ queryKey: ['hrms-incentives'] });
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not deactivate.')),
  });

  const compute = useMutation({
    mutationFn: () => hrmsApi.computeIncentives(month),
    onSuccess: () => showToast('success', 'Computed', `Incentives recomputed for ${month}.`),
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not compute incentives.')),
  });

  if (isLoading) return <div className="flex justify-center py-10"><Spinner /></div>;
  const rows = data ?? [];

  return (
    <>
      <div className="card-brutal flex gap-2 items-end mb-4 flex-wrap" style={{ padding: '12px' }}>
        <Input label="Month" type="month" value={month} onChange={e => setMonth(e.target.value)} />
        <button className="btn-brutal btn-secondary px-3 py-2 font-heading font-bold" style={{ fontSize: '0.78rem' }}
                disabled={compute.isPending} onClick={() => compute.mutate()}>
          {compute.isPending ? 'Computing…' : 'Compute incentives for this month'}
        </button>
        <div style={{ flex: 1 }} />
        <button className="btn-brutal btn-primary px-3 py-2 font-heading font-bold" style={{ fontSize: '0.78rem' }}
                onClick={() => setEditing('new')}>
          + Add rule
        </button>
      </div>

      {!rows.length ? (
        <EmptyState icon="₹" title="No incentive rules" message="Define what earns a payout — converted leads, connected calls, talk time, or revenue." />
      ) : (
        <Table headers={['Name', 'Metric', 'Rate', 'Min units', 'Cap', 'Status', '']}>
          {rows.map(r => (
            <tr key={r.id} style={{ borderBottom: '1px solid var(--line)' }}>
              <td style={CELL}>{r.name}</td>
              <td style={CELL}>{METRICS.find(m => m.value === r.metric)?.label ?? r.metric}</td>
              <td style={{ ...CELL, fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>
                {r.metric === 'revenue' ? `${r.per_unit_amount}%` : formatINR(r.per_unit_amount)}
              </td>
              <td style={{ ...CELL, fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{r.min_units}</td>
              <td style={{ ...CELL, fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{r.max_payout ? formatINR(r.max_payout) : '—'}</td>
              <td style={CELL}>{r.is_active ? 'Active' : 'Inactive'}</td>
              <td style={{ ...CELL, textAlign: 'right', whiteSpace: 'nowrap' }}>
                <button onClick={() => setEditing(r)}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '0.85rem', marginRight: '10px' }}>
                  Edit
                </button>
                {r.is_active && (
                  <button onClick={() => {
                            if (window.confirm(`Deactivate "${r.name}"? Earnings it computed that no finalized payslip has paid are removed.`))
                              deactivate.mutate(r.id);
                          }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--hot)', fontSize: '0.85rem' }}>
                    Deactivate
                  </button>
                )}
              </td>
            </tr>
          ))}
        </Table>
      )}

      {editing && <IncentiveRuleModal rule={editing === 'new' ? undefined : editing} onClose={() => setEditing(null)} />}
    </>
  );
}

function IncentiveRuleModal({ rule, onClose }: { rule?: IncentiveRuleConfig; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const isEdit = !!rule;
  const [name, setName] = useState(rule?.name ?? '');
  const [metric, setMetric] = useState(rule?.metric ?? 'converted_leads');
  const [perUnit, setPerUnit] = useState(rule?.per_unit_amount ?? '');
  const [minUnits, setMinUnits] = useState(rule?.min_units ?? '0');
  const [maxPayout, setMaxPayout] = useState(rule?.max_payout ?? '');
  const [roles, setRoles] = useState<string[]>(rule?.applies_to_roles ?? ['agent', 'senior_agent']);

  const toggleRole = (role: string) =>
    setRoles(rs => rs.includes(role) ? rs.filter(r => r !== role) : [...rs, role]);

  const save = useMutation({
    mutationFn: () => {
      const payload = {
        name, metric, per_unit_amount: perUnit, min_units: minUnits,
        max_payout: maxPayout || null, applies_to_roles: roles,
      };
      return isEdit ? hrmsApi.updateIncentiveRule(rule!.id, payload) : hrmsApi.createIncentiveRule(payload);
    },
    onSuccess: () => {
      showToast('success', 'Saved', name);
      qc.invalidateQueries({ queryKey: ['hrms-incentive-rules-config'] });
      onClose();
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not save the rule.')),
  });

  const unit = METRICS.find(m => m.value === metric)?.unit ?? '';

  return (
    <Modal title={isEdit ? 'Edit incentive rule' : 'Add incentive rule'} onClose={onClose} maxWidth="460px">
      <div className="flex flex-col gap-3">
        <Input label="Name" value={name} onChange={e => setName(e.target.value)} placeholder="Conversion bonus" />
        <div>
          <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Metric</label>
          <select className="input-brutal" style={{ cursor: 'pointer' }} value={metric}
                  onChange={e => setMetric(e.target.value as IncentiveMetric)}>
            {METRICS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
          </select>
        </div>
        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label={`Rate (${unit})`} type="number" min="0" max={metric === 'revenue' ? 100 : undefined}
                 step="0.01" value={perUnit} onChange={e => setPerUnit(e.target.value)} />
          <Input label="Min units before payout" type="number" min="0" step="0.01" value={minUnits} onChange={e => setMinUnits(e.target.value)} />
        </div>
        <Input label="Max payout per month (optional)" type="number" min="0" step="0.01" value={maxPayout} onChange={e => setMaxPayout(e.target.value)} />
        <div>
          <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Applies to</label>
          <div className="flex gap-3 flex-wrap">
            {ROLES.map(role => (
              <label key={role} className="flex items-center gap-1.5" style={{ fontSize: '0.78rem', cursor: 'pointer' }}>
                <input type="checkbox" checked={roles.includes(role)} onChange={() => toggleRole(role)} />
                {role.replace('_', ' ')}
              </label>
            ))}
          </div>
        </div>
        {Number(perUnit) >= 10000 && metric !== 'revenue' && (
          <p style={{ fontSize: '0.72rem', color: 'var(--hot)' }}>
            That pays {formatINR(perUnit)} for every single {unit.replace('₹ per ', '')}. Double-check the amount.
          </p>
        )}
        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-2" style={{ fontSize: '0.85rem' }}
                disabled={!name.trim() || !perUnit || save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : 'Save'}
        </button>
      </div>
    </Modal>
  );
}

// ---- Salary Structures ---------------------------------------------
function SalaryStructuresSection() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [employeeId, setEmployeeId] = useState<number | ''>('');
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<SalaryStructureConfig | null>(null);
  const [deleting, setDeleting] = useState<SalaryStructureConfig | null>(null);

  const remove = useMutation({
    mutationFn: (id: number) => hrmsApi.deleteSalaryStructure(id),
    onSuccess: () => {
      showToast('success', 'Removed', '');
      qc.invalidateQueries({ queryKey: ['hrms-salary-structures'] });
      setDeleting(null);
    },
    onError: (e: unknown) => { showToast('error', 'Failed', getErrorMessage(e, 'Could not remove.')); setDeleting(null); },
  });

  const { data: employees } = useQuery({
    queryKey: ['hrms-employees-for-salary'],
    queryFn: () => fetchAllPages(page => hrmsApi.employees({ page_size: 100, page })).then(r => r.results),
  });

  const { data: structures, isLoading } = useQuery({
    queryKey: ['hrms-salary-structures', employeeId],
    queryFn: () => hrmsApi.salaryStructures(employeeId ? Number(employeeId) : undefined).then(r => r.data),
  });

  return (
    <>
      <div className="card-brutal flex gap-2 items-end mb-4 flex-wrap" style={{ padding: '12px' }}>
        <div style={{ minWidth: '220px' }}>
          <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
            Employee
          </label>
          <select className="input-brutal" style={{ cursor: 'pointer' }}
                  value={employeeId} onChange={e => setEmployeeId(e.target.value ? Number(e.target.value) : '')}>
            <option value="">All employees</option>
            {(employees ?? []).map(e => <option key={e.id} value={e.id}>{e.name} ({e.employee_code})</option>)}
          </select>
        </div>
        <button className="btn-brutal btn-primary px-3 py-2 font-heading font-bold" style={{ fontSize: '0.78rem' }}
                disabled={!employees?.length} onClick={() => setAdding(true)}>
          + Add structure
        </button>
      </div>

      <p style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginBottom: '12px' }}>
        A raise is a new row from the date it starts — each day is paid at the structure in force that
        day. A typo can be fixed with Edit until a finalized payslip has used the structure.
      </p>

      {isLoading ? <div className="flex justify-center py-10"><Spinner /></div> : (
        !structures?.length ? (
          <EmptyState icon="₹" title="No salary structures" message="Add one so payroll knows what to pay." />
        ) : (
          <Table headers={['Employee', 'Effective from', 'Gross', 'Deductions', '']}>
            {structures.map(s => (
              <tr key={s.id} style={{ borderBottom: '1px solid var(--line)' }}>
                <td style={CELL}>{employees?.find(e => e.id === s.employee)?.name ?? s.employee}</td>
                <td style={CELL}>{fmtDate(s.effective_from)}</td>
                <td style={{ ...CELL, fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{formatINR(s.gross)}</td>
                <td style={{ ...CELL, fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{formatINR(s.total_deductions)}</td>
                <td style={{ ...CELL, textAlign: 'right', whiteSpace: 'nowrap' }}>
                  <button onClick={() => setEditing(s)}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '0.85rem', marginRight: '10px' }}>
                    Edit
                  </button>
                  <button onClick={() => setDeleting(s)}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--hot)', fontSize: '0.85rem' }}>
                    Remove
                  </button>
                </td>
              </tr>
            ))}
          </Table>
        )
      )}

      {(adding || editing) && (
        <SalaryStructureModal
          employees={employees ?? []}
          defaultEmployeeId={employeeId || undefined}
          structure={editing ?? undefined}
          onClose={() => { setAdding(false); setEditing(null); }}
        />
      )}
      {deleting && (
        <ConfirmDialog title="Remove this salary structure?"
                       message={`From ${fmtDate(deleting.effective_from)}, gross ${formatINR(deleting.gross)}. A structure a finalized payslip used can't be removed.`}
                       confirmLabel="Remove" danger
                       onConfirm={() => remove.mutate(deleting.id)}
                       onCancel={() => setDeleting(null)} />
      )}
    </>
  );
}

function SalaryStructureModal({ employees, defaultEmployeeId, structure, onClose }: {
  employees: Employee[]; defaultEmployeeId?: number;
  /** Given: edit this structure instead of adding one. */
  structure?: SalaryStructureConfig;
  onClose: () => void;
}) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const isEdit = !!structure;
  const [employeeId, setEmployeeId] = useState<number | ''>(structure?.employee ?? defaultEmployeeId ?? '');
  const [effectiveFrom, setEffectiveFrom] = useState(structure?.effective_from ?? localISODate());
  const [fields, setFields] = useState({
    basic: structure?.basic ?? '', hra: structure?.hra ?? '',
    special_allowance: structure?.special_allowance ?? '', other_allowances: structure?.other_allowances ?? '',
    pf_employee: structure?.pf_employee ?? '', esi_employee: structure?.esi_employee ?? '',
    professional_tax: structure?.professional_tax ?? '', tds: structure?.tds ?? '',
  });
  const num = (v: string) => Number(v) || 0;
  const gross = num(fields.basic) + num(fields.hra) + num(fields.special_allowance) + num(fields.other_allowances);
  const deductionsTotal = num(fields.pf_employee) + num(fields.esi_employee) + num(fields.professional_tax) + num(fields.tds);
  const negative = Object.values(fields).some(v => num(v) < 0);
  const problem = negative ? 'Amounts can\'t be negative.'
    : gross <= 0 ? 'Enter the salary.'
    : deductionsTotal > gross ? `Deductions (${formatINR(deductionsTotal)}) are more than the gross (${formatINR(gross)}).`
    : '';

  const set = (k: keyof typeof fields) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setFields(f => ({ ...f, [k]: e.target.value }));

  const save = useMutation({
    mutationFn: () => {
      const payload = {
        employee: Number(employeeId),
        effective_from: effectiveFrom,
        ...Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, v || '0'])),
      };
      return isEdit
        ? hrmsApi.updateSalaryStructure(structure!.id, payload)
        : hrmsApi.createSalaryStructure(payload);
    },
    onSuccess: () => {
      showToast('success', isEdit ? 'Structure updated' : 'Structure added', '');
      qc.invalidateQueries({ queryKey: ['hrms-salary-structures'] });
      onClose();
    },
    onError: (e: unknown) => {
      showToast('error', 'Failed', getErrorMessage(e, 'Could not save.'));
    },
  });

  return (
    <Modal title={isEdit ? 'Edit salary structure' : 'Add salary structure'} onClose={onClose} maxWidth="480px">
      <div className="flex flex-col gap-3">
        <div>
          <label className="block font-heading font-bold mb-1" style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Employee *</label>
          <select className="input-brutal" style={{ cursor: 'pointer' }} disabled={isEdit}
                  value={employeeId} onChange={e => setEmployeeId(e.target.value ? Number(e.target.value) : '')}>
            <option value="">Select…</option>
            {employees.map(e => <option key={e.id} value={e.id}>{e.name} ({e.employee_code})</option>)}
          </select>
        </div>
        <Input label="Effective from" type="date" value={effectiveFrom} onChange={e => setEffectiveFrom(e.target.value)} />

        <div style={{ borderTop: '1px solid var(--line)', paddingTop: '8px' }}>
          <span className="font-heading font-bold" style={{ fontSize: '0.72rem', letterSpacing: '0.06em' }}>EARNINGS (₹/month)</span>
        </div>
        <div className="grid gap-2" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Basic" type="number" min="0" step="0.01" value={fields.basic} onChange={set('basic')} />
          <Input label="HRA" type="number" min="0" step="0.01" value={fields.hra} onChange={set('hra')} />
          <Input label="Special allowance" type="number" min="0" step="0.01" value={fields.special_allowance} onChange={set('special_allowance')} />
          <Input label="Other allowances" type="number" min="0" step="0.01" value={fields.other_allowances} onChange={set('other_allowances')} />
        </div>

        <div style={{ borderTop: '1px solid var(--line)', paddingTop: '8px' }}>
          <span className="font-heading font-bold" style={{ fontSize: '0.72rem', letterSpacing: '0.06em' }}>DEDUCTIONS (₹/month)</span>
        </div>
        <p style={{ fontSize: '0.7rem', color: 'var(--text-3)', marginTop: '-6px' }}>
          Flat amounts you calculate yourself — PF/ESI/PT/TDS rates vary by wage slab and state and
          aren't derived here.
        </p>
        <div className="grid gap-2" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="PF (employee)" type="number" min="0" step="0.01" value={fields.pf_employee} onChange={set('pf_employee')} />
          <Input label="ESI (employee)" type="number" min="0" step="0.01" value={fields.esi_employee} onChange={set('esi_employee')} />
          <Input label="Professional tax" type="number" min="0" step="0.01" value={fields.professional_tax} onChange={set('professional_tax')} />
          <Input label="TDS" type="number" min="0" step="0.01" value={fields.tds} onChange={set('tds')} />
        </div>

        {problem && fields.basic !== '' && (
          <p style={{ fontSize: '0.72rem', color: 'var(--hot)' }}>{problem}</p>
        )}
        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-2" style={{ fontSize: '0.85rem' }}
                disabled={!employeeId || !!problem || save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : isEdit ? 'Save changes' : 'Add structure'}
        </button>
      </div>
    </Modal>
  );
}

// ---- Policy ---------------------------------------------------------
// The present / half-day hours were fixed in code (6 h / 3 h), and nothing
// limited an expense claim.
function PolicySection() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { data, isLoading } = useQuery({
    queryKey: ['hrms-policy'],
    queryFn: () => hrmsApi.policy().then(r => r.data),
  });
  const [form, setForm] = useState<HrmsPolicy | null>(null);
  const values = form ?? data;

  const save = useMutation({
    mutationFn: () => hrmsApi.updatePolicy({
      ...values!,
      expense_receipt_above: values!.expense_receipt_above || null,
    }),
    onSuccess: r => {
      showToast('success', 'Policy saved', '');
      setForm(r.data);
      qc.invalidateQueries({ queryKey: ['hrms-policy'] });
    },
    onError: (e: unknown) => showToast('error', 'Failed', getErrorMessage(e, 'Could not save the policy.')),
  });

  if (isLoading || !values) return <div className="flex justify-center py-10"><Spinner /></div>;
  const set = (k: keyof HrmsPolicy) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm({ ...values, [k]: e.target.value });

  return (
    <div className="card-brutal" style={{ padding: '16px', maxWidth: 560 }}>
      <div className="font-heading font-black" style={{ fontSize: '0.85rem', marginBottom: 8 }}>Attendance</div>
      <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
        <Input label="Hours for a full day" type="number" min="0.5" max="24" step="0.25"
               value={values.full_day_hours} onChange={set('full_day_hours')} />
        <Input label="Hours for a half day" type="number" min="0" step="0.25"
               value={values.half_day_hours} onChange={set('half_day_hours')} />
      </div>
      <p style={{ fontSize: '0.72rem', color: 'var(--text-3)', margin: '6px 0 16px' }}>
        Worked time from the dialer or check-in/out at or above the full-day hours is present, at or
        above the half-day hours a half day, and below that absent. Applies to days synced from now on.
      </p>
      <div className="font-heading font-black" style={{ fontSize: '0.85rem', marginBottom: 8 }}>Expense claims</div>
      <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
        <Input label="Largest claim (₹)" type="number" min="1" step="1"
               value={values.expense_max_amount} onChange={set('expense_max_amount')} />
        <Input label="Receipt needed above (₹)" type="number" min="0" step="1"
               value={values.expense_receipt_above ?? ''} onChange={set('expense_receipt_above')}
               placeholder="Never" />
      </div>
      <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-4" style={{ fontSize: '0.85rem' }}
              disabled={!form || save.isPending} onClick={() => save.mutate()}>
        {save.isPending ? 'Saving…' : 'Save policy'}
      </button>
    </div>
  );
}
