// ============================================================
// HRMS — Incentive earnings
//
// The bridge between the CRM and payroll: rules read converted leads,
// connected calls, talk minutes and deal value, and produce payable earnings
// that the next payroll run folds into a payslip.
//
// Both the list endpoint and the compute endpoint existed and were wrapped in
// the API layer; neither had a screen, so nobody could see what a rule had
// actually paid out before it landed on a payslip.
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { hrmsApi } from '../../api';
import { Column, DataTable, FilterBar, StatusPill } from '../../components/DataTable';
import { ConfirmDialog, Select, StatCard, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINRExact, localISOMonth } from '../../utils/fmt';
import type { IncentiveEarning } from '../../types';
import { fetchAllPages } from '../../utils/fetchAll';

const METRIC_LABELS: Record<string, string> = {
  converted_leads: 'Converted leads',
  connected_calls: 'Connected calls',
  talk_minutes: 'Talk minutes',
  revenue: 'Revenue',
};

export default function IncentivesTab() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canCompute = can(Cap.HRMS_INCENTIVES);

  const [month, setMonth] = useState(localISOMonth());
  const [employeeId, setEmployeeId] = useState('');
  const [search, setSearch] = useState('');
  const [confirm, setConfirm] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['hrms-incentives', month, employeeId],
    queryFn: () => hrmsApi.incentives({
      month, employee: employeeId || undefined, page_size: 200,
    }).then(r => r.data),
  });

  const { data: employees } = useQuery({
    queryKey: ['hrms-employees-picker'],
    queryFn: () => fetchAllPages(page => hrmsApi.employees({ page_size: 100, page })),
  });

  const compute = useMutation({
    mutationFn: () => hrmsApi.computeIncentives(month),
    onSuccess: () => {
      showToast('success', 'Computed', `Incentives recalculated for ${fmtDate(`${month}-01`, 'MMMM yyyy')}.`);
      qc.invalidateQueries({ queryKey: ['hrms-incentives'] });
      setConfirm(false);
    },
    onError: e => { showToast('error', 'Failed', getErrorMessage(e)); setConfirm(false); },
  });

  const rows = useMemo(() => {
    const all = data?.results ?? [];
    const q = search.trim().toLowerCase();
    return q ? all.filter(x => x.employee_name?.toLowerCase().includes(q)
                            || x.rule_name?.toLowerCase().includes(q)) : all;
  }, [data, search]);

  const total = rows.reduce((s, r) => s + Number(r.amount || 0), 0);
  const paid = rows.filter(r => r.paid_in).reduce((s, r) => s + Number(r.amount || 0), 0);
  const earners = new Set(rows.filter(r => Number(r.amount) > 0).map(r => r.employee)).size;

  const columns: Column<IncentiveEarning>[] = [
    { key: 'employee_name', header: 'Employee', sortable: true, render: x => x.employee_name },
    { key: 'rule_name', header: 'Rule', sortable: true, render: x => x.rule_name },
    { key: 'metric', header: 'Metric',
      render: x => METRIC_LABELS[x.metric] ?? x.metric },
    { key: 'units', header: 'Units', numeric: true, sortable: true,
      sortValue: x => Number(x.units),
      // Revenue rules count rupees of deal value; the rest count whole things.
      render: x => x.metric === 'revenue' ? formatINRExact(x.units) : Number(x.units).toLocaleString('en-IN') },
    { key: 'amount', header: 'Payout', numeric: true, sortable: true,
      sortValue: x => Number(x.amount),
      render: x => <b>{formatINRExact(x.amount)}</b> },
    { key: 'paid_in', header: 'Status',
      render: x => <StatusPill value={x.paid_in ? 'paid' : 'pending'} label={x.paid_in ? 'In payslip' : 'Unpaid'} /> },
  ];

  return (
    <>
      {!!rows.length && (
        <div className="grid gap-3 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))' }}>
          <StatCard label="Total payout" value={formatINRExact(total)}
                    sub={fmtDate(`${month}-01`, 'MMMM yyyy')} tone="teal" icon="₹" />
          <StatCard label="Earning employees" value={earners} sub={`of ${employees?.count ?? 0} enrolled`} icon="☷" />
          <StatCard label="Already in payslips" value={formatINRExact(paid)}
                    sub={`${formatINRExact(total - paid)} still unpaid`} tone="green" icon="▦" />
        </div>
      )}

      {canCompute && (
        <div className="card-brutal flex gap-2 items-end mb-3" style={{ padding: '12px', flexWrap: 'wrap' }}>
          <div>
            <label className="block font-heading font-bold mb-1"
                   style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Month</label>
            <input className="input-brutal" type="month" value={month}
                   onChange={e => setMonth(e.target.value)} />
          </div>
          <button className="btn-brutal btn-primary px-3 py-2 font-heading font-bold"
                  style={{ fontSize: '0.78rem' }}
                  disabled={compute.isPending} onClick={() => setConfirm(true)}>
            {compute.isPending ? 'Computing…' : 'Compute incentives'}
          </button>
          <p className="font-medium" style={{ fontSize: '0.72rem', color: 'var(--text-3)', flexBasis: '100%' }}>
            Reads CRM outcomes for the month and rewrites earnings for every active rule.
            Run this <b>before</b> payroll — earnings already folded into a payslip are left alone.
          </p>
        </div>
      )}

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search employee or rule…">
        {!canCompute && (
          <div>
            <label className="block font-heading font-bold mb-1"
                   style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Month</label>
            <input className="input-brutal" type="month" value={month}
                   onChange={e => setMonth(e.target.value)} />
          </div>
        )}
        <Select label="Employee" value={employeeId} onChange={e => setEmployeeId(e.target.value)}>
          <option value="">All employees</option>
          {(employees?.results ?? []).map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={x => x.id}
        isLoading={isLoading}
        pageSize={25}
        empty={{
          icon: '✦', title: 'No incentive earnings for this month',
          message: canCompute
            ? 'Set up rules under Settings → Incentive Rules, then compute for this month.'
            : 'Earnings appear here once HR computes incentives for the month.',
        }}
        footer={rows.length ? (
          <tr style={{ borderTop: '2px solid var(--line)', background: 'var(--paper)' }}>
            <td colSpan={4} style={{ padding: '10px 12px', fontSize: '0.75rem' }} className="font-heading font-bold">
              TOTAL
            </td>
            <td style={{ padding: '10px 12px', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', textAlign: 'right', fontWeight: 700 }}>
              {formatINRExact(total)}
            </td>
            <td />
          </tr>
        ) : undefined}
      />

      {confirm && (
        <ConfirmDialog
          title={`Compute incentives for ${fmtDate(`${month}-01`, 'MMMM yyyy')}?`}
          message="Earnings are recalculated from this month's CRM outcomes for every active rule. Earnings already paid through a payslip are not touched."
          confirmLabel="Compute"
          onConfirm={() => compute.mutate()}
          onCancel={() => setConfirm(false)}
        />
      )}
    </>
  );
}
