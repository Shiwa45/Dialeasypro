// ============================================================
// HRMS — Leave
//
// Two audiences on one screen: an employee applying and tracking their own
// requests, and an approver working a queue. The Apply form is the piece that
// was missing entirely — hrmsApi.applyLeave existed and nothing called it, so
// leave could be approved but never requested.
// ============================================================
import { useMyEmployee } from '../../hooks/useMyEmployee';
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { hrmsApi } from '../../api';
import { Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { Input, Modal, Select, Textarea, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, localISODate } from '../../utils/fmt';
import type { LeaveBalance, LeaveRequest } from '../../types';
import { fetchAllPages } from '../../utils/fetchAll';

/** A dense stat tile. StatCard is built for dashboards and is far too tall to
 *  put eight of in a row above a table. */
function MiniStat({ label, value, note, tone }: {
  label: string; value: number | string; note?: string;
  tone?: 'warm' | 'visit' | 'mute';
}) {
  const colour = tone === 'warm' ? 'var(--warm)' : tone === 'visit' ? 'var(--visit)' : 'var(--text)';
  return (
    <div className="plate no-ticks" style={{ padding: '13px 15px' }}>
      <div style={{
        fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '.12em',
        textTransform: 'uppercase', color: 'var(--text-3)',
      }}>{label}</div>
      <div className="num" style={{ fontSize: 24, fontWeight: 600, marginTop: 7, color: colour, lineHeight: 1 }}>
        {value}
      </div>
      {note && <div style={{ fontSize: 11.5, color: 'var(--text-3)', marginTop: 6 }}>{note}</div>}
    </div>
  );
}

export default function LeaveTab() {
  // Only someone on the HRMS roster can punch in, apply for leave or claim.
  const { enrolled } = useMyEmployee();
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canApprove = can(Cap.HRMS_APPROVE);
  const canManage = can(Cap.HRMS_MANAGE);

  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [applying, setApplying] = useState(false);
  const [allocating, setAllocating] = useState(false);
  const [balanceYear, setBalanceYear] = useState(new Date().getFullYear());

  const { data, isLoading } = useQuery({
    queryKey: ['hrms-leave', status],
    queryFn: () => hrmsApi.leave({ status: status || undefined, page_size: 200 }).then(r => r.data),
  });
  const { data: balances } = useQuery({
    queryKey: ['hrms-leave-balances', balanceYear],
    queryFn: () => hrmsApi.leaveBalances({ year: balanceYear }).then(r => r.data),
  });
  const { data: me } = useQuery({
    queryKey: ['hrms-me'],
    queryFn: () => hrmsApi.me().then(r => r.data),
    retry: false,
  });

  const decide = useMutation({
    mutationFn: ({ id, action }: { id: number; action: string }) => hrmsApi.decideLeave(id, action),
    onSuccess: (_r, v) => {
      showToast('success', 'Done', `Leave request ${v.action}${v.action === 'cancel' ? 'led' : 'd'}.`);
      qc.invalidateQueries({ queryKey: ['hrms-leave'] });
      qc.invalidateQueries({ queryKey: ['hrms-leave-balances'] });
      qc.invalidateQueries({ queryKey: ['hrms-dashboard'] });
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const rows = useMemo(() => {
    const all = data?.results ?? [];
    const q = search.trim().toLowerCase();
    return q ? all.filter(l => l.employee_name?.toLowerCase().includes(q)) : all;
  }, [data, search]);

  // Own balances only. `!me?.id ||` used to sit in front of this test, so an
  // account with no Employee record — every admin, since admins are not on the
  // HR roster — fell through to EVERY employee's balance. That rendered ten
  // identical nameless cards claiming to be "your" leave. Failing to identify
  // the user must show nothing personal, not everyone.
  const myBalances = me?.id
    ? (balances ?? []).filter(b => b.employee === me.id)
    : [];

  // Everyone's balances, for HR: one row per employee, one column per type.
  // The page used to show only "Your leave balance", so HR could not see
  // anyone else's.
  const balanceTable = useMemo(() => {
    const typeNames = Array.from(new Set((balances ?? []).map(b => b.leave_type_name))).sort();
    const byEmp = new Map<number, { name: string; code: string; cells: Record<string, LeaveBalance> }>();
    for (const b of balances ?? []) {
      const row = byEmp.get(b.employee) ?? { name: b.employee_name ?? '', code: b.employee_code ?? '', cells: {} };
      row.cells[b.leave_type_name] = b;
      byEmp.set(b.employee, row);
    }
    return { typeNames, rows: Array.from(byEmp.values()).sort((a, b) => a.code.localeCompare(b.code)) };
  }, [balances]);

  // What an approver needs at a glance, which the personal balances never
  // answered: how much is waiting, and who is out right now.
  const all = data?.results ?? [];
  const today = localISODate();
  const queue = {
    pending: all.filter(l => l.status === 'pending').length,
    pendingDays: all
      .filter(l => l.status === 'pending')
      .reduce((sum, l) => sum + Number(l.days || 0), 0),
    outToday: all.filter(
      l => l.status === 'approved' && l.start_date <= today && l.end_date >= today,
    ).length,
  };

  const columns: Column<LeaveRequest>[] = [
    { key: 'employee_name', header: 'Employee', sortable: true, render: l => l.employee_name },
    { key: 'leave_type_name', header: 'Type', sortable: true, render: l => l.leave_type_name },
    { key: 'start_date', header: 'From', sortable: true, render: l => fmtDate(l.start_date) },
    { key: 'end_date', header: 'To', render: l => fmtDate(l.end_date) },
    { key: 'days', header: 'Days', numeric: true, sortable: true, sortValue: l => Number(l.days),
      render: l => (l.half_day ? '½ day' : l.days) },
    { key: 'reason', header: 'Reason',
      render: l => <span style={{ color: 'var(--text-2)' }}>{l.reason || '—'}</span> },
    { key: 'status', header: 'Status', sortable: true, render: l => <StatusPill value={l.status} /> },
  ];

  return (
    <>
      {/* Approver summary. Three numbers that change what you do next, rather
          than one giant tile per leave type. */}
      {canApprove && (
        <div className="grid gap-3 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))' }}>
          <MiniStat label="Awaiting approval" value={queue.pending}
                    tone={queue.pending ? 'warm' : 'mute'}
                    note={queue.pending ? `${queue.pendingDays} day(s) requested` : 'Nothing waiting'} />
          <MiniStat label="Out today" value={queue.outToday} tone="visit"
                    note={queue.outToday ? 'Approved and on leave now' : 'Everyone in'} />
          <MiniStat label="Requests in view" value={all.length} tone="mute"
                    note={status ? `Filtered to ${status}` : 'All statuses'} />
        </div>
      )}

      {/* Personal entitlement, as a compact strip. Only rendered for a user who
          actually has an Employee record — an admin has no leave balance. */}
      {!!myBalances.length && (
        <div className="plate mb-4">
          <div className="plate-h">
            <div>
              <div className="plate-t">Your leave balance</div>
              <div className="plate-s">{myBalances[0]?.year ?? ''}</div>
            </div>
          </div>
          <div className="plate-b" style={{ display: 'grid', gap: 14,
               gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))' }}>
            {myBalances.map(b => {
              const allocated = Number(b.allocated_days) || 0;
              const used = Number(b.used_days) || 0;
              const pct = allocated ? Math.min(100, (used / allocated) * 100) : 0;
              return (
                <div key={b.id}>
                  <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 8 }}>
                    <span style={{ fontSize: 12.5, fontWeight: 600 }}>{b.leave_type_name}</span>
                    <span className="num" style={{ fontSize: 15, fontWeight: 600 }}>
                      {b.remaining_days}
                      <span style={{ fontSize: 11, color: 'var(--text-3)', fontWeight: 400 }}> left</span>
                    </span>
                  </div>
                  <div className="progress-bar" style={{ marginTop: 7 }}>
                    <span className="progress-fill"
                          style={{ width: `${pct}%`, background: pct >= 80 ? 'var(--hot)' : 'var(--brand)' }} />
                  </div>
                  <div className="num" style={{ fontSize: 10.5, color: 'var(--text-3)', marginTop: 5 }}>
                    {b.used_days} of {b.allocated_days} used
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {canManage && (
        <div className="plate mb-4">
          <div className="plate-h">
            <div>
              <div className="plate-t">Leave balances</div>
              <div className="plate-s">Left / allocated, per employee</div>
            </div>
            <div style={{ width: 110 }}>
              <Input type="number" value={balanceYear} aria-label="Year"
                     onChange={e => setBalanceYear(Number(e.target.value) || new Date().getFullYear())} />
            </div>
          </div>
          <div className="plate-b" style={{ overflowX: 'auto' }}>
            {balanceTable.rows.length === 0 ? (
              <p style={{ fontSize: 12.5, color: 'var(--text-3)' }}>
                No balances for {balanceYear} yet. Use Allocate balances to grant the year's quota.
              </p>
            ) : (
              <table className="table-brutal" style={{ width: '100%', fontSize: 12.5 }}>
                <thead>
                  <tr>
                    <th style={{ textAlign: 'left' }}>Employee</th>
                    {balanceTable.typeNames.map(t => <th key={t} style={{ textAlign: 'right' }}>{t}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {balanceTable.rows.map(r => (
                    <tr key={r.code}>
                      <td>{r.name} <span style={{ color: 'var(--text-3)' }}>{r.code}</span></td>
                      {balanceTable.typeNames.map(t => {
                        const b = r.cells[t];
                        return (
                          <td key={t} className="num" style={{ textAlign: 'right' }}>
                            {b ? <>{b.remaining_days}<span style={{ color: 'var(--text-3)' }}> / {b.allocated_days}</span></> : '—'}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      <div className="flex gap-2 mb-3 flex-wrap">
        {/* HR can apply on someone's behalf even without an employee record. */}
        {(enrolled || canManage) && (
          <button className="btn btn-p" onClick={() => setApplying(true)}>
            {enrolled ? 'Apply for leave' : 'Apply for an employee'}
          </button>
        )}
        {canManage && (
          <button className="btn btn-g" onClick={() => setAllocating(true)}>
            Allocate balances
          </button>
        )}
      </div>

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search employee…">
        <Select label="Status" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="pending">Pending</option>
          <option value="approved">Approved</option>
          <option value="rejected">Rejected</option>
          <option value="cancelled">Cancelled</option>
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={l => l.id}
        isLoading={isLoading}
        pageSize={25}
        actions={l => (
          <>
            {canApprove && l.status === 'pending' && (
              <>
                <RowAction label="Approve" positive onClick={() => decide.mutate({ id: l.id, action: 'approve' })}
                           disabled={decide.isPending} />
                <RowAction label="Reject" danger onClick={() => decide.mutate({ id: l.id, action: 'reject' })}
                           disabled={decide.isPending} />
              </>
            )}
            {/* Cancelling your own pending request was supported by the API's
                URL regex from the start, but had no button anywhere. */}
            {(l.status === 'pending' || l.status === 'approved') && (me?.id === l.employee || canManage) && (
              <RowAction label="Cancel" onClick={() => {
                if (l.status === 'approved' &&
                    !window.confirm('Cancel this approved leave? The days go back to the balance and attendance is rebuilt.')) return;
                decide.mutate({ id: l.id, action: 'cancel' });
              }} disabled={decide.isPending} />
            )}
          </>
        )}
        empty={{ icon: '◷', title: 'No leave requests', message: 'Apply above, or wait for your team to raise one.' }}
      />

      {applying && (
        <ApplyLeaveModal onClose={() => setApplying(false)} forOthers={canManage}
                         selfId={enrolled ? me?.id : undefined} />
      )}
      {allocating && <AllocateBalancesModal onClose={() => setAllocating(false)} />}
    </>
  );
}

/* ---- Apply for leave ---------------------------------------- */
function ApplyLeaveModal({ onClose, forOthers, selfId }: {
  onClose: () => void;
  /** HR: pick whose leave this is. */
  forOthers: boolean;
  /** The caller's own employee id, when they have one. */
  selfId?: number;
}) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const today = localISODate();
  const [employee, setEmployee] = useState(selfId ? String(selfId) : '');
  const [halfDay, setHalfDay] = useState(false);

  const { data: employees } = useQuery({
    queryKey: ['hrms-employees-active'],
    queryFn: () => fetchAllPages(page => hrmsApi.employees({ active: 'true', page_size: 100, page })),
    enabled: forOthers,
  });

  const { data: types } = useQuery({
    queryKey: ['hrms-leave-types'],
    queryFn: () => hrmsApi.leaveTypes().then(r => r.data),
  });

  const [form, setForm] = useState({
    leave_type: '', start_date: today, end_date: today, reason: '',
  });

  // The server counts the days: working days only, so holidays and week-offs
  // inside the range are not charged. The count used to be typed in, and a
  // six-day leave could be charged as half a day.
  const span = useMemo(() => {
    const s = new Date(form.start_date), e = new Date(form.end_date);
    if (isNaN(+s) || isNaN(+e) || e < s) return 0;
    return Math.round((+e - +s) / 86_400_000) + 1;
  }, [form.start_date, form.end_date]);
  const singleDay = span === 1;

  const setDates = (k: 'start_date' | 'end_date', v: string) =>
    setForm(f => {
      const next = { ...f, [k]: v };
      // Keep the range coherent rather than letting the user submit a
      // backwards one and read the serializer's error.
      if (new Date(next.end_date) < new Date(next.start_date)) next.end_date = next.start_date;
      return next;
    });

  const apply = useMutation({
    mutationFn: () => hrmsApi.applyLeave({
      ...(forOthers && employee && Number(employee) !== selfId ? { employee: Number(employee) } : {}),
      leave_type: Number(form.leave_type),
      start_date: form.start_date,
      end_date: form.end_date,
      half_day: singleDay && halfDay,
      reason: form.reason,
    }),
    onSuccess: r => {
      const days = (r.data as { days?: string })?.days;
      showToast('success', 'Applied',
        `${days ? `${days} working day(s) requested` : 'Leave requested'} — pending approval.`);
      qc.invalidateQueries({ queryKey: ['hrms-leave'] });
      onClose();
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const valid = form.leave_type && span > 0 && (!forOthers || employee);

  return (
    <Modal title="Apply for leave" onClose={onClose} maxWidth="480px">
      <div className="flex flex-col gap-3">
        {forOthers && (
          <Select label="Employee" required value={employee} onChange={e => setEmployee(e.target.value)}>
            <option value="">Select an employee…</option>
            {(employees?.results ?? []).map(emp => (
              <option key={emp.id} value={emp.id}>
                {emp.name} ({emp.employee_code}){emp.id === selfId ? ' — you' : ''}
              </option>
            ))}
          </Select>
        )}
        <Select label="Leave type" required value={form.leave_type}
                onChange={e => setForm(f => ({ ...f, leave_type: e.target.value }))}>
          <option value="">Select a type…</option>
          {(types ?? []).map(t => (
            <option key={t.id} value={t.id}>
              {t.name}{t.is_paid ? '' : ' (unpaid)'}
            </option>
          ))}
        </Select>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="From" type="date" value={form.start_date}
                 onChange={e => setDates('start_date', e.target.value)} />
          <Input label="To" type="date" value={form.end_date}
                 onChange={e => setDates('end_date', e.target.value)} />
        </div>

        {singleDay && (
          <label className="flex items-center gap-2" style={{ fontSize: '0.8rem' }}>
            <input type="checkbox" checked={halfDay} onChange={e => setHalfDay(e.target.checked)} />
            Half day
          </label>
        )}
        <p style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>
          {singleDay && halfDay
            ? 'Half a day is taken from the balance.'
            : `Only working days are counted — holidays and week-offs inside the ${span}-day range are not charged.`}
        </p>

        <Textarea label="Reason" rows={3} value={form.reason}
                  onChange={e => setForm(f => ({ ...f, reason: e.target.value }))}
                  placeholder="Optional, but approvers appreciate it" />

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-1"
                style={{ fontSize: '0.85rem' }}
                disabled={!valid || apply.isPending} onClick={() => apply.mutate()}>
          {apply.isPending ? 'Submitting…' : 'Submit request'}
        </button>
      </div>
    </Modal>
  );
}

/* ---- Allocate balances (admin/HR) ---------------------------
   The January chore. Doing it one employee at a time is what makes people
   skip it, so the bulk path is the default and the single grant is the
   exception below it. */
function AllocateBalancesModal({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [year, setYear] = useState(new Date().getFullYear());
  const [single, setSingle] = useState({ employee: '', leave_type: '', allocated_days: '' });

  const { data: employees } = useQuery({
    queryKey: ['hrms-employees-active'],
    queryFn: () => fetchAllPages(page => hrmsApi.employees({ active: 'true', page_size: 100, page })),
  });
  const { data: types } = useQuery({
    queryKey: ['hrms-leave-types'],
    queryFn: () => hrmsApi.leaveTypes().then(r => r.data),
  });
  // The person's current figure for the chosen type and year, so a grant
  // isn't made blind.
  const { data: current } = useQuery({
    queryKey: ['hrms-leave-balances', year, single.employee],
    queryFn: () => hrmsApi.leaveBalances({ year, employee: Number(single.employee) }).then(r => r.data),
    enabled: !!single.employee,
  });
  const currentRow = (current ?? []).find(b => String(b.leave_type) === single.leave_type);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['hrms-leave-balances'] });
  };

  const bulk = useMutation({
    mutationFn: () => hrmsApi.bulkAllocateLeave(year),
    onSuccess: r => {
      showToast('success', 'Allocated',
        `${r.data.created} created, ${r.data.topped_up} topped up across ${r.data.employees} employees`
        + (r.data.carried_forward ? `; ${r.data.carried_forward} carried forward from ${year - 1}.` : '.'));
      invalidate();
      onClose();
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const grant = useMutation({
    mutationFn: () => hrmsApi.allocateLeaveBalance({
      employee: Number(single.employee),
      leave_type: Number(single.leave_type),
      year,
      allocated_days: single.allocated_days,
    }),
    onSuccess: () => {
      showToast('success', 'Allocated', 'Balance updated.');
      invalidate();
      setSingle({ employee: '', leave_type: '', allocated_days: '' });
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  return (
    <Modal title="Allocate leave balances" onClose={onClose} maxWidth="520px">
      <div className="flex flex-col gap-4">
        <Input label="Year" type="number" value={year} onChange={e => setYear(Number(e.target.value))} />

        <div className="card-brutal" style={{ padding: '12px', background: 'var(--paper)' }}>
          <div className="font-heading font-black" style={{ fontSize: '0.85rem', marginBottom: '6px' }}>
            Grant everyone their annual quota
          </div>
          <p className="font-medium" style={{ fontSize: '0.75rem', color: 'var(--text-2)', marginBottom: '10px' }}>
            Every active employee gets each active leave type's annual quota for {year},
            pro-rated by month for anyone who joined during {year}. Types set to carry
            forward add what was left over from {year - 1}. Safe to re-run: it tops
            balances up, never reduces one you raised by hand, and never touches days
            already used.
          </p>
          <button className="btn-brutal btn-primary px-3 py-2 font-heading font-bold"
                  style={{ fontSize: '0.78rem' }}
                  disabled={bulk.isPending} onClick={() => bulk.mutate()}>
            {bulk.isPending ? 'Allocating…' : `Allocate for all employees`}
          </button>
        </div>

        <div style={{ borderTop: '1px solid var(--line)', paddingTop: '12px' }}>
          <div className="font-heading font-black" style={{ fontSize: '0.85rem', marginBottom: '8px' }}>
            Or grant one person
          </div>
          <div className="flex flex-col gap-3">
            <Select label="Employee" value={single.employee}
                    onChange={e => setSingle(s => ({ ...s, employee: e.target.value }))}>
              <option value="">Select…</option>
              {(employees?.results ?? []).map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
            </Select>
            <div className="grid gap-3" style={{ gridTemplateColumns: '2fr 1fr' }}>
              <Select label="Leave type" value={single.leave_type}
                      onChange={e => setSingle(s => ({ ...s, leave_type: e.target.value }))}>
                <option value="">Select…</option>
                {(types ?? []).map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </Select>
              <Input label="Days" type="number" step="0.5" min="0" value={single.allocated_days}
                     onChange={e => setSingle(s => ({ ...s, allocated_days: e.target.value }))} />
            </div>
            {single.employee && single.leave_type && (
              <p style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>
                {currentRow
                  ? `Now: ${currentRow.allocated_days} allocated, ${currentRow.used_days} used, ${currentRow.remaining_days} left in ${year}. The new figure replaces the allocation (it can't be below the used days).`
                  : `No ${year} balance yet for this type.`}
              </p>
            )}
            <button className="btn-brutal px-3 py-2 font-heading font-bold"
                    style={{ fontSize: '0.78rem' }}
                    disabled={!single.employee || !single.leave_type || !single.allocated_days || grant.isPending}
                    onClick={() => grant.mutate()}>
              {grant.isPending ? 'Saving…' : 'Grant'}
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
}
