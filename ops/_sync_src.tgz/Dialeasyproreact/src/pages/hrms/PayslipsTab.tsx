// ============================================================
// HRMS — Payslips & payroll runs
//
// Three things were broken or missing here:
//   * the run button hardcoded the current month AND sent {month, year} ints
//     to an endpoint that parses a 'YYYY-MM' string — so it 500'd, always;
//   * `breakdown` (the component-wise snapshot payroll writes) was fetched on
//     every row and never displayed anywhere;
//   * finalize and mark-paid had no UI, so every slip stayed a draft forever.
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { hrmsApi } from '../../api';
import { Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { ConfirmDialog, Modal, Select, Spinner, useToast } from '../../components/ui';
import {
  DocumentBlock, DocumentLetterhead, DocumentPaper, DocumentTotal, DocumentWords,
  useCompany, useDocumentPrint,
} from '../../components/DocumentShell';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINRExact, localISOMonth } from '../../utils/fmt';
import type { Payslip } from '../../types';

export default function PayslipsTab() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canRunPayroll = can(Cap.HRMS_PAYROLL);

  const [month, setMonth] = useState(localISOMonth());
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [openId, setOpenId] = useState<number | null>(null);
  const [confirmRun, setConfirmRun] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['hrms-payslips', month],
    queryFn: () => hrmsApi.payslips({ month, page_size: 200 }).then(r => r.data),
  });

  const run = useMutation({
    mutationFn: () => hrmsApi.runPayroll(month),
    onSuccess: r => {
      const res = r.data;
      const errs = res.errors ?? [];
      const noStructure = res.missing_structure ?? [];
      showToast(errs.length ? 'warning' : 'success', 'Payroll run',
        `${res.payslips} draft payslip(s) generated.`
        + (errs.length ? ` ${errs.length} failed: ${errs.slice(0, 2).join('; ')}${errs.length > 2 ? '…' : ''}` : ''));
      // Nobody has set these people's pay yet, so no slip was made for them.
      if (noStructure.length) {
        const names = noStructure.slice(0, 3).map(m => m.name).join(', ');
        const more = noStructure.length > 3 ? ` and ${noStructure.length - 3} more` : '';
        showToast('warning', 'No salary structure',
          `${names}${more} — add a structure in Settings → Salary, then re-run.`);
      }
      // A run in the middle of the month pays only the days so far.
      if (res.upcoming_days) {
        showToast('info', 'Month not over',
          `${res.upcoming_days} day(s) still to come are not paid yet. Re-run after the month ends, then finalize.`);
      }
      // Days with no attendance record are paid rather than docked; say who,
      // so attendance can be synced or corrected before finalizing.
      const missing = res.unrecorded ?? [];
      if (missing.length) {
        const names = missing.slice(0, 3).map(m => `${m.name} (${m.days}d)`).join(', ');
        const more = missing.length > 3 ? ` and ${missing.length - 3} more` : '';
        showToast('warning', 'Paid without attendance records',
          `${names}${more}. Sync or correct attendance, then re-run before finalizing.`);
      }
      // Leave still awaiting a decision is paid as whatever attendance says
      // (usually absent); approving it later changes the pay.
      const pending = res.pending_leave ?? [];
      if (pending.length) {
        const names = pending.slice(0, 3).map(p => p.name).join(', ');
        const more = pending.length > 3 ? ` and ${pending.length - 3} more` : '';
        showToast('warning', 'Leave still pending',
          `${names}${more} have leave awaiting approval this month. Decide it, then re-run before finalizing.`);
      }
      qc.invalidateQueries({ queryKey: ['hrms-payslips'] });
      qc.invalidateQueries({ queryKey: ['hrms-dashboard'] });
      setConfirmRun(false);
    },
    onError: e => { showToast('error', 'Failed', getErrorMessage(e)); setConfirmRun(false); },
  });

  type SlipAction = 'finalize' | 'paid' | 'reopen' | 'delete';
  const act = useMutation({
    mutationFn: ({ id, action }: { id: number; action: SlipAction }) =>
      action === 'finalize' ? hrmsApi.finalizePayslip(id)
        : action === 'paid' ? hrmsApi.markPayslipPaid(id)
        : action === 'reopen' ? hrmsApi.reopenPayslip(id)
        : hrmsApi.deletePayslip(id),
    onSuccess: (_r, v) => {
      showToast('success', 'Updated', {
        finalize: 'Payslip finalized.', paid: 'Marked as paid.',
        reopen: 'Payslip reopened as a draft.', delete: 'Draft payslip deleted.',
      }[v.action]);
      qc.invalidateQueries({ queryKey: ['hrms-payslips'] });
      qc.invalidateQueries({ queryKey: ['hrms-dashboard'] });
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const rows = useMemo(() => {
    let all = data?.results ?? [];
    if (status) all = all.filter(p => p.status === status);
    const q = search.trim().toLowerCase();
    return q ? all.filter(p => p.employee_name?.toLowerCase().includes(q)
                            || p.employee_code?.toLowerCase().includes(q)) : all;
  }, [data, search, status]);

  const totalNet = rows.reduce((s, p) => s + Number(p.net_pay || 0), 0);

  const columns: Column<Payslip>[] = [
    { key: 'employee_code', header: 'Code', sortable: true,
      render: p => <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{p.employee_code}</span> },
    { key: 'employee_name', header: 'Employee', sortable: true, render: p => p.employee_name },
    { key: 'days', header: 'Paid days', numeric: true,
      render: p => `${Number(p.payable_days)}/${Number(p.total_days)}` },
    { key: 'lop', header: 'LOP', numeric: true,
      render: p => {
        const lop = Number(attendanceOf(p)?.lop_days ?? 0);
        return lop ? <span style={{ color: 'var(--hot)' }}>{lop}</span> : '—';
      } },
    { key: 'gross_earnings', header: 'Gross', numeric: true, sortable: true,
      sortValue: p => Number(p.gross_earnings), render: p => formatINRExact(p.gross_earnings) },
    { key: 'incentives_amount', header: 'Incentives', numeric: true,
      render: p => formatINRExact(p.incentives_amount) },
    { key: 'reimbursements_amount', header: 'Reimburse.', numeric: true,
      render: p => formatINRExact(p.reimbursements_amount) },
    { key: 'total_deductions', header: 'Deductions', numeric: true,
      render: p => formatINRExact(p.total_deductions) },
    { key: 'net_pay', header: 'Net pay', numeric: true, sortable: true,
      sortValue: p => Number(p.net_pay),
      render: p => <b>{formatINRExact(p.net_pay)}</b> },
    { key: 'status', header: 'Status', sortable: true, render: p => <StatusPill value={p.status} /> },
  ];

  return (
    <>
      {canRunPayroll && (
        <div className="card-brutal flex gap-2 items-end mb-3" style={{ padding: '12px', flexWrap: 'wrap' }}>
          <div>
            <label className="block font-heading font-bold mb-1"
                   style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Payroll month</label>
            <input className="input-brutal" type="month" value={month}
                   onChange={e => setMonth(e.target.value)} />
          </div>
          <button className="btn-brutal btn-primary px-3 py-2 font-heading font-bold"
                  style={{ fontSize: '0.78rem' }}
                  disabled={run.isPending} onClick={() => setConfirmRun(true)}>
            {run.isPending ? 'Running…' : 'Run payroll'}
          </button>
          <p className="font-medium" style={{ fontSize: '0.72rem', color: 'var(--text-3)', flexBasis: '100%' }}>
            Generates drafts only. Statutory deductions (PF, ESI, PT, TDS) come from each
            employee's salary structure — they are not computed for you.
          </p>
        </div>
      )}

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search employee…">
        {!canRunPayroll && (
          <div>
            <label className="block font-heading font-bold mb-1"
                   style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Month</label>
            <input className="input-brutal" type="month" value={month}
                   onChange={e => setMonth(e.target.value)} />
          </div>
        )}
        <Select label="Status" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="draft">Draft</option>
          <option value="finalized">Finalized</option>
          <option value="paid">Paid</option>
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={p => p.id}
        isLoading={isLoading}
        pageSize={25}
        minWidth="900px"
        onRowClick={p => setOpenId(p.id)}
        actions={canRunPayroll ? p => (
          <>
            {p.status === 'draft' && (
              <>
                <RowAction label="Finalize" disabled={act.isPending}
                           onClick={() => act.mutate({ id: p.id, action: 'finalize' })} />
                <RowAction label="Delete" danger disabled={act.isPending}
                           onClick={() => {
                             if (window.confirm(`Delete ${p.employee_name}'s draft payslip? Its incentives and claims go back for the next run.`))
                               act.mutate({ id: p.id, action: 'delete' });
                           }} />
              </>
            )}
            {p.status === 'finalized' && (
              <>
                <RowAction label="Mark paid" disabled={act.isPending}
                           onClick={() => act.mutate({ id: p.id, action: 'paid' })} />
                <RowAction label="Reopen" disabled={act.isPending}
                           onClick={() => {
                             if (window.confirm(`Reopen ${p.employee_name}'s payslip as a draft to correct it?`))
                               act.mutate({ id: p.id, action: 'reopen' });
                           }} />
              </>
            )}
            <RowAction label="View" onClick={() => setOpenId(p.id)} />
          </>
        ) : undefined}
        empty={{
          icon: '▦', title: 'No payslips for this month',
          message: canRunPayroll ? 'Run payroll above to generate this month\'s drafts.'
                                 : 'Your payslip appears here once payroll is run.',
        }}
        footer={rows.length ? (
          <tr style={{ borderTop: '2px solid var(--line)', background: 'var(--paper)' }}>
            <td colSpan={8} style={{ padding: '10px 12px', fontSize: '0.75rem' }} className="font-heading font-bold">
              {rows.length} PAYSLIP{rows.length === 1 ? '' : 'S'} · TOTAL NET
            </td>
            <td style={{ padding: '10px 12px', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', textAlign: 'right', fontWeight: 700 }}>
              {formatINRExact(totalNet)}
            </td>
            <td colSpan={2} />
          </tr>
        ) : undefined}
      />

      {openId !== null && <PayslipDetail id={openId} onClose={() => setOpenId(null)} />}

      {confirmRun && (
        <ConfirmDialog
          title={`Run payroll for ${fmtDate(`${month}-01`, 'MMMM yyyy')}?`}
          message="Draft payslips are created for every active employee with a salary structure. Re-running the same month refreshes the drafts; finalized slips are left untouched."
          confirmLabel="Run payroll"
          onConfirm={() => run.mutate()}
          onCancel={() => setConfirmRun(false)}
        />
      )}
    </>
  );
}

/* ---- Payslip document ---------------------------------------
   A payslip is proof of income: an employee hands it to a bank, a landlord
   or the next employer. This screen rendered one as a stack of app cards
   with the company name nowhere on it, and its Print button called
   window.print(), which puts the sidebar and the modal chrome on the paper.

   It is a document now — the tenant's letterhead, the employment details a
   payslip is expected to carry, earnings set against deductions, and a
   printed copy containing nothing but the document itself. */
function PayslipDetail({ id, onClose }: { id: number; onClose: () => void }) {
  const { data, isLoading } = useQuery({
    queryKey: ['hrms-payslip', id],
    queryFn: () => hrmsApi.payslip(id).then(r => r.data),
  });
  const { data: company } = useCompany();
  const label = componentLabel;

  const period = data ? fmtDate(data.period_month, 'MMMM yyyy') : '';
  const { ref, print } = useDocumentPrint(
    data ? 'Payslip ' + data.employee_code + ' ' + period : 'Payslip',
  );

  // The breakdown is whatever services/payroll.py wrote, so it is read
  // generically. Only the two component groups are line items; the scalars
  // beside them (structure id, LOP ratio, the statutory note) are metadata,
  // and they used to be listed as though they were pay components.
  const { earnings, deductions, note, rates, lopAmount } = useMemo(() => {
    const b = (data?.breakdown ?? {}) as Record<string, unknown>;
    const group = (key: string): Array<[string, string]> => {
      const val = b[key];
      if (!val || typeof val !== 'object' || Array.isArray(val)) return [];
      // In payslip order: the database stores the JSON with its keys
      // reordered, which put HRA above Basic.
      return Object.entries(val as Record<string, unknown>)
        .map(([k, v]) => [k, String(v)] as [string, string])
        .filter(([, v]) => Number(v) !== 0)
        .sort(([a], [b]) => componentRank(a) - componentRank(b));
    };
    return {
      earnings: group('earnings'),
      deductions: group('deductions'),
      note: typeof b.statutory_note === 'string' ? b.statutory_note : '',
      // Monthly rates the earned amounts were pro-rated from (payslips built
      // since payroll started counting days; older ones have none).
      rates: Object.fromEntries(group('earnings_full').map(([k, v]) => [label(k), v])),
      lopAmount: typeof b.lop_amount === 'string' ? Number(b.lop_amount) : 0,
    };
  }, [data]);
  const att = data ? attendanceOf(data) : null;

  // Incentives and reimbursements are paid out but live on the slip rather
  // than in the structure snapshot, so they join the earnings column here.
  const earningRows: Array<[string, string]> = data ? [
    ...earnings.map(([k, v]) => [label(k), v] as [string, string]),
    ...(Number(data.incentives_amount) ? [['Incentives', data.incentives_amount] as [string, string]] : []),
    ...(Number(data.reimbursements_amount) ? [['Reimbursements', data.reimbursements_amount] as [string, string]] : []),
  ] : [];
  const deductionRows = deductions.map(([k, v]) => [label(k), v] as [string, string]);

  const grossTotal = data
    ? Number(data.gross_earnings) + Number(data.incentives_amount) + Number(data.reimbursements_amount)
    : 0;

  const statusLine = !data ? ''
    : data.status === 'paid' ? ('Paid ' + (data.paid_at ? fmtDate(data.paid_at) : '')).trim()
    : data.status === 'finalized' ? 'Finalized'
    : 'Draft';

  return (
    <Modal title="Payslip"
           subtitle={data ? data.employee_name + ' · ' + period : undefined}
           onClose={onClose} maxWidth="820px">
      {isLoading || !data ? <Spinner /> : (
        <>
          <DocumentPaper innerRef={ref}>
           <div style={{ position: 'relative' }}>
            {/* A draft must never pass for a final payslip on paper. */}
            {data.status === 'draft' && (
              <div aria-hidden style={{
                position: 'absolute', inset: 0, display: 'flex', alignItems: 'center',
                justifyContent: 'center', pointerEvents: 'none', zIndex: 1, overflow: 'hidden',
              }}>
                <span style={{
                  transform: 'rotate(-30deg)', fontSize: 120, fontWeight: 800, letterSpacing: '.2em',
                  color: 'rgba(200, 40, 40, 0.12)', border: '6px solid rgba(200, 40, 40, 0.12)',
                  padding: '0 24px', whiteSpace: 'nowrap',
                }}>DRAFT</span>
              </div>
            )}
            <DocumentLetterhead
              company={company}
              docLabel="Payslip"
              docNumber={period}
              meta={[
                ['Employee', data.employee_code],
                ['Paid days', Number(data.payable_days) + ' of ' + Number(data.total_days)],
                ...(att && Number(att.lop_days) ? [['LOP days', String(Number(att.lop_days))] as [string, string]] : []),
                ['Status', statusLine],
              ]}
            />

            <div style={{ display: 'grid', gap: 24, gridTemplateColumns: '1fr 1fr', marginBottom: 22 }}>
              <DocumentBlock title="Employee">
                <div className="doc-party-name">{data.employee_name}</div>
                {data.designation && <div className="doc-party-line">{data.designation}</div>}
                {data.department && <div className="doc-party-line">{data.department}</div>}
                {data.date_of_joining && (
                  <div className="doc-party-line">Joined {fmtDate(data.date_of_joining)}</div>
                )}
              </DocumentBlock>

              <DocumentBlock title="Payment details">
                <DocLine k="Employee code" v={data.employee_code} />
                {data.pan && <DocLine k="PAN" v={data.pan} />}
                {data.uan && <DocLine k="UAN" v={data.uan} />}
                {data.bank_account_masked && (
                  <DocLine k="Bank account"
                           v={data.bank_account_masked + (data.bank_ifsc ? ' · ' + data.bank_ifsc : '')} />
                )}
              </DocumentBlock>
            </div>

            {att && <AttendanceSummary att={att} lopAmount={lopAmount} />}

            {/* Earnings against deductions — the shape every payslip uses. */}
            <div style={{ display: 'grid', gap: 22, gridTemplateColumns: '1fr 1fr', alignItems: 'start' }}>
              <ComponentTable title="Earnings" rows={earningRows} rates={att ? rates : undefined}
                              total={grossTotal} totalLabel="Total earnings" />
              <ComponentTable title="Deductions" rows={deductionRows}
                              total={Number(data.total_deductions)} totalLabel="Total deductions" />
            </div>

            <div className="doc-totals">
              <DocumentTotal label="Total earnings" value={formatINRExact(grossTotal)} />
              <DocumentTotal label="Total deductions" value={'− ' + formatINRExact(data.total_deductions)} />
              <DocumentTotal label="Net pay" value={formatINRExact(data.net_pay)} variant="grand" />
            </div>

            <DocumentWords amount={data.net_pay} />

            <div className="doc-foot">
              <div style={{ maxWidth: 380 }}>
                {att && Number(att.lop_days) > 0 && (
                  <div>
                    Earnings are pro-rated: {Number(data.payable_days)} paid day(s) of{' '}
                    {Number(data.total_days)}. {Number(att.lop_days)} day(s) of absence or unpaid
                    leave reduced pay by {formatINRExact(lopAmount)}.
                  </div>
                )}
                {note && <div style={{ marginTop: 4 }}>{note}</div>}
                <div style={{ marginTop: 4 }}>
                  This is a computer-generated payslip and does not require a signature.
                </div>
              </div>
              <div className="doc-sign">
                <div className="doc-sign-rule">For {company?.company_name || 'the company'}</div>
              </div>
            </div>
           </div>
          </DocumentPaper>

          <div className="flex gap-2 mt-4">
            <button className="btn btn-p" onClick={print}>Print / Save as PDF</button>
            <button className="btn btn-g" onClick={onClose}>Close</button>
          </div>
        </>
      )}
    </Modal>
  );
}

/** Payslip order and names for the components payroll writes. */
const COMPONENTS: Array<[string, string]> = [
  ['basic', 'Basic'],
  ['hra', 'HRA'],
  ['special_allowance', 'Special allowance'],
  ['other_allowances', 'Other allowances'],
  ['pf_employee', 'PF (employee)'],
  ['esi_employee', 'ESI (employee)'],
  ['professional_tax', 'Professional tax'],
  ['tds', 'TDS'],
];

function componentRank(key: string): number {
  const i = COMPONENTS.findIndex(([k]) => k === key);
  return i < 0 ? COMPONENTS.length : i;
}

function componentLabel(key: string): string {
  return COMPONENTS.find(([k]) => k === key)?.[1]
    ?? key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

/** A key/value line inside a document block. */
function DocLine({ k, v }: { k: string; v: string }) {
  return (
    <div className="doc-party-line" style={{ display: 'flex', gap: 8 }}>
      <span style={{ color: 'var(--text-3)', minWidth: 96 }}>{k}</span>
      <span style={{ fontFamily: 'var(--mono)', fontSize: 11 }}>{v}</span>
    </div>
  );
}

/** One side of the earnings/deductions pair. */
function ComponentTable({ title, rows, rates, total, totalLabel }: {
  title: string; rows: Array<[string, string]>; total: number; totalLabel: string;
  /** Monthly rate per row label; adds a "Monthly rate" column when given. */
  rates?: Record<string, string>;
}) {
  const cols = rates ? 3 : 2;
  return (
    <table className="doc-table">
      <thead>
        <tr>
          <th>{title}</th>
          {rates && <th className="n">Monthly rate</th>}
          <th className="n">{rates ? 'Earned' : 'Amount'}</th>
        </tr>
      </thead>
      <tbody>
        {rows.length === 0 && (
          <tr><td colSpan={cols} style={{ color: 'var(--text-3)', fontSize: 11.5 }}>None</td></tr>
        )}
        {rows.map(([k, v]) => (
          <tr key={k}>
            <td>{k}</td>
            {rates && <td className="n" style={{ color: 'var(--text-3)' }}>{rates[k] ? formatINRExact(rates[k]) : '—'}</td>}
            <td className="n">{formatINRExact(v)}</td>
          </tr>
        ))}
      </tbody>
      <tfoot>
        <tr>
          <td colSpan={cols - 1} style={{ fontWeight: 600, borderBottom: 'none' }}>{totalLabel}</td>
          <td className="n" style={{ fontWeight: 600, borderBottom: 'none' }}>{formatINRExact(total)}</td>
        </tr>
      </tfoot>
    </table>
  );
}

/** The day-by-day count payroll stored on the slip (breakdown.attendance). */
interface AttendanceBreakdown {
  total_days: number; working_days: number; present: number; half_day: number;
  paid_leave: number; unpaid_leave: number; absent: number; holiday: number;
  week_off: number; unrecorded: number; not_employed: number;
  /** Days after the run date: neither paid nor docked yet. */
  upcoming?: number;
  half_day_leave?: number;
  days_worked: string; lop_days: string; payable_days: string;
  paid_leave_by_type?: Record<string, number>;
}

function attendanceOf(p: Payslip): AttendanceBreakdown | null {
  const a = (p.breakdown as Record<string, unknown> | undefined)?.attendance;
  return a && typeof a === 'object' ? (a as AttendanceBreakdown) : null;
}

/** Attendance and leave for the month: how the paid days were reached. */
function AttendanceSummary({ att, lopAmount }: { att: AttendanceBreakdown; lopAmount: number }) {
  const cells: Array<[string, number | string, 'hot' | 'strong' | undefined]> = [
    ['Days in month', att.total_days, undefined],
    ['Working days', att.working_days, undefined],
    ['Present', att.present, undefined],
    ['Half days', att.half_day, undefined],
    ['Paid leave', att.paid_leave, undefined],
    ['Unpaid leave', att.unpaid_leave, att.unpaid_leave ? 'hot' : undefined],
    ['Absent', att.absent, att.absent ? 'hot' : undefined],
    ['Holidays', att.holiday, undefined],
    ['Week offs', att.week_off, undefined],
    ...(att.not_employed ? [['Not yet joined / left', att.not_employed, undefined] as [string, number, undefined]] : []),
    ...(att.half_day_leave ? [['Half-day leave', att.half_day_leave, undefined] as [string, number, undefined]] : []),
    ...(att.unrecorded ? [['No record (paid)', att.unrecorded, undefined] as [string, number, undefined]] : []),
    ...(att.upcoming ? [['Still to come', att.upcoming, 'hot'] as [string, number, 'hot']] : []),
    ['Loss of pay days', Number(att.lop_days), Number(att.lop_days) ? 'hot' : undefined],
    ['Paid days', Number(att.payable_days), 'strong'],
  ];
  const byType = Object.entries(att.paid_leave_by_type ?? {});

  return (
    <div style={{ marginBottom: 22 }}>
      <div className="doc-block-t">Attendance &amp; leave</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(118px, 1fr))',
                    border: '1px solid var(--line)', borderRadius: 6, overflow: 'hidden' }}>
        {cells.map(([k, v, tone]) => (
          <div key={k} style={{
            padding: '8px 10px', borderRight: '1px solid var(--line)', borderBottom: '1px solid var(--line)',
            background: tone === 'strong' ? 'var(--paper)' : undefined, marginRight: -1, marginBottom: -1,
          }}>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 9, letterSpacing: '.1em',
                          textTransform: 'uppercase', color: 'var(--text-3)' }}>{k}</div>
            <div style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', fontSize: 14,
                          fontWeight: tone === 'strong' ? 700 : 600, marginTop: 2,
                          color: tone === 'hot' ? 'var(--hot)' : 'var(--text)' }}>{v}</div>
          </div>
        ))}
      </div>
      {(byType.length > 0 || lopAmount > 0) && (
        <div style={{ fontSize: 11, color: 'var(--text-2)', marginTop: 6, display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          {byType.length > 0 && (
            <span>Paid leave: {byType.map(([t, n]) => `${t} ${n}`).join(', ')}</span>
          )}
          {lopAmount > 0 && <span>Loss of pay: {formatINRExact(lopAmount)}</span>}
        </div>
      )}
    </div>
  );
}
