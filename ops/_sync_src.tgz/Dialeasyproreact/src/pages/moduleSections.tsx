// ============================================================
// DialSathi — Module section registry
//
// HRMS, Sales & Billing and Recruitment each used to be one page holding a row
// of tabs, so "manage employees" and "run payroll" shared a URL. That meant no
// deep link, no back button, no way to bookmark the roster, and a reload always
// dumped you on the module's first tab.
//
// Each section is now its own route. This file is the single source those
// routes AND the sidebar submenu are both generated from — defining them
// separately is how a nav item ends up pointing at a route that no longer
// exists.
//
// `cap` gates the section. Absent means every user with the module can see it.
// ============================================================
import type { ReactNode } from 'react';
import { Cap } from '../hooks/useCapabilities';
import { Module } from '../hooks/useFeatures';

// ---- HRMS ----
import HrmsDashboard from './hrms/DashboardTab';
import HrmsAttendance from './hrms/AttendanceTab';
import HrmsLeave from './hrms/LeaveTab';
import HrmsExpenses from './hrms/ExpensesTab';
import HrmsPayslips from './hrms/PayslipsTab';
import HrmsIncentives from './hrms/IncentivesTab';
import HrmsEmployees from './hrms/EmployeesTab';
import HrmsSettings from './hrms/HRMSSettings';

// ---- Sales & Billing (ERP) ----
import ErpDashboard from './erp/DashboardTab';
import ErpInvoices from './erp/InvoicesTab';
import ErpOrders from './erp/OrdersTab';
import ErpQuotations from './erp/QuotationsTab';
import ErpCustomers from './erp/CustomersTab';
import ErpProducts from './erp/ProductsTab';
import ErpPayments from './erp/PaymentsTab';
import ErpExports from './erp/ExportsTab';

// ---- Recruitment (ATS) ----
import AtsDashboard from './recruitment/DashboardTab';
import AtsOpenings from './recruitment/OpeningsTab';
import AtsPipeline from './recruitment/PipelineTab';
import AtsCandidates from './recruitment/CandidatesTab';
import AtsInterviews from './recruitment/InterviewsTab';
import AtsOffers from './recruitment/OffersTab';
import AtsSettings from './recruitment/RecruitmentSettings';

export type ModuleSection = {
  /** Path segment under the module root, e.g. "employees" → /hrms/employees */
  path: string;
  /** Sidebar label. Kept short — it sits in a 244px rail. */
  label: string;
  /** Page title. Can be longer and more explicit than the nav label. */
  title: string;
  sub?: string;
  cap?: string;
  element: ReactNode;
};

export type ModuleGroup = {
  /** Route prefix and nav key, e.g. "/hrms" */
  base: string;
  label: string;
  /** Add-on module that must be active for any of this to exist. */
  module: string;
  sections: ModuleSection[];
};

export const HRMS_SECTIONS: ModuleSection[] = [
  { path: 'dashboard',  label: 'Dashboard',  title: 'HRMS Dashboard',
    sub: 'Headcount, attendance and payroll at a glance', cap: Cap.HRMS_VIEW_ALL,
    element: <HrmsDashboard /> },
  { path: 'employees',  label: 'Employees',  title: 'Employees',
    sub: 'The roster, salary structures and exits', cap: Cap.HRMS_VIEW_ALL,
    element: <HrmsEmployees /> },
  { path: 'attendance', label: 'Attendance', title: 'Attendance',
    sub: 'Derived from dialer sessions; corrections are manual',
    element: <HrmsAttendance /> },
  { path: 'leave',      label: 'Leave',      title: 'Leave',
    sub: 'Requests, balances and approvals',
    element: <HrmsLeave /> },
  { path: 'expenses',   label: 'Expenses',   title: 'Expense Claims',
    sub: 'Reimbursements, approved into the next payslip',
    element: <HrmsExpenses /> },
  { path: 'payslips',   label: 'Payslips',   title: 'Payroll',
    sub: 'Monthly payslips built from attendance, incentives and claims',
    element: <HrmsPayslips /> },
  { path: 'incentives', label: 'Incentives', title: 'Incentives',
    sub: 'Rules and earned payouts per period', cap: Cap.HRMS_VIEW_ALL,
    element: <HrmsIncentives /> },
  { path: 'settings',   label: 'Settings',   title: 'HRMS Settings',
    sub: 'Leave types, holidays and incentive rules', cap: Cap.HRMS_MANAGE,
    element: <HrmsSettings /> },
];

export const ERP_SECTIONS: ModuleSection[] = [
  { path: 'dashboard',  label: 'Dashboard',    title: 'Sales & Billing',
    sub: 'Revenue, outstanding and recent documents',
    element: <ErpDashboard /> },
  { path: 'quotations', label: 'Quotations',   title: 'Quotations',
    sub: 'Proposals sent to customers',
    element: <ErpQuotations /> },
  { path: 'orders',     label: 'Sales Orders', title: 'Sales Orders',
    sub: 'Accepted quotations, ready to invoice',
    element: <ErpOrders /> },
  { path: 'invoices',   label: 'Invoices',     title: 'Customer Invoices',
    sub: 'GST invoices, issued and outstanding',
    element: <ErpInvoices /> },
  { path: 'payments',   label: 'Payments',     title: 'Payments',
    sub: 'Receipts recorded against invoices',
    element: <ErpPayments /> },
  { path: 'customers',  label: 'Customers',    title: 'Customers',
    sub: 'Billing parties, GSTIN and addresses',
    element: <ErpCustomers /> },
  { path: 'products',   label: 'Products',     title: 'Products & Services',
    sub: 'Catalogue, HSN codes and GST rates',
    element: <ErpProducts /> },
  { path: 'exports',    label: 'Exports',      title: 'Exports',
    sub: 'Tally and accounting extracts', cap: Cap.ERP_EXPORT,
    element: <ErpExports /> },
];

export const ATS_SECTIONS: ModuleSection[] = [
  { path: 'dashboard',  label: 'Dashboard',    title: 'Recruitment',
    sub: 'Openings, pipeline health and upcoming interviews', cap: Cap.ATS_VIEW,
    element: <AtsDashboard /> },
  { path: 'openings',   label: 'Job Openings', title: 'Job Openings',
    sub: 'Roles you are hiring for', cap: Cap.ATS_VIEW,
    element: <AtsOpenings /> },
  { path: 'pipeline',   label: 'Pipeline',     title: 'Hiring Pipeline',
    sub: 'Candidates by stage', cap: Cap.ATS_VIEW,
    element: <AtsPipeline /> },
  { path: 'candidates', label: 'Candidates',   title: 'Candidates',
    sub: 'Everyone who has applied', cap: Cap.ATS_VIEW,
    element: <AtsCandidates /> },
  { path: 'interviews', label: 'Interviews',   title: 'Interviews',
    sub: 'Scheduled rounds and feedback', cap: Cap.ATS_INTERVIEW,
    element: <AtsInterviews /> },
  { path: 'offers',     label: 'Offers',       title: 'Offers',
    sub: 'Issued, accepted and declined', cap: Cap.ATS_OFFER,
    element: <AtsOffers /> },
  { path: 'settings',   label: 'Settings',     title: 'Recruitment Settings',
    sub: 'The stages a candidate moves through', cap: Cap.ATS_MANAGE,
    element: <AtsSettings /> },
];

export const MODULE_GROUPS: ModuleGroup[] = [
  { base: '/hrms',        label: 'HRMS',            module: Module.HRMS,        sections: HRMS_SECTIONS },
  { base: '/erp',         label: 'Sales & Billing', module: Module.ERP_SALES,   sections: ERP_SECTIONS },
  { base: '/recruitment', label: 'Recruitment',     module: Module.RECRUITMENT, sections: ATS_SECTIONS },
];
