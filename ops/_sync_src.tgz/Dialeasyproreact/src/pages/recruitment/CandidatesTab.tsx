// ============================================================
// Recruitment — Candidate database
//
// A candidate is a PERSON, stored once, independent of the roles they apply
// for. That is what makes "have we seen this person before?" answerable, and
// it is why the add form checks for duplicates as you type rather than after
// you save.
// ============================================================
import { useEffect, useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { atsApi } from '../../api';
import { AddButton, Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { Input, Modal, Select, Spinner, Textarea, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINR } from '../../utils/fmt';
import type { Candidate } from '../../types';

const SOURCES = [
  { value: 'referral', label: 'Referral' },
  { value: 'job_board', label: 'Job Board' },
  { value: 'linkedin', label: 'LinkedIn' },
  { value: 'careers_page', label: 'Careers Page' },
  { value: 'agency', label: 'Agency' },
  { value: 'walk_in', label: 'Walk-in' },
  { value: 'other', label: 'Other' },
];

export default function CandidatesTab() {
  const { can } = useCapabilities();
  const canManage = can(Cap.ATS_MANAGE);

  const [search, setSearch] = useState('');
  const [source, setSource] = useState('');
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<Candidate | null>(null);
  const [viewing, setViewing] = useState<Candidate | null>(null);
  const [applying, setApplying] = useState<Candidate | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['ats-candidates', source, search],
    queryFn: () => atsApi.candidates({
      source: source || undefined, q: search || undefined, page_size: 200,
    }).then(r => r.data),
  });

  const rows = data?.results ?? [];

  const columns: Column<Candidate>[] = [
    { key: 'name', header: 'Candidate', sortable: true,
      render: c => (
        <>
          <b>{c.name}</b>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>
            {[c.email, c.phone].filter(Boolean).join(' · ')}
          </div>
        </>
      ) },
    { key: 'current_company', header: 'Current', sortable: true,
      render: c => c.current_company
        ? <>{c.current_designation && <>{c.current_designation}<br /></>}
            <span style={{ color: 'var(--text-2)', fontSize: '0.75rem' }}>{c.current_company}</span></>
        : '—' },
    { key: 'total_experience_years', header: 'Exp', numeric: true, sortable: true,
      sortValue: c => Number(c.total_experience_years), render: c => `${c.total_experience_years} yr` },
    { key: 'expected_ctc', header: 'Expected', numeric: true, sortable: true,
      sortValue: c => Number(c.expected_ctc ?? 0),
      render: c => c.expected_ctc ? formatINR(c.expected_ctc) : '—' },
    { key: 'notice_period_days', header: 'Notice', numeric: true,
      render: c => c.notice_period_days ? `${c.notice_period_days}d` : 'Immediate' },
    { key: 'source', header: 'Source',
      render: c => SOURCES.find(s => s.value === c.source)?.label ?? c.source },
    { key: 'application_count', header: 'Applied to', numeric: true, render: c => c.application_count },
    { key: 'resume', header: 'CV',
      render: c => c.resume
        ? <a href={c.resume} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()}
             style={{ textDecoration: 'underline', fontSize: '0.75rem' }}>Open</a>
        : <span style={{ color: 'var(--text-3)' }}>—</span> },
    { key: 'is_active', header: 'Status',
      render: c => <StatusPill value={c.is_active ? 'active' : 'inactive'} /> },
  ];

  return (
    <>
      {canManage && <AddButton label="Add candidate" onClick={() => setAdding(true)} />}

      <FilterBar search={search} onSearch={setSearch}
                 searchPlaceholder="Search name, email, phone, company…">
        <Select label="Source" value={source} onChange={e => setSource(e.target.value)}>
          <option value="">All sources</option>
          {SOURCES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={c => c.id}
        isLoading={isLoading}
        pageSize={25}
        minWidth="1000px"
        onRowClick={c => setViewing(c)}
        actions={c => (
          <>
            <RowAction label="Profile" onClick={() => setViewing(c)} />
            {canManage && <RowAction label="Apply to role" onClick={() => setApplying(c)} />}
            {canManage && <RowAction label="Edit" onClick={() => setEditing(c)} />}
          </>
        )}
        empty={{
          icon: '◉', title: 'No candidates yet',
          message: 'Add the people you are considering — they stay in the database across roles.',
          action: canManage ? { label: 'Add candidate', onClick: () => setAdding(true) } : undefined,
        }}
      />

      {adding && <CandidateModal onClose={() => setAdding(false)} />}
      {editing && <CandidateModal candidate={editing} onClose={() => setEditing(null)} />}
      {viewing && <CandidateProfile candidate={viewing} onClose={() => setViewing(null)} />}
      {applying && <ApplyModal candidate={applying} onClose={() => setApplying(null)} />}
    </>
  );
}

/* ---- Add / edit ---------------------------------------------- */
function CandidateModal({ candidate, onClose }: { candidate?: Candidate; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const isEdit = !!candidate;

  const [form, setForm] = useState({
    name: candidate?.name ?? '',
    email: candidate?.email ?? '',
    phone: candidate?.phone ?? '',
    source: candidate?.source ?? 'other',
    current_company: candidate?.current_company ?? '',
    current_designation: candidate?.current_designation ?? '',
    total_experience_years: candidate?.total_experience_years ?? '0',
    current_ctc: candidate?.current_ctc ?? '',
    expected_ctc: candidate?.expected_ctc ?? '',
    notice_period_days: String(candidate?.notice_period_days ?? 0),
    location: candidate?.location ?? '',
    skills: (candidate?.skills ?? []).join(', '),
    notes: candidate?.notes ?? '',
  });
  const [resume, setResume] = useState<File | null>(null);
  const [dupes, setDupes] = useState<Candidate[]>([]);

  const set = (k: keyof typeof form) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>,
  ) => setForm(f => ({ ...f, [k]: e.target.value }));

  // Debounced duplicate check. Warns, never blocks — people apply from a
  // personal and a work address, and a shared family phone is a real thing.
  useEffect(() => {
    const email = form.email.trim(), phone = form.phone.trim();
    if (!email && !phone) { setDupes([]); return; }
    const t = setTimeout(() => {
      atsApi.checkDuplicate(email || undefined, phone || undefined, candidate?.id)
        .then(r => setDupes(r.data.matches))
        .catch(() => setDupes([]));
    }, 450);
    return () => clearTimeout(t);
  }, [form.email, form.phone, candidate?.id]);

  const save = useMutation({
    mutationFn: () => {
      const fd = new FormData();
      fd.append('name', form.name);
      fd.append('email', form.email);
      fd.append('phone', form.phone);
      fd.append('source', form.source);
      fd.append('current_company', form.current_company);
      fd.append('current_designation', form.current_designation);
      fd.append('total_experience_years', form.total_experience_years || '0');
      if (form.current_ctc) fd.append('current_ctc', form.current_ctc);
      if (form.expected_ctc) fd.append('expected_ctc', form.expected_ctc);
      fd.append('notice_period_days', form.notice_period_days || '0');
      fd.append('location', form.location);
      // skills is a JSONField; send it as JSON text inside the multipart body.
      fd.append('skills', JSON.stringify(
        form.skills.split(',').map(s => s.trim()).filter(Boolean),
      ));
      fd.append('notes', form.notes);
      if (resume) fd.append('resume', resume);
      return isEdit ? atsApi.updateCandidate(candidate!.id, fd) : atsApi.createCandidate(fd);
    },
    onSuccess: () => {
      showToast('success', isEdit ? 'Candidate updated' : 'Candidate added', form.name);
      qc.invalidateQueries({ queryKey: ['ats-candidates'] });
      qc.invalidateQueries({ queryKey: ['ats-dashboard'] });
      onClose();
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const valid = form.name.trim() && (form.email.trim() || form.phone.trim());

  return (
    <Modal title={isEdit ? 'Edit candidate' : 'Add candidate'} onClose={onClose} maxWidth="620px">
      <div className="flex flex-col gap-3">
        <div className="grid gap-3" style={{ gridTemplateColumns: '2fr 1fr' }}>
          <Input label="Full name" required value={form.name} onChange={set('name')} />
          <Select label="Source" value={form.source} onChange={set('source')}>
            {SOURCES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
          </Select>
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Email" type="email" value={form.email} onChange={set('email')} />
          <Input label="Phone" value={form.phone} onChange={set('phone')} placeholder="9876543210" />
        </div>
        {!valid && form.name.trim() && (
          <p style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>
            Give at least an email address or a phone number — without one they can't be
            contacted or matched against existing candidates.
          </p>
        )}

        {!!dupes.length && (
          <div className="card-brutal" style={{ padding: '10px 12px', background: 'var(--warm-50)' }}>
            <span className="font-heading font-bold" style={{ fontSize: '0.78rem' }}>
              {dupes.length === 1 ? 'This may already be in the database' : 'These may be the same person'}
            </span>
            {dupes.map(d => (
              <div key={d.id} style={{ fontSize: '0.75rem', marginTop: 4 }}>
                {d.name} — {[d.email, d.phone].filter(Boolean).join(' · ')}
                {d.application_count > 0 && ` · applied to ${d.application_count} role(s)`}
              </div>
            ))}
            <p style={{ fontSize: '0.7rem', color: 'var(--text-2)', marginTop: 6 }}>
              Saving anyway is fine — this is a warning, not a block.
            </p>
          </div>
        )}

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Current company" value={form.current_company} onChange={set('current_company')} />
          <Input label="Current designation" value={form.current_designation} onChange={set('current_designation')} />
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr 1fr' }}>
          <Input label="Experience (yrs)" type="number" step="0.5" min="0"
                 value={form.total_experience_years} onChange={set('total_experience_years')} />
          <Input label="Current CTC (₹/yr)" type="number" step="1000" min="0"
                 value={form.current_ctc} onChange={set('current_ctc')} />
          <Input label="Expected CTC (₹/yr)" type="number" step="1000" min="0"
                 value={form.expected_ctc} onChange={set('expected_ctc')} />
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Notice period (days)" type="number" min="0"
                 value={form.notice_period_days} onChange={set('notice_period_days')} />
          <Input label="Location" value={form.location} onChange={set('location')} />
        </div>

        <Input label="Skills (comma separated)" value={form.skills} onChange={set('skills')}
               placeholder="Telesales, CRM, Hindi, Excel" />

        <div>
          <label className="block font-heading font-bold mb-1"
                 style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
            Resume {isEdit && candidate?.resume ? '(replaces the current one)' : ''}
          </label>
          <input className="input-brutal" type="file" accept=".pdf,.doc,.docx"
                 onChange={e => setResume(e.target.files?.[0] ?? null)} />
        </div>

        <Textarea label="Notes" rows={3} value={form.notes} onChange={set('notes')} />

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-1"
                style={{ fontSize: '0.85rem' }}
                disabled={!valid || save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : isEdit ? 'Save changes' : 'Add candidate'}
        </button>
      </div>
    </Modal>
  );
}

/* ---- Profile ------------------------------------------------- */
function CandidateProfile({ candidate, onClose }: { candidate: Candidate; onClose: () => void }) {
  const { data: applications, isLoading } = useQuery({
    queryKey: ['ats-candidate-applications', candidate.id],
    queryFn: () => atsApi.applications({ candidate: candidate.id, page_size: 100 }).then(r => r.data),
  });

  return (
    <Modal title={candidate.name}
           subtitle={[candidate.current_designation, candidate.current_company].filter(Boolean).join(' at ')}
           onClose={onClose} maxWidth="640px">
      <div className="flex flex-col gap-4">
        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))' }}>
          <Field label="Email" value={candidate.email || '—'} />
          <Field label="Phone" value={candidate.phone || '—'} mono />
          <Field label="Experience" value={`${candidate.total_experience_years} yrs`} />
          <Field label="Notice" value={candidate.notice_period_days ? `${candidate.notice_period_days} days` : 'Immediate'} />
          <Field label="Current CTC" value={candidate.current_ctc ? formatINR(candidate.current_ctc) : '—'} />
          <Field label="Expected CTC" value={candidate.expected_ctc ? formatINR(candidate.expected_ctc) : '—'} />
          <Field label="Location" value={candidate.location || '—'} />
          <Field label="Source" value={SOURCES.find(s => s.value === candidate.source)?.label ?? candidate.source} />
        </div>

        {!!candidate.skills?.length && (
          <div>
            <div className="font-heading font-bold mb-2"
                 style={{ fontSize: '0.7rem', textTransform: 'uppercase', color: 'var(--text-3)' }}>
              Skills
            </div>
            <div className="flex gap-2 flex-wrap">
              {candidate.skills.map(s => (
                <span key={s} className="font-heading font-bold"
                      style={{ background: 'var(--surface-2)', border: '1px solid var(--line)',
                               padding: '2px 8px', fontSize: '0.7rem' }}>
                  {s}
                </span>
              ))}
            </div>
          </div>
        )}

        {candidate.resume && (
          <a href={candidate.resume} target="_blank" rel="noreferrer"
             className="btn-brutal btn-secondary px-3 py-2 font-heading font-bold"
             style={{ fontSize: '0.78rem', textAlign: 'center', textDecoration: 'none' }}>
            Open resume
          </a>
        )}

        <div>
          <div className="font-heading font-black mb-2" style={{ fontSize: '0.85rem' }}>
            Applications
          </div>
          {isLoading ? <Spinner /> : !applications?.results.length ? (
            <p style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>
              Not applied to any role yet.
            </p>
          ) : (
            <div className="card-brutal" style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <tbody>
                  {applications.results.map(a => (
                    <tr key={a.id} style={{ borderBottom: '1px solid var(--line)' }}>
                      <td style={{ padding: '7px 10px', fontSize: '0.8rem' }}>
                        <b>{a.opening_title}</b>
                        <div style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>{a.opening_code}</div>
                      </td>
                      <td style={{ padding: '7px 10px' }}><StatusPill value={a.stage_name.toLowerCase()} label={a.stage_name} /></td>
                      <td style={{ padding: '7px 10px' }}><StatusPill value={a.status} /></td>
                      <td style={{ padding: '7px 10px', fontSize: '0.75rem', color: 'var(--text-3)' }}>
                        {fmtDate(a.applied_on)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {candidate.notes && (
          <div>
            <div className="font-heading font-bold mb-1"
                 style={{ fontSize: '0.7rem', textTransform: 'uppercase', color: 'var(--text-3)' }}>Notes</div>
            <p style={{ fontSize: '0.82rem', whiteSpace: 'pre-wrap' }}>{candidate.notes}</p>
          </div>
        )}
      </div>
    </Modal>
  );
}

function Field({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div>
      <div className="font-heading font-bold"
           style={{ fontSize: '0.68rem', textTransform: 'uppercase', color: 'var(--text-3)' }}>{label}</div>
      <div style={{ fontSize: '0.85rem', fontFamily: mono ? 'monospace' : undefined }}>{value}</div>
    </div>
  );
}

/* ---- Apply to a role ----------------------------------------- */
function ApplyModal({ candidate, onClose }: { candidate: Candidate; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [opening, setOpening] = useState('');

  const { data: openings } = useQuery({
    queryKey: ['ats-openings-open'],
    queryFn: () => atsApi.openings({ status: 'open', page_size: 200 }).then(r => r.data),
  });

  const apply = useMutation({
    mutationFn: () => atsApi.createApplication(candidate.id, Number(opening)),
    onSuccess: () => {
      showToast('success', 'Applied', `${candidate.name} is now in the pipeline.`);
      qc.invalidateQueries({ queryKey: ['ats-applications'] });
      qc.invalidateQueries({ queryKey: ['ats-candidates'] });
      qc.invalidateQueries({ queryKey: ['ats-dashboard'] });
      onClose();
    },
    onError: e => showToast('error', 'Could not apply', getErrorMessage(e)),
  });

  const rows = openings?.results ?? [];

  return (
    <Modal title="Apply to a role" subtitle={candidate.name} onClose={onClose} maxWidth="440px">
      <div className="flex flex-col gap-3">
        <Select label="Job opening" required value={opening} onChange={e => setOpening(e.target.value)}>
          <option value="">Select an open role…</option>
          {rows.map(o => (
            <option key={o.id} value={o.id}>
              {o.code} — {o.title}{o.is_filled ? ' (already filled)' : ''}
            </option>
          ))}
        </Select>

        {!rows.length && (
          <p style={{ fontSize: '0.75rem', color: 'var(--text-3)' }}>
            No roles are open. Publish an opening first — draft and closed roles
            don't accept applications.
          </p>
        )}

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                style={{ fontSize: '0.85rem' }}
                disabled={!opening || apply.isPending} onClick={() => apply.mutate()}>
          {apply.isPending ? 'Applying…' : 'Add to pipeline'}
        </button>
      </div>
    </Modal>
  );
}
