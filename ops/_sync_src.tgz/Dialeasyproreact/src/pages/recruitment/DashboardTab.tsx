// ============================================================
// Recruitment — Dashboard
//
// The old version was four tinted StatCards, a stack of progress bars whose
// fill was --brass-50 (a near-white background tone, so the bars read as
// empty at every value), and a second grid of four more StatCards holding
// numbers nobody acts on. Nothing on it linked anywhere, and with an empty
// ATS it rendered as a wall of zeroes with no hint of what to do first.
//
// This is built around the two questions a recruiter opens a dashboard with:
// where is everyone in the funnel, and what is stuck. Every count that names
// a problem is a link to the screen that fixes it.
// ============================================================
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { atsApi } from '../../api';
import { Kpi, Spinner } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { fmtDate, localISODate } from '../../utils/fmt';

// ---- Icons ---------------------------------------------------
const Ico = ({ d }: { d: React.ReactNode }) => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor"
       strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{d}</svg>
);
const I = {
  role: <><rect x="2" y="7" width="20" height="14" rx="2" /><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" /></>,
  people: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  gauge: <><path d="M12 14 20 6" /><path d="M3.5 18a9 9 0 1 1 17 0" /></>,
  check: <><path d="M20 6 9 17l-5-5" /></>,
};

/* The funnel ramp: pale at the top of the funnel, deepening toward the
   stages that matter. Read top to bottom it shows progress toward a hire. */
const FUNNEL_RAMP = ['#8FB6AE', '#6BA396', '#4A9084', '#2E7D71', '#12665C', '#084A43'];

function rampColour(index: number, total: number) {
  if (total <= 1) return FUNNEL_RAMP[FUNNEL_RAMP.length - 1];
  const pos = index / (total - 1);
  return FUNNEL_RAMP[Math.round(pos * (FUNNEL_RAMP.length - 1))];
}

export default function DashboardTab() {
  const nav = useNavigate();
  const { can } = useCapabilities();

  const { data, isLoading } = useQuery({
    queryKey: ['ats-dashboard'],
    queryFn: () => atsApi.dashboard().then(r => r.data),
    refetchInterval: 60_000,
  });

  // Open roles, for the fill-rate table. Small page: this is a summary, and
  // the Job Openings screen is one click away for the full list.
  const { data: openings } = useQuery({
    queryKey: ['ats-dashboard-openings'],
    queryFn: () => atsApi.openings({ status: 'open', page_size: 6 }).then(r => r.data),
  });

  // Interviews are gated behind their own capability, so an interviewer-less
  // recruiter would otherwise get a 403 firing on every dashboard load.
  const canInterview = can(Cap.ATS_INTERVIEW);
  const { data: interviews } = useQuery({
    queryKey: ['ats-dashboard-interviews'],
    queryFn: () => atsApi.interviews({
      status: 'scheduled',
      date_from: localISODate(),
      page_size: 50,
    }).then(r => r.data),
    enabled: canInterview,
  });

  if (isLoading) return <div className="flex justify-center py-16"><Spinner /></div>;
  if (!data) return null;

  const live = data.by_stage.filter(s => !s.is_terminal);
  const inPipeline = live.reduce((sum, s) => sum + s.count, 0);
  const maxCount = Math.max(1, ...live.map(s => s.count));

  const upcoming = [...(interviews?.results ?? [])]
    .sort((a, b) => a.scheduled_at.localeCompare(b.scheduled_at))
    .slice(0, 5);

  // Everything that is somebody's next action, worst first.
  const attention = [
    {
      key: 'onboard',
      count: data.offers.pending_conversion,
      label: 'Accepted offers not onboarded',
      hint: 'Convert them so they appear in HRMS from their joining date',
      tone: 'var(--hot)',
      to: '/recruitment/offers',
      show: can(Cap.ATS_OFFER),
    },
    {
      key: 'feedback',
      count: data.interviews.awaiting_feedback,
      label: 'Interviews awaiting feedback',
      hint: 'A candidate is waiting on a scorecard nobody has written',
      tone: 'var(--warm)',
      to: '/recruitment/interviews',
      show: canInterview,
    },
    {
      key: 'offers',
      count: data.offers.sent,
      label: 'Offers awaiting a response',
      hint: 'Sent, not yet accepted or declined',
      tone: 'var(--visit)',
      to: '/recruitment/offers',
      show: can(Cap.ATS_OFFER),
    },
    {
      key: 'hold',
      count: data.openings.on_hold,
      label: 'Roles on hold',
      hint: 'Paused, and still counting against your plan',
      tone: 'var(--cold)',
      to: '/recruitment/openings',
      show: true,
    },
  ].filter(row => row.show && row.count > 0);

  // Nothing configured at all. A grid of zeroes tells a new tenant nothing,
  // so say what the first three steps are instead.
  const isEmpty = data.openings.open === 0
    && data.openings.on_hold === 0
    && data.openings.closed === 0
    && data.candidates.total === 0;

  if (isEmpty) return <GettingStarted canManage={can(Cap.ATS_MANAGE)} nav={nav} />;

  return (
    <div className="flex flex-col gap-4">
      {/* ---- KPIs ---- */}
      <div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))' }}>
        <Kpi label="Open roles" value={data.openings.open} tone="brand" icon={<Ico d={I.role} />}
             note={`${data.openings.positions} position${data.openings.positions === 1 ? '' : 's'} to fill`}
             onClick={() => nav('/recruitment/openings')} />
        <Kpi label="In pipeline" value={data.candidates.applications_open} tone="visit"
             icon={<Ico d={I.people} />}
             note={`${data.candidates.applied_this_month} applied this month`}
             onClick={() => nav('/recruitment/pipeline')} />
        <Kpi label="Interviews this week" value={data.interviews.upcoming_7_days} tone="brass"
             icon={<Ico d={I.clock} />}
             note={data.interviews.awaiting_feedback
               ? `${data.interviews.awaiting_feedback} awaiting feedback`
               : 'All feedback filed'}
             onClick={canInterview ? () => nav('/recruitment/interviews') : undefined} />
        <Kpi label="Time to hire"
             value={data.avg_time_to_hire_days ?? '—'}
             unit={data.avg_time_to_hire_days !== null ? 'days' : undefined}
             tone="won" icon={<Ico d={I.gauge} />}
             note={data.avg_time_to_hire_days !== null ? 'Average, last 90 days' : 'No hires in the last 90 days'} />
      </div>

      <div className="grid gap-4" style={{ gridTemplateColumns: '1.5fr 1fr' }}>
        {/* ---- Funnel ---- */}
        <div className="plate">
          <div className="plate-h">
            <div>
              <div className="plate-t">Hiring funnel</div>
              <div className="plate-s">Where live applications are sitting</div>
            </div>
            <span className="num" style={{ fontSize: 20, fontWeight: 600 }}>
              {inPipeline}
              <span style={{ fontSize: 11, color: 'var(--text-3)', fontWeight: 400 }}> live</span>
            </span>
          </div>
          <div className="plate-b">
            {!live.length ? (
              <Blank>No active pipeline stages configured.</Blank>
            ) : inPipeline === 0 ? (
              <Blank>No candidates in the pipeline yet.</Blank>
            ) : live.map((s, i) => (
                <div key={s.id} style={{ marginBottom: i === live.length - 1 ? 0 : 15 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 6 }}>
                    <span style={{ fontSize: 12.5, fontWeight: 500 }}>{s.name}</span>
                    <span className="num" style={{ marginLeft: 'auto', fontSize: 14, fontWeight: 600 }}>
                      {s.count}
                    </span>
                    {/* Share of everyone live, NOT a conversion rate. by_stage
                        counts who is sitting in each stage right now, so a
                        stage can legitimately hold more people than the one
                        before it, and a stage-to-stage pass-through read off
                        these numbers would be nonsense. */}
                    <span className="num" style={{ fontSize: 10.5, color: 'var(--text-3)', width: 38, textAlign: 'right' }}>
                      {inPipeline ? Math.round((s.count / inPipeline) * 100) : 0}%
                    </span>
                  </div>
                  {/* Scaled to the biggest stage, not to the total: a stage
                      holding 80% would otherwise render every other bar as an
                      invisible sliver. */}
                  <div style={{ height: 9, borderRadius: 4, background: 'var(--sunken)', overflow: 'hidden' }}>
                    <div style={{
                      width: `${Math.max(s.count ? 2 : 0, (s.count / maxCount) * 100)}%`,
                      height: '100%', borderRadius: 4,
                      background: rampColour(i, live.length),
                      transition: 'width .3s ease',
                    }} />
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* ---- Needs attention ---- */}
        <div className="plate">
          <div className="plate-h">
            <div>
              <div className="plate-t">Needs attention</div>
              <div className="plate-s">Waiting on someone</div>
            </div>
          </div>
          <div className="plate-b" style={{ paddingTop: 6 }}>
            {!attention.length ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '18px 0' }}>
                <span className="kpi-ic" style={{ background: 'var(--won-50)', color: 'var(--won)' }}>
                  <Ico d={I.check} />
                </span>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>Nothing waiting</div>
                  <div style={{ fontSize: 11.5, color: 'var(--text-3)' }}>
                    Every offer, scorecard and role is up to date.
                  </div>
                </div>
              </div>
            ) : attention.map(row => (
              <button key={row.key} onClick={() => nav(row.to)} className="attn-row">
                <span className="attn-bar" style={{ background: row.tone }} />
                <span style={{ minWidth: 0, textAlign: 'left' }}>
                  <span style={{ display: 'block', fontSize: 12.5, fontWeight: 600 }}>{row.label}</span>
                  <span style={{ display: 'block', fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>
                    {row.hint}
                  </span>
                </span>
                <span className="num" style={{ marginLeft: 'auto', fontSize: 17, fontWeight: 600, color: row.tone }}>
                  {row.count}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid gap-4" style={{ gridTemplateColumns: '1.5fr 1fr' }}>
        {/* ---- Open roles ---- */}
        <div className="plate">
          <div className="plate-h">
            <div>
              <div className="plate-t">Open roles</div>
              <div className="plate-s">Applications against positions</div>
            </div>
            <button className="btn btn-g" onClick={() => nav('/recruitment/openings')}>
              All roles
            </button>
          </div>
          <div className="plate-b" style={{ padding: 0 }}>
            {!openings?.results?.length ? (
              <div style={{ padding: 18 }}><Blank>No roles are open right now.</Blank></div>
            ) : (
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <tbody>
                  {openings.results.map(o => {
                    const target = Math.max(1, o.openings);
                    const pct = Math.min(100, (o.hired_count / target) * 100);
                    return (
                      <tr key={o.id} className="role-row" onClick={() => nav('/recruitment/openings')}>
                        <td style={{ padding: '11px 18px', borderTop: '1px solid var(--line)' }}>
                          <div style={{ fontSize: 12.5, fontWeight: 600 }}>{o.title}</div>
                          <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>
                            {[o.department, o.location].filter(Boolean).join(' · ') || o.code}
                          </div>
                        </td>
                        <td style={{ padding: '11px 10px', borderTop: '1px solid var(--line)', width: 96 }}>
                          <div className="num" style={{ fontSize: 12 }}>
                            {o.application_count}
                            <span style={{ color: 'var(--text-3)', fontSize: 10.5 }}> applied</span>
                          </div>
                        </td>
                        <td style={{ padding: '11px 18px', borderTop: '1px solid var(--line)', width: 150 }}>
                          <div className="num" style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 4, textAlign: 'right' }}>
                            {o.hired_count} of {o.openings} filled
                          </div>
                          <div className="progress-bar">
                            <span className="progress-fill"
                                  style={{ width: `${pct}%`, background: pct >= 100 ? 'var(--won)' : 'var(--brand)' }} />
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* ---- Upcoming interviews ---- */}
        <div className="plate">
          <div className="plate-h">
            <div>
              <div className="plate-t">Next interviews</div>
              <div className="plate-s">Scheduled from today</div>
            </div>
          </div>
          <div className="plate-b" style={{ paddingTop: 8 }}>
            {!canInterview ? (
              <Blank>You do not have access to interview scheduling.</Blank>
            ) : !upcoming.length ? (
              <Blank>Nothing scheduled.</Blank>
            ) : upcoming.map(iv => {
              const when = new Date(iv.scheduled_at);
              return (
                <button key={iv.id} onClick={() => nav('/recruitment/interviews')} className="attn-row">
                  <span className="iv-date">
                    <b className="num">{when.getDate()}</b>
                    <i>{when.toLocaleDateString('en-IN', { month: 'short' })}</i>
                  </span>
                  <span style={{ minWidth: 0, textAlign: 'left' }}>
                    <span style={{ display: 'block', fontSize: 12.5, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {iv.candidate_name}
                    </span>
                    <span style={{ display: 'block', fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>
                      {iv.opening_title} · Round {iv.round_number}
                    </span>
                  </span>
                  <span className="num" style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text-2)', textAlign: 'right' }}>
                    {when.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                    <span style={{ display: 'block', fontSize: 10, color: 'var(--text-3)', textTransform: 'capitalize' }}>
                      {iv.mode}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ---- Offer outcomes ---- */}
      <div className="plate">
        <div className="plate-h">
          <div>
            <div className="plate-t">Offers</div>
            <div className="plate-s">To date</div>
          </div>
        </div>
        <div className="plate-b" style={{ display: 'grid', gap: 18,
             gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))' }}>
          <Figure label="Sent" value={data.offers.sent} note="Awaiting a response" tone="var(--visit)" />
          <Figure label="Accepted" value={data.offers.accepted} note="Total to date" tone="var(--won)" />
          <Figure label="To onboard" value={data.offers.pending_conversion}
                  note="Accepted, not yet an employee"
                  tone={data.offers.pending_conversion ? 'var(--hot)' : 'var(--text-3)'} />
          <Figure label="Candidates" value={data.candidates.total} note="In the database" tone="var(--text)" />
        </div>
      </div>
    </div>
  );
}

// ---- Small pieces --------------------------------------------

function Blank({ children }: { children: React.ReactNode }) {
  return <p style={{ fontSize: 12.5, color: 'var(--text-3)', margin: 0 }}>{children}</p>;
}

function Figure({ label, value, note, tone }: {
  label: string; value: number; note: string; tone: string;
}) {
  return (
    <div>
      <div className="kpi-l">{label}</div>
      <div className="num" style={{ fontSize: 24, fontWeight: 600, marginTop: 7, color: tone, lineHeight: 1 }}>
        {value}
      </div>
      <div style={{ fontSize: 11.5, color: 'var(--text-3)', marginTop: 6 }}>{note}</div>
    </div>
  );
}

/* A fresh tenant has no roles, no candidates and no stages worth charting.
   Four zeroes and an empty funnel say nothing; these three steps do. */
function GettingStarted({ canManage, nav }: {
  canManage: boolean; nav: (to: string) => void;
}) {
  const steps = [
    {
      n: 1, title: 'Set up your pipeline',
      body: 'Name the stages a candidate moves through.',
      to: '/recruitment/settings', cta: 'Open settings', show: canManage,
    },
    {
      n: 2, title: 'Post a job opening',
      body: 'A role with a title, department and how many positions you are filling.',
      to: '/recruitment/openings', cta: 'Add a role', show: true,
    },
    {
      n: 3, title: 'Add candidates',
      body: 'Attach a resume, apply them to a role, and they enter the pipeline.',
      to: '/recruitment/candidates', cta: 'Add a candidate', show: true,
    },
  ].filter(s => s.show);

  return (
    <div className="plate" style={{ maxWidth: 760 }}>
      <div className="plate-h">
        <div>
          <div className="plate-t">Start hiring</div>
          <div className="plate-s">No openings or candidates yet</div>
        </div>
      </div>
      <div className="plate-b" style={{ display: 'grid', gap: 18 }}>
        {steps.map(s => (
          <div key={s.n} style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
            <span className="step-n">{s.n}</span>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div style={{ fontSize: 13.5, fontWeight: 600 }}>{s.title}</div>
              <div style={{ fontSize: 12, color: 'var(--text-2)', marginTop: 3, lineHeight: 1.55 }}>{s.body}</div>
            </div>
            <button className="btn btn-g" style={{ flex: 'none' }} onClick={() => nav(s.to)}>
              {s.cta}
            </button>
          </div>
        ))}
        <p style={{ fontSize: 11.5, color: 'var(--text-3)', margin: 0, borderTop: '1px solid var(--line)', paddingTop: 12 }}>
          Once candidates are moving, this page shows the funnel, what is stuck,
          and every role against the positions it still has to fill.
          Today is {fmtDate(localISODate())}.
        </p>
      </div>
    </div>
  );
}
