// ============================================================
// Recruitment — Interviews & scorecards
//
// Feedback is filed PER INTERVIEWER, not per interview: a panel where three
// people disagree is the interesting case, and one shared form loses exactly
// the thing worth reading. You can only ever edit your own scorecard.
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { atsApi } from '../../api';
import { Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { Input, Modal, Select, StatCard, Textarea, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { useAuthStore } from '../../store/authStore';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, localISODate } from '../../utils/fmt';
import type { Application, Interview } from '../../types';

const MODES = [
  { value: 'video', label: 'Video' },
  { value: 'phone', label: 'Phone' },
  { value: 'onsite', label: 'On-site' },
];

const RECOMMENDATIONS = [
  { value: 'strong_yes', label: 'Strong Yes', tone: 'var(--won-50)' },
  { value: 'yes', label: 'Yes', tone: 'var(--won-50)' },
  { value: 'maybe', label: 'Maybe', tone: 'var(--warm-50)' },
  { value: 'no', label: 'No', tone: 'var(--lost-50)' },
  { value: 'strong_no', label: 'Strong No', tone: 'var(--lost-50)' },
];

/** Criteria every scorecard is scored on. Kept short on purpose — a
    fifteen-row rubric is a rubric nobody fills in. */
const CRITERIA = ['Communication', 'Domain knowledge', 'Problem solving', 'Culture fit'];

export default function InterviewsTab() {
  const { can } = useCapabilities();
  const canManage = can(Cap.ATS_MANAGE);

  const [status, setStatus] = useState('scheduled');
  const [mine, setMine] = useState(false);
  const [search, setSearch] = useState('');
  const [scheduling, setScheduling] = useState(false);
  const [feedbackFor, setFeedbackFor] = useState<Interview | null>(null);
  const [viewing, setViewing] = useState<Interview | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['ats-interviews', status, mine],
    queryFn: () => atsApi.interviews({
      status: status || undefined,
      mine: mine ? 'true' : undefined,
      page_size: 200,
    }).then(r => r.data),
  });

  const rows = useMemo(() => {
    const all = data?.results ?? [];
    const q = search.trim().toLowerCase();
    return q ? all.filter(i => i.candidate_name?.toLowerCase().includes(q)
                            || i.opening_title?.toLowerCase().includes(q)) : all;
  }, [data, search]);

  const upcoming = rows.filter(i => i.status === 'scheduled' && new Date(i.scheduled_at) >= new Date()).length;
  const pendingFeedback = rows.filter(i => i.feedback_pending > 0 && i.status === 'completed').length;

  const columns: Column<Interview>[] = [
    { key: 'scheduled_at', header: 'When', sortable: true,
      sortValue: i => i.scheduled_at,
      render: i => (
        <>
          {fmtDate(i.scheduled_at, 'dd MMM yyyy')}
          <div style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>
            {fmtDate(i.scheduled_at, 'HH:mm')} · {i.duration_minutes} min
          </div>
        </>
      ) },
    { key: 'candidate_name', header: 'Candidate', sortable: true,
      render: i => (
        <>
          <b>{i.candidate_name}</b>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>{i.opening_title}</div>
        </>
      ) },
    { key: 'round_number', header: 'Round', numeric: true, sortable: true,
      render: i => i.title || `R${i.round_number}` },
    { key: 'mode', header: 'Mode', render: i => MODES.find(m => m.value === i.mode)?.label ?? i.mode },
    { key: 'interviewer_names', header: 'Panel',
      render: i => i.interviewer_names.length
        ? <span style={{ fontSize: '0.78rem' }}>{i.interviewer_names.join(', ')}</span>
        : <span style={{ color: 'var(--text-3)' }}>—</span> },
    { key: 'average_score', header: 'Score', numeric: true, sortable: true,
      sortValue: i => i.average_score ?? 0,
      render: i => i.average_score !== null
        ? <b style={{ color: i.average_score >= 3.5 ? 'var(--won)' : i.average_score < 2.5 ? 'var(--hot)' : undefined }}>
            {i.average_score.toFixed(1)}/5
          </b>
        : <span style={{ color: 'var(--text-3)' }}>—</span> },
    { key: 'feedback_pending', header: 'Feedback',
      render: i => i.feedback_pending > 0
        ? <span style={{ color: 'var(--warm)', fontSize: '0.75rem', fontWeight: 700 }}>
            {i.feedback_pending} pending
          </span>
        : <span style={{ color: 'var(--text-3)', fontSize: '0.75rem' }}>
            {i.feedback.length} filed
          </span> },
    { key: 'status', header: 'Status', sortable: true, render: i => <StatusPill value={i.status} /> },
  ];

  return (
    <>
      <div className="grid gap-3 mb-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))' }}>
        <StatCard label="Upcoming" value={upcoming} sub="Scheduled and still ahead" icon="◷" />
        <StatCard label="Awaiting feedback" value={pendingFeedback}
                  sub={pendingFeedback ? 'Panels who have not filed' : 'All caught up'}
                  tone={pendingFeedback ? 'purple' : 'green'} icon="✎" />
      </div>

      <div className="flex gap-2 mb-3">
        {canManage && (
          <button className="btn-brutal btn-primary px-3 py-2 font-heading font-black"
                  style={{ fontSize: '0.8rem' }} onClick={() => setScheduling(true)}>
            + Schedule interview
          </button>
        )}
        <button className="btn-brutal px-3 py-2 font-heading font-bold"
                style={{ fontSize: '0.78rem', background: mine ? 'var(--brass-50)' : 'var(--surface)' }}
                onClick={() => setMine(m => !m)}>
          {mine ? 'Showing only mine' : 'Only my interviews'}
        </button>
      </div>

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search candidate or role…">
        <Select label="Status" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All</option>
          <option value="scheduled">Scheduled</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
          <option value="no_show">No show</option>
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={i => i.id}
        isLoading={isLoading}
        pageSize={25}
        minWidth="1000px"
        onRowClick={i => setViewing(i)}
        actions={i => (
          <>
            <RowAction label="Scorecards" onClick={() => setViewing(i)} />
            {i.status !== 'cancelled' && (
              <RowAction label="Give feedback" onClick={() => setFeedbackFor(i)} />
            )}
          </>
        )}
        empty={{
          icon: '◷', title: 'No interviews',
          message: canManage
            ? 'Schedule one against an application in the pipeline.'
            : 'Interviews you are on the panel for appear here.',
        }}
      />

      {scheduling && <ScheduleModal onClose={() => setScheduling(false)} />}
      {feedbackFor && <FeedbackModal interview={feedbackFor} onClose={() => setFeedbackFor(null)} />}
      {viewing && <ScorecardsModal interview={viewing}
                                   onGiveFeedback={() => { setFeedbackFor(viewing); setViewing(null); }}
                                   onClose={() => setViewing(null)} />}
    </>
  );
}

/* ---- Schedule ------------------------------------------------ */
function ScheduleModal({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();

  const { data: applications } = useQuery({
    queryKey: ['ats-applications-open'],
    queryFn: () => atsApi.applications({ open: 'true', page_size: 300 }).then(r => r.data),
  });
  // /recruitment/people/, not /auth/agents/: the agent list is manager-only,
  // so HR got a 403 here and a recruiter always would. This returns just
  // id, name and role — what a picker needs and nothing more.
  const { data: agents } = useQuery({
    queryKey: ['ats-people'],
    queryFn: () => atsApi.people().then(r => r.data),
  });

  const [form, setForm] = useState({
    application: '',
    round_number: '1',
    title: '',
    date: localISODate(),
    time: '10:00',
    duration_minutes: '45',
    mode: 'video',
    location_or_link: '',
    notes: '',
  });
  const [panel, setPanel] = useState<number[]>([]);

  const set = (k: keyof typeof form) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>,
  ) => setForm(f => ({ ...f, [k]: e.target.value }));

  // Suggest the next round number for whichever application is picked, so a
  // second interview isn't accidentally filed as round 1 again.
  const selected = (applications?.results ?? []).find(a => String(a.id) === form.application);
  const suggestedRound = selected ? selected.interview_count + 1 : 1;

  const create = useMutation({
    mutationFn: () => atsApi.createInterview({
      application: Number(form.application),
      round_number: Number(form.round_number) || suggestedRound,
      title: form.title,
      // Local datetime → ISO. The input gives local wall time; the server
      // stores UTC, and the browser converts back on read.
      scheduled_at: new Date(`${form.date}T${form.time}`).toISOString(),
      duration_minutes: Number(form.duration_minutes) || 45,
      mode: form.mode,
      location_or_link: form.location_or_link,
      notes: form.notes,
      interviewers: panel,
    }),
    onSuccess: () => {
      showToast('success', 'Scheduled', 'The panel can now file scorecards against it.');
      qc.invalidateQueries({ queryKey: ['ats-interviews'] });
      qc.invalidateQueries({ queryKey: ['ats-dashboard'] });
      onClose();
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const togglePanel = (id: number) =>
    setPanel(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  return (
    <Modal title="Schedule an interview" onClose={onClose} maxWidth="560px">
      <div className="flex flex-col gap-3">
        <Select label="Application" required value={form.application}
                onChange={e => {
                  const app = (applications?.results ?? []).find(a => String(a.id) === e.target.value);
                  setForm(f => ({
                    ...f, application: e.target.value,
                    round_number: String((app?.interview_count ?? 0) + 1),
                  }));
                }}>
          <option value="">Select a candidate in the pipeline…</option>
          {(applications?.results ?? []).map((a: Application) => (
            <option key={a.id} value={a.id}>
              {a.candidate_name} — {a.opening_code} ({a.stage_name})
            </option>
          ))}
        </Select>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 2fr' }}>
          <Input label="Round" type="number" min="1" value={form.round_number} onChange={set('round_number')} />
          <Input label="Title" value={form.title} onChange={set('title')} placeholder="Technical round" />
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr 1fr' }}>
          <Input label="Date" type="date" value={form.date} onChange={set('date')} />
          <Input label="Time" type="time" value={form.time} onChange={set('time')} />
          <Input label="Minutes" type="number" min="15" step="15"
                 value={form.duration_minutes} onChange={set('duration_minutes')} />
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 2fr' }}>
          <Select label="Mode" value={form.mode} onChange={set('mode')}>
            {MODES.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
          </Select>
          <Input label={form.mode === 'onsite' ? 'Location' : 'Meeting link'}
                 value={form.location_or_link} onChange={set('location_or_link')}
                 placeholder={form.mode === 'onsite' ? 'Office, 3rd floor' : 'https://meet…'} />
        </div>

        <div>
          <label className="block font-heading font-bold mb-1"
                 style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Panel</label>
          <div className="card-brutal" style={{ padding: '8px 10px', maxHeight: 150, overflowY: 'auto' }}>
            {(agents ?? []).map(a => (
              <label key={a.id} className="flex items-center gap-2"
                     style={{ fontSize: '0.8rem', padding: '3px 0', cursor: 'pointer' }}>
                <input type="checkbox" checked={panel.includes(a.id)} onChange={() => togglePanel(a.id)} />
                {a.name} <span style={{ color: 'var(--text-3)', fontSize: '0.72rem' }}>({a.role})</span>
              </label>
            ))}
          </div>
          {!panel.length && (
            <p style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginTop: 4 }}>
              Nobody selected — the interview will have no scorecards to chase.
            </p>
          )}
        </div>

        <Textarea label="Notes for the panel" rows={2} value={form.notes} onChange={set('notes')} />

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-1"
                style={{ fontSize: '0.85rem' }}
                disabled={!form.application || create.isPending} onClick={() => create.mutate()}>
          {create.isPending ? 'Scheduling…' : 'Schedule interview'}
        </button>
      </div>
    </Modal>
  );
}

/* ---- Give feedback ------------------------------------------- */
function FeedbackModal({ interview, onClose }: { interview: Interview; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { agent } = useAuthStore();

  // Editing your own existing scorecard, if you already filed one.
  const existing = interview.feedback.find(f => f.interviewer === agent?.id);

  const [recommendation, setRecommendation] = useState(existing?.recommendation ?? '');
  const [scores, setScores] = useState<Record<string, number>>(existing?.scores ?? {});
  const [strengths, setStrengths] = useState(existing?.strengths ?? '');
  const [concerns, setConcerns] = useState(existing?.concerns ?? '');
  const [comments, setComments] = useState(existing?.comments ?? '');

  const submit = useMutation({
    mutationFn: () => atsApi.submitFeedback(interview.id, {
      recommendation, scores, strengths, concerns, comments,
    }),
    onSuccess: () => {
      showToast('success', existing ? 'Scorecard updated' : 'Scorecard filed', interview.candidate_name);
      qc.invalidateQueries({ queryKey: ['ats-interviews'] });
      qc.invalidateQueries({ queryKey: ['ats-dashboard'] });
      onClose();
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  return (
    <Modal title={existing ? 'Edit your scorecard' : 'Interview scorecard'}
           subtitle={`${interview.candidate_name} · ${interview.title || `Round ${interview.round_number}`}`}
           onClose={onClose} maxWidth="540px">
      <div className="flex flex-col gap-4">
        <div>
          <label className="block font-heading font-bold mb-2"
                 style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Recommendation *</label>
          <div className="flex gap-2 flex-wrap">
            {RECOMMENDATIONS.map(r => (
              <button key={r.value} onClick={() => setRecommendation(r.value)}
                      className="btn-brutal px-3 py-2 font-heading font-bold"
                      style={{
                        fontSize: '0.75rem',
                        background: recommendation === r.value ? r.tone : 'var(--surface)',
                        boxShadow: recommendation === r.value ? '3px 3px 0 var(--text)' : undefined,
                      }}>
                {r.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block font-heading font-bold mb-2"
                 style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>Scores (1–5)</label>
          {CRITERIA.map(c => (
            <div key={c} className="flex items-center justify-between" style={{ padding: '4px 0' }}>
              <span style={{ fontSize: '0.82rem' }}>{c}</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map(n => (
                  <button key={n} onClick={() => setScores(s => ({ ...s, [c.toLowerCase().replace(/ /g, '_')]: n }))}
                          className="btn-brutal font-heading font-bold"
                          style={{
                            width: 30, height: 30, fontSize: '0.75rem',
                            background: scores[c.toLowerCase().replace(/ /g, '_')] === n
                              ? 'var(--brass-50)' : 'var(--surface)',
                          }}>
                    {n}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        <Textarea label="Strengths" rows={2} value={strengths} onChange={e => setStrengths(e.target.value)}
                  placeholder="What they did well" />
        <Textarea label="Concerns" rows={2} value={concerns} onChange={e => setConcerns(e.target.value)}
                  placeholder="What gave you pause" />
        <Textarea label="Other comments" rows={3} value={comments} onChange={e => setComments(e.target.value)} />

        <p className="font-medium" style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>
          This is <b>your</b> scorecard. Other panel members file their own, and nobody
          can overwrite yours.
        </p>

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                style={{ fontSize: '0.85rem' }}
                disabled={!recommendation || submit.isPending} onClick={() => submit.mutate()}>
          {submit.isPending ? 'Saving…' : existing ? 'Update scorecard' : 'File scorecard'}
        </button>
      </div>
    </Modal>
  );
}

/* ---- Read the panel's scorecards ----------------------------- */
function ScorecardsModal({ interview, onGiveFeedback, onClose }: {
  interview: Interview; onGiveFeedback: () => void; onClose: () => void;
}) {
  const label = (k: string) => k.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());

  return (
    <Modal title={interview.title || `Round ${interview.round_number}`}
           subtitle={`${interview.candidate_name} · ${interview.opening_title}`}
           onClose={onClose} maxWidth="620px">
      <div className="flex flex-col gap-4">
        <div className="flex gap-2 items-center flex-wrap">
          <StatusPill value={interview.status} />
          <span style={{ fontSize: '0.78rem', color: 'var(--text-2)' }}>
            {fmtDate(interview.scheduled_at, 'dd MMM yyyy, HH:mm')} · {interview.duration_minutes} min ·{' '}
            {MODES.find(m => m.value === interview.mode)?.label}
          </span>
          {interview.average_score !== null && (
            <span className="font-heading font-black" style={{ fontSize: '0.9rem', marginLeft: 'auto' }}>
              {interview.average_score.toFixed(1)}/5
            </span>
          )}
        </div>

        {interview.location_or_link && (
          <div style={{ fontSize: '0.8rem' }}>
            {interview.mode === 'onsite' ? interview.location_or_link : (
              <a href={interview.location_or_link} target="_blank" rel="noreferrer"
                 style={{ textDecoration: 'underline' }}>{interview.location_or_link}</a>
            )}
          </div>
        )}

        {!interview.feedback.length ? (
          <p style={{ fontSize: '0.82rem', color: 'var(--text-2)' }}>
            No scorecards filed yet
            {interview.feedback_pending > 0 && ` — waiting on ${interview.feedback_pending} panel member(s)`}.
          </p>
        ) : interview.feedback.map(f => (
          <div key={f.id} className="card-brutal" style={{ padding: '12px' }}>
            <div className="flex justify-between items-center mb-2">
              <b style={{ fontSize: '0.85rem' }}>{f.interviewer_name}</b>
              <StatusPill value={f.recommendation.includes('yes') ? 'hired' : f.recommendation === 'maybe' ? 'screening' : 'rejected'}
                          label={RECOMMENDATIONS.find(r => r.value === f.recommendation)?.label ?? f.recommendation} />
            </div>
            {!!Object.keys(f.scores ?? {}).length && (
              <div className="flex gap-3 flex-wrap mb-2">
                {Object.entries(f.scores).map(([k, v]) => (
                  <span key={k} style={{ fontSize: '0.75rem', color: 'var(--text-2)' }}>
                    {label(k)}: <b style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{v}/5</b>
                  </span>
                ))}
              </div>
            )}
            {f.strengths && <P label="Strengths" text={f.strengths} />}
            {f.concerns && <P label="Concerns" text={f.concerns} />}
            {f.comments && <P label="Comments" text={f.comments} />}
          </div>
        ))}

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                style={{ fontSize: '0.85rem' }} onClick={onGiveFeedback}>
          File / edit my scorecard
        </button>
      </div>
    </Modal>
  );
}

function P({ label, text }: { label: string; text: string }) {
  return (
    <div style={{ marginTop: 6 }}>
      <div className="font-heading font-bold"
           style={{ fontSize: '0.66rem', textTransform: 'uppercase', color: 'var(--text-3)' }}>{label}</div>
      <div style={{ fontSize: '0.8rem', whiteSpace: 'pre-wrap' }}>{text}</div>
    </div>
  );
}
