// ============================================================
// Recruitment — Offers, and the handover into HRMS
//
// "Convert to employee" is the bridge that makes this one company suite
// rather than two products sharing a login: it creates the HRMS Employee and
// a draft salary structure from the offer, so the new joiner has attendance,
// leave and payroll from day one without anybody retyping the numbers.
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { atsApi } from '../../api';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { AddButton, Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { ConfirmDialog, Input, Modal, Select, Textarea, useToast } from '../../components/ui';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINRExact } from '../../utils/fmt';
import type { Application, Offer } from '../../types';

const EMPLOYMENT_TYPES = [
  { value: 'full_time', label: 'Full Time' },
  { value: 'part_time', label: 'Part Time' },
  { value: 'contract', label: 'Contract' },
  { value: 'intern', label: 'Intern' },
];

export default function OffersTab() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  // Converting a hire into an HRMS employee creates payroll records, so it
  // is HR/Admin's step (ats.onboard), not the recruiter's. The API refuses it
  // to a recruiter regardless.
  const { can } = useCapabilities();
  const canOnboard = can(Cap.ATS_ONBOARD);

  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState<Offer | null>(null);
  const [converting, setConverting] = useState<Offer | null>(null);
  const [confirm, setConfirm] = useState<{ offer: Offer; status: string } | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['ats-offers', status],
    queryFn: () => atsApi.offers({ status: status || undefined, page_size: 200 }).then(r => r.data),
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['ats-offers'] });
    qc.invalidateQueries({ queryKey: ['ats-dashboard'] });
    qc.invalidateQueries({ queryKey: ['ats-applications'] });
  };

  const setStatusMut = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => atsApi.setOfferStatus(id, status),
    onSuccess: (_r, v) => {
      showToast('success', 'Updated', `Offer marked ${v.status}.`);
      invalidate();
      setConfirm(null);
    },
    onError: e => { showToast('error', 'Failed', getErrorMessage(e)); setConfirm(null); },
  });

  const rows = useMemo(() => {
    const all = data?.results ?? [];
    const q = search.trim().toLowerCase();
    return q ? all.filter(o => o.candidate_name?.toLowerCase().includes(q)
                            || o.opening_title?.toLowerCase().includes(q)) : all;
  }, [data, search]);

  const columns: Column<Offer>[] = [
    { key: 'candidate_name', header: 'Candidate', sortable: true,
      render: o => (
        <>
          <b>{o.candidate_name}</b>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>{o.opening_title}</div>
        </>
      ) },
    { key: 'designation', header: 'Role offered', render: o => o.designation || '—' },
    { key: 'annual_ctc', header: 'Annual CTC', numeric: true, sortable: true,
      sortValue: o => Number(o.annual_ctc), render: o => <b>{formatINRExact(o.annual_ctc)}</b> },
    { key: 'joining_date', header: 'Joining', sortable: true,
      render: o => {
        const soon = new Date(o.joining_date) <= new Date(Date.now() + 7 * 86_400_000);
        return <span style={{ color: soon && o.status === 'accepted' ? 'var(--won)' : undefined }}>
          {fmtDate(o.joining_date)}
        </span>;
      } },
    { key: 'valid_until', header: 'Valid until',
      render: o => {
        if (!o.valid_until) return '—';
        const lapsed = new Date(o.valid_until) < new Date() && o.status === 'sent';
        return <span style={{ color: lapsed ? 'var(--hot)' : undefined, fontWeight: lapsed ? 700 : 400 }}>
          {fmtDate(o.valid_until)}{lapsed && ' · lapsed'}
        </span>;
      } },
    { key: 'status', header: 'Status', sortable: true, render: o => <StatusPill value={o.status} /> },
    { key: 'converted_employee_code', header: 'In HRMS',
      render: o => o.converted_employee_code
        ? <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', fontSize: '0.75rem' }}>{o.converted_employee_code}</span>
        : o.status === 'accepted'
          ? <span style={{ color: 'var(--warm)', fontSize: '0.72rem', fontWeight: 700 }}>Not onboarded</span>
          : <span style={{ color: 'var(--text-3)' }}>—</span> },
  ];

  const pendingConversion = rows.filter(o => o.status === 'accepted' && !o.converted_employee).length;

  return (
    <>
      {pendingConversion > 0 && (
        <div className="card-brutal mb-3" style={{ padding: '12px 14px', background: 'var(--warm-50)' }}>
          <span className="font-heading font-bold" style={{ fontSize: '0.82rem' }}>
            {pendingConversion} accepted offer{pendingConversion === 1 ? '' : 's'} waiting to be onboarded.
          </span>
          <p className="font-medium" style={{ fontSize: '0.75rem', color: 'var(--text-2)', marginTop: 4 }}>
            {canOnboard
              ? 'Converting creates their HRMS employee record and a draft salary structure from the offer, so payroll has something to run against on day one.'
              : 'HR onboards accepted hires into HRMS — they will see these waiting on their Offers screen.'}
          </p>
        </div>
      )}

      <AddButton label="New offer" onClick={() => setCreating(true)} />

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search candidate or role…">
        <Select label="Status" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="draft">Draft</option>
          <option value="sent">Sent</option>
          <option value="accepted">Accepted</option>
          <option value="declined">Declined</option>
          <option value="revoked">Revoked</option>
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={o => o.id}
        isLoading={isLoading}
        pageSize={25}
        minWidth="960px"
        onRowClick={o => setEditing(o)}
        actions={o => (
          <>
            {(o.status === 'draft' || o.status === 'sent') && (
              <RowAction label="Edit" onClick={() => setEditing(o)} />
            )}
            {o.status === 'draft' && (
              <RowAction label="Mark sent" onClick={() => setConfirm({ offer: o, status: 'sent' })} />
            )}
            {o.status === 'sent' && (
              <>
                <RowAction label="Accepted" onClick={() => setConfirm({ offer: o, status: 'accepted' })} />
                <RowAction label="Declined" danger onClick={() => setConfirm({ offer: o, status: 'declined' })} />
              </>
            )}
            {canOnboard && o.status === 'accepted' && !o.converted_employee && (
              <RowAction label="Onboard → HRMS" onClick={() => setConverting(o)} />
            )}
          </>
        )}
        empty={{
          icon: '✉', title: 'No offers',
          message: 'Raise an offer against a candidate who has cleared their interviews.',
          action: { label: 'New offer', onClick: () => setCreating(true) },
        }}
      />

      {creating && <OfferModal onClose={() => setCreating(false)} />}
      {editing && <OfferModal offer={editing} onClose={() => setEditing(null)} />}
      {converting && <ConvertModal offer={converting} onClose={() => setConverting(null)} />}

      {confirm && (
        <ConfirmDialog
          title={confirmTitle(confirm.status)}
          message={confirmMessage(confirm.status, confirm.offer)}
          confirmLabel={confirm.status === 'accepted' ? 'Mark accepted' : 'Confirm'}
          danger={confirm.status === 'declined'}
          onConfirm={() => setStatusMut.mutate({ id: confirm.offer.id, status: confirm.status })}
          onCancel={() => setConfirm(null)}
        />
      )}
    </>
  );
}

function confirmTitle(status: string) {
  return status === 'sent' ? 'Mark this offer as sent?'
       : status === 'accepted' ? 'Candidate accepted?'
       : 'Candidate declined?';
}

function confirmMessage(status: string, offer: Offer) {
  if (status === 'sent') {
    return `Records that ${offer.candidate_name} has been sent the offer. You can still edit it while it is out.`;
  }
  if (status === 'accepted') {
    return `${offer.candidate_name}'s application is marked as hired. You can then onboard them into HRMS, which creates their employee record and a draft salary structure from this offer.`;
  }
  return `${offer.candidate_name} declined. Their application stays open — a declined offer is not automatically a rejection, in case you want to re-offer or consider them for another role.`;
}

/* ---- Create / edit an offer ---------------------------------- */
function OfferModal({ offer, onClose }: { offer?: Offer; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const isEdit = !!offer;

  const { data: applications } = useQuery({
    queryKey: ['ats-applications-offerable'],
    queryFn: () => atsApi.applications({ open: 'true', page_size: 300 }).then(r => r.data),
    enabled: !isEdit,
  });
  // /recruitment/reporting-options/, not /hrms/employees/: that needs an HRMS
  // capability a recruiter never has. Empty (not an error) without HRMS.
  const { data: employees } = useQuery({
    queryKey: ['ats-reporting-options'],
    queryFn: () => atsApi.reportingOptions().then(r => r.data),
  });

  const [form, setForm] = useState({
    application: offer ? String(offer.application) : '',
    annual_ctc: offer?.annual_ctc ?? '',
    fixed_component: offer?.fixed_component ?? '',
    variable_component: offer?.variable_component ?? '0',
    joining_bonus: offer?.joining_bonus ?? '0',
    designation: offer?.designation ?? '',
    department: offer?.department ?? '',
    employment_type: offer?.employment_type ?? 'full_time',
    reporting_to: offer?.reporting_to ?? ('' as number | ''),
    joining_date: offer?.joining_date ?? '',
    valid_until: offer?.valid_until ?? '',
    notes: offer?.notes ?? '',
  });

  const set = (k: keyof typeof form) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>,
  ) => setForm(f => ({ ...f, [k]: e.target.value }));

  const save = useMutation({
    mutationFn: () => {
      const payload = {
        application: Number(form.application),
        annual_ctc: form.annual_ctc,
        // Default the fixed component to the whole CTC when it's left blank,
        // so the salary structure created on conversion isn't seeded from zero.
        fixed_component: form.fixed_component || form.annual_ctc,
        variable_component: form.variable_component || '0',
        joining_bonus: form.joining_bonus || '0',
        designation: form.designation,
        department: form.department,
        employment_type: form.employment_type,
        reporting_to: form.reporting_to || null,
        joining_date: form.joining_date,
        valid_until: form.valid_until || null,
        notes: form.notes,
      };
      return isEdit ? atsApi.updateOffer(offer!.id, payload) : atsApi.createOffer(payload);
    },
    onSuccess: () => {
      showToast('success', isEdit ? 'Offer updated' : 'Offer drafted', '');
      qc.invalidateQueries({ queryKey: ['ats-offers'] });
      qc.invalidateQueries({ queryKey: ['ats-dashboard'] });
      onClose();
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const splitOver = form.annual_ctc &&
    (Number(form.fixed_component || 0) + Number(form.variable_component || 0)) > Number(form.annual_ctc);
  const valid = form.application && Number(form.annual_ctc) > 0 && form.joining_date && !splitOver;

  return (
    <Modal title={isEdit ? 'Edit offer' : 'New offer'}
           subtitle={offer?.candidate_name} onClose={onClose} maxWidth="580px">
      <div className="flex flex-col gap-3">
        {!isEdit && (
          <Select label="Application" required value={form.application} onChange={set('application')}>
            <option value="">Select a candidate…</option>
            {(applications?.results ?? []).filter((a: Application) => !a.has_offer).map((a: Application) => (
              <option key={a.id} value={a.id}>
                {a.candidate_name} — {a.opening_code} ({a.stage_name})
              </option>
            ))}
          </Select>
        )}

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Designation" value={form.designation} onChange={set('designation')}
                 placeholder="Senior Sales Executive" />
          <Input label="Department" value={form.department} onChange={set('department')} placeholder="Sales" />
        </div>

        <Input label="Annual CTC (₹)" type="number" step="1000" min="1" required
               value={form.annual_ctc} onChange={set('annual_ctc')} />

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr 1fr' }}>
          <Input label="Fixed (₹/yr)" type="number" step="1000" min="0"
                 value={form.fixed_component} onChange={set('fixed_component')}
                 placeholder={form.annual_ctc || 'Same as CTC'} />
          <Input label="Variable (₹/yr)" type="number" step="1000" min="0"
                 value={form.variable_component} onChange={set('variable_component')} />
          <Input label="Joining bonus (₹)" type="number" step="1000" min="0"
                 value={form.joining_bonus} onChange={set('joining_bonus')} />
        </div>
        {splitOver && (
          <p style={{ fontSize: '0.72rem', color: 'var(--hot)' }}>
            Fixed plus variable is more than the annual CTC — check the split.
          </p>
        )}

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Joining date" type="date" required value={form.joining_date} onChange={set('joining_date')} />
          <Input label="Offer valid until" type="date" value={form.valid_until} onChange={set('valid_until')} />
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Select label="Employment type" value={form.employment_type} onChange={set('employment_type')}>
            {EMPLOYMENT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
          </Select>
          <Select label="Reports to" value={form.reporting_to} onChange={set('reporting_to')}>
            <option value="">— None —</option>
            {(employees ?? []).map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
          </Select>
        </div>

        <Textarea label="Notes" rows={2} value={form.notes} onChange={set('notes')} />

        <p className="font-medium" style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>
          The fixed component seeds the salary structure created when this hire is
          onboarded into HRMS — so it is worth getting right now.
        </p>

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                style={{ fontSize: '0.85rem' }}
                disabled={!valid || save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : isEdit ? 'Save offer' : 'Create draft offer'}
        </button>
      </div>
    </Modal>
  );
}

/* ---- Convert to employee ------------------------------------- */
function ConvertModal({ offer, onClose }: { offer: Offer; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();

  const { data: suggestion } = useQuery({
    queryKey: ['ats-suggest-code'],
    queryFn: () => atsApi.suggestEmployeeCode().then(r => r.data),
  });
  const [code, setCode] = useState('');

  const convert = useMutation({
    mutationFn: () => atsApi.convertToEmployee(offer.id, code || suggestion?.employee_code),
    onSuccess: r => {
      showToast('success', 'Onboarded',
        `${offer.candidate_name} is now employee ${r.data.employee.employee_code}.`);
      qc.invalidateQueries({ queryKey: ['ats-offers'] });
      qc.invalidateQueries({ queryKey: ['hrms-employees'] });
      qc.invalidateQueries({ queryKey: ['ats-dashboard'] });
      onClose();
    },
    onError: e => showToast('error', 'Could not onboard', getErrorMessage(e)),
  });

  return (
    <Modal title="Onboard into HRMS" subtitle={offer.candidate_name} onClose={onClose} maxWidth="480px">
      <div className="flex flex-col gap-3">
        <div className="card-brutal" style={{ padding: '12px', background: 'var(--paper)' }}>
          <Line label="Joining" value={fmtDate(offer.joining_date)} />
          <Line label="Designation" value={offer.designation || '—'} />
          <Line label="Department" value={offer.department || '—'} />
          <Line label="Annual CTC" value={formatINRExact(offer.annual_ctc)} />
          <Line label="Monthly (from fixed)"
                value={formatINRExact(Number(offer.fixed_component || offer.annual_ctc) / 12)} />
        </div>

        <Input label="Employee code" value={code || suggestion?.employee_code || ''}
               onChange={e => setCode(e.target.value)} />

        <div style={{ fontSize: '0.76rem', color: 'var(--text-2)', lineHeight: 1.6 }}>
          <p style={{ marginBottom: 6 }}>This creates their HRMS employee record and a draft
          salary structure split 50 / 30 / 20 across basic, HRA and special allowance —
          the common Indian default. <b>Review it before the first payroll run</b>;
          statutory deductions (PF, ESI, PT, TDS) stay at zero because their rates
          depend on wage slab and state.</p>
          <p>It does <b>not</b> create a login. Their agent account must already exist
          with the email <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{offer.candidate_email || '(none set)'}</span> —
          handing out CRM access is a decision an admin makes deliberately, not a side
          effect of accepting an offer.</p>
        </div>

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                style={{ fontSize: '0.85rem' }}
                disabled={convert.isPending} onClick={() => convert.mutate()}>
          {convert.isPending ? 'Onboarding…' : 'Create employee record'}
        </button>
      </div>
    </Modal>
  );
}

function Line({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between" style={{ padding: '3px 0', fontSize: '0.82rem' }}>
      <span style={{ color: 'var(--text-2)' }}>{label}</span>
      <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{value}</span>
    </div>
  );
}
