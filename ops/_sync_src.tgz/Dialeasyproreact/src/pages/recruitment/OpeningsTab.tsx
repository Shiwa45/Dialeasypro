// ============================================================
// Recruitment — Job openings
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { atsApi } from '../../api';
import { AddButton, Column, DataTable, FilterBar, RowAction, StatusPill } from '../../components/DataTable';
import { Input, Modal, Select, Textarea, useToast } from '../../components/ui';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate, formatINR } from '../../utils/fmt';
import type { JobOpening } from '../../types';

const EMPLOYMENT_TYPES = [
  { value: 'full_time', label: 'Full Time' },
  { value: 'part_time', label: 'Part Time' },
  { value: 'contract', label: 'Contract' },
  { value: 'intern', label: 'Intern' },
];

export default function OpeningsTab() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canManage = can(Cap.ATS_MANAGE);

  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<JobOpening | null>(null);
  const [adding, setAdding] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['ats-openings', status],
    queryFn: () => atsApi.openings({ status: status || undefined, page_size: 200 }).then(r => r.data),
  });

  const setStatusMut = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => atsApi.setOpeningStatus(id, status),
    onSuccess: (_r, v) => {
      showToast('success', 'Updated', `Marked ${v.status.replace('_', ' ')}.`);
      qc.invalidateQueries({ queryKey: ['ats-openings'] });
      qc.invalidateQueries({ queryKey: ['ats-dashboard'] });
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const rows = useMemo(() => {
    const all = data?.results ?? [];
    const q = search.trim().toLowerCase();
    return q ? all.filter(o => o.title?.toLowerCase().includes(q)
                            || o.code?.toLowerCase().includes(q)
                            || o.department?.toLowerCase().includes(q)) : all;
  }, [data, search]);

  const columns: Column<JobOpening>[] = [
    { key: 'code', header: 'Code', sortable: true,
      render: o => <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums', fontWeight: 700 }}>{o.code}</span> },
    { key: 'title', header: 'Role', sortable: true,
      render: o => (
        <>
          <b>{o.title}</b>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>
            {[o.department, o.location].filter(Boolean).join(' · ') || '—'}
          </div>
        </>
      ) },
    { key: 'employment_type', header: 'Type', render: o => o.employment_type.replace('_', ' ') },
    { key: 'openings', header: 'Filled', numeric: true, sortable: true,
      sortValue: o => o.hired_count / Math.max(1, o.openings),
      render: o => (
        <span style={{ color: o.is_filled ? 'var(--won)' : undefined, fontWeight: o.is_filled ? 700 : 400 }}>
          {o.hired_count}/{o.openings}
        </span>
      ) },
    { key: 'application_count', header: 'Applicants', numeric: true, sortable: true,
      render: o => o.application_count },
    { key: 'salary', header: 'Salary band', numeric: true,
      render: o => o.salary_min || o.salary_max
        ? `${formatINR(o.salary_min)} – ${formatINR(o.salary_max)}`
        : <span style={{ color: 'var(--text-3)' }}>—</span> },
    { key: 'hiring_manager_name', header: 'Hiring manager', render: o => o.hiring_manager_name || '—' },
    { key: 'opened_on', header: 'Opened', sortable: true, render: o => fmtDate(o.opened_on) },
    { key: 'status', header: 'Status', sortable: true, render: o => <StatusPill value={o.status} /> },
  ];

  return (
    <>
      {canManage && <AddButton label="New opening" onClick={() => setAdding(true)} />}

      <FilterBar search={search} onSearch={setSearch} searchPlaceholder="Search role, code, department…">
        <Select label="Status" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          <option value="draft">Draft</option>
          <option value="open">Open</option>
          <option value="on_hold">On hold</option>
          <option value="closed">Closed</option>
        </Select>
      </FilterBar>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={o => o.id}
        isLoading={isLoading}
        pageSize={25}
        minWidth="1000px"
        onRowClick={canManage ? o => setEditing(o) : undefined}
        actions={canManage ? o => (
          <>
            <RowAction label="Edit" onClick={() => setEditing(o)} />
            {o.status === 'draft' && (
              <RowAction label="Publish" disabled={setStatusMut.isPending}
                         onClick={() => setStatusMut.mutate({ id: o.id, status: 'open' })} />
            )}
            {o.status === 'open' && (
              <>
                <RowAction label="Hold" disabled={setStatusMut.isPending}
                           onClick={() => setStatusMut.mutate({ id: o.id, status: 'on_hold' })} />
                <RowAction label="Close" danger disabled={setStatusMut.isPending}
                           onClick={() => setStatusMut.mutate({ id: o.id, status: 'closed' })} />
              </>
            )}
            {(o.status === 'on_hold' || o.status === 'closed') && (
              <RowAction label="Reopen" disabled={setStatusMut.isPending}
                         onClick={() => setStatusMut.mutate({ id: o.id, status: 'open' })} />
            )}
          </>
        ) : undefined}
        empty={{
          icon: '▣', title: 'No job openings',
          message: 'Create a role, publish it, then start adding candidates to its pipeline.',
          action: canManage ? { label: 'New opening', onClick: () => setAdding(true) } : undefined,
        }}
      />

      {adding && <OpeningModal onClose={() => setAdding(false)} />}
      {editing && <OpeningModal opening={editing} onClose={() => setEditing(null)} />}
    </>
  );
}

function OpeningModal({ opening, onClose }: { opening?: JobOpening; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const isEdit = !!opening;

  // /recruitment/people/, not /auth/agents/: the agent list is manager-only,
  // so HR got a 403 here and a recruiter always would. This returns just
  // id, name and role — what a picker needs and nothing more.
  const { data: agents } = useQuery({
    queryKey: ['ats-people'],
    queryFn: () => atsApi.people().then(r => r.data),
  });

  const [form, setForm] = useState({
    title: opening?.title ?? '',
    code: opening?.code ?? suggestCode(),
    department: opening?.department ?? '',
    location: opening?.location ?? '',
    employment_type: opening?.employment_type ?? 'full_time',
    openings: String(opening?.openings ?? 1),
    min_experience_years: opening?.min_experience_years ?? '0',
    max_experience_years: opening?.max_experience_years ?? '',
    salary_min: opening?.salary_min ?? '',
    salary_max: opening?.salary_max ?? '',
    description: opening?.description ?? '',
    hiring_manager: opening?.hiring_manager ?? ('' as number | ''),
  });

  const set = (k: keyof typeof form) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>,
  ) => setForm(f => ({ ...f, [k]: e.target.value }));

  const save = useMutation({
    mutationFn: () => {
      const payload = {
        ...form,
        openings: Number(form.openings) || 1,
        // Blank optional numerics must go as null, not "" — DRF rejects an
        // empty string on a DecimalField.
        max_experience_years: form.max_experience_years || null,
        salary_min: form.salary_min || null,
        salary_max: form.salary_max || null,
        hiring_manager: form.hiring_manager || null,
      };
      return isEdit ? atsApi.updateOpening(opening!.id, payload) : atsApi.createOpening(payload);
    },
    onSuccess: () => {
      showToast('success', isEdit ? 'Opening updated' : 'Opening created', form.title);
      qc.invalidateQueries({ queryKey: ['ats-openings'] });
      qc.invalidateQueries({ queryKey: ['ats-dashboard'] });
      onClose();
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const bandBackwards = form.salary_min && form.salary_max
    && Number(form.salary_min) > Number(form.salary_max);
  const valid = form.title.trim() && form.code.trim() && !bandBackwards;

  return (
    <Modal title={isEdit ? 'Edit job opening' : 'New job opening'} onClose={onClose} maxWidth="600px">
      <div className="flex flex-col gap-3">
        <div className="grid gap-3" style={{ gridTemplateColumns: '2fr 1fr' }}>
          <Input label="Role title" required value={form.title} onChange={set('title')}
                 placeholder="Senior Sales Executive" />
          <Input label="Code" required value={form.code} onChange={set('code')} placeholder="SLS-2026-01" />
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr 1fr' }}>
          <Input label="Department" value={form.department} onChange={set('department')} placeholder="Sales" />
          <Input label="Location" value={form.location} onChange={set('location')} placeholder="Pune" />
          <Input label="Positions" type="number" min="1" value={form.openings} onChange={set('openings')} />
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr 1fr' }}>
          <Select label="Employment type" value={form.employment_type} onChange={set('employment_type')}>
            {EMPLOYMENT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
          </Select>
          <Input label="Min experience (yrs)" type="number" step="0.5" min="0"
                 value={form.min_experience_years} onChange={set('min_experience_years')} />
          <Input label="Max experience (yrs)" type="number" step="0.5" min="0"
                 value={form.max_experience_years} onChange={set('max_experience_years')} />
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: '1fr 1fr' }}>
          <Input label="Salary from (₹/yr)" type="number" step="1000" min="0"
                 value={form.salary_min} onChange={set('salary_min')} />
          <Input label="Salary to (₹/yr)" type="number" step="1000" min="0"
                 value={form.salary_max} onChange={set('salary_max')} />
        </div>
        {bandBackwards && (
          <p style={{ fontSize: '0.72rem', color: 'var(--hot)' }}>
            The lower end of the band is higher than the upper end.
          </p>
        )}

        <Select label="Hiring manager" value={form.hiring_manager} onChange={set('hiring_manager')}>
          <option value="">— None —</option>
          {(agents ?? []).map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
        </Select>

        <Textarea label="Job description" rows={6} value={form.description} onChange={set('description')}
                  placeholder="What the role does, who it reports to, what you're looking for…" />

        {!isEdit && (
          <p className="font-medium" style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>
            Created as a <b>draft</b>. Publish it before candidates can be applied to it.
          </p>
        )}

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black mt-1"
                style={{ fontSize: '0.85rem' }}
                disabled={!valid || save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : isEdit ? 'Save changes' : 'Create opening'}
        </button>
      </div>
    </Modal>
  );
}

/** A sensible starting code — YYYY-MM plus a slot the user overwrites. */
function suggestCode() {
  const d = new Date();
  return `JOB-${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}
