// ============================================================
// Recruitment — Pipeline board
//
// A kanban across the configured stages. Drag to move, or select several and
// move them together: screening twenty CVs one row at a time is what makes a
// recruiter give up on the pipeline and go back to a spreadsheet.
//
// Uses the HTML5 drag API rather than a drag library — one dependency fewer,
// and the interaction is a single drop target per column.
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { atsApi } from '../../api';
import { Modal, Select, Spinner, Textarea, useToast } from '../../components/ui';
import { StatusPill } from '../../components/DataTable';
import { Cap, useCapabilities } from '../../hooks/useCapabilities';
import { getErrorMessage } from '../../utils/errors';
import { fmtDate } from '../../utils/fmt';
import type { Application, ApplicationActivity } from '../../types';

export default function PipelineTab() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canManage = can(Cap.ATS_MANAGE);

  const [opening, setOpening] = useState('');
  const [dragging, setDragging] = useState<number | null>(null);
  const [dropTarget, setDropTarget] = useState<number | null>(null);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [detail, setDetail] = useState<Application | null>(null);

  const { data: stages } = useQuery({
    queryKey: ['ats-stages'],
    queryFn: () => atsApi.stages().then(r => r.data),
  });
  const { data: openings } = useQuery({
    queryKey: ['ats-openings-picker'],
    queryFn: () => atsApi.openings({ page_size: 200 }).then(r => r.data),
  });
  const { data: applications, isLoading } = useQuery({
    queryKey: ['ats-applications', opening],
    queryFn: () => atsApi.applications({
      opening: opening || undefined, open: 'true', page_size: 500,
    }).then(r => r.data),
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['ats-applications'] });
    qc.invalidateQueries({ queryKey: ['ats-dashboard'] });
    qc.invalidateQueries({ queryKey: ['ats-stages'] });
  };

  const move = useMutation({
    mutationFn: ({ id, stage }: { id: number; stage: number }) => atsApi.moveApplication(id, stage),
    onSuccess: () => { invalidate(); },
    onError: e => showToast('error', 'Could not move', getErrorMessage(e)),
  });

  const bulkMove = useMutation({
    mutationFn: (stage: number) => atsApi.bulkMove([...selected], stage),
    onSuccess: r => {
      const { moved, errors, stage } = r.data;
      showToast(errors.length ? 'warning' : 'success', `Moved ${moved} to ${stage}`,
        errors.length ? `${errors.length} could not be moved: ${errors[0].message}` : '');
      setSelected(new Set());
      invalidate();
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const activeStages = useMemo(
    () => (stages ?? []).filter(s => s.is_active).sort((a, b) => a.order - b.order),
    [stages],
  );

  const byStage = useMemo(() => {
    const map: Record<number, Application[]> = {};
    for (const a of applications?.results ?? []) {
      (map[a.stage] ??= []).push(a);
    }
    return map;
  }, [applications]);

  const toggle = (id: number) => setSelected(s => {
    const next = new Set(s);
    next.has(id) ? next.delete(id) : next.add(id);
    return next;
  });

  const onDrop = (stageId: number) => {
    setDropTarget(null);
    if (dragging === null) return;
    const app = (applications?.results ?? []).find(a => a.id === dragging);
    setDragging(null);
    if (!app || app.stage === stageId) return;
    move.mutate({ id: app.id, stage: stageId });
  };

  if (isLoading) return <div className="flex justify-center py-16"><Spinner /></div>;

  return (
    <>
      <div className="card-brutal flex gap-2 items-end mb-3" style={{ padding: '10px 12px', flexWrap: 'wrap' }}>
        <div style={{ minWidth: 240 }}>
          <Select label="Job opening" value={opening} onChange={e => setOpening(e.target.value)}>
            <option value="">All open roles</option>
            {(openings?.results ?? []).map(o => (
              <option key={o.id} value={o.id}>{o.code} — {o.title}</option>
            ))}
          </Select>
        </div>

        {canManage && selected.size > 0 && (
          <div className="flex gap-2 items-end" style={{ marginLeft: 'auto' }}>
            <span className="font-heading font-bold" style={{ fontSize: '0.78rem', paddingBottom: 8 }}>
              {selected.size} selected
            </span>
            <Select label="Move all to" value=""
                    onChange={e => e.target.value && bulkMove.mutate(Number(e.target.value))}>
              <option value="">Pick a stage…</option>
              {activeStages.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
            <button className="btn-brutal btn-secondary px-3 py-2 font-heading font-bold"
                    style={{ fontSize: '0.78rem' }} onClick={() => setSelected(new Set())}>
              Clear
            </button>
          </div>
        )}
      </div>

      {!activeStages.length ? (
        <p style={{ fontSize: '0.85rem', color: 'var(--text-2)' }}>
          No pipeline stages are configured. Set them up under Settings.
        </p>
      ) : (
        <div style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 8 }}>
          {activeStages.map(stage => {
            const cards = byStage[stage.id] ?? [];
            const isTarget = dropTarget === stage.id;
            return (
              <div key={stage.id}
                   onDragOver={e => { if (canManage) { e.preventDefault(); setDropTarget(stage.id); } }}
                   onDragLeave={() => setDropTarget(t => (t === stage.id ? null : t))}
                   onDrop={() => canManage && onDrop(stage.id)}
                   style={{
                     minWidth: 260, flex: '0 0 260px',
                     background: isTarget ? 'var(--brass-50)' : 'var(--surface-2)',
                     border: '1px solid var(--line)',
                     transition: 'background .12s',
                   }}>
                <div className="font-heading font-black"
                     style={{
                       padding: '10px 12px', fontSize: '0.8rem',
                       borderBottom: '1px solid var(--line)',
                       display: 'flex', justifyContent: 'space-between',
                       background: stage.is_terminal ? 'var(--surface)' : undefined,
                     }}>
                  <span>{stage.name}</span>
                  <span style={{ fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>{cards.length}</span>
                </div>

                <div style={{ padding: 8, minHeight: 120, maxHeight: '62vh', overflowY: 'auto' }}>
                  {!cards.length && (
                    <p style={{ fontSize: '0.75rem', color: 'var(--text-3)', padding: '12px 4px', textAlign: 'center' }}>
                      {canManage ? 'Drop a candidate here' : 'Empty'}
                    </p>
                  )}
                  {cards.map(a => (
                    <div key={a.id}
                         draggable={canManage}
                         onDragStart={() => setDragging(a.id)}
                         onDragEnd={() => { setDragging(null); setDropTarget(null); }}
                         onClick={() => setDetail(a)}
                         className="card-brutal"
                         style={{
                           padding: '9px 10px', marginBottom: 8, background: 'var(--surface)',
                           cursor: canManage ? 'grab' : 'pointer',
                           opacity: dragging === a.id ? 0.4 : 1,
                           borderLeft: selected.has(a.id) ? '4px solid var(--brass-50)' : undefined,
                         }}>
                      <div className="flex items-start gap-2">
                        {canManage && (
                          <input type="checkbox" checked={selected.has(a.id)}
                                 onClick={e => e.stopPropagation()}
                                 onChange={() => toggle(a.id)}
                                 style={{ marginTop: 2 }} />
                        )}
                        <div style={{ minWidth: 0, flex: 1 }}>
                          <div className="font-heading font-bold" style={{ fontSize: '0.82rem' }}>
                            {a.candidate_name}
                          </div>
                          <div style={{ fontSize: '0.7rem', color: 'var(--text-3)' }}>
                            {a.opening_code} · {a.candidate_experience} yr
                          </div>
                          <div className="flex gap-2 items-center" style={{ marginTop: 4, flexWrap: 'wrap' }}>
                            {/* Days in stage is the signal that a pipeline is
                                stalling — it goes on the card, not in a report
                                nobody opens. */}
                            <span style={{
                              fontSize: '0.68rem',
                              color: a.days_in_stage > 14 ? 'var(--hot)' : 'var(--text-3)',
                              fontWeight: a.days_in_stage > 14 ? 700 : 400,
                            }}>
                              {a.days_in_stage}d in stage
                            </span>
                            {a.interview_count > 0 && (
                              <span style={{ fontSize: '0.68rem', color: 'var(--text-3)' }}>
                                {a.interview_count} interview{a.interview_count === 1 ? '' : 's'}
                              </span>
                            )}
                            {a.has_offer && <StatusPill value="offer" label="Offer" />}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {detail && <ApplicationDrawer application={detail} onClose={() => setDetail(null)} />}
    </>
  );
}

/* ---- Application drawer -------------------------------------- */
function ApplicationDrawer({ application, onClose }: { application: Application; onClose: () => void }) {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const { can } = useCapabilities();
  const canManage = can(Cap.ATS_MANAGE);
  const [note, setNote] = useState('');

  const { data: activity } = useQuery({
    queryKey: ['ats-activity', application.id],
    queryFn: () => atsApi.activity(application.id).then(r => r.data),
  });
  const { data: stages } = useQuery({
    queryKey: ['ats-stages'],
    queryFn: () => atsApi.stages().then(r => r.data),
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['ats-activity', application.id] });
    qc.invalidateQueries({ queryKey: ['ats-applications'] });
    qc.invalidateQueries({ queryKey: ['ats-dashboard'] });
  };

  const addNote = useMutation({
    mutationFn: () => atsApi.addNote(application.id, note),
    onSuccess: () => { setNote(''); invalidate(); },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const move = useMutation({
    mutationFn: (stage: number) => atsApi.moveApplication(application.id, stage),
    onSuccess: () => { showToast('success', 'Moved', ''); invalidate(); onClose(); },
    onError: e => showToast('error', 'Could not move', getErrorMessage(e)),
  });

  const setStatus = useMutation({
    mutationFn: (status: string) => atsApi.setApplicationStatus(application.id, status),
    onSuccess: () => { showToast('success', 'Updated', ''); invalidate(); onClose(); },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  return (
    <Modal title={application.candidate_name}
           subtitle={`${application.opening_code} — ${application.opening_title}`}
           onClose={onClose} maxWidth="600px">
      <div className="flex flex-col gap-4">
        <div className="flex gap-2 items-center flex-wrap">
          <StatusPill value={application.stage_name.toLowerCase()} label={application.stage_name} />
          <StatusPill value={application.status} />
          <span style={{ fontSize: '0.75rem', color: 'var(--text-2)' }}>
            Applied {fmtDate(application.applied_on)} · {application.days_in_stage} days in stage
          </span>
        </div>

        <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))' }}>
          <Small label="Email" value={application.candidate_email || '—'} />
          <Small label="Phone" value={application.candidate_phone || '—'} />
          <Small label="Experience" value={`${application.candidate_experience} yrs`} />
          <Small label="Recruiter" value={application.owner_name || '—'} />
        </div>

        {canManage && (
          <div className="card-brutal flex gap-2 items-end" style={{ padding: '10px 12px', flexWrap: 'wrap' }}>
            <div style={{ minWidth: 170 }}>
              <Select label="Move to stage" value=""
                      onChange={e => e.target.value && move.mutate(Number(e.target.value))}>
                <option value="">Pick a stage…</option>
                {(stages ?? []).filter(s => s.is_active && s.id !== application.stage)
                  .map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </Select>
            </div>
            {application.status === 'active' && (
              <>
                <button className="btn-brutal px-3 py-2 font-heading font-bold" style={{ fontSize: '0.75rem' }}
                        onClick={() => setStatus.mutate('on_hold')}>Put on hold</button>
                <button className="btn-brutal px-3 py-2 font-heading font-bold"
                        style={{ fontSize: '0.75rem', background: 'var(--lost-50)' }}
                        onClick={() => setStatus.mutate('withdrawn')}>Withdrawn</button>
              </>
            )}
          </div>
        )}

        <div>
          <div className="font-heading font-black mb-2" style={{ fontSize: '0.85rem' }}>Activity</div>
          <div className="flex gap-2 mb-3">
            <input className="input-brutal" value={note} placeholder="Add a note…"
                   onChange={e => setNote(e.target.value)}
                   onKeyDown={e => { if (e.key === 'Enter' && note.trim()) addNote.mutate(); }} />
            <button className="btn-brutal btn-primary px-3 py-2 font-heading font-bold"
                    style={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}
                    disabled={!note.trim() || addNote.isPending} onClick={() => addNote.mutate()}>
              Add
            </button>
          </div>

          {!activity?.length ? (
            <p style={{ fontSize: '0.8rem', color: 'var(--text-2)' }}>No activity yet.</p>
          ) : (
            <div style={{ maxHeight: 260, overflowY: 'auto' }}>
              {activity.map((a: ApplicationActivity) => (
                <div key={a.id} style={{ borderLeft: '2px solid var(--line)', padding: '6px 0 6px 12px', marginBottom: 2 }}>
                  <div style={{ fontSize: '0.8rem' }}>{a.summary}</div>
                  {a.detail && (
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-2)', marginTop: 2 }}>{a.detail}</div>
                  )}
                  <div style={{ fontSize: '0.68rem', color: 'var(--text-3)', marginTop: 2 }}>
                    {a.actor_name ?? 'System'} · {fmtDate(a.created_at, 'dd MMM yyyy, HH:mm')}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {application.rejection_reason && (
          <p style={{ fontSize: '0.78rem', background: 'var(--lost-50)', border: '1px solid var(--line)',
                      padding: '8px 10px' }}>
            Rejected: {application.rejection_reason}
          </p>
        )}
      </div>
    </Modal>
  );
}

function Small({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="font-heading font-bold"
           style={{ fontSize: '0.66rem', textTransform: 'uppercase', color: 'var(--text-3)' }}>{label}</div>
      <div style={{ fontSize: '0.82rem' }}>{value}</div>
    </div>
  );
}
