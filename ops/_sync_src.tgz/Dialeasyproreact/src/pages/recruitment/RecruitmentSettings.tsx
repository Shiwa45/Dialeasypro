// ============================================================
// Recruitment — Settings: pipeline stages
//
// Stages are data rather than an enum because every company names them
// differently. Reordering rewrites `order` in one call, and removing a stage
// deactivates it — applications reference stages with PROTECT, so a real
// delete would be refused by the database anyway.
// ============================================================
import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { atsApi } from '../../api';
import { ConfirmDialog, Input, Modal, Spinner, useToast } from '../../components/ui';
import { getErrorMessage } from '../../utils/errors';
import type { PipelineStage } from '../../types';

export default function RecruitmentSettings() {
  const qc = useQueryClient();
  const { showToast } = useToast();
  const [editing, setEditing] = useState<PipelineStage | 'new' | null>(null);
  const [removing, setRemoving] = useState<PipelineStage | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['ats-stages'],
    queryFn: () => atsApi.stages().then(r => r.data),
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ['ats-stages'] });

  const reorder = useMutation({
    mutationFn: (order: number[]) => atsApi.reorderStages(order),
    onSuccess: () => invalidate(),
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  const remove = useMutation({
    mutationFn: (id: number) => atsApi.deleteStage(id),
    onSuccess: () => {
      showToast('success', 'Deactivated', 'The stage is hidden from the board; existing history is kept.');
      invalidate();
      setRemoving(null);
    },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  if (isLoading) return <Spinner />;

  const stages = [...(data ?? [])].sort((a, b) => a.order - b.order);

  const shift = (index: number, direction: -1 | 1) => {
    const next = [...stages];
    const target = index + direction;
    if (target < 0 || target >= next.length) return;
    [next[index], next[target]] = [next[target], next[index]];
    reorder.mutate(next.map(s => s.id));
  };

  return (
    <>
      <div className="flex justify-between items-center mb-3 flex-wrap gap-2">
        <div>
          <div className="font-heading font-black" style={{ fontSize: '0.9rem' }}>Pipeline stages</div>
          <p className="font-medium" style={{ fontSize: '0.76rem', color: 'var(--text-2)' }}>
            The columns on the pipeline board, in order. A <b>terminal</b> stage is one
            nobody moves out of — moving a candidate into one also closes their application.
          </p>
        </div>
        <button className="btn-brutal btn-primary px-3 py-2 font-heading font-black"
                style={{ fontSize: '0.8rem' }} onClick={() => setEditing('new')}>
          + Add stage
        </button>
      </div>

      <div className="card-brutal" style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 560 }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--line)' }}>
              {['Order', 'Stage', 'Type', 'In this stage', ''].map(h => (
                <th key={h} className="th bare">
                  {h.toUpperCase()}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {stages.map((s, i) => (
              <tr key={s.id} style={{ borderBottom: '1px solid var(--line)', opacity: s.is_active ? 1 : 0.45 }}>
                <td style={{ padding: '8px 11px', whiteSpace: 'nowrap' }}>
                  <button className="btn-brutal font-heading font-bold"
                          style={{ width: 26, height: 26, fontSize: '0.7rem' }}
                          disabled={i === 0 || reorder.isPending} onClick={() => shift(i, -1)}>↑</button>
                  <button className="btn-brutal font-heading font-bold"
                          style={{ width: 26, height: 26, fontSize: '0.7rem', marginLeft: 4 }}
                          disabled={i === stages.length - 1 || reorder.isPending}
                          onClick={() => shift(i, 1)}>↓</button>
                </td>
                <td style={{ padding: '8px 11px', fontSize: '0.85rem', fontWeight: 600 }}>
                  {s.name}
                  {!s.is_active && (
                    <span style={{ fontSize: '0.7rem', color: 'var(--text-3)', marginLeft: 6 }}>(inactive)</span>
                  )}
                </td>
                <td style={{ padding: '8px 11px', fontSize: '0.8rem' }}>
                  {s.is_terminal ? 'Terminal' : 'In progress'}
                </td>
                <td style={{ padding: '8px 11px', fontSize: '0.8rem', fontFamily: 'var(--mono)', fontVariantNumeric: 'tabular-nums' }}>
                  {s.application_count}
                </td>
                <td style={{ padding: '8px 11px', textAlign: 'right', whiteSpace: 'nowrap' }}>
                  <button onClick={() => setEditing(s)}
                          style={{ background: 'none', border: 'none', cursor: 'pointer',
                                   textDecoration: 'underline', fontSize: '0.78rem' }}>Edit</button>
                  {s.is_active && (
                    <button onClick={() => setRemoving(s)}
                            style={{ background: 'none', border: 'none', cursor: 'pointer',
                                     color: 'var(--hot)', fontSize: '0.78rem', marginLeft: 10 }}>
                      Deactivate
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editing && (
        <StageModal stage={editing === 'new' ? null : editing}
                    nextOrder={stages.length + 1}
                    onDone={() => { invalidate(); setEditing(null); }}
                    onClose={() => setEditing(null)} />
      )}

      {removing && (
        <ConfirmDialog
          title={`Deactivate "${removing.name}"?`}
          message={
            removing.application_count > 0
              ? `${removing.application_count} application(s) are sitting in this stage. They stay where they are and keep their history — the stage just stops appearing on the board and in the move menus. Move them somewhere else first if you want the board to stay accurate.`
              : 'The stage stops appearing on the board and in move menus. Its history is kept.'
          }
          confirmLabel="Deactivate"
          danger
          onConfirm={() => remove.mutate(removing.id)}
          onCancel={() => setRemoving(null)}
        />
      )}
    </>
  );
}

function StageModal({ stage, nextOrder, onDone, onClose }: {
  stage: PipelineStage | null; nextOrder: number; onDone: () => void; onClose: () => void;
}) {
  const { showToast } = useToast();
  const isEdit = !!stage;
  const [name, setName] = useState(stage?.name ?? '');
  const [isTerminal, setIsTerminal] = useState(stage?.is_terminal ?? false);
  const [isActive, setIsActive] = useState(stage?.is_active ?? true);

  const save = useMutation({
    mutationFn: () => {
      const payload = {
        name, is_terminal: isTerminal, is_active: isActive,
        order: stage?.order ?? nextOrder,
      };
      return isEdit ? atsApi.updateStage(stage!.id, payload) : atsApi.createStage(payload);
    },
    onSuccess: () => { showToast('success', isEdit ? 'Stage updated' : 'Stage added', name); onDone(); },
    onError: e => showToast('error', 'Failed', getErrorMessage(e)),
  });

  return (
    <Modal title={isEdit ? 'Edit stage' : 'Add stage'} onClose={onClose} maxWidth="420px">
      <div className="flex flex-col gap-3">
        <Input label="Stage name" required value={name} onChange={e => setName(e.target.value)}
               placeholder="Technical Screening" />

        <label className="flex items-center gap-2" style={{ fontSize: '0.85rem', cursor: 'pointer' }}>
          <input type="checkbox" checked={isTerminal} onChange={e => setIsTerminal(e.target.checked)} />
          Terminal stage
        </label>
        <p style={{ fontSize: '0.72rem', color: 'var(--text-3)', marginTop: -6 }}>
          Nobody moves out of a terminal stage. Moving someone into one whose name
          contains "hire" or "reject" also sets their application status to match,
          so the board and your reports can never disagree.
        </p>

        {isEdit && (
          <label className="flex items-center gap-2" style={{ fontSize: '0.85rem', cursor: 'pointer' }}>
            <input type="checkbox" checked={isActive} onChange={e => setIsActive(e.target.checked)} />
            Active (shown on the board)
          </label>
        )}

        <button className="btn-brutal btn-primary px-4 py-2 font-heading font-black"
                style={{ fontSize: '0.85rem' }}
                disabled={!name.trim() || save.isPending} onClick={() => save.mutate()}>
          {save.isPending ? 'Saving…' : isEdit ? 'Save stage' : 'Add stage'}
        </button>
      </div>
    </Modal>
  );
}
