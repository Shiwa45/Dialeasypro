// ============================================================
// Workflows → editor.
//
// WHEN (trigger + its options) → ONLY FOR (conditions) → DO (steps) →
// settings (once per lead or every time, quiet hours). Every list the
// dropdowns offer comes from one /automation/options/ call; the server
// validates everything again and names the step it rejects.
// ============================================================
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  automationApi, type Workflow, type WorkflowInput, type WorkflowOptions,
  type WorkflowStep, type WorkflowStepType,
} from '../../api';
import { Modal, Spinner, useToast } from '../../components/ui';
import { getErrorMessage } from '../../utils/errors';

const STEP_ICON: Record<WorkflowStepType, string> = {
  wait: '⏳', send_whatsapp: '💬', send_sms: '📱', assign: '👤', change_status: '🏷',
  create_followup: '📅', add_note: '📝', notify: '🔔', webhook: '🔗',
};

const lbl: React.CSSProperties = { fontSize: '0.75rem', fontWeight: 600 };
const hint: React.CSSProperties = { fontSize: '0.68rem', color: 'var(--text-3)', marginTop: 2 };

export default function WorkflowEditor({ initial, workflowId, onClose, onSaved }: {
  initial: Partial<WorkflowInput>;
  workflowId?: number;
  onClose: () => void;
  onSaved: (wf: Workflow) => void;
}) {
  const { showToast } = useToast();
  const qc = useQueryClient();
  const { data: opts, isLoading } = useQuery({
    queryKey: ['workflow-options'],
    queryFn: () => automationApi.options().then(r => r.data),
  });

  const [wf, setWf] = useState<Partial<WorkflowInput>>(() => ({
    conditions: {}, trigger_config: {}, steps: [], ...initial,
    quiet_start: (initial.quiet_start ?? '21:00').slice(0, 5),
    quiet_end: (initial.quiet_end ?? '09:00').slice(0, 5),
  }));
  const [showConditions, setShowConditions] = useState(
    Object.values(initial.conditions ?? {}).some(v => Array.isArray(v) && v.length > 0),
  );
  const set = <K extends keyof WorkflowInput>(k: K, v: WorkflowInput[K]) => setWf(p => ({ ...p, [k]: v }));
  const cfg = (wf.trigger_config ?? {}) as Record<string, unknown>;
  const setCfg = (k: string, v: unknown) => set('trigger_config', { ...cfg, [k]: v });
  const steps = wf.steps ?? [];
  const setStep = (i: number, patch: Partial<WorkflowStep>) =>
    set('steps', steps.map((s, j) => (j === i ? { ...s, ...patch } : s)));

  const save = useMutation({
    mutationFn: (activate: boolean) => {
      const payload = { ...wf, is_active: activate ? true : wf.is_active };
      return workflowId
        ? automationApi.update(workflowId, payload)
        : automationApi.create(payload);
    },
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ['workflows'] });
      showToast('success', 'Workflow saved', r.data.is_active ? 'It is switched on.' : 'Switch it on when you are ready.');
      onSaved(r.data);
    },
    onError: (e) => showToast('error', 'Could not save', getErrorMessage(e)),
  });

  const trigger = opts?.triggers.find(t => t.key === wf.trigger);

  return (
    <Modal title={workflowId ? `Edit workflow` : 'New workflow'}
           subtitle="When something happens to a lead, do these steps" onClose={onClose} maxWidth="880px">
      {isLoading || !opts ? <div className="flex justify-center py-10"><Spinner /></div> : (
        <div className="flex flex-col gap-4">
          <div style={{ display: 'grid', gap: 10, gridTemplateColumns: '1fr 1fr' }}>
            <div>
              <label style={lbl}>Name</label>
              <input className="input-brutal" value={wf.name ?? ''} placeholder="e.g. Welcome new leads"
                     onChange={e => set('name', e.target.value)} style={{ width: '100%', marginTop: 4 }} />
            </div>
            <div>
              <label style={lbl}>Description (optional)</label>
              <input className="input-brutal" value={wf.description ?? ''}
                     onChange={e => set('description', e.target.value)} style={{ width: '100%', marginTop: 4 }} />
            </div>
          </div>

          {/* ---- WHEN ---- */}
          <Section title="When" tone="var(--brand-50)">
            <select className="input-brutal" value={wf.trigger}
                    onChange={e => setWf(p => ({ ...p, trigger: e.target.value as WorkflowInput['trigger'], trigger_config: {} }))}
                    style={{ width: '100%' }}>
              {opts.triggers.map(t => <option key={t.key} value={t.key}>{t.label}</option>)}
            </select>
            {trigger && <div style={hint}>{trigger.description}{trigger.scanned ? ' Checked every 15 minutes.' : ''}</div>}
            <TriggerOptions trigger={wf.trigger!} cfg={cfg} setCfg={setCfg} opts={opts} />
          </Section>

          {/* ---- ONLY FOR ---- */}
          <Section title="Only for leads that…" tone="var(--sunken)"
                   aside={<button className="btn btn-g" style={{ fontSize: '0.72rem' }}
                                  onClick={() => setShowConditions(v => !v)}>
                     {showConditions ? 'Hide' : 'Add conditions'}
                   </button>}>
            {!showConditions ? (
              <div style={hint}>Every lead. Add conditions to narrow it to a source, status, batch, agent, city or tag.</div>
            ) : (
              <Conditions value={(wf.conditions ?? {}) as Record<string, unknown>}
                          onChange={v => set('conditions', v as WorkflowInput['conditions'])} opts={opts} />
            )}
          </Section>

          {/* ---- DO ---- */}
          <Section title="Do" tone="var(--won-50)">
            <div className="flex flex-col gap-2">
              {steps.map((s, i) => (
                <StepCard key={i} index={i} step={s} count={steps.length} opts={opts}
                          onChange={p => setStep(i, p)}
                          onType={t => set('steps', steps.map((x, j) => (j === i ? defaultStep(t) : x)))}
                          onMove={d => {
                            const next = [...steps];
                            const [moved] = next.splice(i, 1);
                            next.splice(i + d, 0, moved);
                            set('steps', next);
                          }}
                          onDelete={() => set('steps', steps.filter((_, j) => j !== i))} />
              ))}
            </div>
            <div className="flex gap-2" style={{ marginTop: 10 }}>
              <button className="btn btn-g" style={{ fontSize: '0.75rem' }}
                      onClick={() => set('steps', [...steps, defaultStep('send_whatsapp')])}>+ Add action</button>
              <button className="btn btn-g" style={{ fontSize: '0.75rem' }}
                      onClick={() => set('steps', [...steps, defaultStep('wait')])}>+ Add wait</button>
            </div>
          </Section>

          {/* ---- Settings ---- */}
          <Section title="Settings" tone="var(--sunken)">
            <label className="flex items-center gap-2" style={{ fontSize: '0.8rem' }}>
              <input type="checkbox" checked={!!wf.repeat} onChange={e => set('repeat', e.target.checked)} />
              Run every time it happens
            </label>
            <div style={hint}>
              {wf.repeat
                ? 'Each event starts the workflow again (the same event never twice).'
                : 'A lead goes through this workflow once, ever.'}
            </div>
            <label className="flex items-center gap-2" style={{ fontSize: '0.8rem', marginTop: 10 }}>
              <input type="checkbox" checked={!!wf.quiet_hours_enabled}
                     onChange={e => set('quiet_hours_enabled', e.target.checked)} />
              Quiet hours — hold WhatsApp and SMS from
              <input type="time" className="input-brutal" value={wf.quiet_start}
                     disabled={!wf.quiet_hours_enabled}
                     onChange={e => set('quiet_start', e.target.value)} style={{ width: 110, padding: '2px 6px' }} />
              to
              <input type="time" className="input-brutal" value={wf.quiet_end}
                     disabled={!wf.quiet_hours_enabled}
                     onChange={e => set('quiet_end', e.target.value)} style={{ width: 110, padding: '2px 6px' }} />
            </label>
          </Section>

          <div className="flex gap-3" style={{ marginTop: 4 }}>
            <button onClick={onClose} className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">Cancel</button>
            <button onClick={() => save.mutate(false)} disabled={save.isPending || !wf.name?.trim()}
                    className="btn-brutal btn-secondary flex-1 py-2.5 font-heading font-black">
              {save.isPending ? 'Saving…' : 'Save'}
            </button>
            {!wf.is_active && (
              <button onClick={() => save.mutate(true)} disabled={save.isPending || !wf.name?.trim()}
                      className="btn-brutal btn-primary flex-1 py-2.5 font-heading font-black">
                Save &amp; switch on
              </button>
            )}
          </div>
        </div>
      )}
    </Modal>
  );
}

function defaultStep(type: WorkflowStepType): WorkflowStep {
  switch (type) {
    case 'wait': return { type, amount: 1, unit: 'days' };
    case 'send_whatsapp': return { type, template: null };
    case 'send_sms': return { type, message: '' };
    case 'assign': return { type, agents: [], mode: 'round_robin' };
    case 'change_status': return { type, status: '' };
    case 'create_followup': return { type, in_hours: 24, note: '', followup_type: 'call' };
    case 'add_note': return { type, text: '' };
    case 'notify': return { type, to: 'owner', message: '' };
    case 'webhook': return { type, url: 'https://' };
  }
}

function Section({ title, tone, aside, children }: {
  title: string; tone: string; aside?: React.ReactNode; children: React.ReactNode;
}) {
  return (
    <div style={{ border: '1px solid var(--line)', borderRadius: 10, overflow: 'hidden' }}>
      <div className="flex items-center justify-between"
           style={{ background: tone, padding: '8px 12px', borderBottom: '1px solid var(--line)' }}>
        <span className="font-heading font-black" style={{ fontSize: '0.78rem', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
          {title}
        </span>
        {aside}
      </div>
      <div style={{ padding: 12 }}>{children}</div>
    </div>
  );
}

/** Toggle chips for picking several values from a short list. */
function ChipPick<T extends string | number>({ options, value, onChange }: {
  options: Array<{ value: T; label: string }>; value: T[]; onChange: (v: T[]) => void;
}) {
  return (
    <div className="flex gap-1" style={{ flexWrap: 'wrap', marginTop: 4 }}>
      {options.map(o => {
        const on = value.includes(o.value);
        return (
          <button key={String(o.value)} type="button"
                  onClick={() => onChange(on ? value.filter(v => v !== o.value) : [...value, o.value])}
                  className={`chip ${on ? 'c-brand' : 'c-mute'}`}
                  style={{ cursor: 'pointer', border: on ? '1px solid var(--brand)' : '1px solid transparent' }}>
            {on ? '✓ ' : ''}{o.label}
          </button>
        );
      })}
    </div>
  );
}

const listText = (v: unknown) => (Array.isArray(v) ? v.join(', ') : '');
const textList = (s: string) => s.split(',').map(x => x.trim()).filter(Boolean);

function TriggerOptions({ trigger, cfg, setCfg, opts }: {
  trigger: string; cfg: Record<string, unknown>; setCfg: (k: string, v: unknown) => void; opts: WorkflowOptions;
}) {
  const statuses = opts.statuses.map(s => ({ value: s.key, label: s.label }));
  switch (trigger) {
    case 'lead_status_changed':
      return (
        <div style={{ marginTop: 10 }}>
          <label style={lbl}>Moves to</label>
          <ChipPick options={statuses} value={(cfg.to as string[]) ?? []} onChange={v => setCfg('to', v)} />
          <label style={{ ...lbl, display: 'block', marginTop: 8 }}>Coming from (optional)</label>
          <ChipPick options={statuses} value={(cfg.from as string[]) ?? []} onChange={v => setCfg('from', v)} />
        </div>
      );
    case 'call_outcome':
      return (
        <div style={{ marginTop: 10 }}>
          <label style={lbl}>Outcomes (none picked = any outcome)</label>
          <ChipPick options={opts.dispositions.map(d => ({ value: d.id, label: d.name }))}
                    value={(cfg.dispositions as number[]) ?? []} onChange={v => setCfg('dispositions', v)} />
        </div>
      );
    case 'call_connected':
    case 'call_not_connected':
      return (
        <div style={{ marginTop: 10 }}>
          <label style={lbl}>Calls</label>
          <select className="input-brutal" value={(cfg.direction as string) ?? 'any'}
                  onChange={e => setCfg('direction', e.target.value)} style={{ width: 220, marginLeft: 8 }}>
            <option value="any">Any direction</option>
            <option value="outbound">Calls the agent made</option>
            <option value="inbound">Calls the lead made</option>
          </select>
        </div>
      );
    case 'whatsapp_received':
      return (
        <div style={{ marginTop: 10, display: 'grid', gap: 8, gridTemplateColumns: '2fr 1fr' }}>
          <div>
            <label style={lbl}>Keywords (comma separated — blank = any message)</label>
            <input className="input-brutal" defaultValue={listText(cfg.keywords)} placeholder="price, brochure, rate"
                   onBlur={e => setCfg('keywords', textList(e.target.value))} style={{ width: '100%', marginTop: 4 }} />
          </div>
          <div>
            <label style={lbl}>Match</label>
            <select className="input-brutal" value={(cfg.match as string) ?? 'contains'}
                    onChange={e => setCfg('match', e.target.value)} style={{ width: '100%', marginTop: 4 }}>
              <option value="contains">Message contains a keyword</option>
              <option value="exact">Message is exactly a keyword</option>
            </select>
          </div>
        </div>
      );
    case 'followup_missed':
      return (
        <div style={{ marginTop: 10 }} className="flex items-center gap-2">
          <span style={lbl}>Still open</span>
          <input type="number" min={5} className="input-brutal" value={(cfg.minutes as number) ?? 30}
                 onChange={e => setCfg('minutes', Number(e.target.value))} style={{ width: 90 }} />
          <span style={lbl}>minutes after it was due</span>
        </div>
      );
    case 'lead_inactive':
      return (
        <div style={{ marginTop: 10 }} className="flex items-center gap-2">
          <span style={lbl}>No contact for</span>
          <input type="number" min={1} className="input-brutal" value={(cfg.days as number) ?? 3}
                 onChange={e => setCfg('days', Number(e.target.value))} style={{ width: 80 }} />
          <span style={lbl}>days (open leads only)</span>
        </div>
      );
    default:
      return null;
  }
}

function Conditions({ value, onChange, opts }: {
  value: Record<string, unknown>; onChange: (v: Record<string, unknown>) => void; opts: WorkflowOptions;
}) {
  const put = (k: string, v: unknown) => onChange({ ...value, [k]: v });
  return (
    <div className="flex flex-col gap-3">
      <div>
        <label style={lbl}>Source is</label>
        <ChipPick options={opts.sources.map(s => ({ value: s.key, label: s.label }))}
                  value={(value.sources as string[]) ?? []} onChange={v => put('sources', v)} />
      </div>
      <div>
        <label style={lbl}>Status is</label>
        <ChipPick options={opts.statuses.map(s => ({ value: s.key, label: s.label }))}
                  value={(value.statuses as string[]) ?? []} onChange={v => put('statuses', v)} />
      </div>
      <div>
        <label style={lbl}>Assigned to</label>
        <ChipPick options={[{ value: 0, label: 'Unassigned' }, ...opts.agents.map(a => ({ value: a.id, label: a.name }))]}
                  value={(value.assigned_to as number[]) ?? []} onChange={v => put('assigned_to', v)} />
      </div>
      {opts.batches.length > 0 && (
        <div>
          <label style={lbl}>In batch</label>
          <ChipPick options={opts.batches.slice(0, 30).map(b => ({ value: b.id, label: b.name }))}
                    value={(value.batches as number[]) ?? []} onChange={v => put('batches', v)} />
        </div>
      )}
      <div style={{ display: 'grid', gap: 8, gridTemplateColumns: '1fr 1fr' }}>
        <div>
          <label style={lbl}>City is (comma separated)</label>
          <input className="input-brutal" defaultValue={listText(value.cities)}
                 onBlur={e => put('cities', textList(e.target.value))} style={{ width: '100%', marginTop: 4 }} />
        </div>
        <div>
          <label style={lbl}>Has tag (comma separated)</label>
          <input className="input-brutal" defaultValue={listText(value.tags)}
                 onBlur={e => put('tags', textList(e.target.value))} style={{ width: '100%', marginTop: 4 }} />
        </div>
      </div>
    </div>
  );
}

function StepCard({ index, step, count, opts, onChange, onType, onMove, onDelete }: {
  index: number; step: WorkflowStep; count: number; opts: WorkflowOptions;
  onChange: (p: Partial<WorkflowStep>) => void; onType: (t: WorkflowStepType) => void;
  onMove: (d: -1 | 1) => void; onDelete: () => void;
}) {
  const isWait = step.type === 'wait';
  const approved = useMemo(() => opts.templates.filter(t => t.status === 'approved'), [opts.templates]);
  const multiNumber = opts.whatsapp_numbers.length > 1;
  const placeholderHint = `Use ${opts.placeholders.map(p => `{${p}}`).join(', ')}`;
  // A WhatsApp step sends either an approved template or free text.
  const isText = step.type === 'send_whatsapp' && !step.template && step.message !== undefined;

  return (
    <div style={{
      border: '1px solid var(--line)', borderRadius: 8, padding: 10,
      background: isWait ? 'var(--warm-50)' : 'var(--surface)',
    }}>
      <div className="flex items-center gap-2">
        <span className="font-heading font-black" style={{ fontSize: '0.75rem', minWidth: 22 }}>{index + 1}.</span>
        <span style={{ fontSize: '1rem' }}>{STEP_ICON[step.type]}</span>
        {isWait ? (
          <span className="flex items-center gap-2" style={{ fontSize: '0.8rem', fontWeight: 600 }}>
            Wait
            <input type="number" min={1} className="input-brutal" value={step.amount ?? 1}
                   onChange={e => onChange({ amount: Number(e.target.value) })} style={{ width: 80, padding: '2px 6px' }} />
            <select className="input-brutal" value={step.unit ?? 'days'}
                    onChange={e => onChange({ unit: e.target.value as WorkflowStep['unit'] })} style={{ padding: '2px 6px' }}>
              <option value="minutes">minutes</option>
              <option value="hours">hours</option>
              <option value="days">days</option>
            </select>
          </span>
        ) : (
          <select className="input-brutal" value={step.type} onChange={e => onType(e.target.value as WorkflowStepType)}
                  style={{ padding: '3px 8px', fontWeight: 600 }}>
            {opts.actions.filter(a => a.key !== 'wait').map(a => <option key={a.key} value={a.key}>{a.label}</option>)}
          </select>
        )}
        <span style={{ marginLeft: 'auto' }} className="flex gap-1">
          <button className="btn btn-g" style={{ fontSize: '0.7rem', padding: '2px 8px' }} disabled={index === 0}
                  onClick={() => onMove(-1)} title="Move up">↑</button>
          <button className="btn btn-g" style={{ fontSize: '0.7rem', padding: '2px 8px' }} disabled={index === count - 1}
                  onClick={() => onMove(1)} title="Move down">↓</button>
          <button className="btn btn-g" style={{ fontSize: '0.7rem', padding: '2px 8px', color: 'var(--hot)' }}
                  onClick={onDelete} title="Remove step">✕</button>
        </span>
      </div>

      {!isWait && (
        <div style={{ marginTop: 8, paddingLeft: 30 }} className="flex flex-col gap-2">
          {step.type === 'send_whatsapp' && (
            <>
              <div style={{ display: 'grid', gap: 8, gridTemplateColumns: multiNumber ? '2fr 1fr' : '1fr' }}>
                <select className="input-brutal" value={isText ? 'text' : (step.template ?? '')}
                        onChange={e => {
                          const v = e.target.value;
                          if (v === 'text') onChange({ template: undefined, message: step.message ?? '' });
                          else onChange({ template: v ? Number(v) : null, message: undefined });
                        }}>
                  <option value="">Choose an approved template…</option>
                  {approved.map(t => (
                    <option key={t.id} value={t.id} disabled={t.unmapped.length > 0}>
                      {t.name}{t.account_label && multiNumber ? ` · ${t.account_label}` : ''}{t.unmapped.length ? ' — map its variables first' : ''}
                    </option>
                  ))}
                  <option value="text">Free text (only reaches leads who wrote in the last 24 h)</option>
                </select>
                {multiNumber && (
                  <select className="input-brutal" value={step.account ?? ''}
                          onChange={e => onChange({ account: e.target.value ? Number(e.target.value) : null })}>
                    <option value="">Send from: automatic</option>
                    {opts.whatsapp_numbers.map(n => <option key={n.id} value={n.id}>From {n.label}</option>)}
                  </select>
                )}
              </div>
              {isText && (
                <>
                  <textarea className="input-brutal" rows={3} value={step.message} placeholder="Hi {first_name}, …"
                            onChange={e => onChange({ message: e.target.value })} />
                  <div style={hint}>{placeholderHint}</div>
                </>
              )}
              {step.template && (
                <div style={{ ...hint, fontSize: '0.72rem' }}>
                  {approved.find(t => t.id === step.template)?.body_text}
                </div>
              )}
              {!approved.length && (
                <div style={{ ...hint, color: 'var(--hot)' }}>
                  No approved templates yet — add one under Communications → Templates.
                </div>
              )}
            </>
          )}

          {step.type === 'send_sms' && (
            <>
              <textarea className="input-brutal" rows={2} value={step.message ?? ''} placeholder="Hi {first_name}, …"
                        onChange={e => onChange({ message: e.target.value })} />
              <div style={hint}>{placeholderHint}. DND leads are skipped.</div>
            </>
          )}

          {step.type === 'assign' && (
            <>
              <ChipPick options={opts.agents.map(a => ({ value: a.id, label: a.name }))}
                        value={step.agents ?? []} onChange={v => onChange({ agents: v })} />
              <div className="flex gap-3" style={{ fontSize: '0.75rem' }}>
                <label className="flex items-center gap-1">
                  <input type="radio" checked={step.mode !== 'fixed'} onChange={() => onChange({ mode: 'round_robin' })} />
                  Round-robin between them
                </label>
                <label className="flex items-center gap-1">
                  <input type="radio" checked={step.mode === 'fixed'} onChange={() => onChange({ mode: 'fixed' })} />
                  Always the first one
                </label>
                <label className="flex items-center gap-1">
                  <input type="checkbox" checked={!!step.only_if_unassigned}
                         onChange={e => onChange({ only_if_unassigned: e.target.checked })} />
                  Only if the lead has no owner
                </label>
              </div>
            </>
          )}

          {step.type === 'change_status' && (
            <select className="input-brutal" value={step.status ?? ''} onChange={e => onChange({ status: e.target.value })}
                    style={{ maxWidth: 280 }}>
              <option value="">Choose a status…</option>
              {opts.statuses.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
            </select>
          )}

          {step.type === 'create_followup' && (
            <div className="flex items-center gap-2" style={{ flexWrap: 'wrap', fontSize: '0.78rem' }}>
              <select className="input-brutal" value={step.followup_type ?? 'call'}
                      onChange={e => onChange({ followup_type: e.target.value })} style={{ padding: '3px 8px' }}>
                {opts.followup_types.map(f => <option key={f.key} value={f.key}>{f.label}</option>)}
              </select>
              in
              <input type="number" min={0} className="input-brutal" value={step.in_hours ?? 24}
                     onChange={e => onChange({ in_hours: Number(e.target.value) })} style={{ width: 80, padding: '2px 6px' }} />
              hours, for the lead&apos;s owner
              <input className="input-brutal" value={step.note ?? ''} placeholder="Note (optional)"
                     onChange={e => onChange({ note: e.target.value })} style={{ flex: 1, minWidth: 200 }} />
            </div>
          )}

          {step.type === 'add_note' && (
            <textarea className="input-brutal" rows={2} value={step.text ?? ''} placeholder="Note on the lead…"
                      onChange={e => onChange({ text: e.target.value })} />
          )}

          {step.type === 'notify' && (
            <div style={{ display: 'grid', gap: 8, gridTemplateColumns: '1fr 2fr' }}>
              <select className="input-brutal" value={step.to === 'agent' ? String(step.agent ?? '') : 'owner'}
                      onChange={e => onChange(e.target.value === 'owner'
                        ? { to: 'owner', agent: undefined } : { to: 'agent', agent: Number(e.target.value) })}>
                <option value="owner">The lead&apos;s owner</option>
                {opts.agents.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
              </select>
              <input className="input-brutal" value={step.message ?? ''} placeholder="e.g. New hot lead {name}"
                     onChange={e => onChange({ message: e.target.value })} />
            </div>
          )}

          {step.type === 'webhook' && (
            <>
              <input className="input-brutal" value={step.url ?? ''} placeholder="https://…"
                     onChange={e => onChange({ url: e.target.value })} />
              <div style={hint}>The lead&apos;s details are POSTed as JSON. Only public https addresses are allowed.</div>
            </>
          )}

          {index > 0 && ['send_whatsapp', 'send_sms', 'notify', 'create_followup'].includes(step.type) && (
            <label className="flex items-center gap-1" style={{ fontSize: '0.72rem', color: 'var(--text-2)' }}>
              <input type="checkbox" checked={!!step.only_if_no_reply}
                     onChange={e => onChange({ only_if_no_reply: e.target.checked })} />
              Only if the lead hasn&apos;t replied on WhatsApp since the workflow started
            </label>
          )}
        </div>
      )}
    </div>
  );
}
