// ============================================================
// Workflows → ready-made starting points.
//
// Each preset fills the editor; nothing is saved until the admin reviews it,
// picks the template / agents it needs and presses Save. Template and agent
// ids are left empty on purpose — they differ in every workspace.
// ============================================================
import type { WorkflowInput } from '../../api';

export type Preset = {
  key: string;
  title: string;
  blurb: string;
  icon: string;
  workflow: Partial<WorkflowInput>;
};

const base = {
  description: '', is_active: false, conditions: {}, repeat: false,
  quiet_hours_enabled: true, quiet_start: '21:00', quiet_end: '09:00',
};

export const PRESETS: Preset[] = [
  {
    key: 'welcome',
    title: 'Welcome new leads',
    blurb: 'Send a WhatsApp welcome the moment a lead arrives, and a reminder next day if they don’t reply.',
    icon: '👋',
    workflow: {
      ...base, name: 'Welcome new leads', trigger: 'lead_created', trigger_config: {},
      steps: [
        { type: 'send_whatsapp', template: null },
        { type: 'wait', amount: 1, unit: 'days' },
        { type: 'send_whatsapp', template: null, only_if_no_reply: true },
      ],
    },
  },
  {
    key: 'missed-call',
    title: 'Missed call follow-up',
    blurb: 'When a call doesn’t connect, WhatsApp the lead and book a call-back for the agent.',
    icon: '📵',
    workflow: {
      ...base, name: 'Missed call follow-up', trigger: 'call_not_connected',
      trigger_config: { direction: 'outbound' }, repeat: true,
      steps: [
        { type: 'send_whatsapp', template: null },
        { type: 'create_followup', in_hours: 2, note: 'Call back {first_name} — last call did not connect', followup_type: 'call' },
      ],
    },
  },
  {
    key: 'interested',
    title: 'Interested → send details',
    blurb: 'When a lead is marked Interested, send the brochure on WhatsApp and remind the agent tomorrow.',
    icon: '📄',
    workflow: {
      ...base, name: 'Interested → send details', trigger: 'lead_status_changed',
      trigger_config: { to: ['interested'], from: [] },
      steps: [
        { type: 'send_whatsapp', template: null },
        { type: 'create_followup', in_hours: 24, note: 'Check {first_name} has seen the details', followup_type: 'call' },
      ],
    },
  },
  {
    key: 'idle',
    title: 'Re-engage idle leads',
    blurb: 'An open lead nobody has contacted for a week gets a WhatsApp nudge, and its owner a reminder.',
    icon: '⏰',
    workflow: {
      ...base, name: 'Re-engage idle leads', trigger: 'lead_inactive', trigger_config: { days: 7 }, repeat: true,
      steps: [
        { type: 'send_whatsapp', template: null },
        { type: 'notify', to: 'owner', message: '{name} has had no contact for a week' },
      ],
    },
  },
  {
    key: 'auto-reply',
    title: 'Keyword auto-reply',
    blurb: 'When a customer writes “price” or “brochure”, reply instantly and tell the lead’s owner.',
    icon: '💬',
    workflow: {
      ...base, name: 'Price enquiry auto-reply', trigger: 'whatsapp_received',
      trigger_config: { keywords: ['price', 'rate', 'brochure'], match: 'contains' }, repeat: true,
      quiet_hours_enabled: false,
      steps: [
        { type: 'send_whatsapp', message: 'Hi {first_name}, thanks for asking! Our team will share the details shortly.' },
        { type: 'notify', to: 'owner', message: '{name} asked about pricing on WhatsApp' },
      ],
    },
  },
  {
    key: 'round-robin',
    title: 'Share new leads round-robin',
    blurb: 'Give every new, unassigned lead to the next agent in turn and let them know.',
    icon: '🔁',
    workflow: {
      ...base, name: 'Round-robin new leads', trigger: 'lead_created', trigger_config: {},
      quiet_hours_enabled: false,
      steps: [
        { type: 'assign', agents: [], mode: 'round_robin', only_if_unassigned: true },
        { type: 'notify', to: 'owner', message: 'New lead for you: {name}' },
      ],
    },
  },
];

export const BLANK: Partial<WorkflowInput> = {
  ...base, name: '', trigger: 'lead_created', trigger_config: {},
  steps: [{ type: 'send_whatsapp', template: null }],
};
