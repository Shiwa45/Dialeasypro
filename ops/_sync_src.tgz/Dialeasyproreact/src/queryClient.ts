import { QueryClient } from '@tanstack/react-query';

// One client for the whole app, in its own module so the auth store can clear
// it. Every cached answer — features, capabilities, workspace, leads — belongs
// to whoever was signed in when it was fetched; see authStore.
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Retry once on a network error or a server fault, never on a refusal
      // (4xx). Above all not on 429 "too many requests": retrying a throttled
      // request only spends more of the allowance that ran out.
      retry: (failureCount, error) => {
        const status = (error as { response?: { status?: number } })?.response?.status;
        if (status && status >= 400 && status < 500) return false;
        return failureCount < 1;
      },
      staleTime: 30_000,
      refetchOnWindowFocus: false,
    },
  },
});
