import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Agent } from '../types';
import { setAuth, clearAuth } from '../api/client';
import { queryClient } from '../queryClient';

interface AuthState {
  agent: Agent | null;
  isAuthenticated: boolean;
  mustChangePassword: boolean;
  setAuth: (agent: Agent, access: string, refresh: string, mustChange?: boolean) => void;
  logout: () => void;
  updateAgent: (agent: Partial<Agent>) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      agent: null,
      isAuthenticated: false,
      mustChangePassword: false,

      setAuth: (agent, access, refresh, mustChange = false) => {
        // Drop everything cached for whoever was here before. Without this, an
        // admin signing out and a recruiter signing in on the same tab left
        // the recruiter holding the admin's cached capabilities and workspace
        // for five minutes — and the admin's cached leads on screen meanwhile.
        queryClient.clear();
        setAuth(access, refresh);
        set({ agent, isAuthenticated: true, mustChangePassword: mustChange });
      },

      logout: () => {
        clearAuth();
        queryClient.clear();
        set({ agent: null, isAuthenticated: false, mustChangePassword: false });
      },

      updateAgent: (updates) =>
        set((s) => ({ agent: s.agent ? { ...s.agent, ...updates } : null })),
    }),
    {
      name: 'dialeasypro-auth',
      partialize: (s) => ({ agent: s.agent, isAuthenticated: s.isAuthenticated }),
    }
  )
);
