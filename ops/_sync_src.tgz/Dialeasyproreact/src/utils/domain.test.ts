import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { resolveTenantOrigin, buildTenantWsUrl } from './domain';

describe('domain.ts utility', () => {
    const originalWindow = global.window;
    
    beforeEach(() => {
        // Reset localStorage and window mock
        vi.stubGlobal('localStorage', {
            getItem: vi.fn(),
            setItem: vi.fn(),
            removeItem: vi.fn(),
        });
    });

    afterEach(() => {
        vi.unstubAllGlobals();
    });

    const mockWindowLocation = (origin: string) => {
        vi.stubGlobal('window', {
            ...originalWindow,
            location: new URL(origin)
        });
    };

    describe('Old SaaS: dialeasypro.easyian.com', () => {
        it('should resolve from root domain to demo tenant', () => {
            mockWindowLocation('https://dialeasypro.easyian.com');
            expect(resolveTenantOrigin('demo')).toBe('https://demo.dialeasypro.easyian.com');
        });

        it('should resolve from existing tenant domain to another tenant', () => {
            mockWindowLocation('https://client1.dialeasypro.easyian.com');
            expect(resolveTenantOrigin('demo')).toBe('https://demo.dialeasypro.easyian.com');
        });
    });

    describe('New SaaS: easyian.shop', () => {
        it('should resolve from root domain to demo tenant', () => {
            mockWindowLocation('https://easyian.shop');
            expect(resolveTenantOrigin('demo')).toBe('https://demo.easyian.shop');
        });

        it('should resolve from existing tenant domain to another tenant', () => {
            mockWindowLocation('https://client1.easyian.shop');
            expect(resolveTenantOrigin('demo')).toBe('https://demo.easyian.shop');
        });
    });

    describe('Reserved Subdomains', () => {
        it('should resolve from api.easyian.shop to demo tenant', () => {
            mockWindowLocation('https://api.easyian.shop');
            expect(resolveTenantOrigin('demo')).toBe('https://demo.easyian.shop');
        });

        it('should resolve from www.easyian.shop to demo tenant', () => {
            mockWindowLocation('https://www.easyian.shop');
            expect(resolveTenantOrigin('demo')).toBe('https://demo.easyian.shop');
        });
    });

    describe('Localhost Support', () => {
        it('should resolve localhost with port', () => {
            mockWindowLocation('http://localhost:5173');
            expect(resolveTenantOrigin('demo')).toBe('http://demo.localhost:5173');
        });

        it('should keep IPv4 unaltered without inventing subdomains', () => {
            mockWindowLocation('http://127.0.0.1:5173');
            expect(resolveTenantOrigin('demo')).toBe('http://127.0.0.1:5173');
        });
    });

    describe('No workspace', () => {
        it('should return original origin if workspace is null', () => {
            mockWindowLocation('https://demo.easyian.shop');
            expect(resolveTenantOrigin(null)).toBe('https://demo.easyian.shop');
            expect(resolveTenantOrigin()).toBe('https://demo.easyian.shop');
        });
    });

    describe('WebSocket URL Generation', () => {
        it('should generate wss:// correctly from https', () => {
            mockWindowLocation('https://demo.easyian.shop');
            vi.mocked(localStorage.getItem).mockImplementation((key) => {
                if (key === 'tenant_workspace') return 'demo';
                if (key === 'access_token') return 'dummy-token';
                return null;
            });
            expect(buildTenantWsUrl('/ws/agent-monitor/')).toBe('wss://demo.easyian.shop/ws/agent-monitor/');
        });

        it('should generate ws:// correctly from http (localhost)', () => {
            mockWindowLocation('http://localhost:5173');
            vi.mocked(localStorage.getItem).mockImplementation((key) => {
                if (key === 'tenant_workspace') return 'demo';
                if (key === 'access_token') return 'dummy-token';
                return null;
            });
            expect(buildTenantWsUrl('/ws/agent-monitor/')).toBe('ws://demo.localhost:5173/ws/agent-monitor/');
        });
    });
});
