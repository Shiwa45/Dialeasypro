export const KNOWN_ROOT_DOMAINS = [
    "easyian.shop",
    "dialeasypro.easyian.com",
];

export const RESERVED_SUBDOMAINS = [
    "api",
    "www",
];

/**
 * Resolves the origin URL for a given tenant workspace.
 * Preserves protocols and ports. Replaces any existing tenant or reserved subdomains.
 *
 * @param workspace The tenant schema name (e.g. 'demo')
 * @returns The fully constructed origin string (e.g. 'https://demo.easyian.shop')
 */
export const resolveTenantOrigin = (workspace?: string | null): string => {
    // 1. Determine base origin
    const envBase = typeof import.meta !== "undefined" && import.meta.env ? import.meta.env.VITE_API_BASE_URL : undefined;
    let baseStr = (envBase as string | undefined) || (typeof window !== "undefined" ? window.location.origin : "");
    baseStr = baseStr.replace(/\/+$/, '');

    if (!workspace) return baseStr;
    if (!baseStr) return '';

    try {
        const urlObj = new URL(baseStr);
        const hostname = urlObj.hostname;

        // 2. Do not invent tenant subdomains for IPv4 addresses
        if (/^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(hostname)) {
            return urlObj.origin;
        }

        // 3. Handle localhost (localhost, 127.0.0.1 handled above, demo.localhost)
        if (hostname === 'localhost' || hostname.endsWith('.localhost')) {
            urlObj.hostname = `${workspace}.localhost`;
            return urlObj.origin;
        }

        // 4. Find matching root domain
        let matchedRoot = '';
        for (const root of KNOWN_ROOT_DOMAINS) {
            if (hostname === root || hostname.endsWith(`.${root}`)) {
                matchedRoot = root;
                break;
            }
        }

        // Fallback for unknown custom domains (e.g., crm.company.com -> company.com)
        if (!matchedRoot) {
            const parts = hostname.split('.');
            if (parts.length >= 2) {
                matchedRoot = parts.slice(-2).join('.');
            } else {
                matchedRoot = hostname;
            }
        }

        // 5. Apply the workspace subdomain
        urlObj.hostname = `${workspace}.${matchedRoot}`;
        return urlObj.origin;
    } catch (e) {
        return baseStr;
    }
};

/**
 * Builds the tenant WebSocket URL, ensuring it matches the resolved REST API origin.
 * Automatically handles http->ws and https->wss conversion.
 * 
 * The token is NOT in the URL: web servers log URLs, and logs were holding
 * week-long tokens. Open the socket with openTenantSocket(), which sends the
 * token as the "bearer" subprotocol (a header) instead.
 *
 * @param path The WebSocket path (e.g. '/ws/agent-monitor/')
 * @returns The WebSocket URL, without credentials
 */
export const buildTenantWsUrl = (path: string): string => {
    const workspace = typeof localStorage !== 'undefined' ? localStorage.getItem('tenant_workspace') : null;
    const origin = resolveTenantOrigin(workspace);
    
    // Replace protocols securely
    const wsOrigin = origin.replace(/^http:/, 'ws:').replace(/^https:/, 'wss:').replace(/\/$/, '');
    
    return `${wsOrigin}${path}`;
};
