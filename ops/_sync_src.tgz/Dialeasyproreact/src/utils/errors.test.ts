import { describe, expect, it } from 'vitest';
import { getErrorMessage, isUpgradeRequired } from './errors';

const refused = {
  response: {
    status: 402,
    data: { error: 'upgrade_required', message: 'This feature is not available on your current plan. Please upgrade.', feature_label: 'Lead Export' },
  },
};

describe('plan refusals', () => {
  it('recognises a 402 upgrade_required', () => {
    expect(isUpgradeRequired(refused)).toBe(true);
  });

  it('ignores other 402s, such as a plan limit', () => {
    expect(isUpgradeRequired({ response: { status: 402, data: { error: 'plan_limit_exceeded' } } })).toBe(false);
    expect(isUpgradeRequired({ response: { status: 400, data: { error: 'upgrade_required' } } })).toBe(false);
    expect(isUpgradeRequired(new Error('boom'))).toBe(false);
  });

  it('names the feature instead of a generic retry message', () => {
    expect(getErrorMessage(refused, 'Please try again.')).toBe("Lead Export isn't included in your plan.");
  });
});
