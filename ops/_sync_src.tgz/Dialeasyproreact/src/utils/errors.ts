// ============================================================
// DialSathi — API error message extraction
//
// The backend's custom_exception_handler (apps/core/exceptions.py) always
// sends `{ error, message }` on failure, but for a DRF validation error it
// deliberately keeps `message` as the generic literal "Validation failed."
// and puts the real per-field reasons in a separate `detail` object —
// `{ error: "validation_error", message: "Validation failed.",
//    detail: { phone: ["Invalid Indian mobile number."] } }`.
//
// Reading only `.message` (the pattern this replaces, copy-pasted across ~14
// call sites) shows the user that literal placeholder text instead of why
// their submission was actually rejected. This unpacks `.detail` first.
// ============================================================

interface ApiErrorBody {
  error?: string;
  message?: string;
  detail?: unknown;
}

function fieldErrorsToText(detail: unknown): string | null {
  if (detail == null) return null;
  if (typeof detail === 'string') return detail;
  if (Array.isArray(detail)) return detail.map(String).join(' ');
  if (typeof detail === 'object') {
    const parts = Object.entries(detail as Record<string, unknown>).map(([field, msgs]) => {
      const text = Array.isArray(msgs) ? msgs.map(String).join(' ') : String(msgs);
      return field === 'non_field_errors' ? text : `${field}: ${text}`;
    });
    return parts.filter(Boolean).join(' · ') || null;
  }
  return null;
}

/**
 * Best available human-readable reason for a failed API call.
 * Prefers the per-field validation detail over the generic top-level message.
 */
export function getErrorMessage(error: unknown, fallback = 'Something went wrong.'): string {
  const err = error as {
    code?: string;
    request?: unknown;
    response?: { status?: number; data?: ApiErrorBody };
  };

  // A request that never got a reply must not borrow the caller's fallback.
  // Callers pass domain-specific text ("Invalid credentials."), so a refused
  // connection was being reported to the user as a rejected password — which
  // sends them to reset a password when the API is simply not reachable.
  if (!err?.response) {
    if (err?.code === 'ECONNABORTED' || err?.code === 'ETIMEDOUT') {
      return 'The server took too long to respond. Check your connection and try again.';
    }
    if (err?.request) {
      return 'Cannot reach the server. Check the workspace ID and that the API is running.';
    }
    return fallback;
  }

  const data = err.response.data;
  if (!data) {
    return err.response.status
      ? `Request failed (HTTP ${err.response.status}).`
      : fallback;
  }
  // The plan does not include it: say which feature, not "try again".
  if (isUpgradeRequired(error)) {
    const label = (data as { feature_label?: string }).feature_label;
    return label ? `${label} isn't included in your plan.` : 'This needs a higher plan.';
  }
  return fieldErrorsToText(data.detail) ?? data.message ?? fallback;
}

/**
 * True when the API refused because the plan lacks the feature (402
 * `upgrade_required`). The app already shows the upgrade dialog for these,
 * so a caller can skip its own error toast.
 */
export function isUpgradeRequired(error: unknown): boolean {
  const res = (error as { response?: { status?: number; data?: { error?: string } } })?.response;
  return res?.status === 402 && res.data?.error === 'upgrade_required';
}
