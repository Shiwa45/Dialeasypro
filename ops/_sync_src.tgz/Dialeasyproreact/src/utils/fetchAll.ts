// ============================================================
// Fetch every page of a paginated list.
//
// The API caps page_size at 100, so a picker that asked for page_size=200 or
// 500 silently stopped at the first 100 people.
// ============================================================
import type { PaginatedResponse } from '../types';

export async function fetchAllPages<T>(
  get: (page: number) => Promise<{ data: PaginatedResponse<T> }>,
  maxPages = 50,
): Promise<PaginatedResponse<T>> {
  const results: T[] = [];
  let first: PaginatedResponse<T> | undefined;
  for (let page = 1; page <= maxPages; page++) {
    const { data } = await get(page);
    first ??= data;
    results.push(...data.results);
    if (!data.next) break;
  }
  return {
    ...(first as PaginatedResponse<T>),
    results,
    count: first?.count ?? results.length,
    next: null,
    previous: null,
  };
}
