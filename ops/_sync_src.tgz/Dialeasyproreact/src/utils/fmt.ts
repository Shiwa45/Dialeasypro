// DialSathi — Utility formatters
import { format, formatDistanceToNow, parseISO } from 'date-fns';

/*
 * Dates in the user's own day.
 *
 * `new Date().toISOString().slice(0, 10)` is the date in UTC, not here: from
 * midnight to 5:30 AM IST it is still yesterday. Invoices raised after
 * midnight on the 1st were dated — and GST-filed — in the previous month, and
 * "Today" on the dashboard showed yesterday. Use these instead.
 */
const pad2 = (n: number) => String(n).padStart(2, '0');

/** YYYY-MM-DD for `d` (default now), in local time. */
export const localISODate = (d: Date = new Date()) =>
  `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;

/** YYYY-MM for `d` (default now), in local time. */
export const localISOMonth = (d: Date = new Date()) => localISODate(d).slice(0, 7);

/** YYYY-MM-DDTHH:mm in local time — what an <input type="datetime-local"> takes. */
export const localISODateTime = (d: Date = new Date()) =>
  `${localISODate(d)}T${pad2(d.getHours())}:${pad2(d.getMinutes())}`;

export const fmtDate = (iso: string | null | undefined, fmt = 'dd MMM yyyy') => {
  if (!iso) return '—';
  try { return format(parseISO(iso), fmt); } catch { return iso; }
};

export const fmtDateTime = (iso: string | null | undefined) => {
  if (!iso) return '—';
  try { return format(parseISO(iso), 'dd MMM yyyy, hh:mm a'); } catch { return iso; }
};

export const fmtRelative = (iso: string | null | undefined) => {
  if (!iso) return '—';
  try { return formatDistanceToNow(parseISO(iso), { addSuffix: true }); } catch { return iso; }
};

export const formatDuration = (seconds: number): string => {
  if (!seconds) return '0s';
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
};

/**
 * Exact rupees, Indian digit grouping: ₹12,34,567.00
 *
 * Use this anywhere the number is a legal or contractual figure — payslips,
 * invoices, offer letters, GST summaries. `formatINR` below abbreviates to
 * ₹1.2L, which is right for a dashboard tile and wrong on a document
 * somebody signs or files a return against.
 */
export const formatINRExact = (amount: number | string | null | undefined): string => {
  if (amount === null || amount === undefined || amount === '') return '—';
  const n = Number(amount);
  if (isNaN(n)) return '—';
  return `₹${n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

/** Abbreviated rupees for dashboards and tiles: ₹1.2L, ₹3.4Cr. */
export const formatINR = (amount: number | string | null | undefined): string => {
  if (amount === null || amount === undefined) return '—';
  const n = Number(amount);
  if (isNaN(n)) return '—';
  if (n >= 10_000_000) return `₹${(n / 10_000_000).toFixed(1)}Cr`;
  if (n >= 100_000)    return `₹${(n / 100_000).toFixed(1)}L`;
  if (n >= 1_000)      return `₹${(n / 1_000).toFixed(1)}K`;
  return `₹${n.toFixed(0)}`;
};

export const LEAD_STATUSES = [
  { value: 'new',           label: 'New'            },
  { value: 'attempted',     label: 'Attempted'       },
  { value: 'contacted',     label: 'Contacted'       },
  { value: 'interested',    label: 'Interested'      },
  { value: 'not_interested',label: 'Not Interested'  },
  { value: 'follow_up',     label: 'Follow-up'       },
  { value: 'negotiation',   label: 'Negotiation'     },
  { value: 'converted',     label: 'Converted / Won' },
  { value: 'lost',          label: 'Lost'            },
  { value: 'duplicate',     label: 'Duplicate'       },
  { value: 'invalid',       label: 'Invalid / Junk'  },
];

/** Changing a lead to one of these by hand needs a reason (server rule). */
export const STATUS_NEEDS_REASON = ['lost', 'invalid'];

// The API's LeadPriority is hot / warm / cold and nothing else. This listed
// high / medium / low, so the New Lead form defaulted to "medium" and the
// server refused every lead created without changing it.
export const LEAD_PRIORITIES = [
  { value: 'hot',  label: '🔥 Hot' },
  { value: 'warm', label: 'Warm'   },
  { value: 'cold', label: 'Cold'   },
];

// Mirrors apps/core/constants.py :: LeadSource.CHOICES — values AND labels.
// It used to list 10 of the 18 (no Instagram, 99acres, Housing.com,
// MagicBricks, JustDial, Sulekha, TradeIndia, API — so leads from those could
// not be filtered), label meta_facebook differently from the lead itself, and
// offer an "Other" the API rejects.
export const LEAD_SOURCES = [
  { value: 'manual',         label: 'Manual Entry' },
  { value: 'meta_facebook',  label: 'Meta - Facebook Lead Ads' },
  { value: 'meta_instagram', label: 'Meta - Instagram Lead Ads' },
  { value: 'meta_ctwa',      label: 'Meta - Click to WhatsApp' },
  { value: 'whatsapp',       label: 'WhatsApp Inbound' },
  { value: 'google_ads',     label: 'Google Ads Lead Forms' },
  { value: 'website',        label: 'Website Widget' },
  { value: 'indiamart',      label: 'IndiaMART' },
  { value: 'tradeindia',     label: 'TradeIndia' },
  { value: 'justdial',       label: 'JustDial' },
  { value: 'sulekha',        label: 'Sulekha' },
  { value: '99acres',        label: '99acres' },
  { value: 'housing_com',    label: 'Housing.com' },
  { value: 'magicbricks',    label: 'MagicBricks' },
  { value: 'referral',       label: 'Referral' },
  { value: 'csv_import',     label: 'CSV Import' },
  { value: 'webhook',        label: 'Webhook' },
  { value: 'api',            label: 'API' },
];
