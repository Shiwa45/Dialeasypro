/*
 * Who counts as a tenant admin — the same rule the API uses.
 *
 * The API (IsTenantAdmin) decides on `role === "admin"`. Screens used to gate
 * on `is_tenant_admin`, a separate flag that marks the account's original
 * owner, and some accepted either. A second admin got admin powers from the
 * API with no admin screens; different pages disagreed about the same person.
 * `is_tenant_admin` still means "the owner account" — use it only for that.
 */
export const isAdmin = (agent?: { role?: string | null } | null): boolean =>
  agent?.role === 'admin';
