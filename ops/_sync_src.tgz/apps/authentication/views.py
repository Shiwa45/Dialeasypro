"""
TeleCRM Backend — apps/authentication/views.py

Two view sets in one file:

A) DRF API Views (for Flutter mobile app)
   - AgentLoginAPIView         POST /api/v1/auth/login/
   - AgentRefreshTokenAPIView  POST /api/v1/auth/refresh/
   - AgentLogoutAPIView        POST /api/v1/auth/logout/
   - AgentProfileAPIView       GET/PATCH /api/v1/auth/me/
   - AgentPasswordChangeAPIView POST /api/v1/auth/change-password/
   - AgentListAPIView          GET /api/v1/auth/agents/
   - AgentDetailAPIView        GET/PATCH/DELETE /api/v1/auth/agents/{id}/
   - TeamListAPIView           GET/POST /api/v1/auth/teams/

B) MVT Views (for web browser tenant admin dashboard)
   - TenantAdminLoginView      GET/POST /crm/login/
   - TenantAdminLogoutView     POST /crm/logout/
   - TenantAdminDashboardView  GET /crm/
   - AgentListView             GET /crm/agents/
   - AgentCreateView           GET/POST /crm/agents/create/
   - AgentUpdateView           GET/POST /crm/agents/{id}/edit/
   - AgentDeleteView           POST /crm/agents/{id}/delete/
   - ProfileView               GET/POST /crm/profile/
"""
import logging

from django.contrib import messages
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views import View
from rest_framework import generics, status
from rest_framework.parsers import JSONParser, MultiPartParser
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.throttling import ScopedRateThrottle

from apps.authentication.models import Agent, AgentLoginSession, Team
from apps.authentication.permissions import (
    CanManageAgent,
    HasFeatureAccess,
    IsActiveAgent,
    IsAuthenticatedAgent,
    IsManagerOrAdmin,
    IsTenantAdmin,
    role_required,
    tenant_admin_required,
)
from apps.authentication.models import AgentTeam
from apps.authentication.serializers import (
    AdminSetPasswordSerializer,
    AgentCreateSerializer,
    AgentLoginSerializer,
    AgentProfileSerializer,
    AgentSerializer,
    AgentSelfUpdateSerializer,
    AgentUpdateSerializer,
    PasswordChangeSerializer,
    TeamSerializer,
    TeamMemberWriteSerializer,
)
from apps.authentication.tokens import (
    blacklist_refresh_token,
    generate_tokens_for_agent,
)
from apps.core.constants import AgentRole, FeatureKey
from apps.core.exceptions import InvalidCredentialsException, PlanLimitExceededException
from apps.core.quotas import agent_limit, enforce_agent_quota
from apps.core.pagination import StandardResultsSetPagination
from apps.superadmin.models import AuditLog
from apps.core.constants import AuditAction

logger = logging.getLogger(__name__)


# ============================================================
# A) DRF API VIEWS — for Flutter mobile app
# ============================================================

class TenantInfoAPIView(APIView):
    """
    GET /api/v1/auth/tenant-info/
    Returns basic public info about the current tenant.
    Used by the Flutter app to verify a workspace name resolves correctly.
    No authentication required.
    """
    authentication_classes = []
    permission_classes = [AllowAny]
    # Its own scope rather than the shared 20/hour anonymous budget, which an
    # office full of phones behind one address would exhaust.
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "tenant_info"

    def get(self, request):
        from django.db import connection
        from apps.tenants.models import Tenant

        schema = connection.schema_name
        if not schema or schema == 'public':
            return Response(
                {"error": "workspace_not_found", "message": "Workspace not found."},
                status=status.HTTP_404_NOT_FOUND,
            )
        try:
            tenant = Tenant.objects.get(schema_name=schema)
            return Response({
                "schema": tenant.schema_name,
                "company_name": tenant.company_name,
                "is_active": tenant.is_active,
            })
        except Tenant.DoesNotExist:
            return Response(
                {"error": "workspace_not_found", "message": "Workspace not found."},
                status=status.HTTP_404_NOT_FOUND,
            )




class CompanyProfileAPIView(APIView):
    """
    GET /api/v1/auth/company/

    The tenant's own billing identity, for the letterhead on invoices,
    quotations and payslips. tenant-info/ exposes only the name and is
    deliberately unauthenticated (the workspace picker calls it before login);
    an address, GSTIN and phone number are not something to hand out to
    unauthenticated callers, so they live here behind a token instead.
    """

    permission_classes = [IsAuthenticatedAgent]

    def get(self, request):
        from django.db import connection

        from apps.tenants.models import Tenant

        tenant = Tenant.objects.filter(schema_name=connection.schema_name).first()
        if tenant is None:
            return Response(
                {"error": "workspace_not_found", "message": "Workspace not found."},
                status=status.HTTP_404_NOT_FOUND,
            )

        logo = ""
        if tenant.logo:
            try:
                logo = request.build_absolute_uri(tenant.logo.url)
            except Exception:  # noqa: BLE001 — a missing file must not 500 an invoice
                logo = ""

        return Response({
            "company_name": tenant.company_name,
            "gstin": tenant.gstin,
            "billing_address": tenant.billing_address,
            "city": tenant.city,
            "state": tenant.state,
            "pincode": tenant.pincode,
            "email": tenant.primary_contact_email,
            "phone": tenant.primary_contact_phone,
            "logo": logo,
            "primary_color": tenant.primary_color,
        })

    def patch(self, request):
        """
        Admins edit the company's billing identity — name, GSTIN, address —
        which every quotation, invoice and payslip prints. There was no screen
        for it: invoices printed the workspace id ("crm") as the company name,
        and a tax invoice went out with no supplier GSTIN.
        """
        from django.db import connection

        from apps.core.capabilities import Cap, has_capability
        from apps.core.constants import INDIAN_STATE_CODES, canonical_state_code
        from apps.erp.gstin import gstin_problem, state_from_gstin
        from apps.tenants.models import Tenant

        if not has_capability(request.user, Cap.CRM_SETTINGS):
            return Response({"error": "forbidden", "message": "Only an admin can change the company profile."},
                            status=status.HTTP_403_FORBIDDEN)
        tenant = Tenant.objects.filter(schema_name=connection.schema_name).first()
        if tenant is None:
            return Response({"error": "workspace_not_found"}, status=status.HTTP_404_NOT_FOUND)

        data = request.data
        errors = {}
        updates = {}
        if "company_name" in data:
            name = str(data.get("company_name") or "").strip()
            if not name:
                errors["company_name"] = ["The company name can't be empty."]
            updates["company_name"] = name[:200]
        if "gstin" in data:
            gstin = str(data.get("gstin") or "").strip().upper()
            if problem := gstin_problem(gstin):
                errors["gstin"] = [problem]
            updates["gstin"] = gstin
        if "state" in data:
            state = canonical_state_code(str(data.get("state") or ""))
            if state and state not in INDIAN_STATE_CODES:
                errors["state"] = ["Pick an Indian state or UT."]
            updates["state"] = state
        for field, limit in (("billing_address", 1000), ("city", 100), ("pincode", 6)):
            if field in data:
                updates[field] = str(data.get(field) or "").strip()[:limit]
        if "pincode" in updates and updates["pincode"] and not (
            updates["pincode"].isdigit() and len(updates["pincode"]) == 6
        ):
            errors["pincode"] = ["A pincode is 6 digits."]

        gstin = updates.get("gstin", tenant.gstin)
        state = updates.get("state", tenant.state)
        if gstin and not errors.get("gstin"):
            from_gstin = state_from_gstin(gstin)
            if from_gstin and not state:
                updates["state"] = from_gstin
            elif from_gstin and state and canonical_state_code(state) != from_gstin:
                errors["state"] = [f"Your GSTIN is registered in {from_gstin}, not {state}."]
        if errors:
            return Response({"error": "validation_error", "message": "Validation failed.", "detail": errors},
                            status=status.HTTP_400_BAD_REQUEST)

        for k, v in updates.items():
            setattr(tenant, k, v)
        if updates:
            tenant.save(update_fields=list(updates))
            AuditLog.log(
                action=AuditAction.SETTINGS_CHANGE, actor_type="tenant_admin",
                actor_id=request.user.pk, actor_email=request.user.email,
                entity_type="Tenant", description=f"Company profile updated: {', '.join(sorted(updates))}",
                request=request,
            )
        return self.get(request)


class AgentLoginAPIView(APIView):
    """
    POST /api/v1/auth/login/
    Authenticate agent and return JWT tokens.

    Request:  { "email": "...", "password": "..." }
    Response: { "access": "...", "refresh": "...", "agent": {...} }
    """

    authentication_classes = []
    permission_classes = [AllowAny]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "login"

    def post(self, request):
        serializer = AgentLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data["email"]
        password = serializer.validated_data["password"]

        # Look up agent (case-insensitive)
        agent = Agent.objects.filter(email__iexact=email).first()
        if not agent:
            # Don't reveal which field is wrong (security)
            AuditLog.log(
                action=AuditAction.LOGIN_FAILED,
                actor_type="agent",
                actor_email=email,
                description=f"Login failed — agent not found",
                request=request,
            )
            raise InvalidCredentialsException()

        if not agent.is_active:
            raise InvalidCredentialsException()

        if not agent.check_password(password):
            AuditLog.log(
                action=AuditAction.LOGIN_FAILED,
                actor_type="agent",
                actor_email=email,
                entity_repr=agent.name,
                request=request,
            )
            raise InvalidCredentialsException()

        # Plan and web sign-in policy: agents/read-only on the web need the
        # plan feature AND the tenant switch; recruiters need the Recruitment
        # module on any client. Checked only AFTER the password: refusing
        # first would tell anyone with an email address which accounts are
        # agents. See apps/authentication/web_access.py.
        from apps.authentication.web_access import (
            feature_checker, is_web_client, refusal_for,
        )

        refusal = refusal_for(
            agent, feature_checker(request), web=is_web_client(request),
        )
        if refusal is not None:
            AuditLog.log(
                action=AuditAction.LOGIN_FAILED,
                actor_type="agent",
                actor_id=agent.pk,
                actor_email=agent.email,
                entity_repr=agent.name,
                description=f"Sign-in refused — {refusal['error']} ({refusal['reason']})",
                request=request,
            )
            return Response(refusal, status=status.HTTP_403_FORBIDDEN)

        # Generate tokens
        tokens = generate_tokens_for_agent(agent)

        # Track login
        ip = request.META.get("HTTP_X_FORWARDED_FOR", "").split(",")[0].strip() or \
             request.META.get("REMOTE_ADDR", "")
        agent.last_login = timezone.now()
        agent.last_login_ip = ip or None
        agent.total_login_count += 1
        agent.save(update_fields=["last_login", "last_login_ip", "total_login_count"])

        # Create session record
        AgentLoginSession.objects.create(
            agent=agent,
            ip_address=ip or None,
            user_agent=request.META.get("HTTP_USER_AGENT", "")[:500],
            device_type="mobile" if any(
                m in request.META.get("HTTP_USER_AGENT", "").lower()
                for m in ("flutter", "dart", "okhttp")
            ) else "api",
            jwt_jti=tokens.get("jti", ""),
        )

        AuditLog.log(
            action=AuditAction.LOGIN,
            actor_type="agent",
            actor_id=agent.pk,
            actor_email=agent.email,
            entity_type="Agent",
            entity_repr=agent.name,
            request=request,
        )

        return Response(
            {
                **tokens,
                "agent": AgentProfileSerializer(agent, context={"request": request}).data,
                "must_change_password": agent.must_change_password,
            }
        )


class AgentRefreshTokenAPIView(APIView):
    """
    POST /api/v1/auth/refresh/
    Refresh expired access token using a valid refresh token.

    Request:  { "refresh": "<refresh_token>" }
    Response: { "access": "<new_access_token>", "refresh": "<rotated_refresh>" }
    """

    authentication_classes = []
    permission_classes = [AllowAny]
    # Was under the default anonymous 20/hour per IP: twenty agents behind
    # one office address used it up within the hour, refreshes started
    # answering 429, and the apps signed everyone out.
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "token_refresh"

    def post(self, request):
        from rest_framework_simplejwt.tokens import RefreshToken
        from rest_framework_simplejwt.exceptions import TokenError

        refresh_token = request.data.get("refresh")
        if not refresh_token:
            return Response(
                {"error": "refresh_required", "message": "Refresh token is required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            refresh = RefreshToken(refresh_token)

            # Verify it's an agent token
            if not refresh.get("agent_id"):
                raise TokenError("Not an agent token")

            # Rotate refresh token (generates new refresh, old one is blacklisted)
            new_tokens = {
                "access": str(refresh.access_token),
                "refresh": str(refresh),
            }
            return Response(new_tokens)

        except TokenError as exc:
            return Response(
                {
                    "error": "token_invalid",
                    "message": "Invalid or expired refresh token. Please log in again.",
                },
                status=status.HTTP_401_UNAUTHORIZED,
            )


class AgentLogoutAPIView(APIView):
    """
    POST /api/v1/auth/logout/
    Invalidate the refresh token (blacklist it).

    Request:  { "refresh": "<refresh_token>" }
    Response: { "message": "Logged out successfully" }
    """

    permission_classes = [IsAuthenticatedAgent]

    def post(self, request):
        refresh_token = request.data.get("refresh")

        if refresh_token:
            blacklist_refresh_token(refresh_token)

        # Mark agent offline immediately so the monitoring dashboard updates.
        try:
            from apps.authentication.presence import set_agent_status
            from apps.core.constants import AgentWorkStatus
            set_agent_status(request.user, AgentWorkStatus.OFFLINE)
        except Exception:
            pass

        # Mark session as inactive
        agent = request.user
        AgentLoginSession.objects.filter(
            agent=agent, is_active=True
        ).update(
            is_active=False, logout_time=timezone.now()
        )

        AuditLog.log(
            action=AuditAction.LOGOUT,
            actor_type="agent",
            actor_id=agent.pk,
            actor_email=agent.email,
            entity_type="Agent",
            entity_repr=agent.name,
            request=request,
        )

        return Response({"message": "Logged out successfully."})


class AgentProfileAPIView(APIView):
    """
    GET  /api/v1/auth/me/     → Return current agent's profile
    PATCH /api/v1/auth/me/    → Update current agent's profile
    """

    permission_classes = [IsAuthenticatedAgent]
    parser_classes = [JSONParser, MultiPartParser]

    def get(self, request):
        serializer = AgentProfileSerializer(
            request.user, context={"request": request}
        )
        return Response(serializer.data)

    def patch(self, request):
        # AgentSelfUpdateSerializer, NOT AgentUpdateSerializer: the admin
        # serializer accepts role / is_active / employee_id, and with no
        # request in its context its role check had no actor to compare — so
        # any agent could PATCH their own role to "admin" here.
        serializer = AgentSelfUpdateSerializer(
            request.user, data=request.data, partial=True
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(
            AgentProfileSerializer(
                request.user, context={"request": request}
            ).data
        )


class AgentPasswordChangeAPIView(APIView):
    """POST /api/v1/auth/change-password/ — Change own password."""

    permission_classes = [IsAuthenticatedAgent]

    def post(self, request):
        serializer = PasswordChangeSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        agent = request.user
        if not agent.check_password(serializer.validated_data["old_password"]):
            return Response(
                {"error": "wrong_password", "message": "Current password is incorrect."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        agent.set_password(serializer.validated_data["new_password"])
        agent.must_change_password = False
        agent.save(update_fields=["password", "must_change_password"])

        AuditLog.log(
            action=AuditAction.PASSWORD_CHANGE,
            actor_type="agent",
            actor_id=agent.pk,
            actor_email=agent.email,
            request=request,
        )

        return Response({"message": "Password changed successfully."})


class AgentListAPIView(generics.ListCreateAPIView):
    """
    GET  /api/v1/auth/agents/  → List all agents (managers/admins only)
    POST /api/v1/auth/agents/  → Create new agent (admins only)
    """

    pagination_class = StandardResultsSetPagination

    def get_permissions(self):
        if self.request.method == "GET":
            return [IsManagerOrAdmin()]
        return [IsTenantAdmin()]

    def get_serializer_class(self):
        if self.request.method == "POST":
            return AgentCreateSerializer
        return AgentSerializer

    def get_queryset(self):
        agent = self.request.user

        # ?is_active=false lists deactivated agents (e.g. the "Deactivated"
        # tab, or the Unassign Leads picker which needs former agents too);
        # ?is_active=all lists both. Default stays active-only so existing
        # callers (dropdowns, assignment pickers) are unaffected.
        status_param = self.request.query_params.get("is_active")
        if status_param == "false":
            qs = Agent.objects.filter(is_active=False).order_by("name")
        elif status_param == "all":
            qs = Agent.objects.all().order_by("name")
        else:
            qs = Agent.objects.filter(is_active=True).order_by("name")

        # Managers see agents in their teams; admins see all
        if agent.role == AgentRole.MANAGER:
            team_ids = agent.team_memberships.values_list("team_id", flat=True)
            qs = qs.filter(team_memberships__team_id__in=team_ids).distinct()

        return qs

    def perform_create(self, serializer):
        # The seat cap: the tenant's own override if the super admin set one,
        # otherwise the plan's max_agents. Resolved in apps/core/quotas.py so
        # this and the reactivate path cannot drift apart.
        enforce_agent_quota()

        agent = serializer.save()
        AuditLog.log(
            action=AuditAction.CREATE,
            actor_type="tenant_admin",
            actor_id=self.request.user.pk,
            actor_email=self.request.user.email,
            entity_type="Agent",
            entity_id=agent.pk,
            entity_repr=agent.name,
            request=self.request,
        )


class AgentDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET    /api/v1/auth/agents/{id}/  → Agent detail
    PATCH  /api/v1/auth/agents/{id}/  → Update agent
    DELETE /api/v1/auth/agents/{id}/  → Deactivate agent
    """

    def get_permissions(self):
        if self.request.method == "DELETE":
            return [IsTenantAdmin()]
        return [IsManagerOrAdmin(), CanManageAgent()]

    def get_serializer_class(self):
        if self.request.method in ("PUT", "PATCH"):
            return AgentUpdateSerializer
        return AgentSerializer

    def get_queryset(self):
        # Deliberately not filtered to is_active=True: a deactivated agent
        # still needs to be viewable/editable by an admin (e.g. to reactivate
        # them, or to fix their record). CanManageAgent still gates access.
        return Agent.objects.all()

    def perform_destroy(self, instance):
        # Never yourself, and never the last admin — see check_admin_removal.
        from apps.authentication.serializers import check_admin_removal

        check_admin_removal(self.request.user, instance, deactivating=True)

        # Soft-delete: deactivate instead of hard delete
        instance.is_active = False
        instance.save(update_fields=["is_active"])
        AuditLog.log(
            action=AuditAction.DELETE,
            actor_type="tenant_admin",
            actor_id=self.request.user.pk,
            actor_email=self.request.user.email,
            entity_type="Agent",
            entity_id=instance.pk,
            entity_repr=instance.name,
            request=self.request,
        )


class AgentReactivateAPIView(APIView):
    """
    POST /api/v1/auth/agents/{id}/reactivate/
    Restores a deactivated agent's access. Blocked with 402 if the tenant is
    already at its seat cap with currently-active agents — the same limit
    enforced when creating a brand-new agent, so reactivating can't be used to
    quietly exceed it.
    """

    permission_classes = [IsTenantAdmin]

    def post(self, request, pk):
        agent = get_object_or_404(Agent, pk=pk)

        if agent.is_active:
            return Response(
                {"error": "already_active", "message": "This agent is already active."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Same cap as creating one — otherwise deactivate/reactivate is a way
        # to hold more agents than the tenant is allowed.
        enforce_agent_quota()

        agent.is_active = True
        agent.save(update_fields=["is_active"])
        AuditLog.log(
            action=AuditAction.UPDATE,
            actor_type="tenant_admin",
            actor_id=request.user.pk,
            actor_email=request.user.email,
            entity_type="Agent",
            entity_id=agent.pk,
            entity_repr=agent.name,
            description=f"Reactivated agent {agent.name}",
            request=request,
        )
        return Response(AgentSerializer(agent).data, status=status.HTTP_200_OK)


class AgentSetPasswordAPIView(APIView):
    """
    POST /api/v1/auth/agents/{id}/set-password/
    Tenant admin sets/resets another agent's password (no old password needed).
    """

    permission_classes = [IsTenantAdmin]

    def post(self, request, pk):
        agent = get_object_or_404(Agent, pk=pk, is_active=True)

        # Admins cannot reset their own password here — they must use
        # the regular change-password flow (which verifies the old password).
        if agent.pk == request.user.pk:
            return Response(
                {
                    "error": "self_reset_not_allowed",
                    "message": "Use the change-password option to update your own password.",
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        serializer = AdminSetPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        agent.set_password(serializer.validated_data["new_password"])
        agent.must_change_password = serializer.validated_data.get(
            "require_change_on_login", False
        )
        agent.save(update_fields=["password", "must_change_password"])

        AuditLog.log(
            action=AuditAction.PASSWORD_RESET,
            actor_type="tenant_admin",
            actor_id=request.user.pk,
            actor_email=request.user.email,
            entity_type="Agent",
            entity_id=agent.pk,
            entity_repr=agent.name,
            request=request,
        )

        return Response(
            {"message": f"Password updated for {agent.name}."},
            status=status.HTTP_200_OK,
        )


class TeamListAPIView(generics.ListCreateAPIView):
    """
    GET  /api/v1/auth/teams/   → teams, with their members
    POST /api/v1/auth/teams/   → create one (tenant admin)

    `?include_inactive=true` returns disbanded teams too, so one can be
    brought back rather than recreated from scratch.
    """

    serializer_class = TeamSerializer

    def get_permissions(self):
        if self.request.method == "POST":
            return [IsTenantAdmin()]
        return [IsManagerOrAdmin()]

    def get_queryset(self):
        qs = Team.objects.prefetch_related("memberships__agent").annotate(
            member_count_annotated=models.Count(
                "memberships",
                filter=models.Q(memberships__agent__is_active=True),
            )
        )
        if self.request.query_params.get("include_inactive") not in ("true", "1"):
            qs = qs.filter(is_active=True)
        return qs.order_by("name")


class TeamDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET/PATCH/DELETE /api/v1/auth/teams/{id}/   (tenant admin for writes)

    DELETE disbands rather than deletes. Memberships cascade, and a team is
    what decides which agents a manager can see and whose leads a senior
    agent can read — dropping the rows would silently change who can see what,
    with nothing left to explain why.
    """

    serializer_class = TeamSerializer

    def get_permissions(self):
        if self.request.method in ("PATCH", "PUT", "DELETE"):
            return [IsTenantAdmin()]
        return [IsManagerOrAdmin()]

    def get_queryset(self):
        return Team.objects.prefetch_related("memberships__agent")

    def perform_destroy(self, instance):
        instance.is_active = False
        instance.save(update_fields=["is_active"])


class TeamMembersAPIView(APIView):
    """
    POST   /api/v1/auth/teams/{id}/members/            → add an agent
    DELETE /api/v1/auth/teams/{id}/members/{agent_id}/ → remove one

    There was no way at all to put an agent in a team through the product,
    which left both rules that depend on membership permanently inert: a
    manager saw no agents, and a senior agent saw only their own leads.
    """

    permission_classes = [IsTenantAdmin]

    def post(self, request, pk):
        team = get_object_or_404(Team, pk=pk)
        serializer = TeamMemberWriteSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        agent = Agent.objects.get(pk=serializer.validated_data["agent_id"])
        membership, created = AgentTeam.objects.get_or_create(
            agent=agent, team=team,
            defaults={"is_team_lead": serializer.validated_data["is_team_lead"]},
        )
        if not created:
            # Already in the team — treat the call as setting their role in it
            # rather than refusing, which is what the UI's toggle wants.
            membership.is_team_lead = serializer.validated_data["is_team_lead"]
            membership.save(update_fields=["is_team_lead"])

        AuditLog.log(
            action=AuditAction.UPDATE,
            actor_type="agent",
            actor_id=request.user.pk,
            actor_email=request.user.email,
            entity_type="Team",
            entity_id=team.pk,
            entity_repr=team.name,
            description=f"{'Added' if created else 'Updated'} {agent.name} in {team.name}",
            request=request,
        )
        return Response(
            TeamSerializer(team).data,
            status=status.HTTP_201_CREATED if created else status.HTTP_200_OK,
        )

    def delete(self, request, pk, agent_id):
        team = get_object_or_404(Team, pk=pk)
        removed = AgentTeam.objects.filter(team=team, agent_id=agent_id).delete()[0]
        if not removed:
            return Response(
                {"error": "not_a_member", "message": "That agent is not in this team."},
                status=status.HTTP_404_NOT_FOUND,
            )

        AuditLog.log(
            action=AuditAction.UPDATE,
            actor_type="agent",
            actor_id=request.user.pk,
            actor_email=request.user.email,
            entity_type="Team",
            entity_id=team.pk,
            entity_repr=team.name,
            description=f"Removed agent {agent_id} from {team.name}",
            request=request,
        )
        return Response(TeamSerializer(team).data)


class TenantFeaturesAPIView(APIView):
    """
    GET /api/v1/auth/features/
    The tenant's EFFECTIVE feature map (plan + add-on entitlements), plan info
    and capacity limits.

    Clients use this to hide/disable gated UI. It is a UX convenience only —
    the backend remains the source of truth and re-checks every gated endpoint.
    """

    permission_classes = [IsAuthenticatedAgent]

    def get(self, request):
        from apps.core.constants import FeatureKey, ModuleKey

        features = getattr(request, "tenant_features", {}) or {}
        # Present every known key so clients don't guess on missing entries.
        full_map = {key: bool(features.get(key, False)) for key in FeatureKey.ALL}

        # `request.tenant_plan` is a SimpleLazyObject — never `is None`, so
        # test truthiness (which forces evaluation).
        plan = getattr(request, "tenant_plan", None)
        plan_data = None
        if plan:
            plan_data = {
                "slug": plan.slug,
                "name": plan.name,
                "limits": {
                    # The effective cap, not the plan's headline number: a
                    # tenant with an override would otherwise be shown a seat
                    # count the API refuses to let them reach.
                    "max_agents": agent_limit() or plan.max_agents,
                    "max_leads": plan.max_leads,
                    "max_leads_per_day": plan.max_leads_per_day,
                    "max_whatsapp_bulk_per_day": plan.max_whatsapp_bulk_per_day,
                    "max_email_bulk_per_day": plan.max_email_bulk_per_day,
                    "max_sms_per_day": plan.max_sms_per_day,
                    "storage_gb": plan.storage_gb,
                    "custom_fields_limit": plan.custom_fields_limit,
                    "lead_sources_limit": plan.lead_sources_limit,
                },
            }

        # A module counts as active only when ALL of its features are enabled.
        modules = {
            module: all(full_map.get(k, False) for k in keys)
            for module, keys in ModuleKey.FEATURES.items()
        }

        # Role capabilities travel with the feature map so the client makes a
        # single call on boot. Same source of truth the API gates on, so a
        # hidden button and a 403 always have the same cause.
        from apps.core.capabilities import capabilities_for

        # Every feature is shown in the app whatever the plan; a locked one
        # opens an upgrade screen, which needs to say what it is, which plans
        # include it and who to ask.
        from apps.plans.upgrade import support_contacts, upgrade_catalog

        from apps.authentication.web_access import feature_checker, refusal_for
        from apps.core.capabilities import workspace_for

        refusal = refusal_for(request.user, feature_checker(request), web=True)

        return Response({
            "features": full_map,
            "modules": modules,
            "plan": plan_data,
            "role": getattr(request.user, "role", None),
            "capabilities": capabilities_for(request.user),
            # Which web experience this person gets — computed here so the
            # sidebar, route guard and landing page read one answer.
            "workspace": workspace_for(request.user),
            # False → an already-open web session signs itself out on boot,
            # showing web_access_message (plan downgraded, switch turned off).
            "web_access_allowed": refusal is None,
            "web_access_message": refusal["message"] if refusal else "",
            "upgrade": {**upgrade_catalog(full_map), "support": support_contacts()},
        })


class CapabilitiesAPIView(APIView):
    """
    GET /api/v1/auth/capabilities/
    Just the role-capability map for the calling agent.

    /auth/features/ already embeds this; this endpoint exists for clients that
    want to refresh permissions after a role change without re-fetching the
    whole (heavily cached) plan payload.
    """

    permission_classes = [IsAuthenticatedAgent]

    def get(self, request):
        from apps.core.capabilities import capabilities_for

        return Response({
            "role": getattr(request.user, "role", None),
            "capabilities": capabilities_for(request.user),
        })


# ============================================================
# Live Agent Monitoring API
# ============================================================

class AgentStatusUpdateAPIView(APIView):
    """
    POST /api/v1/auth/status/
    Agent reports a live work-status transition (available / on_call /
    wrap_up / break / offline). Returns the updated live payload.
    """

    permission_classes = [IsAuthenticatedAgent]

    def post(self, request):
        from apps.authentication.presence import agent_live_payload, set_agent_status
        from apps.core.constants import AgentWorkStatus

        status_val = (request.data.get("status") or "").strip()
        if status_val not in AgentWorkStatus.REPORTABLE:
            return Response(
                {"error": "invalid_status",
                 "message": f"status must be one of {AgentWorkStatus.REPORTABLE}"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        st = set_agent_status(
            request.user,
            status_val,
            break_reason=(request.data.get("break_reason") or "")[:100],
            call_id=request.data.get("call_id"),
            lead_id=request.data.get("lead_id"),
        )
        return Response(agent_live_payload(st))


class AgentHeartbeatAPIView(APIView):
    """
    POST /api/v1/auth/status/heartbeat/
    Keepalive from the agent app — refreshes last_seen so the active session
    isn't swept to offline. Cheap; no broadcast.
    """

    permission_classes = [IsAuthenticatedAgent]

    def post(self, request):
        from apps.authentication.presence import touch_heartbeat

        # The app's own view of its status, when it sends one (see
        # touch_heartbeat). Older app builds send nothing and are unaffected.
        touch_heartbeat(
            request.user,
            status=request.data.get("status") or None,
            break_reason=(request.data.get("break_reason") or "")[:100],
        )
        return Response({"ok": True})


class LiveAgentsAPIView(APIView):
    """
    GET /api/v1/auth/live-agents/
    Manager/admin snapshot of every agent's current status + today's time
    totals. Used for the initial load of the Live Agents dashboard; ongoing
    updates arrive over the /ws/agent-monitor/ WebSocket.

    Plan-gated on AGENT_MONITORING. Note the agent-side status/heartbeat
    endpoints are deliberately NOT gated — agents must always be able to
    report state, otherwise the dialer breaks on un-entitled plans.
    """

    permission_classes = [IsManagerOrAdmin, HasFeatureAccess]
    required_feature = FeatureKey.AGENT_MONITORING

    def get(self, request):
        from apps.authentication.models import AgentStatus
        from apps.authentication.presence import agent_live_payload, compute_today_calls, sweep_stale
        from apps.core.constants import AgentWorkStatus

        # Flip any stale sessions to offline so the snapshot is accurate.
        sweep_stale()

        now = timezone.now()
        statuses = {
            s.agent_id: s
            for s in AgentStatus.objects.select_related("agent").filter(agent__is_active=True)
        }
        agents = Agent.objects.filter(is_active=True).order_by("name")

        out = []
        for agent in agents:
            st = statuses.get(agent.id)
            if st is None:
                out.append({
                    "agent_id": agent.id, "name": agent.name, "email": agent.email,
                    "role": agent.role, "status": AgentWorkStatus.OFFLINE,
                    "status_display": "Offline", "since": None, "break_reason": "",
                    "last_seen": None, "is_online": False, "current_lead_id": None,
                    "session_started_at": None,
                    "totals": {"available": 0, "on_call": 0, "wrap_up": 0, "break": 0, "online": 0},
                    # An agent can call without going online (manual calls).
                    "calls": compute_today_calls(agent, now),
                })
            else:
                out.append(agent_live_payload(st, now))

        return Response({"agents": out, "server_time": now.isoformat()})


# ============================================================
# B) MVT VIEWS — for web browser tenant admin dashboard
# ============================================================

class TenantAdminLoginView(View):
    """
    GET  /crm/login/  → Render login form
    POST /crm/login/  → Process login, set session, redirect to dashboard
    """

    template_name = "tenant_admin/auth/login.html"

    def get(self, request):
        # Redirect if already logged in
        if request.session.get("agent_id"):
            return redirect("tenant_admin:dashboard")
        next_url = request.GET.get("next", "/crm/")
        return render(request, self.template_name, {"next": next_url})

    def post(self, request):
        email = request.POST.get("email", "").strip().lower()
        password = request.POST.get("password", "")
        next_url = request.POST.get("next", "/crm/")

        error = None

        agent = Agent.objects.filter(email__iexact=email, is_active=True).first()
        if agent:
            if agent.check_password(password):
                # Set session
                request.session["agent_id"] = agent.pk
                request.session["agent_role"] = agent.role
                request.session["is_tenant_admin"] = agent.is_tenant_admin
                request.session["agent_name"] = agent.name

                # Update login tracking
                agent.last_login = timezone.now()
                ip = request.META.get("REMOTE_ADDR", "")
                agent.last_login_ip = ip or None
                agent.total_login_count += 1
                agent.save(update_fields=["last_login", "last_login_ip", "total_login_count"])

                AuditLog.log(
                    action=AuditAction.LOGIN,
                    actor_type="tenant_admin",
                    actor_id=agent.pk,
                    actor_email=agent.email,
                    entity_repr=agent.name,
                    request=request,
                )

                # Redirect to password change if required
                if agent.must_change_password:
                    return redirect("tenant_admin:change_password")

                return redirect(next_url if next_url.startswith("/crm/") else "/crm/")
            else:
                error = "Invalid email or password."
        else:
            error = "Invalid email or password."

        return render(
            request, self.template_name, {"error": error, "next": next_url}
        )


class TenantAdminLogoutView(View):
    """POST /crm/logout/ — Clear session and redirect to login."""

    def post(self, request):
        agent_id = request.session.get("agent_id")
        if agent_id:
            AuditLog.log(
                action=AuditAction.LOGOUT,
                actor_type="tenant_admin",
                actor_id=agent_id,
                request=request,
            )
        request.session.flush()
        return redirect("tenant_admin:login")


class TenantAdminDashboardView(View):
    """GET /crm/ — Main dashboard shell."""

    template_name = "tenant_admin/dashboard/index.html"

    @method_decorator(tenant_admin_required)
    def get(self, request):
        agent = request.agent
        ctx = {
            "agent": agent,
            "page_title": "Dashboard",
        }
        return render(request, self.template_name, ctx)


class AgentListView(View):
    """GET /crm/agents/ — List all agents."""

    template_name = "tenant_admin/agents/list.html"

    @method_decorator(tenant_admin_required)
    def get(self, request):
        if request.agent.role not in [AgentRole.ADMIN, AgentRole.MANAGER]:
            return redirect("tenant_admin:dashboard")

        agents = Agent.objects.filter(is_active=True).order_by("name")
        return render(
            request, self.template_name,
            {"agents": agents, "page_title": "Agents"}
        )


class AgentCreateView(View):
    """GET/POST /crm/agents/create/ — Create new agent."""

    template_name = "tenant_admin/agents/form.html"

    @method_decorator(tenant_admin_required)
    def get(self, request):
        if request.agent.role != AgentRole.ADMIN:
            messages.error(request, "Only admins can create agents.")
            return redirect("tenant_admin:agent_list")
        from apps.authentication.forms import AgentCreateForm
        form = AgentCreateForm()
        return render(
            request, self.template_name,
            {"form": form, "page_title": "Add Agent", "action": "create"}
        )

    @method_decorator(tenant_admin_required)
    def post(self, request):
        if request.agent.role != AgentRole.ADMIN:
            return redirect("tenant_admin:agent_list")
        from apps.authentication.forms import AgentCreateForm
        form = AgentCreateForm(request.POST, request.FILES)
        if form.is_valid():
            agent = form.save(commit=False)
            agent.set_password(form.cleaned_data["password"])
            agent.must_change_password = True
            agent.save()
            messages.success(request, f"Agent '{agent.name}' created successfully.")
            return redirect("tenant_admin:agent_list")
        return render(
            request, self.template_name,
            {"form": form, "page_title": "Add Agent", "action": "create"}
        )


class AgentUpdateView(View):
    """GET/POST /crm/agents/{id}/edit/ — Edit agent details."""

    template_name = "tenant_admin/agents/form.html"

    @method_decorator(tenant_admin_required)
    def get(self, request, pk):
        agent_to_edit = get_object_or_404(Agent, pk=pk, is_active=True)
        from apps.authentication.forms import AgentUpdateForm
        form = AgentUpdateForm(instance=agent_to_edit)
        return render(
            request, self.template_name,
            {"form": form, "edit_agent": agent_to_edit, "page_title": "Edit Agent", "action": "edit"}
        )

    @method_decorator(tenant_admin_required)
    def post(self, request, pk):
        agent_to_edit = get_object_or_404(Agent, pk=pk, is_active=True)
        from apps.authentication.forms import AgentUpdateForm
        form = AgentUpdateForm(request.POST, request.FILES, instance=agent_to_edit)
        if form.is_valid():
            form.save()
            messages.success(request, f"Agent '{agent_to_edit.name}' updated.")
            return redirect("tenant_admin:agent_list")
        return render(
            request, self.template_name,
            {"form": form, "edit_agent": agent_to_edit, "page_title": "Edit Agent", "action": "edit"}
        )


class AgentDeleteView(View):
    """POST /crm/agents/{id}/delete/ — Deactivate agent."""

    @method_decorator(tenant_admin_required)
    def post(self, request, pk):
        if request.agent.role != AgentRole.ADMIN:
            return JsonResponse({"error": "Admin only"}, status=403)
        agent_to_delete = get_object_or_404(Agent, pk=pk)
        if agent_to_delete.pk == request.agent.pk:
            messages.error(request, "You cannot deactivate your own account.")
            return redirect("tenant_admin:agent_list")
        agent_to_delete.is_active = False
        agent_to_delete.save(update_fields=["is_active"])
        messages.success(request, f"Agent '{agent_to_delete.name}' deactivated.")
        return redirect("tenant_admin:agent_list")


class ProfileView(View):
    """GET/POST /crm/profile/ — Current agent's profile."""

    template_name = "tenant_admin/profile/index.html"

    @method_decorator(tenant_admin_required)
    def get(self, request):
        from apps.authentication.forms import AgentProfileForm
        form = AgentProfileForm(instance=request.agent)
        return render(
            request, self.template_name,
            {"form": form, "page_title": "My Profile"}
        )

    @method_decorator(tenant_admin_required)
    def post(self, request):
        from apps.authentication.forms import AgentProfileForm
        form = AgentProfileForm(request.POST, request.FILES, instance=request.agent)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated successfully.")
            return redirect("tenant_admin:profile")
        return render(
            request, self.template_name,
            {"form": form, "page_title": "My Profile"}
        )


# Need this for the annotation in AgentListAPIView
from django.db import models



class AgentWebAccessAPIView(APIView):
    """
    GET/PATCH /api/v1/auth/web-access/   {"agent_web_access": true|false}

    The tenant's "agents may sign in on the web" switch. Admin only: it is a
    company-wide policy, and it is CRM_SETTINGS-shaped rather than
    agent-management-shaped.

    The switch only means something on a plan that includes agent web access
    (FeatureKey.AGENT_WEB_ACCESS). GET always answers — with
    `available_in_plan` so the settings screen can show an upgrade prompt —
    but changing it on a plan without the feature is a 402, like any other
    locked feature.
    """

    def get_permissions(self):
        from apps.core.capabilities import Cap
        from apps.core.permissions import capability_required

        return [IsAuthenticatedAgent(), capability_required(Cap.CRM_SETTINGS)()]

    def get(self, request):
        from apps.authentication.web_access import (
            agent_web_access_enabled, agent_web_in_plan, feature_checker,
        )

        return Response({
            "agent_web_access": agent_web_access_enabled(),
            "available_in_plan": agent_web_in_plan(feature_checker(request)),
        })

    def patch(self, request):
        from apps.authentication.web_access import (
            agent_web_in_plan, current_tenant, feature_checker,
        )
        from apps.core.constants import FeatureKey
        from apps.core.exceptions import FeatureNotEnabledException

        if not agent_web_in_plan(feature_checker(request)):
            raise FeatureNotEnabledException(FeatureKey.AGENT_WEB_ACCESS)

        raw = request.data.get("agent_web_access")
        if not isinstance(raw, bool):
            return Response(
                {"error": "invalid", "message": "agent_web_access must be true or false."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        tenant = current_tenant()
        if tenant is None:
            return Response({"error": "no_tenant"}, status=status.HTTP_400_BAD_REQUEST)

        tenant.agent_web_access = raw
        tenant.save(update_fields=["agent_web_access"])
        AuditLog.log(
            action=AuditAction.SETTINGS_CHANGE,
            actor_type="tenant_admin",
            actor_id=request.user.pk,
            actor_email=request.user.email,
            entity_type="Tenant",
            description=f"Agent web sign-in turned {'on' if raw else 'off'}",
            request=request,
        )
        return Response({"agent_web_access": raw, "available_in_plan": True})
