"""
TeleCRM Backend — apps/calls/views.py

DRF API views for call management.

CallLogListCreateView    GET/POST  /api/v1/calls/
CallLogDetailView        GET       /api/v1/calls/{id}/
ClickToCallView          POST      /api/v1/calls/click-to-call/
CallDispositionListView  GET       /api/v1/calls/dispositions/
CallProviderWebhookView  POST      /api/v1/calls/webhook/{provider}/
CallStatsView            GET       /api/v1/calls/stats/
"""
import logging

from django.db import connection
from django.db.models import Avg, Count, Q, Sum
from django.utils import timezone
from rest_framework import generics, status
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.authentication.permissions import (
    IsNotReadOnly,
    HasFeatureAccess,
    IsActiveAgent,
    IsAuthenticatedAgent,
    IsManagerOrAdmin,
    IsTenantAdmin,
)
from apps.calls.models import CallDisposition, CallLog, CallRecording
from apps.calls.scoping import calls_visible_to
from apps.calls.serializers import (
    CallDispositionSerializer,
    CallLogCreateSerializer,
    CallLogSerializer,
    ClickToCallSerializer,
)
from apps.core.constants import AgentRole, FeatureKey
from apps.core.pagination import StandardResultsSetPagination
from apps.leads.models import Lead

logger = logging.getLogger(__name__)


def filter_calls(qs, params):
    """
    The call log's filters, shared by the list and its summary boxes
    (CallStatsView), so the boxes describe exactly the calls listed. The stats
    used to take the dates only: searching an agent filtered the list and left
    the boxes on everyone's calls.
    """
    if lead_id := params.get("lead"):
        qs = qs.filter(lead_id=lead_id)
    if agent_id := params.get("agent"):
        qs = qs.filter(agent_id=agent_id)
    if date_from := params.get("date_from"):
        qs = qs.filter(started_at__date__gte=date_from)
    if date_to := params.get("date_to"):
        qs = qs.filter(started_at__date__lte=date_to)
    if connected := params.get("connected"):
        qs = qs.filter(is_connected=connected.lower() == "true")
    if direction := params.get("direction"):
        qs = qs.filter(direction=direction)
    if disposition := params.get("disposition"):
        # "none": calls still waiting for an outcome.
        if disposition == "none":
            qs = qs.filter(disposition__isnull=True)
        else:
            qs = qs.filter(disposition_id=disposition)
    if category := params.get("category"):
        qs = qs.filter(disposition__category=category)

    # Whether a recording exists. The call log shows a recording column,
    # and "find me the calls I can actually listen back to" had no answer
    # short of paging the whole log by eye.
    has_recording = params.get("has_recording")
    if has_recording is not None and has_recording != "":
        qs = qs.filter(recording__isnull=has_recording.lower() != "true")

    # Free text over the number and the lead's name. A call log without a
    # search box means finding one call is a scroll, and the phone number
    # is how anyone actually refers to a call.
    if q := params.get("q", "").strip():
        qs = qs.filter(
            Q(phone_number__icontains=q)
            | Q(lead__name__icontains=q)
            | Q(agent__name__icontains=q)
        )

    return qs


class CallLogListCreateView(generics.ListCreateAPIView):
    """
    GET  /api/v1/calls/     → Paginated call log (filterable by date, agent, lead)
    POST /api/v1/calls/     → Log a manual call
    """

    permission_classes = [IsAuthenticatedAgent, IsNotReadOnly]
    pagination_class = StandardResultsSetPagination

    def get_serializer_class(self):
        return CallLogCreateSerializer if self.request.method == "POST" else CallLogSerializer

    def get_queryset(self):
        agent = self.request.user
        qs = CallLog.objects.select_related(
            "agent", "lead", "disposition", "recording"
        ).order_by("-started_at")

        # Secure by default, like leads — see calls/scoping.py.
        qs = calls_visible_to(agent, qs)
        return filter_calls(qs, self.request.query_params)

    def create(self, request, *args, **kwargs):
        # A retry of a call already saved (the response was lost) returns that
        # call instead of saving it twice.
        client_call_id = str(request.data.get("client_call_id") or "").strip()
        if client_call_id:
            existing = CallLog.objects.filter(agent=request.user, client_call_id=client_call_id).first()
            if existing is not None:
                return Response(CallLogSerializer(existing, context={"request": request}).data,
                                status=status.HTTP_200_OK)
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        call = CallLog.objects.select_related("agent", "lead", "disposition").get(pk=serializer.instance.pk)
        # The full call, with the outcome's name (the create shape had none).
        return Response(CallLogSerializer(call, context={"request": request}).data,
                        status=status.HTTP_201_CREATED)

    def perform_create(self, serializer):
        # The lead is brought up to date — status, counters, activity, auto
        # follow-up — by the CallLog post_save signal (calls/services/outcomes).
        data = dict(serializer.validated_data)
        twin = self._phone_entry_to_take_over(data)
        if twin is not None:
            serializer.instance = self._take_over(twin, data)
            return
        call = CallLog(agent=self.request.user, **{k: v for k, v in data.items() if k != "followup_at"})
        call._actor = self.request.user
        call._followup_at = data.get("followup_at")
        call.save()
        serializer.instance = call

    def _phone_entry_to_take_over(self, data):
        """
        With phone call tracking on, the phone's call log can deliver a call
        before the agent saves its outcome in the app. The app's save then
        completes that row instead of adding a second one.
        """
        from apps.calls.services.phone_tracking import merge_app_call_into_phone_entry

        try:
            return merge_app_call_into_phone_entry(self.request.user, data)
        except Exception as exc:  # noqa: BLE001 — never lose the call itself
            logger.warning("[Calls] Phone-entry merge lookup failed: %s", exc)
            return None

    def _take_over(self, call, data):
        from apps.calls.services.outcomes import apply_call_outcome

        previous_lead = call.lead_id
        meta = dict(call.provider_meta or {})
        fields = []
        for key, value in data.items():
            if key in ("followup_at",):
                continue
            if key == "duration_seconds" and not value and call.duration_seconds:
                continue  # keep the phone's real talk time
            setattr(call, key, value)
            fields.append(key)
        meta["merged_with_app_call"] = True
        call.provider_meta = meta
        fields.append("provider_meta")
        call.save(update_fields=sorted(set(fields)))
        # The phone's entry counted as a dial only if it was already on this
        # lead (an outbound call is applied when it is created).
        apply_call_outcome(
            call, actor=self.request.user,
            new_dial=previous_lead != call.lead_id,
            followup_at=data.get("followup_at"),
        )
        return call


class CallTrackingSettingsView(APIView):
    """
    GET/PATCH /api/v1/calls/tracking/   {"enabled": true|false}

    The company's phone call tracking switch. With it on, the mobile app of
    every agent whose own switch is on (Agent.call_tracking_enabled) saves
    all incoming and outgoing calls from the phone and uploads recordings.
    GET also lists who is covered, for the settings screen.
    """

    def get_permissions(self):
        from apps.core.capabilities import Cap
        from apps.core.permissions import capability_required

        return [IsAuthenticatedAgent(), capability_required(Cap.CRM_SETTINGS)()]

    def get(self, request):
        from apps.authentication.models import Agent
        from apps.calls.services.phone_tracking import company_tracking_enabled

        agents = Agent.objects.filter(is_active=True).order_by("name")
        return Response({
            "enabled": company_tracking_enabled(),
            "agents": [
                {"id": a.pk, "name": a.name, "role": a.role, "call_tracking_enabled": a.call_tracking_enabled}
                for a in agents
            ],
        })

    def patch(self, request):
        from apps.authentication.models import Agent
        from apps.calls.services.phone_tracking import current_tenant
        from apps.superadmin.models import AuditLog
        from apps.core.constants import AuditAction

        tenant = current_tenant()
        if tenant is None:
            return Response({"error": "no_tenant"}, status=status.HTTP_400_BAD_REQUEST)

        changed = []
        if "enabled" in request.data:
            raw = request.data.get("enabled")
            if not isinstance(raw, bool):
                return Response({"error": "invalid", "message": "enabled must be true or false."},
                                status=status.HTTP_400_BAD_REQUEST)
            tenant.call_tracking_enabled = raw
            tenant.save(update_fields=["call_tracking_enabled"])
            changed.append(f"Phone call tracking turned {'on' if raw else 'off'}")

        # {"agents": {"<id>": true|false, ...}} — per-agent switches.
        per_agent = request.data.get("agents")
        if per_agent is not None:
            if not isinstance(per_agent, dict) or not all(isinstance(v, bool) for v in per_agent.values()):
                return Response({"error": "invalid", "message": "agents must map agent ids to true or false."},
                                status=status.HTTP_400_BAD_REQUEST)
            for agent_id, value in per_agent.items():
                n = Agent.objects.filter(pk=agent_id).update(call_tracking_enabled=value)
                if n:
                    changed.append(f"Call tracking {'on' if value else 'off'} for agent {agent_id}")

        if changed:
            AuditLog.log(
                action=AuditAction.SETTINGS_CHANGE,
                actor_type="tenant_admin",
                actor_id=request.user.pk,
                actor_email=request.user.email,
                entity_type="Tenant",
                description="; ".join(changed)[:500],
                request=request,
            )
        return self.get(request)


class PhoneCallSyncView(APIView):
    """
    POST /api/v1/calls/sync/
        {"calls": [{"device_id": "1234", "number": "+919812345678",
                    "type": "incoming|outgoing|missed|rejected|blocked",
                    "started_at": <epoch ms or ISO>, "duration_seconds": 42}, ...]}

    The mobile app's phone call tracking: entries from the phone's call log.
    Each is saved once (a retry, or a call the app already saved from its
    dialer, returns the existing call) and the answer says which calls still
    need their recording uploaded.

    403 call_tracking_off when the company or this agent is not tracked —
    the app then stops syncing.
    """

    permission_classes = [IsAuthenticatedAgent, IsNotReadOnly]

    def post(self, request):
        from apps.calls.services import phone_tracking as pt

        agent = request.user
        if not pt.tracking_enabled_for(agent):
            return Response(
                {"error": "call_tracking_off",
                 "message": "Phone call tracking is not turned on for you. Ask your admin."},
                status=status.HTTP_403_FORBIDDEN,
            )
        calls = request.data.get("calls")
        if not isinstance(calls, list):
            return Response({"error": "invalid", "message": "Send a list of calls."},
                            status=status.HTTP_400_BAD_REQUEST)
        if len(calls) > pt.MAX_BATCH:
            return Response({"error": "too_many", "message": f"Send at most {pt.MAX_BATCH} calls at a time."},
                            status=status.HTTP_400_BAD_REQUEST)

        results, skipped = [], []
        for raw in calls:
            try:
                entry = pt.clean_entry(raw)
            except pt.EntryError as exc:
                skipped.append({"device_id": str((raw or {}).get("device_id", "")) if isinstance(raw, dict) else "",
                                "reason": str(exc)})
                continue
            try:
                results.append(pt.sync_entry(agent, entry))
            except Exception as exc:  # noqa: BLE001 — one bad row must not lose the batch
                logger.warning("[PhoneSync] Could not save entry %s: %s", entry["device_id"], exc, exc_info=True)
                skipped.append({"device_id": entry["device_id"], "reason": "Could not save this call."})
        return Response({"results": results, "skipped": skipped})


class CallOutcomeView(APIView):
    """
    PATCH /api/v1/calls/{id}/outcome/  {disposition, is_connected?, duration_seconds?, notes?}

    Set the outcome of a call saved without one — a click-to-call, a "Call
    back" from the call log, a provider call. There was no way to do it, so
    those calls stayed outcome-less (or were logged a second time by hand).
    """

    permission_classes = [IsAuthenticatedAgent, IsNotReadOnly]

    def patch(self, request, pk):
        from apps.calls.serializers import CallOutcomeSerializer
        from apps.calls.services.outcomes import apply_call_outcome

        call = calls_visible_to(request.user, CallLog.objects.all()).filter(pk=pk).first()
        if call is None:
            return Response({"error": "not_found", "message": "Call not found."}, status=404)
        is_manager = request.user.role in (AgentRole.ADMIN, AgentRole.MANAGER) or getattr(
            request.user, "is_tenant_admin", False
        )
        if call.agent_id != request.user.pk and not is_manager:
            return Response(
                {"error": "forbidden", "message": "Only the agent who made this call can set its outcome."},
                status=403,
            )

        serializer = CallOutcomeSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        call.disposition = data["disposition"]
        call.is_connected = data["is_connected"]
        fields = ["disposition", "is_connected"]
        if "duration_seconds" in data:
            call.duration_seconds = data["duration_seconds"]
            fields.append("duration_seconds")
        if data.get("notes"):
            call.notes = data["notes"]
            fields.append("notes")
        call.save(update_fields=fields)
        apply_call_outcome(call, actor=request.user, new_dial=False, followup_at=data.get("followup_at"))

        call = CallLog.objects.select_related("agent", "lead", "disposition", "recording").get(pk=call.pk)
        return Response(CallLogSerializer(call, context={"request": request}).data)


class CallLogDetailView(generics.RetrieveAPIView):
    """GET /api/v1/calls/{id}/ — Call detail with recording."""

    permission_classes = [IsAuthenticatedAgent]
    serializer_class = CallLogSerializer

    def get_queryset(self):
        agent = self.request.user
        qs = CallLog.objects.select_related("agent", "lead", "disposition", "recording")
        return calls_visible_to(agent, qs)


# How much each way of finding a recording can be trusted. A better match
# replaces a worse one: the app's microphone fallback is uploaded when the
# phone's own recording can't be found right away, and the phone's file — the
# real two-way audio — used to be refused when it turned up later, because
# the call "already had a recording".
MATCH_RANK = {
    "mic_fallback": 0,
    "timestamp": 1,
    "filename_name": 2,
    "filename_number": 3,
    "manual": 3,
}


def _match_rank(matched_by: str) -> int:
    return MATCH_RANK.get((matched_by or "").strip(), 1)


def _reset_ai_for_new_audio(rec) -> None:
    """New audio for the call: the old transcript and summary describe the old file."""
    from apps.ai.models import CallInsight

    rec.transcript = ""
    rec.transcript_status = "pending"
    rec.transcript_error = ""
    rec.transcript_language = ""
    rec.transcript_provider = ""
    rec.transcribed_at = None
    rec.save(update_fields=[
        "transcript", "transcript_status", "transcript_error",
        "transcript_language", "transcript_provider", "transcribed_at",
    ])
    CallInsight.objects.filter(call_id=rec.call_id).delete()


def _queue_ai_pipeline(call, force: bool = False) -> None:
    """
    Kick off transcription (which chains into insights) for a freshly uploaded
    recording. The task no-ops for tenants without the AI Suite module, so
    there's nothing to check here.

    A broker that's down must never fail the upload — the recording is already
    stored, and `POST /api/v1/ai/backfill/` can pick it up later.
    """
    from apps.ai.tasks import transcribe_call

    try:
        transcribe_call.delay(connection.schema_name, str(call.pk), force=force)
    except Exception as exc:  # noqa: BLE001 — broker unreachable, etc.
        logger.warning("Could not queue AI pipeline for call %s: %s", call.pk, exc)


def _fill_duration_from_recording(call, rec):
    """A connected call the dialer reported with 0 s takes the recording's length."""
    if call.is_connected and not call.duration_seconds and rec.duration_seconds:
        call.duration_seconds = int(rec.duration_seconds)
        call.save(update_fields=["duration_seconds"])


class CallRecordingUploadView(APIView):
    """
    POST /api/v1/calls/{id}/recording/   (multipart/form-data)

    The mobile app uploads the on-device OEM call-recording audio file it
    matched to this call. The file is pushed to Cloudinary and linked to the
    CallLog. Idempotent: re-uploading the same call overwrites (no duplicates).

    Form fields:
      file            — the audio file (required)
      duration_seconds (optional)
      source_filename  (optional) original device filename
      matched_by       (optional) filename_number | filename_name | timestamp |
                       mic_fallback | manual

    A call keeps one recording. A new upload replaces it only when it was
    matched more reliably (MATCH_RANK) — the phone's own recording replaces
    the microphone fallback; anything else is answered "already uploaded".
    """

    permission_classes = [IsAuthenticatedAgent, HasFeatureAccess, IsNotReadOnly]
    required_feature = FeatureKey.CALL_RECORDING_ACCESS
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    # Reject anything that isn't plausibly a call recording.
    MAX_BYTES = 100 * 1024 * 1024  # 100 MB
    ALLOWED_EXT = {"mp3", "m4a", "amr", "wav", "ogg", "aac", "3gp", "mp4"}

    def post(self, request, pk):
        agent = request.user

        # Only the owning agent (or a manager/admin) may attach a recording.
        try:
            call = calls_visible_to(agent).get(pk=pk)
        except CallLog.DoesNotExist:
            return Response(
                {"error": "not_found", "message": "Call not found."},
                status=status.HTTP_404_NOT_FOUND,
            )

        # ---- Mode A: app already uploaded to Cloudinary, just link the URL ----
        client_cloud_url = (request.data.get("cloud_url") or "").strip()
        if client_cloud_url and not _is_own_cloudinary_url(client_cloud_url):
            # Only links into the company's own Cloudinary account. Older app
            # builds uploaded recordings to whatever account an agent had typed
            # into the (since removed) voice-notes settings and linked them
            # here — customer audio held outside the company — and any caller
            # could attach an arbitrary URL as a call's recording.
            return Response(
                {"error": "recording_link_refused",
                 "message": "Upload the recording file itself; external links are not accepted."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if client_cloud_url:
            existing = CallRecording.objects.filter(call=call).first()
            if existing and existing.cloud_url and (
                _match_rank(request.data.get("matched_by") or "filename_number")
                <= _match_rank(existing.matched_by)
            ):
                return Response(
                    {"id": existing.pk, "already_uploaded": True, "playback_url": existing.cloud_url},
                    status=status.HTTP_200_OK,
                )
            try:
                duration = int(request.data.get("duration_seconds") or 0)
            except (TypeError, ValueError):
                duration = 0
            rec, _ = CallRecording.objects.update_or_create(
                call=call,
                defaults={
                    "cloud_url": client_cloud_url,
                    "cloud_public_id": (request.data.get("cloud_public_id") or "")[:300],
                    "duration_seconds": duration,
                    "format": (request.data.get("format") or "m4a")[:10],
                    "source_filename": (request.data.get("source_filename") or "")[:400],
                    "matched_by": (request.data.get("matched_by") or "filename_number")[:20],
                    "uploaded_at": timezone.now(),
                },
            )
            _fill_duration_from_recording(call, rec)
            _queue_ai_pipeline(call)
            return Response(
                {"id": rec.pk, "playback_url": rec.cloud_url, "duration_seconds": rec.duration_seconds},
                status=status.HTTP_201_CREATED,
            )

        # ---- Mode B: app sends the raw file; backend uploads to Cloudinary ----
        upload = request.FILES.get("file")
        if not upload:
            return Response(
                {"error": "file_required", "message": "Provide an audio file or a cloud_url."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if upload.size > self.MAX_BYTES:
            return Response(
                {"error": "file_too_large", "message": "Recording exceeds 100 MB."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        ext = (upload.name.rsplit(".", 1)[-1] if "." in upload.name else "").lower()
        if ext and ext not in self.ALLOWED_EXT:
            return Response(
                {"error": "invalid_format", "message": f"Unsupported audio format: .{ext}"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        matched_by = (request.data.get("matched_by") or "manual")[:20]

        # Idempotency: a call keeps its recording unless this one was matched
        # more reliably (the phone's own file replacing the mic fallback).
        existing = CallRecording.objects.filter(call=call).first()
        replacing = bool(existing and (existing.cloud_url or existing.file))
        if replacing and _match_rank(matched_by) <= _match_rank(existing.matched_by):
            return Response(
                {
                    "id": existing.pk,
                    "already_uploaded": True,
                    "playback_url": existing.cloud_url,
                },
                status=status.HTTP_200_OK,
            )

        from apps.core.cloudinary_utils import upload_call_recording

        public_id = f"call_{call.pk}"
        result = upload_call_recording(
            upload,
            tenant_schema=connection.schema_name,
            public_id=public_id,
        )
        if not result:
            # Local-media fallback: Cloudinary isn't configured (or the upload
            # failed) — store the file on the server's media volume instead so
            # recordings still work with zero external configuration.
            result = self._store_locally(request, upload, ext or "m4a", call)
        if not result:
            return Response(
                {
                    "error": "upload_failed",
                    "message": "Recording storage is not configured or upload failed.",
                },
                status=status.HTTP_502_BAD_GATEWAY,
            )

        # The measured length of the stored audio wins over what the phone
        # said; the phone's figure is the fallback (local storage measures
        # nothing).
        exact = result.get("duration_exact")
        try:
            duration = int(round(exact)) if exact else int(
                request.data.get("duration_seconds") or result.get("duration") or 0
            )
        except (TypeError, ValueError):
            duration = result.get("duration") or 0

        # A microphone recording that captured a fraction of a second is the
        # phone muting the mic during the call, not a recording. Kept, it
        # stood in for the real recording and gave the AI nothing to read.
        if matched_by == "mic_fallback" and exact is not None and exact < 2:
            from apps.core.cloudinary_utils import delete_call_recording

            if not replacing:
                delete_call_recording(result.get("public_id", ""))
            return Response(
                {"error": "recording_empty",
                 "message": "The microphone recording is empty (the phone muted it during the call)."},
                status=status.HTTP_422_UNPROCESSABLE_ENTITY,
            )

        rec, _ = CallRecording.objects.update_or_create(
            call=call,
            defaults={
                "cloud_url": result["url"],
                "cloud_public_id": result["public_id"],
                "file_size_bytes": result.get("bytes", upload.size),
                "duration_seconds": duration,
                "format": (result.get("format") or ext or "m4a")[:10],
                "source_filename": (request.data.get("source_filename") or upload.name)[:400],
                "matched_by": matched_by,
                "uploaded_at": timezone.now(),
            },
        )
        if replacing:
            _reset_ai_for_new_audio(rec)
        _fill_duration_from_recording(call, rec)
        _queue_ai_pipeline(call, force=replacing)

        return Response(
            {
                "id": rec.pk,
                "playback_url": rec.cloud_url,
                "duration_seconds": rec.duration_seconds,
            },
            status=status.HTTP_201_CREATED,
        )

    def _store_locally(self, request, upload, ext: str, call) -> dict | None:
        """Save the recording under MEDIA_ROOT and return Cloudinary-shaped metadata."""
        try:
            from django.conf import settings
            from django.core.files.storage import default_storage

            rel_path = f"call_recordings/{connection.schema_name}/call_{call.pk}.{ext}"
            if default_storage.exists(rel_path):
                default_storage.delete(rel_path)
            saved = default_storage.save(rel_path, upload)
            url = request.build_absolute_uri(settings.MEDIA_URL + saved)
            return {
                "url": url,
                "public_id": f"local:{saved}",
                "bytes": upload.size,
                "duration": 0,
                "format": ext,
            }
        except Exception as exc:
            logger.error(f"[Recording] Local storage fallback failed: {exc}")
            return None


class ClickToCallView(APIView):
    """
    POST /api/v1/calls/click-to-call/
    Initiate a click-to-call via the configured telecom provider.

    The provider dials the agent first, then connects to the lead.
    Creates a CallLog record immediately in 'initiated' state.
    The provider's webhook updates it with actual duration/status.
    """

    permission_classes = [IsAuthenticatedAgent, HasFeatureAccess, IsNotReadOnly]
    required_feature = FeatureKey.CLOUD_TELEPHONY

    def post(self, request):
        serializer = ClickToCallSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        lead_id = serializer.validated_data["lead_id"]
        agent = request.user
        # Only a lead this agent may see. The lookup was unscoped, so any agent
        # could dial — and log a call against — any lead in the tenant.
        from apps.leads.views import leads_visible_to

        lead = leads_visible_to(agent).filter(pk=lead_id).first()
        if lead is None:
            return Response({"error": "lead_not_found"}, status=404)

        # And only that lead's own numbers. `phone_number` used to override the
        # lead's number freely, so any number could be dialled on the tenant's
        # telephony account.
        requested = serializer.validated_data.get("phone_number")
        if requested:
            from apps.core.utils import normalize_indian_phone

            allowed = {n for n in (lead.phone, lead.alternate_phone) if n}
            if normalize_indian_phone(requested) not in allowed:
                return Response(
                    {"error": "number_not_on_lead",
                     "message": "You can only call a number saved on this lead."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
        phone = requested and normalize_indian_phone(requested) or lead.phone

        # The CallLog post_save safety net marks the lead worked and moves it
        # New -> Attempted as soon as the log exists. If the dial then fails,
        # the log is deleted and the lead must go back to how it was.
        before = {"status": lead.status, "has_been_worked": lead.has_been_worked}

        # Create CallLog in initiated state. Its effect on the lead is applied
        # only once the dial went out (see below).
        call = CallLog(agent=agent, lead=lead, direction="outbound", phone_number=phone)
        call._defer_outcome = True
        call.save()

        # Attempt provider call
        try:
            result = _initiate_provider_call(agent, phone, call)
        except Exception as exc:
            logger.error(f"[Click-to-call] Failed: {exc}")
            call.delete()
            Lead.objects.filter(pk=lead.pk).update(**before)
            return Response(
                {"error": "call_failed", "message": "Could not initiate call. Check integration settings."},
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )

        call.provider = result.get("provider", "other")
        call.provider_call_id = result.get("call_id", "")
        call.save(update_fields=["provider", "provider_call_id"])

        # Now the call has gone out: the lead is worked, counted as dialled and
        # moved from New to Attempted. The outcome is set afterwards with
        # PATCH /calls/{id}/outcome/.
        from apps.calls.services.outcomes import apply_call_outcome

        apply_call_outcome(call, actor=agent)

        # Only a real provider rings anyone. In manual mode nothing is dialled
        # — the call is logged and the agent dials from their own phone — so
        # "your phone will ring first" was untrue.
        dialed = call.provider != "manual"
        return Response({
            "call_id": str(call.id),
            "status": "initiated",
            "dialed": dialed,
            "message": (
                "Call initiated. Your phone will ring first."
                if dialed else
                f"Call logged. Dial {phone} from your phone."
            ),
            "provider_call_id": result.get("call_id"),
        })


def _initiate_provider_call(agent, phone: str, call: CallLog) -> dict:
    """
    Initiate call via configured telecom provider.
    Returns dict with provider name and call_id.
    Placeholder — real implementation wires to Exotel/MCUBE API.
    """
    from apps.superadmin.models import GlobalSettings

    # Determine which provider is configured for this tenant
    # In production, tenant settings will have the provider config
    provider = GlobalSettings.get("default_call_provider", "manual")

    dialer = PROVIDER_DIALERS.get(provider)
    if dialer is not None:
        return dialer(agent.phone, phone)

    if provider not in ("manual", "", None):
        # A provider with no working integration. Exotel and MCUBE were
        # routed to stubs that raise, and this setting is platform-wide, so
        # choosing either broke click-to-call for every tenant at once. Log
        # the call as manual instead, and say so loudly.
        logger.warning(
            f"[Click-to-call] default_call_provider={provider!r} has no integration; "
            f"logging the call as manual."
        )
    # Manual mode — just log it, no actual dial
    return {"provider": "manual", "call_id": f"manual_{call.id}"}


def _call_via_exotel(agent_phone: str, lead_phone: str) -> dict:
    """Exotel click-to-call API. Implement when Exotel credentials are configured."""
    raise NotImplementedError("Exotel integration not configured")


def _call_via_mcube(agent_phone: str, lead_phone: str) -> dict:
    """MCUBE click-to-call API. Implement when MCUBE credentials are configured."""
    raise NotImplementedError("MCUBE integration not configured")


# Providers that can actually place a call. Add one here when its integration
# is real; until then _call_via_exotel / _call_via_mcube stay out, because a
# stub that raises takes click-to-call down for every tenant.
PROVIDER_DIALERS = {}


class CallDispositionListView(generics.ListCreateAPIView):
    """
    GET  /api/v1/calls/dispositions/  — Available call dispositions.
    POST /api/v1/calls/dispositions/  — Add one (tenant admin).

    Every tenant starts on the seeded set and every team's outcomes differ, so
    the list has to be editable from the CRM; until this existed the only way
    to add one was a management command on the server.

    Agents see active dispositions only — an outcome switched off should not
    still be offered mid-call. `?include_inactive=true` returns the whole set
    for the settings screen, which has to show what can be switched back on.
    """

    serializer_class = CallDispositionSerializer
    pagination_class = None  # Return all dispositions (short list)

    def get_permissions(self):
        if self.request.method == "POST":
            return [IsTenantAdmin()]
        return [IsAuthenticatedAgent()]

    def get_queryset(self):
        qs = CallDisposition.objects.all()
        if self.request.query_params.get("include_inactive") not in ("true", "1"):
            qs = qs.filter(is_active=True)
        # ?category=connected|not_connected — the outcomes for one call status.
        if category := self.request.query_params.get("category"):
            qs = qs.filter(category=category)
        return qs.order_by("category", "sort_order", "name")


class CallDispositionDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET/PATCH/DELETE /api/v1/calls/dispositions/{id}/ — (tenant admin)

    DELETE switches an outcome off once calls have been logged against it
    rather than removing it. The call's disposition is SET_NULL, so deleting
    a used one would blank the outcome on every past call that carried it —
    losing the history the reports and the AI insights are built on.
    """

    permission_classes = [IsTenantAdmin]
    serializer_class = CallDispositionSerializer
    queryset = CallDisposition.objects.all()

    def destroy(self, request, *args, **kwargs):
        disposition = self.get_object()

        if disposition.is_system:
            return Response(
                {"error": "built_in", "message": f'"{disposition.name}" is a built-in outcome. Switch it off instead.'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if disposition.calls.exists():
            if disposition.is_active:
                disposition.is_active = False
                disposition.save(update_fields=["is_active", "updated_at"])
            return Response(
                {
                    "deactivated": True,
                    "detail": (
                        f'"{disposition.name}" is used by calls already logged, so it '
                        "was switched off instead of deleted. Those calls keep their outcome."
                    ),
                },
                status=status.HTTP_200_OK,
            )

        disposition.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class CallProviderWebhookView(APIView):
    """
    POST /api/v1/calls/webhook/{provider}/
    Receives real-time call events from telecom providers.
    Updates CallLog with actual duration, status, recording URL.
    """

    permission_classes = [AllowAny]  # Validated via provider-specific signature
    # Not rate-limited. A provider posts every delivery and read receipt from
    # a handful of addresses; under the default anonymous throttle
    # (20/hour per IP) the 21st callback in an hour got a 429, and a campaign
    # of any size lost almost all of its statuses. Keeping strangers out is
    # the job of authentication, not of a throttle.
    throttle_classes = []

    def post(self, request, provider):
        payload = request.data
        logger.info(f"[Webhook] Call event from {provider}: {list(payload.keys())}")

        # Knowlarity is not here on purpose: there is no Knowlarity dialing
        # integration, and its handler was an empty `pass` that answered 200
        # and recorded nothing. Unsupported providers are told so.
        handlers = {
            "exotel": self._handle_exotel,
            "mcube": self._handle_mcube,
        }

        handler = handlers.get(provider)
        if not handler:
            return Response({"error": "unsupported_provider"}, status=400)

        # Only a provider that actually places calls (PROVIDER_DIALERS) may
        # report on them. This endpoint took unauthenticated posts, so anyone
        # could overwrite any call's duration and outcome by its call id. No
        # telephony provider is integrated yet; when one is, it must bring its
        # own authentication (a signed callback or a per-tenant token) here.
        if provider not in PROVIDER_DIALERS:
            logger.warning(f"[Webhook] Call callback refused — {provider} is not integrated")
            return Response({"error": "provider_not_integrated"}, status=403)

        try:
            handler(payload)
        except Exception as exc:
            logger.error(f"[Webhook] {provider} handler error: {exc}", exc_info=True)

        return Response({"status": "ok"})

    def _handle_exotel(self, payload: dict):
        """Process Exotel call status webhook."""
        call_sid = payload.get("CallSid")
        status_str = payload.get("Status")  # "completed", "failed", "busy", "no-answer"
        duration = _duration_seconds(payload.get("Duration"))

        try:
            call = CallLog.objects.get(provider_call_id=call_sid)
        except CallLog.DoesNotExist:
            logger.warning(f"[Exotel] CallLog not found for SID: {call_sid}")
            return

        call.duration_seconds = duration
        call.is_connected = status_str == "completed"
        call.provider_meta = payload
        if payload.get("EndTime"):
            from django.utils.dateparse import parse_datetime
            call.ended_at = parse_datetime(payload["EndTime"])
        call.save(update_fields=["duration_seconds", "is_connected", "provider_meta", "ended_at"])

        # Queue recording download if available
        if recording_url := payload.get("RecordingUrl"):
            from apps.calls.tasks import download_call_recording
            from django.db import connection
            download_call_recording.apply_async(
                args=[connection.schema_name, str(call.id), recording_url],
                queue="call_uploads",
            )

    def _handle_mcube(self, payload: dict):
        """Process MCUBE call event webhook."""
        # MCUBE sends different field names — map them
        call_id = payload.get("uniqueid") or payload.get("callid")
        duration = _duration_seconds(payload.get("duration"))
        status_str = payload.get("disposition", "")

        try:
            call = CallLog.objects.get(provider_call_id=call_id)
        except CallLog.DoesNotExist:
            return

        call.duration_seconds = duration
        call.is_connected = status_str == "ANSWERED"
        call.provider_meta = payload
        call.save(update_fields=["duration_seconds", "is_connected", "provider_meta"])



def _duration_seconds(value) -> int:
    """
    A provider's duration field as whole seconds; 0 when blank or unreadable.

    int(payload.get("Duration", 0)) raised on "" (a call that never
    connected), "12.0" or None; the handler's error was swallowed and the
    webhook still answered 200, so the call's status was never recorded.
    """
    try:
        return max(0, int(float(value)))
    except (TypeError, ValueError):
        if value not in (None, ""):
            logger.warning(f"[Webhook] Unreadable call duration: {value!r}")
        return 0


class CallStatsView(APIView):
    """
    GET /api/v1/calls/stats/
    Call analytics for the dashboard and reports.
    """

    permission_classes = [IsAuthenticatedAgent]

    def get(self, request):
        agent = request.user
        # The same filters as the list (search, agent, outcome, …), so the
        # boxes count the calls the list shows.
        qs = filter_calls(calls_visible_to(agent), request.query_params)

        today = timezone.localdate()
        today_qs = qs.filter(started_at__date=today)

        stats = qs.aggregate(
            total_calls=Count("id"),
            connected_calls=Count("id", filter=Q(is_connected=True)),
            # Talk time is connected calls only — a provider reports ring time
            # as "duration" on unanswered calls too.
            total_duration=Sum("duration_seconds", filter=Q(is_connected=True)),
            avg_duration=Avg("duration_seconds", filter=Q(is_connected=True)),
            total_cost_paise=Sum("call_cost_paise"),
        )

        return Response({
            "today": {
                "total": today_qs.count(),
                "connected": today_qs.filter(is_connected=True).count(),
                "total_duration_seconds": today_qs.filter(is_connected=True)
                    .aggregate(s=Sum("duration_seconds"))["s"] or 0,
            },
            "period": {
                "total_calls": stats["total_calls"] or 0,
                "connected_calls": stats["connected_calls"] or 0,
                "connection_rate": round(
                    (stats["connected_calls"] or 0) / (stats["total_calls"] or 1) * 100, 1
                ),
                "total_duration_seconds": stats["total_duration"] or 0,
                "avg_duration_seconds": round(stats["avg_duration"] or 0),
                "total_cost_rupees": (stats["total_cost_paise"] or 0) / 100,
            },
            # is_positive comes back too. The client type has always declared
            # it and the aggregation never selected it, so anything colouring
            # a won outcome differently from a lost one was reading undefined.
            "by_disposition": list(
                qs.filter(disposition__isnull=False)
                .values("disposition__name", "disposition__is_positive")
                .annotate(count=Count("id"))
                .order_by("-count")
            ),
        })


def _is_own_cloudinary_url(url: str) -> bool:
    """True for https://res.cloudinary.com/<our cloud name>/..."""
    from urllib.parse import urlparse

    from django.conf import settings

    cloud = getattr(settings, "CLOUDINARY_CLOUD_NAME", "")
    parsed = urlparse(url)
    return bool(
        cloud
        and parsed.scheme == "https"
        and parsed.hostname == "res.cloudinary.com"
        and parsed.path.split("/")[1:2] == [cloud]
    )
