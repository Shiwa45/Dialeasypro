"""
TeleCRM Backend — apps/core/constants.py

Central constants, enumerations, and choices for the entire platform.
Feature keys used in Plan features, industry choices, lead sources, etc.

IMPORTANT: When adding a new feature key, also update:
  - apps/plans/admin.py (plan feature admin display)
  - TEMPLATES_LIST.md (if it affects UI)
  - apps/core/middleware.py (feature flag injection)
"""

# ============================================================
# Feature Keys — Used in PlanFeature model
# These keys gate features per-plan for each tenant
# ============================================================

class FeatureKey:
    """
    String constants for plan feature gates.
    Usage: tenant.has_feature(FeatureKey.BULK_WHATSAPP)
    """

    # ---- Lead Source Integrations --------------------------
    INDIAMART = "indiamart"
    META_LEAD_ADS = "meta_lead_ads"
    NINETYNINEACRES = "99acres"
    HOUSING_COM = "housing_com"
    MAGICBRICKS = "magicbricks"
    JUSTDIAL = "justdial"
    SULEKHA = "sulekha"
    TRADEINDIA = "tradeindia"
    GOOGLE_ADS_LEADS = "google_ads_leads"
    WEBSITE_WIDGET = "website_widget"
    GENERIC_WEBHOOK = "generic_webhook"
    OUTBOUND_WEBHOOK = "outbound_webhook"
    ZAPIER_INTEGRATION = "zapier_integration"

    # ---- Communication Features ----------------------------
    WHATSAPP_SINGLE_PROVIDER = "whatsapp_single"
    WHATSAPP_MULTI_PROVIDER = "whatsapp_multi"
    BULK_WHATSAPP = "bulk_whatsapp"
    BULK_EMAIL = "bulk_email"
    BULK_SMS = "bulk_sms"
    ONE_CLICK_WHATSAPP = "one_click_whatsapp"
    ONE_CLICK_EMAIL = "one_click_email"
    ONE_CLICK_SMS = "one_click_sms"
    EMAIL_CAMPAIGNS = "email_campaigns"
    SMS_CAMPAIGNS = "sms_campaigns"
    WHATSAPP_INCOMING = "whatsapp_incoming"

    # ---- Call Features -------------------------------------
    CALL_RECORDING_ACCESS = "call_recording_access"
    CALL_RECORDING_DOWNLOAD = "call_recording_download"
    CLOUD_TELEPHONY = "cloud_telephony"
    AUTO_DIALER = "auto_dialer"
    CALL_QUEUES = "call_queues"

    # ---- CRM Features --------------------------------------
    CUSTOM_FIELDS = "custom_fields"
    LEAD_SCORING = "lead_scoring"
    LEAD_PIPELINE = "lead_pipeline"
    LEAD_IMPORT = "lead_import"
    LEAD_EXPORT = "lead_export"
    FOLLOW_UP_AUTOMATION = "followup_automation"
    CONTACT_HISTORY = "contact_history"

    # ---- Agent & Team Features -----------------------------
    TEAM_MANAGEMENT = "team_management"
    AGENT_MONITORING = "agent_monitoring"
    AGENT_GPS_TRACKING = "agent_gps_tracking"
    AGENT_PERFORMANCE_REPORTS = "agent_performance"
    # Agents / read-only users may sign in to the WEB app (their own leads,
    # calls and performance). Without it they use the mobile app only.
    AGENT_WEB_ACCESS = "agent_web_access"

    # ---- Reports & Analytics -------------------------------
    BASIC_REPORTS = "basic_reports"
    ADVANCED_REPORTS = "advanced_reports"
    SCHEDULED_REPORTS = "scheduled_reports"
    CUSTOM_DASHBOARDS = "custom_dashboards"

    # ---- API & Integrations --------------------------------
    API_ACCESS = "api_access"

    # ---- Platform Features ---------------------------------
    WHITE_LABEL = "white_label"
    PRIORITY_SUPPORT = "priority_support"

    # ---- AI Suite (add-on module) --------------------------
    AI_CALL_TRANSCRIPTION = "ai_call_transcription"
    AI_CALL_INSIGHTS = "ai_call_insights"

    # ---- HRMS (add-on module) ------------------------------
    HRMS_ATTENDANCE = "hrms_attendance"
    HRMS_LEAVE = "hrms_leave"
    HRMS_PAYROLL = "hrms_payroll"
    HRMS_EXPENSES = "hrms_expenses"
    INCENTIVE_ENGINE = "incentive_engine"

    # ---- ERP / Sales Ops (add-on module) -------------------
    ERP_PRODUCTS = "erp_products"
    ERP_QUOTATIONS = "erp_quotations"
    ERP_SALES_ORDERS = "erp_sales_orders"
    ERP_CUSTOMER_INVOICING = "erp_customer_invoicing"
    TALLY_INTEGRATION = "tally_integration"

    # ---- Recruitment / ATS (add-on module) -----------------
    ATS_JOB_OPENINGS = "ats_job_openings"
    ATS_CANDIDATES = "ats_candidates"
    ATS_INTERVIEWS = "ats_interviews"
    ATS_OFFERS = "ats_offers"

    # All feature keys as a list (for validation)
    ALL = [
        INDIAMART, META_LEAD_ADS, NINETYNINEACRES, HOUSING_COM, MAGICBRICKS,
        JUSTDIAL, SULEKHA, TRADEINDIA, GOOGLE_ADS_LEADS, WEBSITE_WIDGET,
        GENERIC_WEBHOOK, OUTBOUND_WEBHOOK, ZAPIER_INTEGRATION,
        WHATSAPP_SINGLE_PROVIDER, WHATSAPP_MULTI_PROVIDER, BULK_WHATSAPP,
        BULK_EMAIL, BULK_SMS, ONE_CLICK_WHATSAPP, ONE_CLICK_EMAIL, ONE_CLICK_SMS,
        EMAIL_CAMPAIGNS, SMS_CAMPAIGNS, WHATSAPP_INCOMING,
        CALL_RECORDING_ACCESS, CALL_RECORDING_DOWNLOAD, CLOUD_TELEPHONY, AUTO_DIALER,
        CALL_QUEUES,
        CUSTOM_FIELDS, LEAD_SCORING, LEAD_PIPELINE, LEAD_IMPORT, LEAD_EXPORT,
        FOLLOW_UP_AUTOMATION, CONTACT_HISTORY,
        TEAM_MANAGEMENT, AGENT_MONITORING, AGENT_GPS_TRACKING, AGENT_PERFORMANCE_REPORTS,
        AGENT_WEB_ACCESS,
        BASIC_REPORTS, ADVANCED_REPORTS, SCHEDULED_REPORTS, CUSTOM_DASHBOARDS,
        API_ACCESS, WHITE_LABEL, PRIORITY_SUPPORT,
        AI_CALL_TRANSCRIPTION, AI_CALL_INSIGHTS,
        HRMS_ATTENDANCE, HRMS_LEAVE, HRMS_PAYROLL, HRMS_EXPENSES, INCENTIVE_ENGINE,
        ERP_PRODUCTS, ERP_QUOTATIONS, ERP_SALES_ORDERS, ERP_CUSTOMER_INVOICING,
        TALLY_INTEGRATION,
        ATS_JOB_OPENINGS, ATS_CANDIDATES, ATS_INTERVIEWS, ATS_OFFERS,
    ]

    # Human-readable labels
    LABELS = {
        INDIAMART: "IndiaMART Integration",
        META_LEAD_ADS: "Meta (Facebook/Instagram) Lead Ads",
        NINETYNINEACRES: "99acres Integration",
        HOUSING_COM: "Housing.com Integration",
        MAGICBRICKS: "MagicBricks Integration",
        JUSTDIAL: "JustDial Integration",
        SULEKHA: "Sulekha Integration",
        TRADEINDIA: "TradeIndia Integration",
        GOOGLE_ADS_LEADS: "Google Ads Lead Forms",
        WEBSITE_WIDGET: "Website Lead Widget",
        GENERIC_WEBHOOK: "Generic Inbound Webhook",
        OUTBOUND_WEBHOOK: "Outbound Webhook (push to external CRM)",
        ZAPIER_INTEGRATION: "Zapier / Make.com Integration",
        WHATSAPP_SINGLE_PROVIDER: "WhatsApp Business (Single Provider)",
        WHATSAPP_MULTI_PROVIDER: "Multiple WhatsApp numbers / accounts",
        BULK_WHATSAPP: "Bulk WhatsApp Campaigns",
        BULK_EMAIL: "Bulk Email Campaigns",
        BULK_SMS: "Bulk SMS Campaigns",
        ONE_CLICK_WHATSAPP: "One-Click WhatsApp",
        ONE_CLICK_EMAIL: "One-Click Email",
        ONE_CLICK_SMS: "One-Click SMS",
        EMAIL_CAMPAIGNS: "Email Campaign Management",
        SMS_CAMPAIGNS: "SMS Campaign Management",
        WHATSAPP_INCOMING: "Incoming WhatsApp Messages",
        CALL_QUEUES: "Call Queues",
        CALL_RECORDING_ACCESS: "Call Recording Access (Play)",
        CALL_RECORDING_DOWNLOAD: "Call Recording Download",
        CLOUD_TELEPHONY: "Cloud Telephony (Exotel/Knowlarity)",
        AUTO_DIALER: "Auto-Dialer (Mobile App)",
        CUSTOM_FIELDS: "Custom CRM Fields",
        LEAD_SCORING: "Lead Scoring",
        LEAD_PIPELINE: "Lead Pipeline / Funnel View",
        LEAD_IMPORT: "Lead Import (CSV/Excel)",
        LEAD_EXPORT: "Lead Export (CSV/Excel)",
        FOLLOW_UP_AUTOMATION: "Follow-up Automation Rules",
        CONTACT_HISTORY: "Full Contact History",
        TEAM_MANAGEMENT: "Team Management",
        AGENT_MONITORING: "Real-time Agent Monitoring",
        AGENT_GPS_TRACKING: "Agent GPS Tracking",
        AGENT_PERFORMANCE_REPORTS: "Agent Performance Reports",
        AGENT_WEB_ACCESS: "Agent Web Panel (agents sign in on the web)",
        BASIC_REPORTS: "Basic Reports",
        ADVANCED_REPORTS: "Advanced Analytics & Reports",
        SCHEDULED_REPORTS: "Scheduled Email Reports",
        CUSTOM_DASHBOARDS: "Custom Dashboards",
        API_ACCESS: "REST API Access",
        WHITE_LABEL: "White-label Branding",
        PRIORITY_SUPPORT: "Priority Support",
        AI_CALL_TRANSCRIPTION: "AI Call Transcription",
        AI_CALL_INSIGHTS: "AI Call Summary (sentiment, coaching)",
        HRMS_ATTENDANCE: "HRMS — Attendance & Timesheets",
        HRMS_LEAVE: "HRMS — Leave Management",
        HRMS_PAYROLL: "HRMS — Payroll & Payslips",
        HRMS_EXPENSES: "HRMS — Expense Claims",
        INCENTIVE_ENGINE: "Agent Incentive & Commission Engine",
        ERP_PRODUCTS: "ERP — Products & Price Lists",
        ERP_QUOTATIONS: "ERP — Quotations",
        ERP_SALES_ORDERS: "ERP — Sales Orders",
        ERP_CUSTOMER_INVOICING: "ERP — GST Customer Invoicing",
        TALLY_INTEGRATION: "Tally / Zoho Books Integration",
        ATS_JOB_OPENINGS: "Recruitment — Job Openings",
        ATS_CANDIDATES: "Recruitment — Candidate Database",
        ATS_INTERVIEWS: "Recruitment — Interview Scheduling & Scorecards",
        ATS_OFFERS: "Recruitment — Offers & Onboarding Handover",
    }

    # Feature choices for Django model field
    CHOICES = [(key, label) for key, label in LABELS.items()]


# ============================================================
# Sellable Modules — bundles of features sold as plan add-ons
#
# A tenant's effective features are:
#     plan's PlanFeature set  ∪  TenantEntitlement grants  −  revokes
#
# Granting a module simply creates a TenantEntitlement row per feature it
# contains, so `request.has_feature()` stays a single dict lookup.
# ============================================================

class ModuleKey:
    AI_SUITE = "ai_suite"
    HRMS = "hrms"
    ERP_SALES = "erp_sales"
    RECRUITMENT = "recruitment"

    CHOICES = [
        (AI_SUITE, "AI Suite"),
        (HRMS, "HRMS"),
        (ERP_SALES, "ERP — Sales Ops"),
        (RECRUITMENT, "Recruitment (ATS)"),
    ]

    ALL = [AI_SUITE, HRMS, ERP_SALES, RECRUITMENT]

    # module → the feature keys it unlocks
    FEATURES = {
        AI_SUITE: [
            FeatureKey.AI_CALL_TRANSCRIPTION,
            FeatureKey.AI_CALL_INSIGHTS,
        ],
        HRMS: [
            FeatureKey.HRMS_ATTENDANCE,
            FeatureKey.HRMS_LEAVE,
            FeatureKey.HRMS_PAYROLL,
            FeatureKey.HRMS_EXPENSES,
            FeatureKey.INCENTIVE_ENGINE,
        ],
        ERP_SALES: [
            FeatureKey.ERP_PRODUCTS,
            FeatureKey.ERP_QUOTATIONS,
            FeatureKey.ERP_SALES_ORDERS,
            FeatureKey.ERP_CUSTOMER_INVOICING,
            FeatureKey.TALLY_INTEGRATION,
        ],
        RECRUITMENT: [
            FeatureKey.ATS_JOB_OPENINGS,
            FeatureKey.ATS_CANDIDATES,
            FeatureKey.ATS_INTERVIEWS,
            FeatureKey.ATS_OFFERS,
        ],
    }


# ============================================================
# Plan Choices
# ============================================================

class PlanSlug:
    STARTER = "starter"
    GROWTH = "growth"
    BUSINESS = "business"
    ENTERPRISE = "enterprise"
    CUSTOM = "custom"

    CHOICES = [
        (STARTER, "Starter"),
        (GROWTH, "Growth"),
        (BUSINESS, "Business"),
        (ENTERPRISE, "Enterprise"),
        (CUSTOM, "Custom"),
    ]


# ============================================================
# Subscription Status Choices
# ============================================================

class SubscriptionStatus:
    TRIAL = "trial"
    ACTIVE = "active"
    PAST_DUE = "past_due"
    PAUSED = "paused"
    CANCELLED = "cancelled"
    SUSPENDED = "suspended"

    CHOICES = [
        (TRIAL, "Trial"),
        (ACTIVE, "Active"),
        (PAST_DUE, "Past Due"),
        (PAUSED, "Paused"),
        (CANCELLED, "Cancelled"),
        (SUSPENDED, "Suspended"),
    ]

    # Tenants in these statuses can use the platform
    ACTIVE_STATUSES = [TRIAL, ACTIVE]


# ============================================================
# Industry Choices (Indian market focused)
# ============================================================

class Industry:
    REAL_ESTATE = "real_estate"
    EDTECH = "edtech"
    BFSI = "bfsi"
    INSURANCE = "insurance"
    AUTOMOBILE = "automobile"
    MANUFACTURING = "manufacturing"
    IT_SERVICES = "it_services"
    HEALTHCARE = "healthcare"
    ECOMMERCE = "ecommerce"
    STAFFING = "staffing"
    RETAIL = "retail"
    HOSPITALITY = "hospitality"
    EDUCATION = "education"
    OTHER = "other"

    CHOICES = [
        (REAL_ESTATE, "Real Estate"),
        (EDTECH, "EdTech / Online Education"),
        (BFSI, "Banking, Financial Services & Insurance (BFSI)"),
        (INSURANCE, "Insurance"),
        (AUTOMOBILE, "Automobile / Auto Dealership"),
        (MANUFACTURING, "Manufacturing / B2B"),
        (IT_SERVICES, "IT Services / SaaS"),
        (HEALTHCARE, "Healthcare"),
        (ECOMMERCE, "E-Commerce / D2C"),
        (STAFFING, "Staffing / Recruitment"),
        (RETAIL, "Retail"),
        (HOSPITALITY, "Hospitality / Travel"),
        (EDUCATION, "Education / Institute"),
        (OTHER, "Other"),
    ]


# ============================================================
# Agent Roles
# ============================================================

class AgentRole:
    ADMIN = "admin"          # Full tenant access (same as tenant admin)
    MANAGER = "manager"      # Manage team, view team reports
    HR = "hr"                # HRMS + Recruitment owner; NOT a CRM admin
    ACCOUNTS = "accounts"    # Sales & Billing owner; NOT a CRM admin
    RECRUITER = "recruiter"  # Recruitment (ATS) only; no CRM, no HRMS
    SENIOR_AGENT = "senior_agent"  # Own leads + junior agents' leads
    AGENT = "agent"          # Own leads only
    READONLY = "readonly"    # View only access

    CHOICES = [
        (ADMIN, "Tenant Admin"),
        (MANAGER, "Manager"),
        (HR, "HR"),
        (ACCOUNTS, "Accounts"),
        (RECRUITER, "Recruiter"),
        (SENIOR_AGENT, "Senior Agent"),
        (AGENT, "Agent"),
        (READONLY, "Read Only"),
    ]

    # Roles that can manage other agents
    MANAGEMENT_ROLES = [ADMIN, MANAGER]

    # Roles that can access all leads in their team
    TEAM_ACCESS_ROLES = [ADMIN, MANAGER, SENIOR_AGENT]

    # Back-office roles. They own a business module end-to-end but deliberately
    # sit OUTSIDE the CRM hierarchy: an HR user must be able to run payroll
    # without also being handed every lead and every agent password. Module
    # access for these is decided by apps/core/capabilities.py, not by
    # HIERARCHY — see the module docstring there.
    BACK_OFFICE_ROLES = [HR, ACCOUNTS, RECRUITER]

    # Roles that get the agent web workspace: their own dashboard, their own
    # leads, their own calls — nothing else. See apps/core/capabilities.py ::
    # workspace_for. Read-only sees the same screens with writes removed.
    AGENT_WORKSPACE_ROLES = [AGENT, READONLY]

    # Role hierarchy for permission checks (higher number = more access).
    # HR/Accounts rank alongside a senior agent for *CRM* purposes only.
    HIERARCHY = {
        READONLY: 1,
        AGENT: 2,
        SENIOR_AGENT: 3,
        HR: 3,
        ACCOUNTS: 3,
        RECRUITER: 3,
        MANAGER: 4,
        ADMIN: 5,
    }


class AgentWorkStatus:
    """
    Live work/presence status for agent monitoring.

    Presence is tied to an auto-dial session: starting auto-dial puts the agent
    ONLINE (available); exiting the dialer (or a stale heartbeat) makes them
    OFFLINE. During a session the status cycles available → on_call → wrap_up,
    with break as a manual toggle (only between calls).
    """

    OFFLINE = "offline"      # Not in an auto-dial session
    AVAILABLE = "available"  # Session active, waiting/between calls
    ON_CALL = "on_call"      # Call connected
    WRAP_UP = "wrap_up"      # Call ended, disposing (after-call work)
    BREAK = "break"          # Manual break

    CHOICES = [
        (OFFLINE, "Offline"),
        (AVAILABLE, "Available"),
        (ON_CALL, "On Call"),
        (WRAP_UP, "Wrap-up"),
        (BREAK, "Break"),
    ]

    # Statuses that count as "online" (in an active session)
    ONLINE_STATUSES = [AVAILABLE, ON_CALL, WRAP_UP, BREAK]

    # Valid statuses an agent client may report
    REPORTABLE = [OFFLINE, AVAILABLE, ON_CALL, WRAP_UP, BREAK]


# ============================================================
# Lead Source Choices
# ============================================================

class LeadSource:
    INDIAMART = "indiamart"
    META_FACEBOOK = "meta_facebook"
    META_INSTAGRAM = "meta_instagram"
    META_CTWA = "meta_ctwa"          # Click-to-WhatsApp ads (no lead form)
    NINETYNINEACRES = "99acres"
    HOUSING_COM = "housing_com"
    MAGICBRICKS = "magicbricks"
    JUSTDIAL = "justdial"
    SULEKHA = "sulekha"
    TRADEINDIA = "tradeindia"
    GOOGLE_ADS = "google_ads"
    WEBSITE = "website"
    WEBHOOK = "webhook"
    MANUAL = "manual"
    CSV_IMPORT = "csv_import"
    API = "api"
    WHATSAPP = "whatsapp"
    REFERRAL = "referral"

    CHOICES = [
        (INDIAMART, "IndiaMART"),
        (META_FACEBOOK, "Meta - Facebook Lead Ads"),
        (META_INSTAGRAM, "Meta - Instagram Lead Ads"),
        (META_CTWA, "Meta - Click to WhatsApp"),
        (NINETYNINEACRES, "99acres"),
        (HOUSING_COM, "Housing.com"),
        (MAGICBRICKS, "MagicBricks"),
        (JUSTDIAL, "JustDial"),
        (SULEKHA, "Sulekha"),
        (TRADEINDIA, "TradeIndia"),
        (GOOGLE_ADS, "Google Ads Lead Forms"),
        (WEBSITE, "Website Widget"),
        (WEBHOOK, "Webhook"),
        (MANUAL, "Manual Entry"),
        (CSV_IMPORT, "CSV Import"),
        (API, "API"),
        (WHATSAPP, "WhatsApp Inbound"),
        (REFERRAL, "Referral"),
    ]

    # Lead sources that require specific feature flags
    FEATURE_MAP = {
        INDIAMART: FeatureKey.INDIAMART,
        META_FACEBOOK: FeatureKey.META_LEAD_ADS,
        META_INSTAGRAM: FeatureKey.META_LEAD_ADS,
        NINETYNINEACRES: FeatureKey.NINETYNINEACRES,
        HOUSING_COM: FeatureKey.HOUSING_COM,
        MAGICBRICKS: FeatureKey.MAGICBRICKS,
        JUSTDIAL: FeatureKey.JUSTDIAL,
        SULEKHA: FeatureKey.SULEKHA,
        TRADEINDIA: FeatureKey.TRADEINDIA,
        GOOGLE_ADS: FeatureKey.GOOGLE_ADS_LEADS,
        WEBSITE: FeatureKey.WEBSITE_WIDGET,
        WEBHOOK: FeatureKey.GENERIC_WEBHOOK,
    }


# ============================================================
# Lead Status Choices
# ============================================================

class LeadStatus:
    NEW = "new"
    ATTEMPTED = "attempted"
    CONTACTED = "contacted"
    INTERESTED = "interested"
    NOT_INTERESTED = "not_interested"
    FOLLOW_UP = "follow_up"
    NEGOTIATION = "negotiation"    # Active deal in negotiation stage
    CONVERTED = "converted"
    WON = "converted"              # Alias: WON == CONVERTED (same DB value)
    LOST = "lost"
    DUPLICATE = "duplicate"
    # Junk: wrong person, invalid or out-of-service number. Kept apart from
    # LOST so a bad number never counts as a lost sale.
    INVALID = "invalid"

    CHOICES = [
        (NEW, "New"),
        (ATTEMPTED, "Attempted"),
        (CONTACTED, "Contacted"),
        (INTERESTED, "Interested"),
        (NOT_INTERESTED, "Not Interested"),
        (FOLLOW_UP, "Follow-up Scheduled"),
        (NEGOTIATION, "In Negotiation"),
        (CONVERTED, "Converted / Won"),
        (LOST, "Lost"),
        (DUPLICATE, "Duplicate"),
        (INVALID, "Invalid / Junk"),
    ]

    # Final statuses (no further action needed). NOT_INTERESTED was in neither
    # list, so it was left out of every count and could still be served by a
    # calling queue.
    FINAL_STATUSES = [CONVERTED, LOST, DUPLICATE, NOT_INTERESTED, INVALID]

    # Closed without a sale. A call outcome may close a lead at any open
    # stage; reopening one from here is logged as a reopen.
    CLOSED_STATUSES = [NOT_INTERESTED, LOST, INVALID]

    # Settled for good: no call outcome changes these.
    LOCKED_STATUSES = [CONVERTED, DUPLICATE]

    # Pipeline order. A call outcome only ever moves a lead FORWARD through
    # these (a "Call back" on a lead in Negotiation used to drop it to
    # Follow-up). Interested and Follow-up are the same stage.
    STAGE_RANK = {
        NEW: 0, ATTEMPTED: 1, CONTACTED: 2,
        INTERESTED: 3, FOLLOW_UP: 3,
        NEGOTIATION: 4, CONVERTED: 5,
    }

    # Changing a lead to one of these by hand needs a reason.
    REASON_REQUIRED = [LOST, INVALID]

    # Active statuses (leads to work on — shown in pipeline board)
    ACTIVE_STATUSES = [NEW, ATTEMPTED, CONTACTED, INTERESTED, FOLLOW_UP, NEGOTIATION]


# ============================================================
# Call disposition groups
# ============================================================

class DispositionCategory:
    """Whether an outcome belongs to an answered call or an unanswered one."""

    CONNECTED = "connected"
    NOT_CONNECTED = "not_connected"

    CHOICES = [
        (CONNECTED, "Connected (call answered)"),
        (NOT_CONNECTED, "Not connected (call not answered)"),
    ]


# ============================================================
# Lead Priority
# ============================================================

class LeadPriority:
    HOT = "hot"
    WARM = "warm"
    COLD = "cold"

    CHOICES = [
        (HOT, "Hot 🔥"),
        (WARM, "Warm 🌤"),
        (COLD, "Cold ❄️"),
    ]


# ============================================================
# Call Direction
# ============================================================

class CallDirection:
    OUTBOUND = "outbound"
    INBOUND = "inbound"
    MISSED = "missed"

    CHOICES = [
        (OUTBOUND, "Outbound"),
        (INBOUND, "Inbound"),
        (MISSED, "Missed"),
    ]


# ============================================================
# Follow-Up Type
# ============================================================

class FollowUpType:
    CALL = "call"
    WHATSAPP = "whatsapp"
    EMAIL = "email"
    SITE_VISIT = "site_visit"
    MEETING = "meeting"
    DEMO = "demo"
    OTHER = "other"

    CHOICES = [
        (CALL, "Call"),
        (WHATSAPP, "WhatsApp"),
        (EMAIL, "Email"),
        (SITE_VISIT, "Site Visit"),
        (MEETING, "Meeting"),
        (DEMO, "Demo"),
        (OTHER, "Other"),
    ]


# ============================================================
# WhatsApp Provider Keys
# ============================================================

class WhatsAppProvider:
    WATI = "wati"
    INTERAKT = "interakt"
    GUPSHUP = "gupshup"
    AISENSY = "aisensy"
    TWILIO = "twilio"
    META_CLOUD = "meta_cloud"
    THREE_SIXTY_DIALOG = "360dialog"

    CHOICES = [
        (WATI, "WATI"),
        (INTERAKT, "Interakt"),
        (GUPSHUP, "Gupshup"),
        (AISENSY, "AiSensy"),
        (TWILIO, "Twilio"),
        (META_CLOUD, "Meta Cloud API (Direct)"),
        (THREE_SIXTY_DIALOG, "360dialog"),
    ]


# ============================================================
# Audit Log Actions
# ============================================================

class AuditAction:
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    LOGIN = "login"
    LOGOUT = "logout"
    LOGIN_FAILED = "login_failed"
    IMPERSONATE = "impersonate"
    PLAN_CHANGE = "plan_change"
    SUSPEND = "suspend"
    ACTIVATE = "activate"
    EXPORT = "export"
    IMPORT = "import"
    BULK_ACTION = "bulk_action"
    SETTINGS_CHANGE = "settings_change"
    PASSWORD_CHANGE = "password_change"
    PASSWORD_RESET = "password_reset"

    CHOICES = [
        (CREATE, "Create"),
        (UPDATE, "Update"),
        (DELETE, "Delete"),
        (LOGIN, "Login"),
        (LOGOUT, "Logout"),
        (LOGIN_FAILED, "Login Failed"),
        (IMPERSONATE, "Impersonate"),
        (PLAN_CHANGE, "Plan Change"),
        (SUSPEND, "Suspend"),
        (ACTIVATE, "Activate"),
        (EXPORT, "Export"),
        (IMPORT, "Import"),
        (BULK_ACTION, "Bulk Action"),
        (SETTINGS_CHANGE, "Settings Change"),
        (PASSWORD_CHANGE, "Password Change"),
        (PASSWORD_RESET, "Password Reset"),
    ]


# ============================================================
# GST Configuration (India)
# ============================================================

class GSTState:
    """State codes and GST rates for Indian GST calculation."""

    # States subject to IGST (inter-state supply)
    TELECRM_STATE = "MH"  # TeleCRM's registered state (Maharashtra — update to actual)
    GST_RATE = 18  # 18% GST on SaaS

    # HSN/SAC code for SaaS services
    SAC_CODE = "998315"  # Information technology software services

    @classmethod
    def get_gst_components(cls, customer_state: str):
        """
        Returns GST components based on customer's state vs TeleCRM's state.

        Inter-state → IGST (18%)
        Intra-state → CGST (9%) + SGST (9%)
        """
        if customer_state == cls.TELECRM_STATE:
            return {
                "cgst_rate": 9,
                "sgst_rate": 9,
                "igst_rate": 0,
                "is_interstate": False,
            }
        return {
            "cgst_rate": 0,
            "sgst_rate": 0,
            "igst_rate": 18,
            "is_interstate": True,
        }


# ============================================================
# Cache Timeout Constants (in seconds)
# ============================================================

class CacheTimeout:
    FEATURE_FLAGS = 300          # 5 minutes — tenant plan features
    AGENT_SESSION = 3600         # 1 hour — agent session data
    TENANT_STATS = 600           # 10 minutes — tenant usage stats
    PLAN_LIST = 3600             # 1 hour — public plan list
    REPORT_DATA = 300            # 5 minutes — report query results
    DND_CHECK = 86400 * 30       # 30 days — TRAI DND status per number
    INTEGRATION_STATUS = 300     # 5 minutes — integration health status


# ============================================================
# File Size Limits (in bytes)
# ============================================================

class FileSizeLimit:
    PROFILE_PHOTO = 5 * 1024 * 1024          # 5 MB
    LEAD_ATTACHMENT = 25 * 1024 * 1024       # 25 MB
    CSV_IMPORT = 50 * 1024 * 1024            # 50 MB
    CALL_RECORDING = 200 * 1024 * 1024       # 200 MB
    EMAIL_ATTACHMENT = 10 * 1024 * 1024      # 10 MB
    WHATSAPP_MEDIA = 16 * 1024 * 1024        # 16 MB (Meta limit)


# ============================================================
# Indian State Codes (for GST)
# ============================================================

INDIAN_STATES = [
    ("AN", "Andaman and Nicobar Islands"),
    ("AP", "Andhra Pradesh"),
    ("AR", "Arunachal Pradesh"),
    ("AS", "Assam"),
    ("BR", "Bihar"),
    ("CH", "Chandigarh"),
    ("CG", "Chhattisgarh"),
    ("DN", "Dadra and Nagar Haveli and Daman and Diu"),
    ("DL", "Delhi"),
    ("GA", "Goa"),
    ("GJ", "Gujarat"),
    ("HR", "Haryana"),
    ("HP", "Himachal Pradesh"),
    ("JK", "Jammu and Kashmir"),
    ("JH", "Jharkhand"),
    ("KA", "Karnataka"),
    ("KL", "Kerala"),
    ("LA", "Ladakh"),
    ("LD", "Lakshadweep"),
    ("MP", "Madhya Pradesh"),
    ("MH", "Maharashtra"),
    ("MN", "Manipur"),
    ("ML", "Meghalaya"),
    ("MZ", "Mizoram"),
    ("NL", "Nagaland"),
    ("OD", "Odisha"),
    ("PY", "Puducherry"),
    ("PB", "Punjab"),
    ("RJ", "Rajasthan"),
    ("SK", "Sikkim"),
    ("TN", "Tamil Nadu"),
    ("TS", "Telangana"),
    ("TR", "Tripura"),
    ("UP", "Uttar Pradesh"),
    ("UK", "Uttarakhand"),
    ("WB", "West Bengal"),
]

# Other spellings of the same states/UTs in circulation (older GST code
# lists, vehicle codes). The web app's customer form used these, while the
# tenant's own state used the codes above — so a Telangana seller ("TS")
# invoicing a Telangana customer ("TG") was charged IGST as if interstate.
STATE_CODE_ALIASES = {"CT": "CG", "OR": "OD", "TG": "TS", "UT": "UK", "DD": "DN"}
INDIAN_STATE_CODES = {code for code, _ in INDIAN_STATES}


def canonical_state_code(code: str) -> str:
    code = (code or "").strip().upper()
    return STATE_CODE_ALIASES.get(code, code)
