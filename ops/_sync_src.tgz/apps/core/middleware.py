"""
TeleCRM Backend — apps/core/middleware.py

Custom middleware for TeleCRM:

1. TenantSchemaFromTokenMiddleware
   - Reads the JWT Bearer token and corrects the DB schema for API requests.
   - Runs BEFORE TenantFeatureFlagMiddleware so feature-flag checks use the
     right schema even when subdomain routing cannot resolve the tenant domain
     (e.g. demo.localhost in development, or a misconfigured domain entry).

2. TenantFeatureFlagMiddleware
   - Loads the current tenant's plan features into request
   - Caches feature flags in Redis to avoid DB hit on every request
   - Used in templates via {{ request.tenant_features }}
   - Used in views via request.has_feature(FeatureKey.BULK_WHATSAPP)

3. RequestTimingMiddleware
   - Logs slow requests (> 2 seconds)
   - Adds X-Response-Time header in debug mode

4. MaintenanceModeMiddleware
   - Returns 503 if MAINTENANCE_MODE=True in settings
"""
import logging
import time

from django.conf import settings
from django.core.cache import cache
from django.db import connection
from django.http import HttpResponse, JsonResponse
from django.utils.deprecation import MiddlewareMixin
from django.utils.functional import SimpleLazyObject

from apps.core.constants import CacheTimeout, SubscriptionStatus

logger = logging.getLogger(__name__)

# What every API call of a suspended or expired tenant gets back. The web
# and mobile apps key their "plan expired" screen on `error`.
PLAN_EXPIRED_RESPONSE = {
    "error": "plan_expired",
    "message": "Your plan has expired. Please contact support to renew your account.",
}


class TenantSchemaFromTokenMiddleware(MiddlewareMixin):
    """
    Corrects the active PostgreSQL schema for API requests by reading the
    tenant_schema claim from the JWT Bearer token.

    Why: TenantMainMiddleware sets the schema by looking up the request hostname
    in the Domain table.  In development the frontend hits demo.localhost:8000
    but the Domain table only has demo.telecrm.in, so the lookup fails and the
    connection defaults to the public schema.  Every subsequent check
    (TenantFeatureFlagMiddleware, AgentJWTAuthentication) then runs against the
    wrong schema, producing cascading 401 / 403 errors even for admin users.

    Fix: Before any per-tenant middleware runs, peek at the JWT payload
    (no signature verification needed here — AgentJWTAuthentication does the
    full verification) and switch the connection to the schema stated in the
    token.  Also accepts X-Tenant-Schema header as a fallback for requests
    that arrive before a token is available (e.g. the initial token-refresh
    call after a cold page load).

    Security. This used to switch on an UNVERIFIED token claim or on the
    header, for every /api/ request, arguing that JWT authentication would
    reject a forgery later. That holds only for authenticated endpoints: an
    anonymous request (the lead webhooks, tenant-info) has no later check, so
    anyone could aim one at any tenant by schema name without knowing its
    domain. The rules are now:

      1. When the HOST already names a tenant, the host wins. Only a token
         with a VALID SIGNATURE can name a different one (the user's own
         tenant — the auth backend resolves the agent there). The header can
         never override a tenant host.
      2. When the host names no tenant (the apex domain, or an IP address in
         development), a signed token may name one; the header may only do so
         for the sign-in endpoints that run before a token exists.
      3. The public schema is never targeted.

    Signatures are checked with expiry ignored: an expired token still proves
    which tenant issued it, and routing it there lets the auth backend answer
    401 — which is what makes the clients refresh — instead of a 404.
    """

    # Endpoints that legitimately run before the client holds a token, on a
    # host that may not name the tenant: signing in, refreshing, and the
    # mobile app's workspace check.
    PRE_AUTH_PATHS = (
        '/api/v1/auth/login/',
        '/api/v1/auth/refresh/',
        '/api/v1/auth/tenant-info/',
    )

    def process_request(self, request):
        if not request.path.startswith('/api/'):
            return None

        host_schema = connection.schema_name
        host_is_tenant = bool(host_schema) and host_schema != 'public'
        token_schema = self._schema_from_bearer(request)

        if host_is_tenant:
            # Only a genuinely signed token may move the request elsewhere.
            schema_name = token_schema if token_schema and token_schema != host_schema else None
            if schema_name is None:
                self._ensure_tenant_urlconf(request)
                return None
        else:
            schema_name = token_schema
            if not schema_name and request.path in self.PRE_AUTH_PATHS:
                schema_name = self._schema_from_header(request)

        if not schema_name or schema_name == 'public':
            return None

        if connection.schema_name == schema_name:
            # Schema is already correct; make sure URL routing also uses
            # the tenant conf (could be public if TenantMainMiddleware set it).
            self._ensure_tenant_urlconf(request)
            return None

        try:
            connection.set_schema(schema_name)
            # Keep request.tenant in sync so TenantFeatureFlagMiddleware
            # loads features for the correct tenant.
            self._sync_request_tenant(request, schema_name)
            # Critical: switch URL routing away from the public conf so that
            # tenant API endpoints (e.g. /api/v1/auth/login/) are reachable.
            self._ensure_tenant_urlconf(request)
        except Exception as exc:
            logger.warning(
                f"[TenantSchemaFromToken] Could not switch to schema "
                f"'{schema_name}': {exc}"
            )

        return None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _schema_from_bearer(request) -> str | None:
        auth_header = request.META.get('HTTP_AUTHORIZATION', '')
        if not auth_header.startswith('Bearer '):
            return None
        token_string = auth_header[7:].strip()
        return TenantSchemaFromTokenMiddleware._decode_jwt_schema(token_string)

    @staticmethod
    def _schema_from_header(request) -> str | None:
        """
        Reads X-Tenant-Schema or X-Workspace-ID headers to determine the schema.
        This is critical for mobile apps hitting IP addresses directly.
        """
        schema = request.META.get('HTTP_X_TENANT_SCHEMA', '').strip()
        if schema and schema != 'public':
            try:
                from apps.tenants.models import Domain
                if Domain.objects.filter(tenant__schema_name=schema).exists():
                    return schema
            except Exception:
                pass
                
        workspace = request.META.get('HTTP_X_WORKSPACE_ID', '').strip()
        if workspace:
            try:
                from apps.tenants.models import Domain, Tenant
                # 1. Try subdomain prefix: "demo" → matches "demo.localhost"
                domain_obj = Domain.objects.filter(
                    domain__startswith=f"{workspace}."
                ).exclude(tenant__schema_name='public').select_related('tenant').first()
                if domain_obj:
                    return domain_obj.tenant.schema_name
                # 2. Try exact schema name: "demo_corp" → matches schema directly
                if Tenant.objects.filter(schema_name=workspace).exclude(schema_name='public').exists():
                    return workspace
            except Exception:
                pass

        return None

    @staticmethod
    def _decode_jwt_schema(token_string: str) -> str | None:
        """
        The tenant_schema claim from a token WE signed — None for anything else.

        The signature is verified; expiry is not. A forged token used to be
        enough to pick the schema, because this read the claim without
        checking who wrote it. An expired token is still accepted here: it
        proves which tenant issued it, and routing it there lets the auth
        backend answer 401 (which triggers the client's refresh) rather than
        a confusing 404 from the public URL conf.
        """
        try:
            import jwt

            simple_jwt = getattr(settings, 'SIMPLE_JWT', {})
            payload = jwt.decode(
                token_string,
                simple_jwt.get('SIGNING_KEY', settings.SECRET_KEY),
                algorithms=[simple_jwt.get('ALGORITHM', 'HS256')],
                options={'verify_exp': False, 'verify_aud': False},
            )
        except Exception:
            return None
        schema = payload.get('tenant_schema', '')
        return schema if schema and schema != 'public' else None

    @staticmethod
    def _sync_request_tenant(request, schema_name: str):
        """Updates request.tenant to match the corrected schema."""
        try:
            from apps.tenants.models import Tenant
            tenant = Tenant.objects.get(schema_name=schema_name)
            request.tenant = tenant
        except Exception:
            pass

    @staticmethod
    def _ensure_tenant_urlconf(request):
        """
        Switches URL routing from the public schema conf to the tenant conf.

        When TenantMainMiddleware resolves a request to the public tenant
        (e.g. because the Host header is 'localhost' or an Android emulator IP),
        it sets request.urlconf = PUBLIC_SCHEMA_URLCONF.  That conf has no
        /api/v1/auth/ etc., so those endpoints return 404.  After we correct
        the DB schema we must also correct the URL routing.
        """
        from django.conf import settings
        from django.urls import set_urlconf

        public_urlconf = getattr(settings, 'PUBLIC_SCHEMA_URLCONF', None)
        current = getattr(request, 'urlconf', None)
        if current == public_urlconf or current is None:
            request.urlconf = settings.ROOT_URLCONF
            set_urlconf(settings.ROOT_URLCONF)


class TenantFeatureFlagMiddleware(MiddlewareMixin):
    """
    Injects tenant plan features into every request.

    After this middleware runs, request has:
      - request.tenant_features: dict {feature_key: bool}
      - request.has_feature(key): helper method
      - request.tenant_plan: Plan instance (or None for public schema)
    """

    def process_request(self, request):
        # Skip for public schema (super admin)
        if not hasattr(request, "tenant"):
            request.tenant_features = {}
            request.tenant_plan = None
            return None

        tenant = request.tenant
        if tenant.schema_name == "public":
            request.tenant_features = {}
            request.tenant_plan = None
            # Inject helper method that always returns True for super admin
            request.has_feature = lambda key: True
            return None

        # Load features from cache or DB
        features = self._get_tenant_features(tenant)
        request.tenant_features = features

        # Resolve the plan lazily: `_cached_plan` is only populated on a cache
        # MISS, so reading it directly left tenant_plan None on nearly every
        # request. SimpleLazyObject costs nothing unless something reads it.
        # NOTE: it is never `is None` — test it for truthiness instead.
        request.tenant_plan = SimpleLazyObject(lambda: self._get_tenant_plan(tenant))

        # Inject helper method
        def has_feature(feature_key):
            return bool(features.get(feature_key, False))

        request.has_feature = has_feature

        # Check if tenant is active (not suspended/cancelled/expired)
        if not self._is_tenant_active(tenant):
            # For API requests, return JSON error. Every endpoint, sign-in
            # included: the web and mobile apps show their "plan expired"
            # screen on this code.
            if request.path.startswith("/api/") and request.path not in self.ALWAYS_OPEN:
                return JsonResponse(PLAN_EXPIRED_RESPONSE, status=403)
            # For web requests, redirect to suspended page
            # (let views handle this; just set a flag)
            request.tenant_suspended = True

        return None

    def _get_tenant_features(self, tenant) -> dict:
        """
        Load feature flags from Redis cache, falling back to DB.
        Cache key is per-tenant to ensure isolation.
        """
        cache_key = f"tenant_features:{tenant.schema_name}"
        cached = cache.get(cache_key)

        if cached is not None:
            return cached

        # Load from DB
        features = self._load_features_from_db(tenant)
        cache.set(cache_key, features, timeout=CacheTimeout.FEATURE_FLAGS)
        return features

    def _get_tenant_plan(self, tenant):
        """Resolve the tenant's active Plan (id cached; 0 means 'no plan')."""
        cache_key = f"tenant_plan_id:{tenant.schema_name}"
        plan_id = cache.get(cache_key)

        if plan_id is None:
            from apps.plans.models import Subscription
            subscription = (
                Subscription.objects.filter(
                    tenant=tenant, status__in=SubscriptionStatus.ACTIVE_STATUSES
                )
                .select_related("plan")
                .first()
            )
            plan = subscription.plan if subscription else None
            cache.set(cache_key, plan.pk if plan else 0, timeout=CacheTimeout.FEATURE_FLAGS)
            return plan

        if not plan_id:
            return None

        from apps.plans.models import Plan
        return Plan.objects.filter(pk=plan_id).first()

    def _load_features_from_db(self, tenant) -> dict:
        """
        Resolve the tenant's EFFECTIVE feature map from the public schema:

            plan's PlanFeature set, then TenantEntitlement applied over it

        Entitlements are how add-on modules (HRMS/ERP/AI) are sold independently
        of the plan tier. A grant adds a feature; is_enabled=False explicitly
        revokes one the plan would otherwise allow. Expired rows are ignored.
        A tenant with no subscription can still hold entitlements.
        """
        from django.db.models import Q
        from django.utils import timezone

        features: dict = {}
        try:
            from apps.plans.models import PlanFeature, Subscription, TenantEntitlement

            subscription = (
                Subscription.objects.filter(
                    tenant=tenant,
                    status__in=SubscriptionStatus.ACTIVE_STATUSES,
                )
                .select_related("plan")
                .first()
            )

            if subscription:
                # Cache plan reference on tenant object
                tenant._cached_plan = subscription.plan
                features = {
                    pf["feature_key"]: pf["is_enabled"]
                    for pf in PlanFeature.objects.filter(
                        plan=subscription.plan
                    ).values("feature_key", "is_enabled")
                }

            # Layer per-tenant entitlements (add-ons / bespoke grants) on top.
            now = timezone.now()
            entitlements = TenantEntitlement.objects.filter(
                Q(expires_at__isnull=True) | Q(expires_at__gt=now),
                tenant=tenant,
            ).values("feature_key", "is_enabled")
            for ent in entitlements:
                features[ent["feature_key"]] = ent["is_enabled"]

            return features

        except Exception as exc:
            logger.warning(
                f"Failed to load features for tenant {tenant.schema_name}: {exc}"
            )
            return features

    # Reachable for a suspended tenant: only the health checks.
    ALWAYS_OPEN = ("/api/v1/health/",)

    def _is_tenant_active(self, tenant) -> bool:
        """
        Whether the tenant may use the platform — read straight off the tenant
        row, which django-tenants loads fresh for every request.

        This used to answer from a 60-second cache and, when the tenant's own
        status said "suspended", fall back to the Subscription table — which
        still said "active", because suspending never touched it. So a tenant
        suspended from the panel (its status set to Suspended, or "Active"
        unticked) carried on working: its admin signed in and everything ran.
        """
        try:
            return bool(tenant.can_use_platform)
        except AttributeError:  # a tenant-like object without the property
            return bool(getattr(tenant, "is_active", True))

    @staticmethod
    def invalidate_cache(schema_name: str):
        """
        Call this when a tenant's plan, entitlements or status change.
        Clears the cached feature map for immediate effect.
        """
        cache.delete(f"tenant_features:{schema_name}")
        cache.delete(f"tenant_active:{schema_name}")
        cache.delete(f"tenant_plan_id:{schema_name}")


class RequestTimingMiddleware(MiddlewareMixin):
    """
    Measures request processing time.
    - Logs requests that take > SLOW_REQUEST_THRESHOLD seconds
    - Adds X-Response-Time header in DEBUG mode
    """

    SLOW_REQUEST_THRESHOLD = 2.0  # seconds

    def process_request(self, request):
        request._start_time = time.monotonic()

    def process_response(self, request, response):
        if not hasattr(request, "_start_time"):
            return response

        elapsed = time.monotonic() - request._start_time
        elapsed_ms = int(elapsed * 1000)

        # Add timing header in debug mode
        if settings.DEBUG:
            response["X-Response-Time"] = f"{elapsed_ms}ms"

        # Log slow requests
        if elapsed > self.SLOW_REQUEST_THRESHOLD:
            tenant_schema = getattr(
                getattr(request, "tenant", None), "schema_name", "public"
            )
            logger.warning(
                f"[SlowRequest] {request.method} {request.path} "
                f"took {elapsed_ms}ms | tenant={tenant_schema}"
            )

        return response


class MaintenanceModeMiddleware(MiddlewareMixin):
    """
    Returns a 503 Service Unavailable response when MAINTENANCE_MODE is True.
    Exempts the super admin panel and health check endpoint.
    """

    EXEMPT_PATHS = [
        f"/{settings.ADMIN_URL}",
        "/health/",
        "/api/v1/health/",
    ]

    def process_request(self, request):
        if not getattr(settings, "MAINTENANCE_MODE", False):
            return None

        # Don't block admin or health check
        for path in self.EXEMPT_PATHS:
            if request.path.startswith(path):
                return None

        # API requests → JSON
        if request.path.startswith("/api/"):
            return JsonResponse(
                {
                    "error": "maintenance",
                    "message": (
                        "TeleCRM is currently under scheduled maintenance. "
                        "We'll be back shortly!"
                    ),
                },
                status=503,
            )

        # Web requests → HTML maintenance page
        return HttpResponse(
            """
            <!DOCTYPE html>
            <html>
            <head><title>TeleCRM — Maintenance</title></head>
            <body style="font-family:sans-serif;text-align:center;padding:100px">
                <h1>🔧 Under Maintenance</h1>
                <p>TeleCRM is undergoing scheduled maintenance. We'll be back soon!</p>
            </body>
            </html>
            """,
            status=503,
        )
