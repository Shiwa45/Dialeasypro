"""
TeleCRM Backend — apps/erp/api_urls.py
Mounted at: /api/v1/erp/
"""
from django.urls import path

from apps.erp.views import (
    CustomerDetailView,
    ErpDashboardView,
    GstSummaryView,
    CustomerListCreateView,
    InvoiceCancelView,
    InvoiceDetailView,
    InvoiceIssueView,
    InvoiceItemView,
    InvoiceListView,
    PaymentCreateView,
    PaymentDetailView,
    PaymentListView,
    ProductDetailView,
    ProductListCreateView,
    QuotationConvertView,
    QuotationDetailView,
    QuotationItemView,
    QuotationListCreateView,
    QuotationStatusView,
    SalesOrderCancelView,
    SalesOrderDetailView,
    SalesOrderInvoiceView,
    SalesOrderListView,
    TallyExportView,
)

urlpatterns = [
    # Dashboard
    path("dashboard/", ErpDashboardView.as_view(), name="api_erp_dashboard"),

    # Masters
    path("customers/", CustomerListCreateView.as_view(), name="api_erp_customers"),
    path("customers/<int:pk>/", CustomerDetailView.as_view(), name="api_erp_customer_detail"),
    path("products/", ProductListCreateView.as_view(), name="api_erp_products"),
    path("products/<int:pk>/", ProductDetailView.as_view(), name="api_erp_product_detail"),

    # Quotations
    path("quotations/", QuotationListCreateView.as_view(), name="api_erp_quotations"),
    path("quotations/<int:pk>/", QuotationDetailView.as_view(), name="api_erp_quotation_detail"),
    path("quotations/<int:pk>/items/", QuotationItemView.as_view(), name="api_erp_quotation_items"),
    path("quotations/<int:pk>/items/<int:item_id>/", QuotationItemView.as_view(), name="api_erp_quotation_item"),
    path("quotations/<int:pk>/status/", QuotationStatusView.as_view(), name="api_erp_quotation_status"),
    path("quotations/<int:pk>/convert/", QuotationConvertView.as_view(), name="api_erp_quotation_convert"),

    # Sales orders
    path("orders/", SalesOrderListView.as_view(), name="api_erp_orders"),
    path("orders/<int:pk>/", SalesOrderDetailView.as_view(), name="api_erp_order_detail"),
    path("orders/<int:pk>/invoice/", SalesOrderInvoiceView.as_view(), name="api_erp_order_invoice"),
    path("orders/<int:pk>/cancel/", SalesOrderCancelView.as_view(), name="api_erp_order_cancel"),

    # Invoices
    path("invoices/", InvoiceListView.as_view(), name="api_erp_invoices"),
    path("invoices/<int:pk>/", InvoiceDetailView.as_view(), name="api_erp_invoice_detail"),
    path("invoices/<int:pk>/items/", InvoiceItemView.as_view(), name="api_erp_invoice_items"),
    path("invoices/<int:pk>/items/<int:item_id>/", InvoiceItemView.as_view(), name="api_erp_invoice_item"),
    path("invoices/<int:pk>/issue/", InvoiceIssueView.as_view(), name="api_erp_invoice_issue"),
    path("invoices/<int:pk>/cancel/", InvoiceCancelView.as_view(), name="api_erp_invoice_cancel"),
    path("invoices/<int:pk>/payments/", PaymentCreateView.as_view(), name="api_erp_invoice_payment"),

    # Payments ledger
    path("payments/", PaymentListView.as_view(), name="api_erp_payments"),
    path("payments/<int:pk>/", PaymentDetailView.as_view(), name="api_erp_payment_detail"),

    # Accounting export & reports
    path("export/tally/", TallyExportView.as_view(), name="api_erp_tally_export"),
    path("reports/gst-summary/", GstSummaryView.as_view(), name="api_erp_gst_summary"),
]
