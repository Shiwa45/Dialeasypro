"""
TeleCRM Backend — apps/leads/tasks.py

Celery tasks for the leads app.

process_lead_import     : Main import pipeline — reads CSV/Excel, validates,
                          deduplicates, bulk-inserts leads, generates error report.
recalculate_lead_scores : Periodic scoring task (runs for all tenants).
send_followup_reminder  : Sends reminder for an upcoming follow-up.
cleanup_old_leads       : Archives/deletes leads past data retention period.
"""
import logging

from celery import shared_task
from django.conf import settings
from django.utils import timezone

from apps.core.tasks import PublicSchemaTask, TenantAwareTask

# Lead.budget is Decimal(12, 2): anything from ten billion up cannot be stored,
# and one such cell would fail the whole bulk insert it sits in.
MAX_BUDGET = 10 ** 10

logger = logging.getLogger(__name__)


# ============================================================
# Lead Import Pipeline
# ============================================================

@shared_task(base=TenantAwareTask, bind=True, max_retries=2, time_limit=1800)
def process_lead_import(self, schema_name: str, import_job_id: str):
    """
    Main lead import pipeline.
    Reads file from storage, validates rows, deduplicates, bulk-inserts.

    Progress is tracked via LeadImportJob model fields (polled by frontend).
    Celery task ID stored in LeadImportJob.celery_task_id.
    """
    import csv
    import io
    from apps.leads.models import (
        CustomField, CustomFieldValue, Lead, LeadActivity, LeadBatch, LeadImportJob, LeadNote,
    )
    from apps.core.constants import LeadSource
    from apps.core.utils import normalize_indian_phone, parse_indian_amount

    logger.info(f"[Import] Starting import job {import_job_id} in {schema_name}")

    try:
        job = LeadImportJob.objects.get(pk=import_job_id)
    except LeadImportJob.DoesNotExist:
        logger.error(f"[Import] Job {import_job_id} not found in {schema_name}")
        return

    job.status = "processing"
    job.save(update_fields=["status"])

    # --- Read file ------------------------------------------
    try:
        file_content = job.file.read()
        filename = job.original_filename.lower()
    except Exception as exc:
        job.status = "failed"
        job.row_errors = [{"row": 0, "error": f"Could not read file: {exc}"}]
        job.save(update_fields=["status", "row_errors"])
        return

    # --- Parse into rows ------------------------------------
    rows = _parse_import_file(file_content, filename)
    if rows is None:
        job.status = "failed"
        job.row_errors = [{"row": 0, "error": "Unsupported file format. Use CSV or XLSX."}]
        job.save(update_fields=["status", "row_errors"])
        return

    job.total_rows = len(rows)
    job.save(update_fields=["total_rows"])

    # --- Batch -----------------------------------------------
    # Created only once the file has parsed: a job that dies on an unreadable
    # file must not leave an empty batch sitting in the admin's list.
    batch = getattr(job, "batch", None)
    if batch is None:
        batch = LeadBatch.create_for_import(
            import_job=job,
            name=job.batch_name,
            created_by=job.imported_by,
            source=job.default_source or LeadSource.CSV_IMPORT,
        )
    logger.info(f"[Import] job={job.pk} → batch #{batch.number} ({batch.label})")

    # --- Mapping of column names → Lead fields ---------------
    column_mapping = job.column_mapping or {}
    # Defaults if no mapping configured
    default_mapping = {
        "name": ["name", "full name", "contact name", "customer name", "lead name"],
        "phone": ["phone", "mobile", "contact", "phone number", "mobile number", "contact no"],
        "email": ["email", "email address", "mail"],
        "city": ["city", "location", "town"],
        "state": ["state"],
        "requirement": ["requirement", "query", "message", "remarks", "comments"],
        "budget": ["budget", "amount"],
    }

    # --- Process rows ----------------------------------------
    successful, failed, duplicates = 0, 0, 0
    row_errors = []
    leads_to_create = []
    # Per-row extras, index-aligned with leads_to_create. Custom-field values
    # and notes cannot be written until the leads have primary keys, so they
    # are parked here and flushed after each bulk insert.
    pending_extras = []

    # Custom fields keyed the way the import preview offers them
    # ("custom_<field_key>" — see LeadImportPreviewView.available_fields).
    # Resolved once: a per-row lookup would be one query per cell.
    custom_field_by_key = {
        cf.field_key: cf for cf in CustomField.objects.filter(is_active=True)
    }

    # Build existing phone set for duplicate detection
    existing_phones = set(
        Lead.objects.filter(is_deleted=False).values_list("phone", flat=True)
    )
    # New numbers queued earlier in THIS file: phone -> index in
    # leads_to_create. They are in existing_phones but not yet in the
    # database, so "update duplicates" cannot look them up there.
    queued = {}

    for row_idx, raw_row in enumerate(rows, start=2):  # start=2 (row 1 is header)
        try:
            # Apply column mapping
            row = _apply_mapping(raw_row, column_mapping, default_mapping)

            # Validate required fields
            if not row.get("name", "").strip():
                raise ValueError("Name is required")
            if not row.get("phone", "").strip():
                raise ValueError("Phone is required")

            # Normalize phone
            phone = normalize_indian_phone(row["phone"])
            if not phone:
                raise ValueError(f"Invalid phone number: {row['phone']}")

            # Duplicate handling
            if phone in existing_phones:
                if job.duplicate_action == "skip":
                    duplicates += 1
                    _note_progress(job, row_idx)
                    continue
                elif job.duplicate_action == "update":
                    # Update the existing lead.
                    #
                    # filter().first(), not get(): phone is indexed but NOT
                    # unique, so a number that appears twice — anything
                    # imported under "Allow duplicates", or the same person
                    # entered by two agents — made get() raise
                    # MultipleObjectsReturned, which `except Lead.DoesNotExist`
                    # does not catch. The row then escaped to the outer handler
                    # and was recorded as FAILED rather than updated. Oldest
                    # wins, so repeated runs keep landing on the same lead.
                    existing = (
                        Lead.objects.filter(phone=phone, is_deleted=False)
                        .order_by("id").first()
                    )
                    if existing is not None:
                        _update_lead_from_row(existing, row, job)
                    elif phone in queued:
                        # The same new number twice in one file. It used to
                        # look for a saved lead that did not exist yet, find
                        # none, and drop the row without counting it anywhere.
                        # Merge it into the queued lead instead, by the same
                        # fill-a-blank rule as updating a saved one.
                        idx = queued[phone]
                        _merge_row_into_queued(
                            leads_to_create[idx], pending_extras[idx], row, custom_field_by_key,
                        )
                    else:
                        raise ValueError("Duplicate number, but no lead found to update")
                    successful += 1
                    duplicates += 1
                    _note_progress(job, row_idx)
                    continue
                # else: create_new — allow duplicate

            # Build lead kwargs
            lead_kwargs = {
                "name": row["name"].strip(),
                "phone": phone,
                "email": row.get("email", "").strip().lower(),
                "city": row.get("city", "").strip(),
                "state": row.get("state", "").strip(),
                "requirement": row.get("requirement", "").strip(),
                "source": job.default_source or LeadSource.MANUAL,
                "assigned_to": job.default_assigned_to,
                "import_job": job,
                "batch": batch,
            }
            # Budget: "1.2 Cr", "50L", "20 lakh" as well as plain numbers.
            # One that cannot be read no longer vanishes silently — the lead
            # is still imported, and the row says why its budget is empty.
            budget_text = row.get("budget", "")
            try:
                budget = parse_indian_amount(budget_text)
                if budget is not None and budget >= MAX_BUDGET:
                    raise ValueError("too large")
            except ValueError:
                budget = None
                row_errors.append({
                    "row": row_idx,
                    "data": str(budget_text)[:200],
                    "error": f"Budget '{budget_text.strip()}' not understood — imported without a budget.",
                })
            if budget is not None:
                lead_kwargs["budget"] = budget

            queued[phone] = len(leads_to_create)
            leads_to_create.append(Lead(**lead_kwargs))
            pending_extras.append({
                "phone": phone,
                "custom": _extract_custom_values(row, custom_field_by_key),
                "note": (row.get("notes") or "").strip(),
            })
            existing_phones.add(phone)

        except Exception as exc:
            failed += 1
            row_errors.append({
                "row": row_idx,
                "data": str(raw_row)[:200],
                "error": str(exc),
            })

        _note_progress(job, row_idx)

    # --- Plan capacity ----------------------------------------
    # Truncate to what the plan still allows rather than failing the whole job:
    # importing 900 of 1000 rows is far more useful than importing none.
    from apps.core.quotas import note_leads_created, remaining_lead_allowance

    allowance = remaining_lead_allowance()
    if allowance is not None and len(leads_to_create) > allowance:
        skipped = len(leads_to_create) - allowance
        leads_to_create = leads_to_create[:allowance]
        # Must be sliced identically — the two lists are matched by index.
        pending_extras = pending_extras[:allowance]
        failed += skipped
        row_errors.append({
            "row": "-",
            "data": "",
            "error": (
                f"Plan lead limit reached — {skipped} row(s) not imported. "
                f"Upgrade your plan to import more."
            ),
        })
        logger.warning(f"[Import] job={job.pk} truncated {skipped} rows (plan limit)")

    # --- Bulk create -----------------------------------------
    if leads_to_create:
        try:
            chunk_size = 500
            for i in range(0, len(leads_to_create), chunk_size):
                chunk = leads_to_create[i:i + chunk_size]
                extras = pending_extras[i:i + chunk_size]
                Lead.objects.bulk_create(chunk, ignore_conflicts=True)

                # `ignore_conflicts=True` makes Django skip the RETURNING
                # clause, so the objects in `chunk` come back with pk=None even
                # on PostgreSQL. Re-read them by this job's FK to get the real
                # rows — without this the activity log below silently wrote
                # nothing, and custom values would have nowhere to attach.
                saved = {}
                for lead in Lead.objects.filter(
                    import_job=job, phone__in=[e["phone"] for e in extras]
                ).order_by("id"):
                    # Last wins, so "create duplicates" mode attaches a row's
                    # values to the most recently created lead for that phone.
                    saved[lead.phone] = lead

                activities, values, notes = [], [], []
                for extra in extras:
                    lead = saved.get(extra["phone"])
                    if lead is None:
                        continue
                    activities.append(LeadActivity(
                        lead=lead,
                        activity_type="imported",
                        description=f"Imported from {job.original_filename}",
                    ))
                    for field, value in extra["custom"].items():
                        values.append(CustomFieldValue(lead=lead, field=field, value=value))
                    if extra["note"]:
                        notes.append(LeadNote(lead=lead, content=extra["note"]))

                if activities:
                    LeadActivity.objects.bulk_create(activities)
                if values:
                    # ignore_conflicts covers the unique (lead, field) pair on a
                    # re-run against leads that already have values.
                    CustomFieldValue.objects.bulk_create(values, ignore_conflicts=True)
                if notes:
                    LeadNote.objects.bulk_create(notes)
            successful += len(leads_to_create)
            note_leads_created(len(leads_to_create))
        except Exception as exc:
            logger.error(f"[Import] Bulk create failed: {exc}", exc_info=True)
            failed += len(leads_to_create)
            row_errors.append({"row": "bulk", "error": str(exc)})

    # --- Batch counter & auto-assign -------------------------
    # recount() rather than trusting `successful`: the "update existing"
    # duplicate mode counts rows as successful that were never added to this
    # batch, so incrementing by `successful` would overstate it. Reading the
    # leads actually pointing at the batch is the only figure that is true.
    batch.recount()

    if job.auto_assign and job.assign_to_agents:
        try:
            from apps.authentication.models import Agent
            from apps.leads.services import distribution as dist

            # Preserve the admin's chosen order — round robin starts with the
            # first agent they picked, which is what they expect to see.
            by_pk = {
                a.pk: a for a in Agent.objects.filter(
                    pk__in=job.assign_to_agents, is_active=True,
                )
            }
            agents = [by_pk[pk] for pk in job.assign_to_agents if pk in by_pk]

            if not agents:
                job.assignment_result = {
                    "distributed": 0,
                    "message": "Auto-assign was on, but none of the selected agents are active.",
                }
            else:
                method = job.assign_method or dist.Method.ROUND_ROBIN
                if method not in dist.Method.ALL:
                    method = dist.Method.ROUND_ROBIN
                lead_ids = dist.leads_for_batches(
                    [batch.pk], only_unassigned=True,
                )
                job.assignment_result = dist.distribute(
                    lead_ids, agents,
                    method=method,
                    max_per_agent=job.assign_max_per_agent,
                    actor=job.imported_by,
                )
                logger.info(
                    f"[Import] job={job.pk} auto-assigned "
                    f"{job.assignment_result.get('distributed', 0)} lead(s)"
                )
        except Exception as exc:
            # A failed distribution must never fail the import. The leads are
            # already safely in the batch; the admin can distribute manually
            # from the Batches screen, and the reason is recorded here.
            logger.error(f"[Import] job={job.pk} auto-assign failed: {exc}", exc_info=True)
            job.assignment_result = {
                "distributed": 0,
                "error": str(exc),
                "message": (
                    "Leads imported successfully, but auto-assign failed. "
                    "Distribute this batch manually."
                ),
            }

    # --- Finalize -------------------------------------------
    job.successful_rows = successful
    job.failed_rows = failed
    job.duplicate_rows = duplicates
    job.processed_rows = job.total_rows
    job.row_errors = row_errors[:500]  # Cap error list size
    job.save(update_fields=["assignment_result"])
    job.mark_completed()

    logger.info(
        f"[Import] Job {import_job_id} done: "
        f"{successful} ok / {failed} failed / {duplicates} dupes"
    )
    return {
        "successful": successful,
        "failed": failed,
        "duplicates": duplicates,
        "batch_id": batch.pk,
        "batch_number": batch.number,
        "assigned": job.assignment_result.get("distributed", 0),
    }


def _parse_import_file(file_content: bytes, filename: str) -> list | None:
    """
    Universal sheet & data file parser.
    Supports CSV, XLSX, XLS, XLSM, XLSB, ODS, TSV, TXT files regardless of case or extension.
    Handles encodings, delimiters, float phone numbers (e.g. 9876543210.0 -> 9876543210),
    and dates automatically.
    """
    import io
    import csv
    import logging

    logger = logging.getLogger(__name__)
    if not file_content:
        return None

    fname_lower = (filename or "").lower()
    is_excel = file_content.startswith(b'PK\x03\x04') or file_content.startswith(b'\xd0\xcf\x11\xe0') or fname_lower.endswith((".xlsx", ".xls", ".xlsm", ".xlsb", ".ods"))

    # ============================================================
    # 1. EXCEL PARSING (.xlsx, .xls, .xlsm, .ods)
    # ============================================================
    if is_excel:
        # Strategy A: Openpyxl (standard mode)
        try:
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(file_content), data_only=True)
            ws = wb.active
            rows = []
            for row in ws.iter_rows(values_only=True):
                if any(cell is not None and str(cell).strip() != "" for cell in row):
                    rows.append(row)
            if rows and len(rows) >= 2:
                headers = [str(c or "").strip() for c in rows[0]]
                parsed_rows = []
                for row_cells in rows[1:]:
                    row_dict = {}
                    for i, val in enumerate(row_cells):
                        if i < len(headers) and headers[i]:
                            if val is None:
                                v_str = ""
                            elif isinstance(val, float) and val.is_integer():
                                v_str = str(int(val))
                            else:
                                v_str = str(val).strip()
                                if v_str.endswith(".0") and v_str[:-2].isdigit():
                                    v_str = v_str[:-2]
                            row_dict[headers[i]] = v_str
                    if any(v for v in row_dict.values()):
                        parsed_rows.append(row_dict)
                if parsed_rows:
                    return parsed_rows
        except Exception as exc:
            logger.info(f"[Import] openpyxl standard load failed: {exc}")

        # Strategy B: Openpyxl (read_only mode)
        try:
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(file_content), read_only=True, data_only=True)
            ws = wb.active
            iterator = ws.iter_rows(values_only=True)
            header_row = next(iterator, None)
            if header_row:
                headers = [str(c or "").strip() for c in header_row]
                parsed_rows = []
                for row in iterator:
                    row_dict = {}
                    for i, val in enumerate(row):
                        if i < len(headers) and headers[i]:
                            if val is None:
                                v_str = ""
                            elif isinstance(val, float) and val.is_integer():
                                v_str = str(int(val))
                            else:
                                v_str = str(val).strip()
                                if v_str.endswith(".0") and v_str[:-2].isdigit():
                                    v_str = v_str[:-2]
                            row_dict[headers[i]] = v_str
                    if any(v for v in row_dict.values()):
                        parsed_rows.append(row_dict)
                if parsed_rows:
                    return parsed_rows
        except Exception as exc:
            logger.info(f"[Import] openpyxl read_only load failed: {exc}")

        # Strategy C: Pandas read_excel
        try:
            import pandas as pd
            df = pd.read_excel(io.BytesIO(file_content), dtype=str)
            df = df.dropna(how="all")
            df.columns = [str(col).strip() for col in df.columns]
            parsed_rows = []
            for _, row in df.iterrows():
                row_dict = {}
                for col in df.columns:
                    val = row[col]
                    if pd.isna(val) or val is None or str(val).strip().lower() in ("nan", "none", "null", "nat"):
                        val_str = ""
                    else:
                        val_str = str(val).strip()
                        if val_str.endswith(".0") and val_str[:-2].replace("-", "").isdigit():
                            val_str = val_str[:-2]
                    row_dict[col] = val_str
                if any(v for v in row_dict.values()):
                    parsed_rows.append(row_dict)
            if parsed_rows:
                return parsed_rows
        except Exception as exc:
            logger.info(f"[Import] pandas read_excel failed: {exc}")

    # ============================================================
    # 2. CSV / TEXT PARSING (.csv, .tsv, .txt, or text bytes)
    # ============================================================
    for encoding in ["utf-8-sig", "utf-8", "cp1252", "latin-1", "iso-8859-1", "gbk"]:
        try:
            text = file_content.decode(encoding)
        except Exception:
            continue

        # Skip binary garbage if accidentally passed here
        if "\0" in text[:500]:
            continue

        sample = text[:4096]
        # Detect delimiter
        delimiter = ","
        if ";" in sample and sample.count(";") > sample.count(","):
            delimiter = ";"
        elif "\t" in sample and sample.count("\t") > sample.count(","):
            delimiter = "\t"
        elif "|" in sample and sample.count("|") > sample.count(","):
            delimiter = "|"

        try:
            reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
            rows = []
            for row in reader:
                cleaned_row = {}
                for k, v in row.items():
                    if k is not None:
                        k_str = str(k).strip()
                        v_str = str(v or "").strip()
                        if v_str.endswith(".0") and v_str[:-2].isdigit():
                            v_str = v_str[:-2]
                        cleaned_row[k_str] = v_str
                if any(v for v in cleaned_row.values()):
                    rows.append(cleaned_row)
            if rows:
                return rows
        except Exception as exc:
            logger.info(f"[Import] CSV decode/parse attempt ({encoding}, {delimiter}) failed: {exc}")

    # Strategy D: Pandas read_csv fallback for complex CSVs
    try:
        import pandas as pd
        for encoding in ["utf-8-sig", "utf-8", "latin-1", "cp1252"]:
            for sep in [",", ";", "\t", "|"]:
                try:
                    df = pd.read_csv(io.BytesIO(file_content), sep=sep, encoding=encoding, dtype=str, on_bad_lines="skip")
                    df = df.dropna(how="all")
                    if not df.empty:
                        df.columns = [str(c).strip() for c in df.columns]
                        parsed_rows = []
                        for _, row in df.iterrows():
                            r_dict = {col: ("" if pd.isna(row[col]) else str(row[col]).strip()) for col in df.columns}
                            if any(v for v in r_dict.values()):
                                parsed_rows.append(r_dict)
                        if parsed_rows:
                            return parsed_rows
                except Exception:
                    continue
    except Exception as exc:
        logger.info(f"[Import] pandas read_csv fallback failed: {exc}")

    return None


def _apply_mapping(raw_row: dict, column_mapping: dict, default_mapping: dict) -> dict:
    """Map raw CSV column names to Lead field names."""
    result = {}

    if column_mapping:
        # User-configured explicit mapping
        for lead_field, csv_col in column_mapping.items():
            result[lead_field] = raw_row.get(csv_col, "")
    else:
        # Auto-detect by normalizing column names
        normalized_row = {k.lower().strip(): v for k, v in raw_row.items()}
        for lead_field, aliases in default_mapping.items():
            for alias in aliases:
                if alias in normalized_row:
                    result[lead_field] = normalized_row[alias]
                    break

    return result


def _note_progress(job, row_idx: int):
    """
    Record how far the import has got, writing the job row every 100 rows.

    Duplicate rows used to save the job one at a time, so re-importing a
    50,000-row file meant 50,000 extra UPDATEs.
    """
    job.processed_rows = row_idx - 1
    if job.processed_rows % 100 == 0:
        job.save(update_fields=["processed_rows"])


def _merge_row_into_queued(lead: "Lead", extra: dict, row: dict, custom_field_by_key: dict):
    """
    Fold a later row for the same new number into the lead queued for it.

    The same rule as _update_lead_from_row: fill a blank, never overwrite.
    """
    for field in ("email", "city", "requirement"):
        value = (row.get(field) or "").strip()
        if value and not getattr(lead, field):
            setattr(lead, field, value.lower() if field == "email" else value)
    for field, value in _extract_custom_values(row, custom_field_by_key).items():
        extra["custom"].setdefault(field, value)
    note = (row.get("notes") or "").strip()
    if note:
        extra["note"] = f"{extra['note']}\n{note}" if extra["note"] else note


def _update_lead_from_row(lead: "Lead", row: dict, job: "LeadImportJob"):
    """Update an existing lead from import row data (duplicate update mode)."""
    from apps.leads.models import CustomField, CustomFieldValue

    update_fields = []
    if row.get("email") and not lead.email:
        lead.email = row["email"].strip().lower()
        update_fields.append("email")
    if row.get("city") and not lead.city:
        lead.city = row["city"].strip()
        update_fields.append("city")
    if row.get("requirement") and not lead.requirement:
        lead.requirement = row["requirement"].strip()
        update_fields.append("requirement")
    if update_fields:
        lead.save(update_fields=update_fields)

    # Same rule as the standard columns above: fill a blank, never overwrite a
    # value someone already entered in the CRM.
    custom_field_by_key = {
        cf.field_key: cf for cf in CustomField.objects.filter(is_active=True)
    }
    for field, value in _extract_custom_values(row, custom_field_by_key).items():
        CustomFieldValue.objects.get_or_create(
            lead=lead, field=field, defaults={"value": value},
        )


def _extract_custom_values(row: dict, custom_field_by_key: dict) -> dict:
    """
    Pull the mapped custom-field cells out of one import row.

    The import preview offers custom fields to the mapping UI as
    "custom_<field_key>", so that prefix is the contract between the two —
    anything else in the row is a standard Lead column handled by the caller.
    Returns {CustomField: value}, skipping blanks and keys with no live field
    (a field deleted between choosing the mapping and running the import).
    """
    out = {}
    for key, raw in row.items():
        if not key.startswith("custom_"):
            continue
        value = str(raw).strip() if raw is not None else ""
        if not value:
            continue
        if field := custom_field_by_key.get(key[len("custom_"):]):
            out[field] = value
    return out


# ============================================================
# Lead Scoring
# ============================================================

@shared_task(base=TenantAwareTask, bind=True)
def recalculate_lead_scores(self, schema_name: str):
    """
    Recalculate lead quality scores for all active leads.
    Scoring factors:
    - Has phone: +20
    - Has email: +10
    - Has budget set: +15
    - Has requirement: +10
    - Source quality: +0-20 (IndiaMART/Meta > manual > others)
    - Follow-up completed: +10 per completed (max 20)
    - Response rate: +0-15
    - Days old penalty: -1 per 7 days (max -30)
    """
    from apps.leads.models import Lead, FollowUp
    from apps.core.constants import LeadSource, LeadStatus

    EXCLUDED_STATUSES = [LeadStatus.WON, LeadStatus.LOST, LeadStatus.NOT_INTERESTED, LeadStatus.INVALID]
    SOURCE_SCORES = {
        LeadSource.INDIAMART: 20,
        LeadSource.META_FACEBOOK: 18,
        LeadSource.GOOGLE_ADS: 18,
        LeadSource.WEBSITE: 15,
        LeadSource.REFERRAL: 20,
        LeadSource.MANUAL: 10,
    }

    active_leads = Lead.objects.filter(
        is_deleted=False
    ).exclude(status__in=EXCLUDED_STATUSES)

    update_list = []
    for lead in active_leads.iterator(chunk_size=200):
        score = 0
        if lead.phone:
            score += 20
        if lead.email:
            score += 10
        if lead.budget:
            score += 15
        if lead.requirement:
            score += 10
        score += SOURCE_SCORES.get(lead.source, 5)
        completed_fus = FollowUp.objects.filter(lead=lead, is_completed=True).count()
        score += min(20, completed_fus * 10)
        days_old = (timezone.now() - lead.created_at).days
        score -= min(30, (days_old // 7))

        lead.score = max(0, min(100, score))
        update_list.append(lead)

        if len(update_list) >= 500:
            Lead.objects.bulk_update(update_list, ["score"])
            update_list = []

    if update_list:
        Lead.objects.bulk_update(update_list, ["score"])

    logger.info(f"[Task] Lead scores updated for {schema_name}")


# ============================================================
# Follow-up Reminder
# ============================================================

@shared_task(base=TenantAwareTask, bind=True, max_retries=2)
def send_followup_reminders_for_tenant(self, schema_name: str):
    """
    Find all follow-ups due in the next 30 minutes and send reminders.
    Called from apps.authentication.tasks.dispatch_followup_reminders.
    """
    from datetime import timedelta
    from apps.authentication.notifications import followup_due
    from apps.leads.models import FollowUp

    now = timezone.now()
    # Small enough that a reminder lands on time rather than half an hour
    # early. It was 30 minutes because the dispatcher ran once a day and the
    # window was the only thing catching anything at all.
    window_end = now + timedelta(minutes=6)
    # How far back to look for follow-ups whose moment passed unannounced.
    # The old filter was `scheduled_at >= now`, so anything that came due
    # while the worker was down, or between two runs, was never mentioned
    # again — reminder_sent stayed False and the window had moved past it.
    # A day is long enough to cover an outage and short enough that nobody is
    # woken by last week's backlog.
    lookback = now - timedelta(hours=24)

    from apps.leads.followup_rules import deliverable

    # deliverable(): never for a deleted lead, a deactivated agent, or an
    # agent the lead has since been taken away from.
    due_followups = deliverable(FollowUp.objects.filter(
        is_completed=False,
        reminder_sent=False,
        scheduled_at__gte=lookback,
        scheduled_at__lte=window_end,
    )).select_related("lead", "assigned_to")

    notified = 0
    skipped = 0
    for fu in due_followups:
        if not fu.assigned_to_id:
            # Nobody to tell. Leave reminder_sent alone so it is picked up if
            # the lead is assigned later.
            skipped += 1
            continue
        try:
            # notify() stores the row first, then pushes. The previous version
            # only pushed down a WebSocket, so a reminder for an agent who was
            # not connected at that second was lost with nothing recorded.
            followup_due(fu, overdue=fu.scheduled_at < now)
            fu.reminder_sent = True
            fu.reminder_sent_at = now
            fu.save(update_fields=["reminder_sent", "reminder_sent_at"])
            notified += 1
        except Exception as exc:
            # Deliberately leave reminder_sent False so the next run retries.
            logger.warning(f"[Task] Reminder failed for follow-up {fu.pk}: {exc}")

    logger.info(
        f"[Task] Follow-up reminders sent: {notified} "
        f"({skipped} unassigned) in {schema_name}"
    )
    return {"notified": notified, "skipped_unassigned": skipped}


# ============================================================
# Overdue Follow-up Chaser
# ============================================================

# How long an overdue follow-up keeps being chased. Past this it is not a
# reminder any more, it is noise, and the follow-up needs a person rather
# than another notification.
OVERDUE_CHASE_HOURS = 72


@shared_task(base=TenantAwareTask, bind=True, max_retries=2)
def chase_overdue_followups_for_tenant(self, schema_name: str):
    """
    Nudge once an hour about follow-ups that came due and were not dealt with.

    send_followup_reminders_for_tenant fires once per follow-up and then sets
    reminder_sent, which is right for the reminder itself and useless
    afterwards: a follow-up that is now four hours late has already had its
    one notification and will never be mentioned again.

    Deduplication is by looking at what was already sent rather than by adding
    a column: if this follow-up produced an overdue notification inside the
    last hour, leave it alone. That keeps the hourly cadence even when the
    beat schedule fires late or the task is run by hand.
    """
    from datetime import timedelta

    from apps.authentication.models import Notification, NotificationKind
    from apps.authentication.notifications import followup_due
    from apps.leads.models import FollowUp

    now = timezone.now()
    cutoff = now - timedelta(hours=OVERDUE_CHASE_HOURS)
    last_hour = now - timedelta(minutes=59)

    from apps.leads.followup_rules import deliverable

    overdue = deliverable(FollowUp.objects.filter(
        is_completed=False,
        scheduled_at__lt=now,
        scheduled_at__gte=cutoff,
        assigned_to__isnull=False,
    )).select_related("lead", "assigned_to")

    # One query for everything already chased this hour, rather than one per
    # follow-up. A busy tenant can easily have hundreds overdue.
    recently_chased = set(
        Notification.objects.filter(
            kind=NotificationKind.FOLLOWUP_OVERDUE,
            created_at__gte=last_hour,
            followup_id_ref__isnull=False,
        ).values_list("followup_id_ref", flat=True)
    )

    chased = 0
    for fu in overdue:
        if fu.pk in recently_chased:
            continue
        try:
            followup_due(fu, overdue=True)
            chased += 1
        except Exception as exc:
            logger.warning(f"[Task] Overdue chase failed for follow-up {fu.pk}: {exc}")

    logger.info(
        f"[Task] Overdue follow-ups chased: {chased} "
        f"of {overdue.count()} open in {schema_name}"
    )
    return {"chased": chased}


# ============================================================
# Data Retention Cleanup
# ============================================================

@shared_task(base=TenantAwareTask, bind=True)
def cleanup_old_leads(self, schema_name: str, retention_days: int):
    """
    Archive (soft-delete) leads older than the plan's data retention period.
    Called monthly for each tenant with their plan's retention_days.
    """
    from datetime import timedelta
    from apps.leads.models import Lead

    cutoff = timezone.now() - timedelta(days=retention_days)
    expiring = Lead.objects.filter(created_at__lt=cutoff, is_deleted=False)
    batch_ids = set(expiring.values_list("batch_id", flat=True).distinct())
    count = expiring.update(is_deleted=True)

    from apps.leads.models import LeadBatch

    LeadBatch.recount_ids(batch_ids)

    logger.info(
        f"[Task] Data retention: archived {count} leads in {schema_name} "
        f"(retention: {retention_days} days)"
    )
    return {"archived": count}


@shared_task(base=PublicSchemaTask, bind=True)
def dispatch_lead_score_recalculation(self):
    """Beat dispatcher: trigger lead score recalculation for every tenant."""
    from apps.core.utils import get_all_tenant_schemas
    schemas = get_all_tenant_schemas()
    for schema_name in schemas:
        recalculate_lead_scores.apply_async(args=[schema_name], queue="default")
    return {"dispatched": len(schemas)}
