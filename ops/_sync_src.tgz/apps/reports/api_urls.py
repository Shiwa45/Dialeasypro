"""TeleCRM Backend — apps/reports/api_urls.py"""
from django.urls import path
from apps.reports.views import (
    AgentPerformanceReportView, LeadSourceReportView,
    CallAnalyticsReportView, ConversionFunnelView, DailyActivityView, AgentOutcomeReportView,
    AgentLoginReportView, MyPerformanceView,
)

urlpatterns = [
    path("agent-performance/", AgentPerformanceReportView.as_view(), name="api_report_agent"),
    path("lead-sources/", LeadSourceReportView.as_view(), name="api_report_sources"),
    path("call-analytics/", CallAnalyticsReportView.as_view(), name="api_report_calls"),
    path("conversion-funnel/", ConversionFunnelView.as_view(), name="api_report_funnel"),
    path("agent-outcomes/", AgentOutcomeReportView.as_view(), name="api_report_agent_outcomes"),
    path("daily-activity/", DailyActivityView.as_view(), name="api_report_daily"),
    path("agent-login/", AgentLoginReportView.as_view(), name="api_report_agent_login"),
    path("my-performance/", MyPerformanceView.as_view(), name="api_report_my_performance"),
]
