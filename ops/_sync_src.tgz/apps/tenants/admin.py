"""
TeleCRM Backend — apps/tenants/admin.py

Django Admin (Unfold-themed) for Tenant and Domain management.
Accessible only to Django superusers at /superadmin/
"""
from django.conf import settings
from django.contrib import admin
from django.db.models import Count, Q
from django.utils import timezone
from django.utils.html import format_html
from unfold.admin import ModelAdmin, TabularInline
from unfold.decorators import action, display

from apps.core.constants import SubscriptionStatus
from apps.tenants.models import Domain, Tenant


class DomainInline(TabularInline):
    """Show domains inline within Tenant detail view."""

    model = Domain
    extra = 1
    fields = ("domain", "is_primary")
    show_change_link = True


@admin.register(Tenant)
class TenantAdmin(ModelAdmin):
    """
    Full Tenant management in the super admin panel.
    Supports bulk suspend/activate and plan assignment.
    """

    list_display = [
        "company_name_display",
        "schema_name",
        "primary_contact_email",
        "subscription_status_badge",
        "plan_name",
        "agent_cap",
        "total_agents",
        "total_leads",
        "trial_days_left",
        "is_active_badge",
        "created_at",
    ]
    list_filter = [
        "subscription_status",
        "is_active",
        "industry",
        "plan",
        "onboarding_completed",
    ]
    search_fields = [
        "company_name",
        "schema_name",
        "primary_contact_email",
        "primary_contact_phone",
        "gstin",
    ]
    readonly_fields = [
        "import_fields_link",
        "created_at",
        "updated_at",
        "total_agents",
        "total_leads",
        "total_calls_today",
    ]

    def get_readonly_fields(self, request, obj=None):
        base = list(super().get_readonly_fields(request, obj))
        if obj is not None:
            # schema_name must not change after creation (would break PG schema)
            base.append("schema_name")
        return base

    def get_form(self, request, obj=None, change=False, **kwargs):
        form = super().get_form(request, obj, change=change, **kwargs)
        field = form.base_fields.get("plan")
        if field is not None:
            # Retired plans ("Inactive plans cannot be selected") were still
            # offered here. A tenant already on one keeps it in the list, so
            # its page still saves.
            from apps.plans.models import Plan

            keep = Q(is_active=True)
            if obj is not None and obj.plan_id:
                keep |= Q(pk=obj.plan_id)
            field.queryset = Plan.objects.filter(keep).order_by("sort_order")
        return form
    ordering = ["-created_at"]
    inlines = [DomainInline]
    actions = [
        "suspend_tenants", "activate_tenants", "reset_trial", "sync_subscriptions", "send_welcome_emails",
        "grant_hrms", "grant_erp_sales", "grant_recruitment", "grant_ai_suite",
        "revoke_hrms", "revoke_erp_sales", "revoke_recruitment", "revoke_ai_suite",
    ]

    def get_urls(self):
        from django.urls import path

        return [
            path(
                "<int:tenant_id>/import-fields/",
                self.admin_site.admin_view(self.import_fields_view),
                name="tenants_tenant_import_fields",
            ),
            *super().get_urls(),
        ]

    @display(description="Import fields")
    def import_fields_link(self, obj):
        from django.urls import reverse

        # The add form has no tenant yet, and reversing with pk=None crashed
        # it with a 500. The fields can be edited once the tenant is saved.
        if obj is None or obj.pk is None:
            return "Save the tenant first"
        url = reverse("admin:tenants_tenant_import_fields", args=[obj.pk])
        return format_html('<a class="button" href="{}">Edit fields</a>', url)

    def import_fields_view(self, request, tenant_id):
        """
        The spreadsheet columns one client may map onto, edited from the
        platform panel rather than by the client.

        CustomField lives in the TENANT schema, which Django admin never
        enters on its own — hence schema_context around every read and write.
        """
        from django.contrib import messages
        from django.shortcuts import get_object_or_404, redirect, render
        from django.utils.text import slugify
        from django_tenants.utils import schema_context

        from apps.leads.models import CustomField
        from apps.tenants.models import Tenant

        tenant = get_object_or_404(Tenant, pk=tenant_id)

        if request.method == "POST":
            action = request.POST.get("action")
            if action == "lead_form":
                # Tenant is in the public schema — no schema_context needed.
                tenant.lead_form_settings = {
                    key: {
                        "show": bool(request.POST.get(f"{key}_show")),
                        "label": (request.POST.get(f"{key}_label") or "").strip()[:40],
                    }
                    for key in Tenant.LEAD_FORM_FIELDS
                }
                tenant.save(update_fields=["lead_form_settings"])
                messages.success(request, f"Lead form updated for {tenant.company_name}.")
                return redirect("admin:tenants_tenant_import_fields", tenant_id=tenant.pk)

            with schema_context(tenant.schema_name):
                if action == "add":
                    name = (request.POST.get("name") or "").strip()[:100]
                    if not name:
                        messages.error(request, "Give the field a label.")
                    else:
                        key = slugify(name).replace("-", "_")[:50] or "field"
                        base, n = key, 2
                        while CustomField.objects.filter(field_key=key).exists():
                            key = f"{base[:47]}_{n}"
                            n += 1
                        field_type = request.POST.get("field_type", "text")
                        # A dropdown with no options renders as an empty
                        # picker in the app — there was no way to give it any.
                        options = [
                            o.strip()[:100]
                            for o in (request.POST.get("options") or "").split(",")
                            if o.strip()
                        ] if field_type == "dropdown" else []
                        CustomField.objects.create(
                            name=name,
                            field_key=key,
                            field_type=field_type,
                            options=options,
                            is_required=bool(request.POST.get("is_required")),
                            sort_order=int(request.POST.get("sort_order") or 0),
                        )
                        messages.success(request, f'Added "{name}" for {tenant.company_name}.')

                elif action in ("toggle", "delete"):
                    field = CustomField.objects.filter(pk=request.POST.get("field_id")).first()
                    if field is None:
                        messages.error(request, "That field no longer exists.")
                    elif action == "toggle":
                        field.is_active = not field.is_active
                        field.save(update_fields=["is_active"])
                        messages.success(
                            request,
                            f'"{field.name}" is now {"active" if field.is_active else "switched off"}.',
                        )
                    else:
                        # Values captured on leads go with it — the confirm in
                        # the template says so before anyone gets here.
                        name = field.name
                        field.delete()
                        messages.success(request, f'Deleted "{name}".')

            return redirect("admin:tenants_tenant_import_fields", tenant_id=tenant.pk)

        with schema_context(tenant.schema_name):
            fields = list(CustomField.objects.order_by("sort_order", "name"))

        return render(request, "admin/tenant_import_fields.html", {
            **self.admin_site.each_context(request),
            "tenant": tenant,
            "fields": fields,
            "field_types": CustomField.FIELD_TYPES,
            "lead_form": [
                {"key": key, **value} for key, value in tenant.lead_form().items()
            ],
            "title": f"Import fields — {tenant.company_name}",
        })

    def save_model(self, request, obj, form, change):
        """
        Save the tenant, then make access, subscription and plan agree.

        Turning a tenant off from this form (unticking "Is active", or setting
        the status to Suspended / Cancelled / Past due / Paused) used to change
        that one field only. The middleware then found the subscription still
        "active" and let everyone in, and saving the plan re-saved that active
        subscription, whose signal flipped the tenant back to "active".
        """
        before = (
            Tenant.objects.filter(pk=obj.pk).values("is_active", "subscription_status").first()
            if change else None
        )
        super().save_model(request, obj, form, change)
        if obj.schema_name == "public":
            return

        from apps.plans.models import Subscription

        active = SubscriptionStatus.ACTIVE_STATUSES
        blocked = (not obj.is_active) or obj.subscription_status not in active
        was_blocked = bool(before) and (
            not before["is_active"] or before["subscription_status"] not in active
        )

        if blocked:
            fields = []
            if obj.is_active:
                obj.is_active = False
                fields.append("is_active")
            if obj.subscription_status in active:
                obj.subscription_status = SubscriptionStatus.SUSPENDED
                fields.append("subscription_status")
            if not obj.suspension_kind:
                obj.suspension_kind = Tenant.SUSPENDED_ADMIN
                fields.append("suspension_kind")
            if not was_blocked:
                obj.internal_notes += (
                    f"\n[SUSPENDED {timezone.now().date()}] From the tenant form by {request.user.email}"
                )
                fields.append("internal_notes")
            if fields:
                Tenant.objects.filter(pk=obj.pk).update(**{f: getattr(obj, f) for f in fields})
            obj._sync_subscriptions()
        elif was_blocked:
            # Switched back on from the form: same as the Activate action,
            # keeping the status chosen here (Trial or Active).
            Tenant.objects.filter(pk=obj.pk).update(suspension_kind="")
            obj.suspension_kind = ""
            obj._sync_subscriptions(obj.subscription_status)

        if obj.plan:
            # Plan changes go onto the latest subscription with update(), so
            # the subscription→tenant signal can't overwrite the status.
            latest = Subscription.objects.filter(tenant=obj).order_by("-pk").first()
            if latest is None:
                Subscription.objects.create(
                    tenant=obj, plan=obj.plan, status=obj.subscription_status,
                    trial_end=obj.trial_ends_at,
                )
            elif latest.plan_id != obj.plan_id:
                Subscription.objects.filter(pk=latest.pk).update(plan=obj.plan)

        obj.invalidate_access_cache()

    def delete_model(self, request, obj):
        """Delete one tenant — and drop its schema (Tenant.delete)."""
        obj.delete()

    def delete_queryset(self, request, queryset):
        """
        "Delete selected tenants" called QuerySet.delete(), which skips
        Tenant.delete() — so the schema was never dropped. One at a time.
        """
        for tenant in queryset.exclude(schema_name="public"):
            tenant.delete()

    @action(description="Sync Plan to Subscription table")
    def sync_subscriptions(self, request, queryset):
        """Forces the Subscription table to match the Tenant's assigned Plan."""
        from apps.plans.models import Subscription
        from apps.core.middleware import TenantFeatureFlagMiddleware
        
        count = 0
        for tenant in queryset.exclude(schema_name="public"):
            if not tenant.plan:
                continue
                
            sub = Subscription.objects.filter(
                tenant=tenant, 
                status__in=SubscriptionStatus.ACTIVE_STATUSES
            ).first()
            
            if sub:
                # update(): saving it re-ran the signal that copies the
                # subscription's status onto the tenant.
                Subscription.objects.filter(pk=sub.pk).update(plan=tenant.plan)
            elif tenant.can_use_platform:
                # A suspended tenant gets no new usable subscription here.
                Subscription.objects.create(
                    tenant=tenant,
                    plan=tenant.plan,
                    status=tenant.subscription_status,
                    trial_end=tenant.trial_ends_at
                )
            
            TenantFeatureFlagMiddleware.invalidate_cache(tenant.schema_name)
            count += 1
            
        self.message_user(request, f"✅ Synced subscriptions for {count} tenant(s).")

    @action(description="Send / Resend Welcome Email")
    def send_welcome_emails(self, request, queryset):
        """
        Manually trigger the welcome email for selected tenants.
        If an admin agent already exists, resets their password to a new temporary one
        (only if they haven't set their own password yet, i.e. must_change_password=True).
        """
        from apps.tenants.signals import _create_default_tenant_admin, _generate_temp_password
        from apps.tenants.tasks import send_tenant_welcome_email
        from django.db import connection
        from django.contrib import messages
        
        count = 0
        for tenant in queryset.exclude(schema_name="public"):
            if not tenant.primary_contact_email:
                continue
                
            previous_schema = connection.schema_name
            temp_password = None
            
            try:
                connection.set_schema(tenant.schema_name)
                from apps.authentication.models import Agent
                
                admin_agent = Agent.objects.filter(is_tenant_admin=True).first()
                temp_password = getattr(settings, "DEFAULT_TENANT_PASSWORD", "Admin@123456")
                if not admin_agent:
                    # Admin doesn't exist, create it
                    _create_default_tenant_admin(tenant)
                elif admin_agent.must_change_password:
                    # Still on the first-login password: re-issue it.
                    admin_agent.set_password(temp_password)
                    admin_agent.save(update_fields=["password"])
                else:
                    # They have set their own password. Resending used to
                    # reset it to the default — locking a working admin out
                    # and putting a well-known password on the account.
                    temp_password = ""

                # Queue the email
                send_tenant_welcome_email.apply_async(
                    kwargs={
                        "tenant_id": tenant.pk,
                        "temp_password": temp_password,
                    },
                    queue="notifications",
                )
                count += 1
                        
            except Exception as e:
                self.message_user(request, f"❌ Failed to process {tenant.schema_name}: {e}", level=messages.ERROR)
                continue
            finally:
                connection.set_schema(previous_schema)
            
        self.message_user(request, f"✅ Queued welcome emails for {count} tenant(s).", level=messages.SUCCESS)

    fieldsets = (
        (
            "Company Information",
            {
                "fields": (
                    "company_name",
                    "schema_name",
                    "industry",
                    "gstin",
                    "logo",
                )
            },
        ),
        (
            "Billing Address",
            {
                "fields": ("billing_address", "city", "state", "pincode"),
                "classes": ("collapse",),
            },
        ),
        (
            "Primary Contact",
            {
                "fields": (
                    "primary_contact_name",
                    "primary_contact_email",
                    "primary_contact_phone",
                )
            },
        ),
        (
            "Plan & Subscription",
            {
                "fields": (
                    "plan",
                    "max_agents_override",
                    "subscription_status",
                    "trial_ends_at",
                    "is_active",
                )
            },
        ),
        (
            "Onboarding",
            {
                "fields": ("onboarding_completed", "onboarding_step"),
                "classes": ("collapse",),
            },
        ),
        (
            "Branding",
            {
                "fields": ("primary_color", "custom_domain"),
                "classes": ("collapse",),
            },
        ),
        (
            "Locale",
            {
                "fields": ("timezone", "language_preference"),
                "classes": ("collapse",),
            },
        ),
        (
            "Lead import fields",
            {
                "fields": ("import_fields_link",),
                "description": (
                    "The spreadsheet columns this client can map onto, on top of the "
                    "standard ones. Only this panel can change them."
                ),
            },
        ),
        (
            "Usage Statistics",
            {
                "fields": ("total_agents", "total_leads", "total_calls_today"),
                "classes": ("collapse",),
            },
        ),
        (
            "Internal Notes",
            {
                "fields": ("internal_notes",),
                "classes": ("collapse",),
            },
        ),
        (
            "Timestamps",
            {
                "fields": ("created_at", "updated_at"),
                "classes": ("collapse",),
            },
        ),
    )

    # ---- Custom Display Columns ----------------------------

    @display(description="Company", ordering="company_name")
    def company_name_display(self, obj):
        return format_html(
            '<strong>{}</strong><br><small style="color:#888">{}</small>',
            obj.company_name,
            obj.schema_name,
        )

    @display(description="Status", ordering="subscription_status")
    def subscription_status_badge(self, obj):
        colors = {
            SubscriptionStatus.TRIAL: "#F59E0B",
            SubscriptionStatus.ACTIVE: "#10B981",
            SubscriptionStatus.PAST_DUE: "#EF4444",
            SubscriptionStatus.PAUSED: "#6B7280",
            SubscriptionStatus.CANCELLED: "#EF4444",
            SubscriptionStatus.SUSPENDED: "#DC2626",
        }
        color = colors.get(obj.subscription_status, "#6B7280")
        return format_html(
            '<span style="background:{};color:#fff;padding:2px 8px;'
            'border-radius:4px;font-size:11px;font-weight:600">{}</span>',
            color,
            obj.get_subscription_status_display(),
        )

    @display(description="Plan")
    def plan_name(self, obj):
        if obj.plan:
            return obj.plan.name
        return format_html('<span style="color:#9CA3AF">—</span>')

    @display(description="Agent Cap")
    def agent_cap(self, obj):
        """
        The seat limit this tenant is actually held to, and where it comes
        from. A super admin raising a cap needs to see at a glance whether
        this customer is on the plan's number or their own.
        """
        limit = obj.agent_limit()
        if limit is None:
            return format_html('<span style="color:#9CA3AF">unlimited</span>')

        if obj.max_agents_override is not None:
            return format_html(
                '<span style="font-weight:600">{}</span>'
                '<span style="color:#F59E0B"> override</span>',
                limit,
            )
        return format_html('<span>{}</span>', limit)

    @display(description="Trial Days")
    def trial_days_left(self, obj):
        if not obj.is_trial:
            return "—"
        days = obj.trial_days_remaining
        color = "#EF4444" if days <= 3 else "#F59E0B" if days <= 7 else "#10B981"
        return format_html(
            '<span style="color:{};font-weight:600">{} days</span>', color, days
        )

    @display(description="Active", boolean=True)
    def is_active_badge(self, obj):
        return obj.is_active

    # ---- Bulk Actions --------------------------------------

    @action(description="Suspend selected tenants")
    def suspend_tenants(self, request, queryset):
        count = 0
        for tenant in queryset.exclude(schema_name="public"):
            tenant.suspend(reason=f"Suspended by super admin: {request.user.email}")
            count += 1
        self.message_user(request, f"✅ {count} tenant(s) suspended.")

    @action(description="Activate selected tenants")
    def activate_tenants(self, request, queryset):
        count = 0
        for tenant in queryset.exclude(schema_name="public"):
            tenant.activate()
            count += 1
        self.message_user(request, f"✅ {count} tenant(s) activated.")

    @action(description="Reset trial (14 days)")
    def reset_trial(self, request, queryset):
        count = 0
        for tenant in queryset.exclude(schema_name="public"):
            tenant.set_trial(days=14)
            count += 1
        self.message_user(request, f"✅ Trial reset for {count} tenant(s).")

    # ---- Add-on modules -------------------------------------------
    # One click per company instead of one Tenant Entitlement row per feature
    # (5 for HRMS, 5 for Sales & Billing, 4 for Recruitment): a row left out
    # left one screen of the module locked.

    def _grant(self, request, queryset, module):
        from apps.core.constants import ModuleKey
        from apps.plans.models import TenantEntitlement

        label = dict(ModuleKey.CHOICES).get(module, module)
        names = []
        for tenant in queryset.exclude(schema_name="public"):
            TenantEntitlement.grant_module(tenant, module, note=f"Granted by {request.user}")
            names.append(tenant.company_name or tenant.schema_name)
        self.message_user(request, f"✅ {label} add-on switched on for: {', '.join(names) or 'nobody'}.")

    def _revoke(self, request, queryset, module):
        from apps.core.constants import ModuleKey
        from apps.plans.models import TenantEntitlement

        label = dict(ModuleKey.CHOICES).get(module, module)
        names = []
        for tenant in queryset.exclude(schema_name="public"):
            if TenantEntitlement.revoke_module(tenant, module):
                names.append(tenant.company_name or tenant.schema_name)
        self.message_user(
            request,
            f"{label} add-on removed from: {', '.join(names)}. Their plan's own features are unchanged."
            if names else f"None of the selected tenants had the {label} add-on.",
        )

    @action(description="Add-on: switch on HRMS")
    def grant_hrms(self, request, queryset):
        self._grant(request, queryset, "hrms")

    @action(description="Add-on: switch on Sales & Billing (ERP)")
    def grant_erp_sales(self, request, queryset):
        self._grant(request, queryset, "erp_sales")

    @action(description="Add-on: switch on Recruitment")
    def grant_recruitment(self, request, queryset):
        self._grant(request, queryset, "recruitment")

    @action(description="Add-on: switch on AI Suite")
    def grant_ai_suite(self, request, queryset):
        self._grant(request, queryset, "ai_suite")

    @action(description="Add-on: remove HRMS")
    def revoke_hrms(self, request, queryset):
        self._revoke(request, queryset, "hrms")

    @action(description="Add-on: remove Sales & Billing (ERP)")
    def revoke_erp_sales(self, request, queryset):
        self._revoke(request, queryset, "erp_sales")

    @action(description="Add-on: remove Recruitment")
    def revoke_recruitment(self, request, queryset):
        self._revoke(request, queryset, "recruitment")

    @action(description="Add-on: remove AI Suite")
    def revoke_ai_suite(self, request, queryset):
        self._revoke(request, queryset, "ai_suite")

    def get_queryset(self, request):
        return (
            super()
            .get_queryset(request)
            .exclude(schema_name="public")
            .select_related("plan")
        )


@admin.register(Domain)
class DomainAdmin(ModelAdmin):
    """Manage domain-to-tenant mappings."""

    list_display = ["domain", "tenant_name", "is_primary"]
    list_filter = ["is_primary"]
    search_fields = ["domain", "tenant__company_name", "tenant__schema_name"]
    raw_id_fields = ["tenant"]

    @display(description="Tenant")
    def tenant_name(self, obj):
        return obj.tenant.company_name
