import 'package:dio/dio.dart';
import '../../core/services/tenant_config.dart';
import '../../core/services/token_store.dart';

/// How a token refresh ended. Only [rejected] ends the session.
enum _Refresh { ok, rejected, unreachable }

class ApiClient {
  ApiClient._();
  static final ApiClient instance = ApiClient._();

  // JWT tokens: encrypted at rest, see TokenStore.
  TokenStore get _tokens => TokenStore.instance;

  late final Dio _dio;
  bool _initialized = false;

  /// Called when the session can't be recovered (refresh failed / expired).
  /// The app wires this to log out + route to the login screen so the user
  /// gets a clean re-login instead of a raw 401 error.
  static void Function()? onSessionExpired;

  /// Called when the server answers 403 plan_expired / account_suspended:
  /// the company's plan ran out or the platform owner suspended it, so every
  /// request is refused. The app signs out and shows the message on the
  /// login screen instead of failing request by request.
  static void Function(String message)? onPlanExpired;

  // Single-flight refresh: concurrent 401s share ONE refresh call instead of
  // each firing their own (which races and can spuriously fail).
  Future<_Refresh>? _refreshing;

  Dio get dio {
    if (!_initialized) init();
    return _dio;
  }

  void init() {
    if (_initialized) return;
    _initialized = true;
    _dio = Dio(BaseOptions(
      // baseUrl is set per-request below from TenantConfig, allowing
      // workspace switches without recreating the client.
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 30),
      headers: {'Content-Type': 'application/json'},
    ));

    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        // Resolve tenant URL dynamically
        final tenantBase = TenantConfig.instance.apiBaseUrl;
        options.baseUrl = '$tenantBase/api/v1';
        _applyTenantHeaders(options.headers);

        // JWT
        final token = await _tokens.access;
        if (token != null) {
          options.headers['Authorization'] = 'Bearer $token';
        }

        handler.next(options);
      },
      onError: (error, handler) async {
        // Don't try to refresh on the auth endpoints themselves.
        final path = error.requestOptions.path;
        final isAuthCall = path.contains('/auth/refresh/') || path.contains('/auth/login/');

        // The login screen shows this refusal itself; anywhere else the whole
        // app is locked out until the account is renewed.
        if (error.response?.statusCode == 403 && !isAuthCall) {
          final data = error.response?.data;
          final code = data is Map ? data['error'] : null;
          if (code == 'plan_expired' || code == 'account_suspended') {
            final msg = (data as Map)['message'];
            try {
              onPlanExpired?.call(msg is String && msg.isNotEmpty
                  ? msg
                  : 'Your plan has expired. Please contact support to renew your account.');
            } catch (_) {}
          }
        }

        if (error.response?.statusCode == 401 && !isAuthCall) {
          final outcome = await _tryRefresh();
          if (outcome == _Refresh.ok) {
            final token = await _tokens.access;
            error.requestOptions.headers['Authorization'] = 'Bearer $token';
            try {
              final retry = await _dio.fetch(error.requestOptions);
              return handler.resolve(retry);
            } on DioException catch (retryError) {
              // The session is fine — the refresh just worked. Whatever the
              // retry failed with (a 500, a 403, a dropped connection) is that
              // request's problem, not a reason to sign the agent out. This
              // used to fall through to clearTokens() below.
              return handler.next(retryError);
            }
          }
          if (outcome == _Refresh.rejected) {
            // The server refused the refresh token itself: expired, revoked or
            // the agent was deactivated. Only then is the session over.
            await clearTokens();
            try {
              onSessionExpired?.call();
            } catch (_) {}
          }
          // _Refresh.unreachable: no network, or the server hiccuped. Keep the
          // session and let this request fail; the next one will refresh.
          // Treating this as an expired session is what signed agents out
          // every time the phone lost signal.
        }
        handler.next(error);
      },
    ));
  }

  Future<_Refresh> _tryRefresh() {
    // Reuse an in-flight refresh if one is already running.
    return _refreshing ??= _doRefresh().whenComplete(() => _refreshing = null);
  }

  Future<_Refresh> _doRefresh() async {
    final refresh = await _tokens.refresh;
    if (refresh == null) return _Refresh.rejected;
    try {
      final tenantBase = TenantConfig.instance.apiBaseUrl;
      final headers = <String, dynamic>{'Content-Type': 'application/json'};
      _applyTenantHeaders(headers);
      final res = await Dio().post(
        '$tenantBase/api/v1/auth/refresh/',
        data: {'refresh': refresh},
        options: Options(headers: headers),
      );
      final access = res.data['access'] as String?;
      // Backend may or may not rotate the refresh token; keep the old one if absent.
      final newRefresh = (res.data['refresh'] as String?) ?? refresh;
      if (access == null) return _Refresh.unreachable;
      await saveTokens(access: access, refresh: newRefresh);
      return _Refresh.ok;
    } on DioException catch (e) {
      // 400/401 from the refresh endpoint means the token itself was refused.
      // Anything else — no response, a timeout, a 5xx — says nothing about the
      // session.
      final code = e.response?.statusCode;
      return (code == 400 || code == 401) ? _Refresh.rejected : _Refresh.unreachable;
    } catch (_) {
      return _Refresh.unreachable;
    }
  }

  Future<void> saveTokens({required String access, required String refresh}) =>
      _tokens.save(access: access, refresh: refresh);

  Future<void> clearTokens() => _tokens.clear();

  Future<String?> get accessToken => _tokens.access;

  /// Probe the current tenant URL. Returns null on success, error message on failure.
  Future<String?> testTenantConnection() async {
    try {
      final base = TenantConfig.instance.apiBaseUrl;
      final headers = <String, dynamic>{};
      _applyTenantHeaders(headers);
      final probe = await Dio(BaseOptions(
        connectTimeout: const Duration(seconds: 10),
        receiveTimeout: const Duration(seconds: 10),
      )).get('$base/api/v1/auth/tenant-info/',
          options: Options(
            headers: headers,
            validateStatus: (s) => s != null && s < 500,
          ));
      if (probe.statusCode == null || probe.statusCode! >= 500) {
        return 'Server error (HTTP ${probe.statusCode}). Check the workspace URL.';
      }
      return null;
    } on DioException catch (e) {
      if (e.type == DioExceptionType.connectionTimeout || e.type == DioExceptionType.receiveTimeout) {
        return 'Connection timed out. Check your internet & workspace URL.';
      }
      if (e.type == DioExceptionType.connectionError) {
        return 'Cannot reach this workspace. Verify the spelling.';
      }
      if (e.response?.statusCode == 404) {
        return 'Workspace not found. Double-check the name.';
      }
      return 'Connection failed: ${e.message ?? e.type.name}';
    } catch (e) {
      return 'Unexpected error: $e';
    }
  }

  /// A message worth showing the user.
  ///
  /// DRF reports a rejected save as {"field": ["reason"]} — not as `message`
  /// or `detail`. Reading only those two keys turned every validation failure
  /// into a blank "An error occurred", which is how a mobile form that sent an
  /// invalid choice on EVERY submit went unexplained: the server said exactly
  /// what was wrong and the app threw it away. Field errors are named here so
  /// the next mismatch is legible instead of mysterious.
  /// "phone: A lead with this phone number already exists."
  ///
  /// Two entries at most: a toast is not a form, and the first rejection is
  /// almost always the actionable one.
  static String _fieldErrors(Map data, {Set<String> skip = const {}}) {
    final out = <String>[];
    data.forEach((key, value) {
      if (skip.contains(key)) return;
      final text = value is List
          ? value.map((v) => v.toString()).join(' ')
          : value.toString();
      if (text.isEmpty || text == '{}' || text == '[]') return;
      // non_field_errors has no useful label to put in front of it.
      out.add(key == 'non_field_errors' ? text : '$key: $text');
    });
    return out.take(2).join('\n');
  }

  /// Turn an API failure into something worth showing a person.
  ///
  /// The field errors are read FIRST. The backend wraps a 400 as
  ///
  ///   {"error": "validation_error",
  ///    "message": "Validation failed.",
  ///    "detail": {"phone": ["A lead with this phone number already exists."]}}
  ///
  /// and this used to return data['message'] before looking any further — so
  /// every rejected form said "Validation failed." and nothing else. An agent
  /// adding a lead that already existed had no way to find that out, and the
  /// one line that would have told them was sitting in `detail`, unread.
  static String errorMessage(dynamic error) {
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map) {
        // `detail` is a map of field -> messages on a validation error, and a
        // plain string on most other failures. Only the map form is unpacked.
        final detail = data['detail'];
        if (detail is Map) {
          final fields = _fieldErrors(detail);
          if (fields.isNotEmpty) return fields;
        }

        // Field errors sent at the top level rather than under `detail`.
        final topLevel = _fieldErrors(data, skip: const {'error', 'message', 'detail'});
        if (topLevel.isNotEmpty) return topLevel;

        final direct = data['message'] as String? ?? data['detail'] as String?;
        if (direct != null && direct.isNotEmpty) return direct;

        return 'An error occurred.';
      }
      if (error.type == DioExceptionType.connectionTimeout) return 'Connection timeout. Check your internet.';
      if (error.type == DioExceptionType.connectionError) return 'Cannot connect to server. Check workspace URL.';
      if (error.response?.statusCode == 404) return 'Workspace not found or endpoint missing.';
    }
    return 'An unexpected error occurred.';
  }

  void _applyTenantHeaders(Map<String, dynamic> headers) {
    final config = TenantConfig.instance;
    final host = config.tenantHost;
    final workspace = config.workspaceId;
    if (host == null || host.isEmpty) return;

    headers['X-Tenant-Domain'] = host;
    headers['X-Workspace-ID'] = workspace ?? host;

    if (workspace != null && workspace.isNotEmpty) {
      headers['X-Tenant'] = workspace;
      headers['X-Tenant-Schema'] = workspace;
      headers['X-DTS-Schema'] = workspace;
    }

    if (TenantConfig.useLocalApi) {
      headers['Host'] = host;
    }
  }
}
